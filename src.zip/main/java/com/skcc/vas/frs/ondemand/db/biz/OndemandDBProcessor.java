package com.skcc.vas.frs.ondemand.db.biz;

import java.util.List;

import com.skcc.vas.frs.akka.model.OndemandDBSubJob;
import com.skcc.vas.frs.interfaces.activemq.publisher.DetectedFacePublisher;

public interface OndemandDBProcessor {

	public List<OndemandDBSubJob> splitJobs(String jobId, int numOfNode);

	public int search(OndemandDBSubJob subJob, int nodeId, String masterAddress) throws Exception;
	
	public int abort(int nodeId, String masterAddress) throws Exception;

}
