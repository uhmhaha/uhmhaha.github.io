package com.skcc.vas.frs.ondemand.vms.db.rdb.domain;

import javax.validation.constraints.Pattern;

/**
 * @author
 * @since 2015-06-19
 */
public interface SearchCriteria {

	public String getSystemId();

	public String getDeviceId();

	/**
	 * @return string in yyyyMMddHHmm format
	 */
	@Pattern(regexp = "[1-9][0-9]{11}")
	public String getFrom();

	/**
	 * @return string in yyyyMMddHHmm format
	 */
	@Pattern(regexp = "[1-9][0-9]{11}")
	public String getTo();

}
