package com.skcc.vas.frs.ondemand.vms.biz;

import org.hibernate.validator.constraints.NotBlank;

/**
 * @author
 * @since 2016-07-27
 *
 */
public interface SearchProcessor {

	void search(@NotBlank String jobId);

	void stop(@NotBlank Boolean arg0);

	void updStatus(String jobId, String rsltStts);

}
