package com.skcc.vas.frs.ondemand.video.db.rdb.repository;

import java.util.List;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;

@Repository("fileAnalysisResourceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface FileAnalysisResourceMapper {

	@Nullable
	List<FileAnalysisRequest.AnalysisResource> selectFileAnalysisResourcesByJob(@Param("jobId") String jobId);
}
