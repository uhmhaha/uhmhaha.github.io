package com.skcc.vas.frs.ondemand.video.biz;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.Validate;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.ondemand.video.db.rdb.service.FileAnalysisDataManager;
import com.skcc.vas.frs.ondemand.vms.biz.SearchProcessor;

@ThreadSafe
@ParametersAreNonnullByDefault
public abstract class FileAnalysisProcessorBase implements SearchProcessor {

	public static final int UNIT_TIME_DEFAULT = 10;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private final FileAnalysisDataManager fileAnalysisDataManager;

	public FileAnalysisDataManager getFileAnalysisDataManager() {
		return this.fileAnalysisDataManager;
	}

	private final FaceDataManager faceDataMgr;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataMgr;
	}

	public FileAnalysisProcessorBase(@Nonnull FileAnalysisDataManager fileAnalysisDataManager,
			@Nonnull FaceDataManager faceDataMgr) {

		Validate.isTrue(fileAnalysisDataManager != null, "The data accessor for search job should be provided.");
		Validate.isTrue(faceDataMgr != null, "The data accessor for face service should be provided.");

		this.fileAnalysisDataManager = fileAnalysisDataManager;
		this.faceDataMgr = faceDataMgr;
	}
}
