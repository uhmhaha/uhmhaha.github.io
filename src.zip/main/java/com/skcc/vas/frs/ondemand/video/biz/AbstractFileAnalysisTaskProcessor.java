package com.skcc.vas.frs.ondemand.video.biz;

import java.util.TimeZone;

import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.event.EventContext;
import com.skcc.vas.frs.common.util.base.TaskStatus;
import com.skcc.vas.frs.common.util.ondemand.TimeRangeRuler;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;

@ThreadSafe
public abstract class AbstractFileAnalysisTaskProcessor<SC extends AnalysisResource, E extends Event, EC extends EventContext>
		implements
			FileAnalysisProcessor<SC, E, EC> {

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	private String jobId;

	private String taskId;

	private SC analysisRsc;

	private TaskStatus status;

	private TimeRangeRuler timeRangeRuler;

	public AbstractFileAnalysisTaskProcessor(@Min(0) int defaultSkips) {
		Validate.isTrue(defaultSkips >= 0, "Skip number should be non-negative.");

		this.defaultSkips = defaultSkips;

		if (defaultSkips < 5) {
			logger.warn("Skip number {} is too small. It may cause too many duplicated event.", defaultSkips);
		}
	}

	protected void setJobId(String id) {
		this.jobId = id;
	}

	@Override
	@ManagedAttribute
	public String getJobId() {
		return this.jobId;
	}

	protected void setTaskId(String id) {
		this.taskId = id;
	}

	@Override
	@ManagedAttribute
	public String getTaskId() {
		return this.taskId;
	}

	@Override
	public SC getAnalysisRsc() {
		return analysisRsc;
	}

	public void setAnalysisRsc(SC analysisRsc) {
		this.analysisRsc = analysisRsc;
	}

	protected void setStatus(TaskStatus status) {
		this.status = status;
	}

	@Override
	public TaskStatus getStatus() {
		return this.status;
	}

	@Override
	public void setTimeRangeRuler(TimeRangeRuler ruler) {
		this.timeRangeRuler = ruler;
	}

	protected TimeRangeRuler getTimeRangeRuler() {
		return this.timeRangeRuler;
	}

	/**
	 * Default value for the number of frames to skip after an event is
	 * detected.
	 */
	private final int defaultSkips;

	/**
	 * Default value for the number of frames to skip after an event is
	 * detected.
	 * <p>
	 * Later another 'process' method can be added that can control the skips at
	 * request scope.
	 *
	 * @see #defaultSkips
	 */
	@ManagedAttribute
	@Override
	public int getDefaultSkipsAfterDetect() {
		return this.defaultSkips;
	}

	/**
	 * @since 1.0.1
	 */
	private int exceptions = 0;

	/**
	 * @param delta
	 * @since 1.0.1
	 */
	public void addNumberOfExceptions(@Min(0) int delta) {
		this.exceptions = this.exceptions + delta;
	}

	/**
	 * @return
	 * @since 1.0.1
	 */
	@ManagedAttribute
	@Override
	public int getNumberOfExceptions() {
		return this.exceptions;
	}

	/**
	 * TimeZone to handle the event data
	 */
	private TimeZone timeZone = java.util.TimeZone.getDefault();

	/**
	 * Gets time-zone to handle the event data. By default, the default
	 * time-zone for this VM instacne (which can be identified using
	 * {@link java.util.TimeZone#getDefault()}) would be specified for this
	 * instance.
	 *
	 * @return
	 */
	@ManagedAttribute
	public TimeZone getTimeZone() {
		return this.timeZone;
	}

	/**
	 * @param tzId
	 * @see java.util.TimeZone#getTimeZone(String)
	 */
	public void setTimeZoneId(@NotBlank String tzId) {
		TimeZone tz = TimeZone.getTimeZone(tzId);
	}

}
