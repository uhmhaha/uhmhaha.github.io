package com.skcc.vas.frs.ondemand.video.biz;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.Validate;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.skcc.adapter.video.sparser.SParserJNI;
import com.skcc.adapter.vms.incon.FsUtilTypes.DecodeFlag;
import com.skcc.adapter.vms.incon.FsUtilTypes.DecodingMode;
import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiEventContext;

public abstract class AbstractSparserSearchTaskProcessor<SC extends AnalysisResource, E extends Event>
		extends
			AbstractFileAnalysisTaskProcessor<SC, E, TriumiEventContext> {

	/**
	 * Default decoding mode for Trium-i library to use when decoding the video.
	 * You need to set explicitly to use another decoding mode.
	 *
	 * @see #setDecodingMode
	 */
	public final static DecodingMode DEFAULT_DECODING_MODE = DecodingMode.RGB24;

	/**
	 * Default decode flag for Trium-i library to use when decoding the video.
	 * You need to set explicitly to use another decode flag.
	 *
	 * @see #setDecodeFlag
	 */
	public final static DecodeFlag DEFAULT_DECODE_FLAG = DecodeFlag.NONE;

	@Nonnull
	private final FilePreparer filePreparer;

	@Nonnull
	public FilePreparer getFilePreparer() {
		return this.filePreparer;
	}

	@Nonnull
	private final SParserJNI sParserAdapter;

	@Nonnull
	public SParserJNI getSParserJNI() {
		return this.sParserAdapter;
	}

	@Nullable
	private final ThumbnailPersister thumbnailPersister;

	@Nullable
	protected ThumbnailPersister getThumbnailPersister() {
		return this.thumbnailPersister;
	}

	private DecodingMode decodingMode = DEFAULT_DECODING_MODE;

	@ManagedAttribute
	public DecodingMode getDecodingMode() {
		return this.decodingMode;
	}

	public void setDecodingMode(DecodingMode mode) {
		this.decodingMode = mode;
	}

	private DecodeFlag decodeFalg = DEFAULT_DECODE_FLAG;

	@ManagedAttribute
	public DecodeFlag getDecodeFlag() {
		return this.decodeFalg;
	}

	public void setDecodeFlag(DecodeFlag flag) {
		this.decodeFalg = flag;
	}

	public AbstractSparserSearchTaskProcessor(@Nonnull final FilePreparer filePreparer,
			@Nonnull final SParserJNI sparserAdapter, @Nullable ThumbnailPersister thumbPersister, @Min(0) int skips) {
		super(skips);

		// Validate.isTrue(filePreparer != null,
		// "File preparer object for video files should be provided.");
		Validate.isTrue(sparserAdapter != null, "Adapter for Trium i video file utility should be provided.");

		this.filePreparer = filePreparer;
		this.sParserAdapter = sparserAdapter;
		this.thumbnailPersister = thumbPersister;

		if (thumbnailPersister == null) {
			this.logger.warn("Thumbnail persister is not provided. So, no thumbnail would be created.");
		}
	}
}
