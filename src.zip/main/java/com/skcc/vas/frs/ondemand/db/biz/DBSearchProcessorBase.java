package com.skcc.vas.frs.ondemand.db.biz;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.Validate;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.SearchDataManager;

/**
 * @author
 * @since 2016-07-20
 *
 */
@ThreadSafe
@ParametersAreNonnullByDefault
public abstract class DBSearchProcessorBase implements DBSearchProcessor {

	public static final int UNIT_TIME_DEFAULT = 10;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private SearchDataManager searchDataMgr = null;

	protected SearchDataManager getSearchDataManager() {
		return this.searchDataMgr;
	}

	private FaceDataManager faceDataMgr = null;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataMgr;
	}

	public DBSearchProcessorBase(@Nonnull SearchDataManager searchDataMgr, @Nonnull FaceDataManager faceDataMgr) {

		Validate.isTrue(searchDataMgr != null, "The data accessor for search job should be provided.");
		Validate.isTrue(faceDataMgr != null, "The data accessor for face service should be provided.");

		this.searchDataMgr = searchDataMgr;
		this.faceDataMgr = faceDataMgr;
	}

}
