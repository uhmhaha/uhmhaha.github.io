package com.skcc.vas.frs.ondemand.db.biz;

public class DetectedFaceInfo {
	private String systemId;
	private String cctvId;
	private String srvcType;
	private String imgFile;
	private String imgW;
	private String imgH;
	private String imgX;
	private String imgY;
	private String frmFile;
	private String frmW;
	private String frmH;
	private String frmTime;

	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getCctvId() {
		return cctvId;
	}
	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}
	public String getSrvcType() {
		return srvcType;
	}
	public void setSrvcType(String srvcType) {
		this.srvcType = srvcType;
	}
	public String getImgFile() {
		return imgFile;
	}
	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}
	public String getImgW() {
		return imgW;
	}
	public void setImgW(String imgW) {
		this.imgW = imgW;
	}
	public String getImgH() {
		return imgH;
	}
	public void setImgH(String imgH) {
		this.imgH = imgH;
	}
	public String getImgX() {
		return imgX;
	}
	public void setImgX(String imgX) {
		this.imgX = imgX;
	}
	public String getImgY() {
		return imgY;
	}
	public void setImgY(String imgY) {
		this.imgY = imgY;
	}
	public String getFrmFile() {
		return frmFile;
	}
	public void setFrmFile(String frmFile) {
		this.frmFile = frmFile;
	}
	public String getFrmW() {
		return frmW;
	}
	public void setFrmW(String frmW) {
		this.frmW = frmW;
	}
	public String getFrmH() {
		return frmH;
	}
	public void setFrmH(String frmH) {
		this.frmH = frmH;
	}
	public String getFrmTime() {
		return frmTime;
	}
	public void setFrmTime(String frmTime) {
		this.frmTime = frmTime;
	}
}
