package com.skcc.vas.frs.ondemand.video.biz;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.event.EventType;

/**
 * @author
 * @since 2016-07-20
 *
 */
@Immutable
public class StandardEvent implements Event {

	private final EventType type;

	public StandardEvent(@Nonnull EventType type) {
		this.type = type;
	}

	@Override
	public EventType getType() {
		return this.type;
	}

}
