package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Collection;

import javax.annotation.RegEx;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.ondemand.vms.biz.TriumiVideoStore.StoreByDevice;

/**
 * Builds a instance of the immutable
 * {@link com.skcc.nexcore.vas.support.triumi.TriumiVideoStore} class.
 * <p>
 * This class assumes that the Trium-i VMS stores its archived video files into
 * the filesystem like the following directory structure.
 * 
 * <pre>
 * \\triumiserver\\data\video
 *                       |--------00000026
 *                       |--------00000029
 *                       +--------00000030
 * </pre>
 * 
 * @author
 * @since 2015-09-16
 * @see com.skcc.nexcore.vas.support.triumi.TriumiVideoStore
 */
@ThreadSafe
public class TriumiVideoStoreBuilder {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private final File base;

	/**
	 *
	 * @return the canonical absolute pathname for the base directory, or
	 *         {@code null} if a proper base directory is not yet set.
	 */
	public String getBaseDir() {
		String dir = null;
		try {
			dir = this.base.getCanonicalPath();
		} catch (Exception ex) {
			dir = null;
		}

		return dir;
	}

	/**
	 * Regex pattern for the directories for devices which are assumed to be
	 * located right below the base direcotry.
	 * <p>
	 * For example
	 * 
	 * <pre>
	 * \\triumiserver\\data\video
	 *                       |--------00000026
	 *                       |--------00000029
	 *                       +--------00000030
	 * </pre>
	 */
	private final String devDirPattern;

	/**
	 * @return regex pattern for the right subdirectories under the base
	 *         directory
	 */
	public String getSubDirPattern() {
		return this.devDirPattern;
	}

	/**
	 * @param base
	 *            the full path for the base directory of the video store to
	 *            build
	 * @param pattern
	 *            regex pattern for the directories for devices
	 */
	public TriumiVideoStoreBuilder(String base, @NotBlank @RegEx String pattern) {

		// @TODO More robust validation is possible compiling the regex.
		Validate.isTrue(pattern != null && pattern.length() > 0,
				"The pattern for device directory should NOT be blank.");

		this.devDirPattern = pattern;

		File f = new File(base);
		if (!f.exists()) {
			logger.error("The specified base direcotry({}) does NOT exist.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") does NOT exist.");
		} else if (!f.isDirectory()) {
			logger.error("The specified base direcotry({}) is NOT directory.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") is NOT directory.");
		} else if (!f.canRead()) {
			logger.error("The specified base direcotry({}) is NOT readable.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") is NOT readable.");
		} else {
			this.base = f;
		}

	}

	// @NOTE Concurrency should be considered, 'cause build method is kind of
	// lazy initialization.
	public TriumiVideoStore build() {

		Validate.validState(this.base != null, "The base directory should be NON-null at build method.");

		// find right below directories that assumed to be stores by device
		FilenameFilter filter = new AndFileFilter(DirectoryFileFilter.INSTANCE, new RegexFileFilter(this.devDirPattern));
		File[] subdirs = this.base.listFiles(filter);

		this.logger.debug("Found {} subdirectories under {}.", subdirs.length, this.base);

		final StoreByDevice[] substores = new StoreByDevice[subdirs.length];

		String subdirName = null;
		String devId = null;
		Collection<File> files = null; // list of video files
		String[] fileNames = null; // list of the absolute file names
		long t1 = 0, t2 = 0;
		for (int i = 0, n = subdirs.length; i < n; i++) {
			t1 = System.currentTimeMillis();
			// trim the leading '0's in short name of the subdirectory
			devId = subdirs[i].getName().replaceFirst("0*", "");

			files = FileUtils.listFiles(subdirs[i], new String[]{"VF1", "vf1"}, true);
			fileNames = new String[files.size()];
			int cnt = 0;
			for (File f : files) {
				try {
					fileNames[cnt++] = f.getCanonicalPath();
				} catch (Exception ex) {
					throw new IllegalStateException("Unexpected fail of path resolution.", ex);
				}
			}
			t2 = System.currentTimeMillis();
			logger.info("Trium i per-device video store scan - dir: {}, duration: {} milliseconds",
					subdirs[i].getAbsolutePath(), t2 - t1);

			try {
				substores[i] = new StoreByDevice(devId, subdirs[i].getCanonicalPath(), fileNames);
			} catch (Exception ex) {
				throw new IllegalStateException("Fail to create per-device store.", ex);
			}

		}

		return new TriumiVideoStore(this.getBaseDir(), substores);
	}

}
