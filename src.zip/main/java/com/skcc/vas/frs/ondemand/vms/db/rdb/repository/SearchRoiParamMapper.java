package com.skcc.vas.frs.ondemand.vms.db.rdb.repository;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.biz.model.SearchRequest;

/**
 * @author
 *
 */
@Repository("searchRoiParamMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface SearchRoiParamMapper {
	// @NOTE Do not use transaction control(annotation) in the mapper.

	@Nonnull
	List<SearchRequest.Param> selectSearchRoiParamsByRoi(@Param("jobId") String jobId, @Param("vmsId") String vmsId,
			@Param("cctvId") String cctvId, @Param("roiNo") int roiNo);

	int insertSearchRoiParam(@Param("jobId") String jobId, @Param("vmsId") String sysId,
			@Param("cctvId") String cctvId, @Param("roiNo") int roiNo, @Param("param") SearchRequest.Param<Float> param);

}
