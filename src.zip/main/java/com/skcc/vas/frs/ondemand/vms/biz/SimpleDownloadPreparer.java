package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.NotThreadSafe;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.commons.lang3.time.FastDateFormat;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.skcc.adapter.vms.incon.InteropBackupAdapter;
import com.skcc.adapter.vms.incon.InteropTypes.DownloadFileInfo;
import com.skcc.vas.frs.common.util.ondemand.FilePrepareState;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;

/**
 *
 * @author
 * @since 2015-06-11
 */
@ManagedResource(objectName = ":type=bean,name=triumiSimpleDownloadPreparer", description = "Simple FilePreparer implementation for Trium i")
@NotThreadSafe
@ParametersAreNonnullByDefault
public class SimpleDownloadPreparer implements FilePreparer {

	/**
	 * Min. time interval in millisecond to poll the file downloading
	 */
	public static final int POLLING_INTERVAL_MIN = 1000;

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	protected final FastDateFormat dateFormat = FastDateFormat.getInstance("yyyyMMddHHmmssSSS");

	/**
	 * Normally starting with driver letter. Driver letter should be lower-case
	 * and path separator should be double backslash (\\)
	 */
	// @TODO @Inject causes BeanCreationException with autodetect JMX exporter.
	// Is there any workarounds or fixes?
	// @Inject
	private String baseDir;

	@ManagedAttribute
	public String getBaseDir() {
		return this.baseDir;
	}

	private InteropBackupAdapter backupAdapter;

	public InteropBackupAdapter getBackupAdapter() {
		return this.backupAdapter;
	}

	/**
	 * Interval in milliseconds to polling file downloading progress.
	 */
	private int pollingInterval;

	@ManagedAttribute
	public int getPollingInterval() {
		return this.pollingInterval;
	}

	// @TODO Why @Required annotation causes BeanCreationException with
	// autodetction of JMX exporter.
	// @Required
	public void setPollingInterval(@Min(POLLING_INTERVAL_MIN) int interval) {
		if (interval < POLLING_INTERVAL_MIN) {
			logger.warn("Specified polling interval({} ms) is too short.", interval);
			this.pollingInterval = POLLING_INTERVAL_MIN;
		} else {
			this.pollingInterval = interval;
		}
	}

	// The following fields make this class thread-unsafe
	/**
	 * Only for internal purpose of watching file downloading.
	 */
	@Nonnull
	private File[] allFiles = new File[0];

	@Nonnull
	private Set<File> downloadedFiles = new HashSet<File>();

	private FilePrepareState state;

	/**
	 *
	 * Note that this class doesn't connect or disconnect the given
	 * InteropBackupAdatper instance, so the client uses this class should
	 * execute {@code backupAdapter.connect} method before using this instance
	 * and execute {@code backupAdapter.disconnect} method after using this
	 * instance.
	 *
	 * @param backupAdapter
	 * @param baseDir
	 * @throws IllegalArgumentException
	 *             If the specified directory doesn't exist or isn't writable
	 */
	public SimpleDownloadPreparer(InteropBackupAdapter backupAdapter, @NotBlank String baseDir,
			@Min(POLLING_INTERVAL_MIN) int pollingInterval) {

		if (backupAdapter == null) {
			throw new IllegalArgumentException("The parameter 'backupAdapter' should be specified.");
		}
		if (baseDir == null) {
			throw new IllegalArgumentException("The paramter 'baseDir' should be specified.");
		} else {
			try {
				File f = new File(baseDir);

				if (!f.isDirectory()) {
					throw new IllegalArgumentException("The specified 'baseDir' should be a directory.");
				} else if (!f.exists()) {
					throw new IllegalArgumentException("The specified 'baseDir' should exist.");
				} else if (!f.canWrite()) {
					throw new IllegalArgumentException("The specified 'baseDir' should be writable.");
				}
			} catch (Exception ex) {
				this.logger.error("Fail to identify base directory: {}", baseDir, ex);
				throw ex;
			}
		}

		this.baseDir = baseDir;
		this.backupAdapter = backupAdapter;

		this.pollingInterval = pollingInterval;
	}

	// @TODO Remove 'systemId' or NOT?
	@Override
	public FileValue[] prepareFiles(String systemId, String deviceId, @Pattern(regexp = "[1-9][0-9]{11}") String from,
			@Pattern(regexp = "[1-9][0-9]{11}") String to) {

		Integer devId = null;
		String start = null;
		String end = null;

		// For Trium i, device ID is integer
		try {
			devId = Integer.valueOf(deviceId);
		} catch (Exception ex) {
			throw new IllegalArgumentException("For Trium i, device ID should be integer.", ex);
		}

		if (from == null || from.length() != 12) {
			throw new IllegalArgumentException("Start should be in 'yyyyMMddHHmm' format.");
		} else {
			start = from + "00";
		}

		if (to == null || to.length() != 12) {
			throw new IllegalArgumentException("End shoud be in 'yyyyMMddHHmm' format.");
		} else {
			end = to + "00";
		}

		MutableInt cntx = new MutableInt(-1); // context ID for the search
		MutableInt num = new MutableInt(-1); // number of files found

		DownloadFileInfo[] files = this.backupAdapter.findFiles(devId, start, end, cntx, num);
		this.logger.info("Video files found summary - device ID: {}, start: {}, end: {}, cntx: {}, # of files: {}",
				devId, start, end, cntx.intValue(), num.intValue());
		if (this.logger.isTraceEnabled()) {
			for (DownloadFileInfo f : files) {
				this.logger.trace("Video files found - name: {}, size: {}", f.name, f.size);
			}
		}

		this.state = new FilePrepareState(files.length, 0);

		String dir = this.baseDir + "\\" + this.generateSubPath(systemId, deviceId);
		File file = new File(dir);
		if (file.exists()) {
			throw new IllegalStateException("The directory to download already exist. Maybe multiple downloads mixed.");
		}
		if (!file.mkdir()) {
			throw new IllegalStateException("Fail to make the directory to download.");
		}

		this.allFiles = new File[files.length];
		for (int i = 0, n = files.length; i < n; i++) {
			this.allFiles[i] = new File(dir, files[i].name);
		}

		if (files.length == 0) {
			this.logger.info("There's no file to download.");
		} else {
			this.backupAdapter.start(cntx.intValue(), dir);
			this.logger.info("Started downloading video files. - cntx: {}, directory: {}", cntx.intValue(), dir);

			// @TODO Apply observer pattern later
			// @TODO Apply timeout
			while (true) {
				try {
					Thread.sleep(this.pollingInterval);
					this.updateStatus(files, dir);
				} catch (Exception ex) {
					throw new IllegalStateException("Thread sleep is interrupted.", ex);
				}
				if (this.state.isCompleted()) {
					this.logger.info("All files are downloaded. - cntx: {}, directory: {}", cntx.intValue(), dir);
					break;
				}
			}
		}

		FileValue[] downloaded = new FileValue[this.downloadedFiles.size()];
		int index = 0;
		for (File f : this.downloadedFiles) {
			downloaded[index++] = new FileValue(f.getAbsolutePath(), f.length());
		}

		return downloaded;
	}

	@Override
	@ManagedAttribute
	public FilePrepareState getState() {
		return this.state;
	}

	private String generateSubPath(String systemId, String devId) {
		String str = this.dateFormat.format(new java.util.Date());
		return str;
	}

	private void updateStatus(DownloadFileInfo[] files, String dir) {

		if (files == null)
			throw new IllegalArgumentException("Files shouldn't be null.");
		if (dir == null)
			throw new IllegalArgumentException("Dir shouldn't be null.");

		for (int i = 0, n = files.length; i < n; i++) {
			if (this.downloadedFiles.contains(this.allFiles[i])) {
				continue;
			}
			if (this.allFiles[i].exists() && (this.allFiles[i].length() == (double) files[i].size)) {
				this.downloadedFiles.add(this.allFiles[i]);
				logger.info("A file is downloaded : {}", this.allFiles[i].getAbsolutePath());
			}
		}

		this.state = new FilePrepareState(this.allFiles.length, this.downloadedFiles.size());
		this.logger.debug("state: {}", this.state.toString());
	}
}
