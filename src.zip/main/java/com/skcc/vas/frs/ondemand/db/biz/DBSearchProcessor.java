package com.skcc.vas.frs.ondemand.db.biz;

import org.hibernate.validator.constraints.NotBlank;

/**
 * @author
 * @since 2016-07-27
 *
 */
public interface DBSearchProcessor {

	void search(@NotBlank String jobId);
	void stop(@NotBlank Boolean bVal);
	void updStatus(@NotBlank String jobId, @NotBlank String rsltStts);
}
