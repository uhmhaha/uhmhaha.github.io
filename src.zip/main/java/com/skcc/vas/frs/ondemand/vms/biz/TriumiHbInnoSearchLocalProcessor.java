package com.skcc.vas.frs.ondemand.vms.biz;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.skcc.adapter.vms.incon.FsUtilAdapter;
import com.skcc.adapter.vms.incon.InteropLiveAdapter;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngineOndemandVMSFile;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.SearchProgressListener;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Cctv;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.base.JobStatus;
import com.skcc.vas.frs.common.util.base.Point;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.ondemand.vms.model.SimpleSearchCriteria;

/**
 * @author
 * @since 2016-07-26
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=triumiHbInnoSearchLocalProcessor", description = "Process on-demand search for face recognition.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class TriumiHbInnoSearchLocalProcessor extends SearchProcessorBase {

	public static final int UNIT_TIME_DEFAULT = 10;

	public static final int THREAD_POOL_SIZE_MIN = 5;

	public static final int THREAD_POOL_SIZE_MAX = 200;

	public static final int SKIPS_MAX = 30;

	protected static int getThreadPoolSizeMax() {
		return THREAD_POOL_SIZE_MAX;
	}

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private volatile FilePreparer filePreparer;

	public FilePreparer getFilePreparer() {
		return this.filePreparer;
	}

	private final FsUtilAdapter fsUtilAdapter;

	public FsUtilAdapter getFsUtilAdapter() {
		return this.fsUtilAdapter;
	}

	private volatile int skips;

	@ManagedAttribute
	public int getSkips() {
		return this.skips;
	}

	private final HbInnoParameter hbInnoParam;

	public HbInnoParameter getHbInnoParam() {
		return this.hbInnoParam;
	}

	private final FaceMatchJobService faceMatchJobService;

	private List<HashMap<String, Object>> faceFeatureList;

	public List<HashMap<String, Object>> getFaceFeatureList() {
		return faceFeatureList;
	}

	// @Value("${vas.dataDir}")
	private String vasDir;

	// @Value("${vas.concernedFace.saveDir}")
	private String concernedFaceDir;

	private HbinnoEngineOndemandVMSFile hbinnoEngineInstance;

	private int maxPoolSize;

	private String pattern = DirectAccessFilePreparer.DEFAULT_DEVICE_DIR_PATTERN;

	private VasConfigService configService;

	@ManagedAttribute
	public void setSkips(@Min(0) @Max(SKIPS_MAX) int skips) {
		if (skips < 0) {
			this.logger.warn("The specified skip number({}) is less than zero. The skip number would be set to 0.",
					skips);
		} else if (skips > SKIPS_MAX) {
			this.logger.warn("The specified skip number({}) is too large. The skip number would be set to {}.", skips,
					SKIPS_MAX);
		} else {
			this.logger.info("The skip number is changed to {} from {}.", skips, this.skips);
			this.skips = skips;
		}
	}

	private final ThumbnailPersister thumbnailPersister;

	public ThumbnailPersister getThumbnailPersister() {
		return this.thumbnailPersister;
	}

	private volatile SearchProgressListener progressListener = null;

	private final OnDemandWithFileParameter demandWithFileParameter;

	public OnDemandWithFileParameter getDemandWithFileParameter() {
		return demandWithFileParameter;
	}

	@ManagedAttribute
	public final boolean hasProgressListener() {
		return (this.progressListener == null) ? false : true;
	}

	public SearchProgressListener getProgressListener() {
		return this.progressListener;
	}

	// private volatile int threadPoolSize;
	//
	// @ManagedAttribute
	// public int getThreadPoolSize(){ return this.threadPoolSize; }
	//
	// @ManagedAttribute
	// public void setThreadPoolSize(@Min(THREAD_POOL_SIZE_MIN) int
	// threadPoolSize){
	// if(threadPoolSize < THREAD_POOL_SIZE_MIN){
	// this.logger.warn("The specified thread pool size(%1$d) is too small. It would be set to the possible min. value %2$d",
	// threadPoolSize, THREAD_POOL_SIZE_MIN);
	// this.threadPoolSize = THREAD_POOL_SIZE_MIN;
	// }else if(threadPoolSize > getThreadPoolSizeMax()){
	// this.logger.warn("The specified thread pool size(%1$d) is too large. It would be set to the possible min. value %2$d",
	// threadPoolSize, getThreadPoolSizeMax());
	// this.threadPoolSize = getThreadPoolSizeMax();
	// }else{
	// this.threadPoolSize = threadPoolSize;
	// }
	// }

	private final ExecutorService executor;

	public TriumiHbInnoSearchLocalProcessor(@Nonnull SearchDataManager searchDataMgr,
			@Nonnull FaceDataManager faceDataMgr, @Nonnull FilePreparer filePreparer,
			@Nonnull FsUtilAdapter fsUtilAdapter, @Min(0) @Max(SKIPS_MAX) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull ThreadPoolTaskExecutor taskExecutor,
			@Nonnull HbInnoParameter hbInnoParam, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter,
			@Nonnull HbinnoEngineOndemandVMSFile hbinnoEngineInstance, @Nonnull VasConfigService configService) {

		super(searchDataMgr, faceDataMgr);

		// Validate.isTrue(filePreparer != null,
		// "The file preparer for video files should be provided.");
		Validate.isTrue(fsUtilAdapter != null, "The file utility for Triumi-i should be provided.");
		Validate.isTrue(taskExecutor != null, "The executor for search task should be provided.");

		this.filePreparer = filePreparer;
		this.fsUtilAdapter = fsUtilAdapter;
		this.setSkips(skips);
		this.thumbnailPersister = thumbPersister;
		this.hbInnoParam = hbInnoParam;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.hbinnoEngineInstance = hbinnoEngineInstance;
		this.configService = configService;

		if (thumbPersister == null) {
			this.logger.warn("The thumbnail persister is not provided. The thumbnail file wouldn't be saved.");
		}

		this.executor = new ExecutorServiceAdapter(taskExecutor);
	}

	public void initConfig() {
		// ("${vas.dataDir}")
		this.vasDir = configService.getConfigValByName("vas.dataDir");

		// @Value("${vas.concernedFace.saveDir}")
		this.concernedFaceDir = configService.getConfigValByName("vas.concernedFace.saveDir");
		// <constructor-arg value="${vas.ondemand.vms.thread.core}"/>
		this.maxPoolSize = Integer.parseInt(configService.getConfigValByName("vas.ondemand.vms.thread.core"));

	}

	@Override
	@Async
	public void search(@NotBlank final String jobId) {

		if (hasProgressListener()) {
			this.progressListener.jobAccepted(jobId, System.currentTimeMillis());
		} else {
			this.logger
					.warn("The progress listener is not set. The statistics for the progress of jobs and tasks are not collected.");
		}

		final SearchRequest req = this.getSearchDataManager().findSearchRequest(jobId);
		if (req == null) {
			final String msg = String.format("The search job[id: %1$s] can't be found.", jobId);
			if (this.hasProgressListener())
				this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());
			throw new IllegalStateException(msg);
		}

		final List<Cctv> cctvs = req.getCctvs();
		final String start = req.getStart();
		final String end = req.getEnd();
		String start2;
		String end2;
		if (req.getStart2() != null && req.getEnd2() != null) {
			start2 = req.getStart2();
			end2 = req.getEnd2();
		} else {
			start2 = req.getStart2();
			end2 = req.getEnd2();
		}

		if (cctvs.isEmpty()) {
			final String msg = String.format("The search job[id: %1$s] contains NO CCTV.", jobId);
			if (this.hasProgressListener())
				this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());

			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(start)) {
			final String msg = String.format("The start time for the search is not specified.");
			if (this.hasProgressListener())
				this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());

			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(end)) {
			final String msg = String.format("The end time for the search is not specified.");
			if (this.hasProgressListener())
				this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());

			throw new IllegalArgumentException(msg);
		} else if (StringUtils.equals(start, end) && StringUtils.equals(start2, end2)) {
			final String msg = String.format("The time interval has NO duration. Start is same with end.");
			if (this.hasProgressListener())
				this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());

			throw new IllegalArgumentException(msg);
		} else {
			this.logger.info(
					"Found a search job. - id: {}, name: {}, type: {}, start: {}, end: {}, cctvs: {}, threshold: {}",
					req.getId(), req.getName(), req.getType(), req.getStart(), req.getEnd(), req.getCctvs().size(),
					req.getThreshold());
		}

		// Observer 생성
		ObserverProgressOnDemandWithFile observer = new ObserverProgressOnDemandWithFile(faceMatchJobService);
		observer.setJobId(jobId);

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", req.getId());

		List<SearchTask> stasks = new ArrayList<SearchTask>();
		List<Task> tasks = new ArrayList<Task>();

		// if(baseDirList.size() > 0){
		// for(String baseDir: baseDirList){
		for (Cctv cctv : cctvs) {
			if (cctv.getRois().size() > 1) {
				final String msg = String.format("Multiple ROIs can't be specified yet.");
				if (this.hasProgressListener())
					this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());
				throw new IllegalArgumentException(msg);
			}

			int num = 0;
			if (cctv.getRois().size() == 1) {
				num = cctv.getRois().get(0).getPoints().size();
				if (num != 0 && num != 4) {
					final String msg = String.format("The ROI should be rectangle or entire screen.");
					if (this.hasProgressListener())
						this.progressListener.jobFinished(jobId, JobStatus.FAIL, msg, System.currentTimeMillis());
					throw new IllegalArgumentException(msg);
				}
			}
		}

		// int unitTime = this.calcOptimalUnitTime(start, end, start2, end2);
		// //multithread 용도
		int unitTime = Integer.parseInt(demandWithFileParameter.getVmsUnitTime()); // single
																					// thread
																					// 용도.
																					// temporary

		List<Pair<String, String>> subs = new ArrayList<Pair<String, String>>();

		if ("CONTINUOUS".equals(req.getTimeType())) {
			subs = BaseUtils.splitInterval(start, end, unitTime);
			if (start2 != null && end2 != null) {
				final List<Pair<String, String>> subs2 = BaseUtils.splitInterval(start2, end2, unitTime);
				for (Pair<String, String> sub : subs2)
					subs.add(sub);
			}
		} else {
			String startDate = (String) start.substring(0, 8);
			String endDate = (String) end.substring(0, 8);
			// 조회기간에 해당하는 일자 리스트
			List<String> dateList = BaseUtils.fromToDateList(startDate, endDate);

			for (String date : dateList) {
				String tempStartTime = date + start.substring(8, 12);
				String tempEndTime = date + end.substring(8, 12);

				List<Pair<String, String>> tmpSubs = BaseUtils.splitInterval(tempStartTime, tempEndTime, unitTime);
				for (Pair<String, String> sub : tmpSubs)
					subs.add(sub);
			}

			if (start2 != null && end2 != null) {
				String startDate2 = (String) start2.substring(0, 8);
				String endDate2 = (String) end2.substring(0, 8);
				// 조회기간에 해당하는 일자 리스트
				List<String> dateList2 = BaseUtils.fromToDateList(startDate2, endDate2);

				for (String date : dateList2) {
					String tempStartTime2 = date + start2.substring(8, 12);
					String tempEndTime2 = date + end2.substring(8, 12);

					List<Pair<String, String>> tmpSubs2 = BaseUtils.splitInterval(tempStartTime2, tempEndTime2,
							unitTime);
					for (Pair<String, String> sub : tmpSubs2)
						subs.add(sub);
				}
			}

		}

		this.faceFeatureList = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		final int total = (subs.size()) * cctvs.size();
		this.logger.info("Partitioned a face search job. - id: {}, # of partitions: {}", req.getId(), total);
		if (this.hasProgressListener())
			this.progressListener.jobStarted(jobId, total, System.currentTimeMillis());

		List<Point<Float>> points = null;
		SimpleSearchCriteria srchCrtr = null;
		int taskId = 1;

		for (Cctv cctv : cctvs) {
			for (Pair<String, String> sub : subs) {
				points = new ArrayList<Point<Float>>(4);
				if (cctv.getRois().size() == 1) {
					for (SearchRequest.Point pt : cctv.getRois().get(0).getPoints()) {
						points.add(new Point(pt.getX(), pt.getY()));
					}
				} else {
					points.add(new Point(0.0f, 0.0f));
					points.add(new Point(0.0f, 1.0f));
					points.add(new Point(1.0f, 1.0f));
					points.add(new Point(1.0f, 0.0f));
				}

				srchCrtr = new SimpleSearchCriteria(cctv.getSystemId(), cctv.getId(), sub.getLeft(), sub.getRight(),
						points.get(0), points.get(1), points.get(2), points.get(3), req.getThreshold());

				// try{
				// Thread.sleep(1000);
				// }catch(InterruptedException e){
				// logger.error("Sleep error");
				// }

				TriumiVideoStore.FileValue[] files = new TriumiVideoStore.FileValue[0];

				final InteropLiveAdapter interopLiveAdapter = new InteropLiveAdapter();
				int fileControlHandle = interopLiveAdapter.addRecordData(Integer.parseInt(srchCrtr.getDeviceId()),
						srchCrtr.getFrom() + "00", srchCrtr.getTo() + "00");

				// Handle 정보를 가져오기 위해 Sleep
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					logger.error("Sleep error");
				}

				ArrayList<String> filePaths = (java.util.ArrayList<String>) interopLiveAdapter.getDownloadFileInfo(
						fileControlHandle, Integer.parseInt(srchCrtr.getDeviceId()));

				if (filePaths == null) {
					this.logger.warn("VMS File is not exist - CCTV ID : {}", srchCrtr.getDeviceId());
					continue;
				}

				files = new TriumiVideoStore.FileValue[filePaths.size()];

				for (int j = 0; j < filePaths.size(); j++) {
					TriumiVideoStore.FileValue file = new TriumiVideoStore.FileValue(j, filePaths.get(j));
					logger.debug("File Path : {}", filePaths.get(j));
					files[j] = file;
				}

				// Old source (VMS File Search)
				// files =
				// videoStoreByDevice.findVideosByInterval(srchCrtr.getDeviceId(),
				// srchCrtr.getFrom(), srchCrtr.getTo(), false);
				// this.logger.info("Found {} files. - jobId: {}, taskId: {} (cctvId: {}, fromDate: {}, toDate: {})",
				// files.length, jobId, taskId,srchCrtr.getDeviceId(),
				// srchCrtr.getFrom(), srchCrtr.getTo());
				// } else {
				// // throw new
				// RuntimeException("Fail to build cctv list for conditions(cctvId, fromDate, toDate)");
				// this.logger.error("Fail to build cctv list for conditions(cctvId: {}, fromDate: {}, toDate: {})",
				// srchCrtr.getDeviceId(),
				// srchCrtr.getFrom(), srchCrtr.getTo());
				// }

				if (faceFeatureList.size() > 0 && files.length > 0) {
					// @TODO Need further implementation.
					final FsUtilAdapter fsUtilAdapter = new FsUtilAdapter();

					tasks.add(new Task(jobId, String.valueOf(taskId), srchCrtr, this.filePreparer, fsUtilAdapter,
							this.skips, this.thumbnailPersister, this.getFaceDataManager(), progressListener,
							this.hbInnoParam, this.faceFeatureList, this.faceMatchJobService,
							this.demandWithFileParameter, observer, files));

					// observe 전체파일 갯수 세팅
					// synchronized (observer) {
					String dirAndTaskId = new StringBuffer().append(srchCrtr.getSystemId()).append("_")
							.append(srchCrtr.getDeviceId()).append("_").append(taskId).toString();
					if (files.length > 0) {
						observer.addTotalFilesForTask(dirAndTaskId, files.length);
					}
					// }
					taskId++;

				} else {
					logger.warn("This job for cctvId {} have no any concerned face!!", cctv.getId());
				}
			}
		}
		// }

		HashMap<String, Object> startJobParam = new HashMap<String, Object>();
		startJobParam.put("job_id", jobId);

		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		this.faceMatchJobService.updateJobStartTime(startJobParam);

		List<Future<Void>> futures = new ArrayList<Future<Void>>(tasks.size());

		int i = 0;
		for (Task task : tasks) {
			try {

				i++;
				logger.info("{} 's task!!", i);
				task.setHbinnoEngine(this.hbinnoEngineInstance);
				futures.add(this.executor.submit(task));

			} catch (Throwable ex) {
				this.logger.error("Fail to submit a face search task. - jobId: {}, taskId: {}", task.getJobId(),
						task.getTaskId());
				this.logger.error(">>>>>>>>>>>> {}", ex);
			}

		}

		tasks.clear();
		for (Future<Void> future : futures) {
			try {
				if (future != null) {
					future.get();
				}
			} catch (Throwable ex) {
				this.logger.error("Fail to process a face search task. {}", ex);
				// Thread.currentThread().interrupt();
			}
		}

		HashMap<String, Object> statusChkParam = new HashMap<String, Object>();
		statusChkParam.put("job_id", jobId);
		String prevStatus = faceMatchJobService.searchStopStatus(statusChkParam);

		if (prevStatus.equals("ABORTED") || prevStatus.equals("FAIL")) {
			return;
		} else {

			// ---------- job end update --------------------------
			// 완료시 상태를 COMPLETED 으로 하고, 진행률을 100%로 한다.
			faceMatchJobService.updateJobEndTime(param);
		}
		//
		// this.executor.shutdown();
		// }
		// else {
		// this.logger.warn("This job [{}] is no valid vms file path", jobId);
		// }
	}

	@Override
	public void stop(Boolean bVal) {
		logger.info("++STOP      COMMAND      INPUT  ");
	}

	@Override
	public void updStatus(String jobId, String rsltStts) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);
		param.put("rslt_stts", rsltStts);
		if (rsltStts.equals("ABORTED")) {
			param.put("rslt_stts_desc", "ondemand aborted!");
		}
		faceMatchJobService.updateJobStatus(param);

	}

	private int calcOptimalUnitTime(String start, String end, String start2, String end2) {
		// @TODO The following is completely temporary. (2016-07-20, Sangmooh j
		return UNIT_TIME_DEFAULT;
	}

	public void destroy() {
		if (this.executor != null && !(this.executor instanceof ExecutorServiceAdapter)) {
			this.executor.shutdown();
		}
	}

	// private void setTargetFeatures(List<HashMap<String, Object>>
	// faceFeatureList) {
	//
	// //Map<String, byte[]> features = new HashMap<String, byte[]>();
	// Map<String, Pair<byte[], String>> featureNpath = new HashMap<String,
	// Pair<byte[], String>>();
	//
	// /*
	// * HBInno Adapter에 concerned feature를 모두 추가한다
	// * ConcernedFace.getId() = face Id
	// */
	// for(HashMap<String, Object> faceFeature : faceFeatureList) {
	//
	// featureNpath.put((String)faceFeature.get("cncrn_face_id"),
	// Pair.of((byte[])faceFeature.get("feature"),
	// (String)faceFeature.get("img_path")));
	// }
	//
	//
	// try {
	// int count =
	// getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
	// if(faceFeatureList.size() > count) {
	// this.logger.warn("++ The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
	// count);
	// }
	// this.logger.debug("++ Total {} concerned features added into Hbinno Adatper.",
	// count);
	//
	// } catch(Exception ex) {
	// logger.error("++ Thread sleep() meet error !");
	// }
	//
	// }

}

@Immutable
class SearchTask {

	private final String jobId;

	protected String getJobId() {
		return this.jobId;
	}

	private final String taskId;

	protected String getTaskId() {
		return this.taskId;
	}

	private final SimpleSearchCriteria srchCrtr;

	private final FilePreparer filePreparer;

	private final FsUtilAdapter fsUtilAdapter;

	private final int skips;

	private final ThumbnailPersister thumbPersister;

	private final FaceDataManager faceDataManager;

	private final SearchProgressListener progressListener;

	private final HbInnoParameter hbInnoParameter;

	private List<HashMap<String, Object>> faceFeatureList;

	private final FaceMatchJobService faceMatchJobService;

	private final OnDemandWithFileParameter demandWithFileParameter;

	private final ObserverProgressOnDemandWithFile observer;

	private HbinnoEngine hbinnoEngine;

	public void setHbinnoEngine(HbinnoEngine hbinnoEngine) {
		this.hbinnoEngine = hbinnoEngine;
	}

	private TriumiVideoStore.FileValue[] files;

	public SearchTask(@NotBlank String jobId, @NotBlank String taskId, @Nonnull SimpleSearchCriteria srchCrtr,
			@Nonnull FilePreparer filePreparer, @Nonnull FsUtilAdapter fsUtilAdapter, @Min(0) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager,
			@Nullable SearchProgressListener progressListener, @Nonnull HbInnoParameter hbInnoParam,
			List<HashMap<String, Object>> faceFeatureList, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter,
			@Nonnull ObserverProgressOnDemandWithFile observer, TriumiVideoStore.FileValue[] files) {

		this.jobId = jobId;
		this.taskId = taskId;
		this.srchCrtr = srchCrtr;
		this.filePreparer = filePreparer;
		this.fsUtilAdapter = fsUtilAdapter;
		this.skips = skips;
		this.thumbPersister = thumbPersister;
		this.faceDataManager = faceDataManager;
		this.progressListener = progressListener;
		this.hbInnoParameter = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.observer = observer;
		this.files = files;
	}

	public void process() {
		SearchTaskProcessor<SimpleSearchCriteria, FaceEvent, TriumiEventContext> task = new TriumiHbInnoSearchTaskProcessor(
				this.filePreparer, this.fsUtilAdapter, this.thumbPersister, this.faceDataManager, this.skips,
				this.hbInnoParameter, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
				this.observer, this.hbinnoEngine, this.files);

		((TriumiHbInnoSearchTaskProcessor) task).postConstruct();
		((TriumiHbInnoSearchTaskProcessor) task).setProgressListener(this.progressListener);
		((TriumiHbInnoSearchTaskProcessor) task).process(this.jobId, this.taskId, this.srchCrtr);
		((TriumiHbInnoSearchTaskProcessor) task).preDestroy();
	}
}

@Immutable
class Task implements Callable<Void> {

	private final String jobId;

	protected String getJobId() {
		return this.jobId;
	}

	private final String taskId;

	protected String getTaskId() {
		return this.taskId;
	}

	private final SimpleSearchCriteria srchCrtr;

	private final FilePreparer filePreparer;

	private final FsUtilAdapter fsUtilAdapter;

	private final int skips;

	private final ThumbnailPersister thumbPersister;

	private final FaceDataManager faceDataManager;

	private final SearchProgressListener progressListener;

	private final HbInnoParameter hbInnoParameter;

	private List<HashMap<String, Object>> faceFeatureList;

	private final FaceMatchJobService faceMatchJobService;

	private final OnDemandWithFileParameter demandWithFileParameter;

	private final ObserverProgressOnDemandWithFile observer;

	private HbinnoEngine hbinnoEngine;

	public void setHbinnoEngine(HbinnoEngine hbinnoEngine) {
		this.hbinnoEngine = hbinnoEngine;
	}

	private TriumiVideoStore.FileValue[] files;

	public Task(@NotBlank String jobId, @NotBlank String taskId, @Nonnull SimpleSearchCriteria srchCrtr,
			@Nonnull FilePreparer filePreparer, @Nonnull FsUtilAdapter fsUtilAdapter, @Min(0) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager,
			@Nullable SearchProgressListener progressListener, @Nonnull HbInnoParameter hbInnoParam,
			List<HashMap<String, Object>> faceFeatureList, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter,
			@Nonnull ObserverProgressOnDemandWithFile observer, TriumiVideoStore.FileValue[] files) {

		this.jobId = jobId;
		this.taskId = taskId;
		this.srchCrtr = srchCrtr;
		this.filePreparer = filePreparer;
		this.fsUtilAdapter = fsUtilAdapter;
		this.skips = skips;
		this.thumbPersister = thumbPersister;
		this.faceDataManager = faceDataManager;
		this.progressListener = progressListener;
		this.hbInnoParameter = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.observer = observer;
		this.files = files;
	}

	@Override
	public Void call() {
		SearchTaskProcessor<SimpleSearchCriteria, FaceEvent, TriumiEventContext> task = new TriumiHbInnoSearchTaskProcessor(
				this.filePreparer, this.fsUtilAdapter, this.thumbPersister, this.faceDataManager, this.skips,
				this.hbInnoParameter, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
				this.observer, this.hbinnoEngine, this.files);

		((TriumiHbInnoSearchTaskProcessor) task).postConstruct();
		((TriumiHbInnoSearchTaskProcessor) task).setProgressListener(this.progressListener);
		((TriumiHbInnoSearchTaskProcessor) task).process(this.jobId, this.taskId, this.srchCrtr);
		((TriumiHbInnoSearchTaskProcessor) task).preDestroy();

		return null;

	}
}