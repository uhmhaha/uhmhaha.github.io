package com.skcc.vas.frs.ondemand.video.db.rdb.domain;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;

public class FileAnalysisRequest {

	private String jobId;

	private int threshold;

	private final List<AnalysisResource> analysisResources = new ArrayList<AnalysisResource>();

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	@Nonnull
	public List<AnalysisResource> getAnalysisResources() {
		return this.analysisResources;
	}

	public FileAnalysisRequest addAnalysisResources(@Nonnull AnalysisResource analysisResource) {
		if (analysisResource != null)
			this.analysisResources.add(analysisResource);
		return this;
	}

	public static class AnalysisResource implements java.io.Serializable {

		private String id;

		private String rsltStts;

		private String rsltSttsDesc;

		private String rscTitle;

		private String rscSceneType;

		private String rscOrigin;

		private String rscType;

		private String rscPath;

		private String rscThumbPath;

		private String rscFileNm;

		private int rscWidth;

		private int rscHeight;

		private float rscFileSize;

		private int videoLength;

		private String remarks;

		private String isValid;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getRsltStts() {
			return rsltStts;
		}

		public void setRsltStts(String rsltStts) {
			this.rsltStts = rsltStts;
		}

		public String getRsltSttsDesc() {
			return rsltSttsDesc;
		}

		public void setRsltSttsDesc(String rsltSttsDesc) {
			this.rsltSttsDesc = rsltSttsDesc;
		}

		public String getRscTitle() {
			return rscTitle;
		}

		public void setRscTitle(String rscTitle) {
			this.rscTitle = rscTitle;
		}

		public String getRscSceneType() {
			return rscSceneType;
		}

		public void setRscSceneType(String rscSceneType) {
			this.rscSceneType = rscSceneType;
		}

		public String getRscOrigin() {
			return rscOrigin;
		}

		public void setRscOrigin(String rscOrigin) {
			this.rscOrigin = rscOrigin;
		}

		public String getRscType() {
			return rscType;
		}

		public void setRscType(String rscType) {
			this.rscType = rscType;
		}

		public String getRscPath() {
			return rscPath;
		}

		public void setRscPath(String rscPath) {
			this.rscPath = rscPath;
		}

		public String getRscThumbPath() {
			return rscThumbPath;
		}

		public void setRscThumbPath(String rscThumbPath) {
			this.rscThumbPath = rscThumbPath;
		}

		public String getRscFileNm() {
			return rscFileNm;
		}

		public void setRscFileNm(String rscFileNm) {
			this.rscFileNm = rscFileNm;
		}

		public int getRscWidth() {
			return rscWidth;
		}

		public void setRscWidth(int rscWidth) {
			this.rscWidth = rscWidth;
		}

		public int getRscHeight() {
			return rscHeight;
		}

		public void setRscHeight(int rscHeight) {
			this.rscHeight = rscHeight;
		}

		public float getRscFileSize() {
			return rscFileSize;
		}

		public void setRscFileSize(float rscFileSize) {
			this.rscFileSize = rscFileSize;
		}

		public int getVideoLength() {
			return videoLength;
		}

		public void setVideoLength(int videoLength) {
			this.videoLength = videoLength;
		}

		public String getRemarks() {
			return remarks;
		}

		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

		public String getIsValid() {
			return isValid;
		}

		public void setIsValid(String isValid) {
			this.isValid = isValid;
		}

	}
}
