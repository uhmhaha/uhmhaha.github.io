package com.skcc.vas.frs.ondemand.video.biz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.skcc.adapter.video.sparser.SParserJNI;
import com.skcc.vas.adapter.fr.hbinno.HbInnoEngineOndemandVideoFile;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.SearchProgressListener;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.ondemand.video.db.rdb.service.FileAnalysisDataManager;
import com.skcc.vas.frs.ondemand.vms.biz.DirectAccessFilePreparer;
import com.skcc.vas.frs.ondemand.vms.biz.ObserverProgressOnDemandWithFile;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiEventContext;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiVideoStore;

public class SParserHbInnoSearchVideoProcessor extends FileAnalysisProcessorBase {

	public static final int UNIT_TIME_DEFAULT = 10;

	public static final int THREAD_POOL_SIZE_MIN = 5;

	public static final int THREAD_POOL_SIZE_MAX = 200;

	public static final int SKIPS_MAX = 30;

	protected static int getThreadPoolSizeMax() {
		return THREAD_POOL_SIZE_MAX;
	}

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private volatile FilePreparer filePreparer;

	public FilePreparer getFilePreparer() {
		return this.filePreparer;
	}

	private final SParserJNI sParserAdapter;

	public SParserJNI getsParserAdapter() {
		return sParserAdapter;
	}

	private volatile int skips;

	@ManagedAttribute
	public int getSkips() {
		return this.skips;
	}

	@ManagedAttribute
	public void setSkips(@Min(0) @Max(SKIPS_MAX) int skips) {
		if (skips < 0) {
			this.logger.warn("The specified skip number({}) is less than zero. The skip number would be set to 0.",
					skips);
		} else if (skips > SKIPS_MAX) {
			this.logger.warn("The specified skip number({}) is too large. The skip number would be set to {}.", skips,
					SKIPS_MAX);
		} else {
			this.logger.info("The skip number is changed to {} from {}.", skips, this.skips);
			this.skips = skips;
		}
	}

	private final HbInnoParameter hbInnoParam;

	public HbInnoParameter getHbInnoParam() {
		return this.hbInnoParam;
	}

	private final FaceMatchJobService faceMatchJobService;

	private List<HashMap<String, Object>> faceFeatureList;

	public List<HashMap<String, Object>> getFaceFeatureList() {
		return faceFeatureList;
	}

	// @Value("${vas.dataDir}")
	private String vasDir;

	// @Value("${vas.concernedFace.saveDir}")
	private String concernedFaceDir;

	// @Value("${vas.file.analysis.baseDir}")
	private String baseDir;

	private HbInnoEngineOndemandVideoFile hbinnoEngineInstance;

	private String pattern = DirectAccessFilePreparer.DEFAULT_DEVICE_DIR_PATTERN;

	private final ExecutorService executor;

	private final ThumbnailPersister thumbnailPersister;

	public ThumbnailPersister getThumbnailPersister() {
		return this.thumbnailPersister;
	}

	private volatile SearchProgressListener progressListener = null;

	private final OnDemandWithFileParameter demandWithFileParameter;

	public OnDemandWithFileParameter getDemandWithFileParameter() {
		return demandWithFileParameter;
	}

	private VasConfigService configService;

	public SParserHbInnoSearchVideoProcessor(@Nonnull FileAnalysisDataManager fileAnalysisDataManager,
			@Nonnull FaceDataManager faceDataMgr, @Nonnull FilePreparer filePreparer,
			@Nonnull SParserJNI sParserAdapter, @Min(0) @Max(SKIPS_MAX) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull ThreadPoolTaskExecutor taskExecutor,
			@Nonnull HbInnoParameter hbInnoParam, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter,
			@Nonnull HbInnoEngineOndemandVideoFile hbinnoEngineInstance, @Nonnull VasConfigService configService) {
		super(fileAnalysisDataManager, faceDataMgr);

		Validate.isTrue(sParserAdapter != null, "The file utility for Triumi-i should be provided.");
		Validate.isTrue(taskExecutor != null, "The executor for search task should be provided.");

		this.filePreparer = filePreparer;
		this.sParserAdapter = sParserAdapter;
		this.setSkips(skips);
		this.thumbnailPersister = thumbPersister;
		this.hbInnoParam = hbInnoParam;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.hbinnoEngineInstance = hbinnoEngineInstance;

		this.configService = configService;

		if (thumbPersister == null) {
			this.logger.warn("The thumbnail persister is not provided. The thumbnail file wouldn't be saved.");
		}

		this.executor = new ExecutorServiceAdapter(taskExecutor);

	}

	public void initConfig() {

		// @Value("${vas.dataDir}")
		vasDir = configService.getConfigValByName("vas.dataDir");

		// @Value("${vas.concernedFace.saveDir}")
		concernedFaceDir = configService.getConfigValByName("vas.concernedFace.saveDir");

		// @Value("${vas.file.analysis.baseDir}")
		baseDir = configService.getConfigValByName("vas.file.analysis.baseDir");
	}

	@Override
	@Async
	public void search(@NotBlank final String jobId) {
		// todo modify
		final FileAnalysisRequest req = this.getFileAnalysisDataManager().findAnalysisRequest(jobId);
		List<AnalysisResource> analysisResources = new ArrayList<AnalysisResource>();
		if (req == null) {
			final String msg = String.format("The resource of file analysis job[id: %1$s] can't be found.", jobId);
			throw new IllegalStateException(msg);
		} else {
			analysisResources = req.getAnalysisResources();
			if (analysisResources.isEmpty() == true) {
				final String msg = String.format("The resource of file analysis job[id: %1$s] contains NO.", jobId);
				throw new IllegalArgumentException(msg);
			} else {
				for (AnalysisResource analysisRsc : analysisResources) {
					this.logger
							.info("Found a search job. - jobId: {}, rscId: {}, rscTitle: {}, rsc_scene_type: {}, rsc_path: {}, rsc_thumb_path: {}, rsc_file_nm: {}",
									req.getJobId(), analysisRsc.getId(), analysisRsc.getRscTitle(),
									analysisRsc.getRscSceneType(), analysisRsc.getRscPath(),
									analysisRsc.getRscThumbPath(), analysisRsc.getRscFileNm());
				}
			}
		}

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", req.getJobId());
		this.faceFeatureList = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		// Observer 생성
		ObserverProgressOnDemandWithFile observer = new ObserverProgressOnDemandWithFile(faceMatchJobService);
		observer.setJobId(jobId);

		List<FileAnalysisTask> tasks = new ArrayList<FileAnalysisTask>();
		int taskId = 1;
		for (AnalysisResource analysisRsc : analysisResources) {

			if (faceFeatureList.size() > 0) {
				final SParserJNI sParserAdapter = new SParserJNI();

				tasks.add(new FileAnalysisTask(jobId, String.valueOf(taskId), analysisRsc, this.filePreparer,
						sParserAdapter, this.skips, this.thumbnailPersister, this.getFaceDataManager(),
						this.hbInnoParam, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
						this.baseDir, observer, req.getThreshold()));

				synchronized (observer) {
					// observe 전체파일 갯수 세팅
					String dirAndTaskId = new StringBuffer().append(req.getJobId()).append("_")
							.append(analysisRsc.getRscFileNm()).append("_").append(taskId).toString();
					observer.addTotalFilesForTask(dirAndTaskId, 1);

				}
				taskId++;
			}
		}

		HashMap<String, Object> startJobParam = new HashMap<String, Object>();
		startJobParam.put("job_id", jobId);

		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		this.faceMatchJobService.updateJobStartTime(startJobParam);

		List<Future<Void>> futures = new ArrayList<Future<Void>>(tasks.size());

		int i = 0;
		for (FileAnalysisTask task : tasks) {
			try {

				i++;
				logger.info("{} 's task!!", i);
				task.setHbinnoEngine(this.hbinnoEngineInstance);
				futures.add(this.executor.submit(task));

			} catch (Throwable ex) {
				this.logger.error("Fail to submit a face search task. - jobId: {}, taskId: {}", task.getJobId(),
						task.getTaskId());
				this.logger.error(">>>>>>>>>>>> {}", ex);
			}

		}

		tasks.clear();
		for (Future<Void> future : futures) {
			try {
				if (future != null) {
					future.get();
				}
			} catch (Throwable ex) {
				this.logger.error("Fail to process a face search task. {}", ex);
				// Thread.currentThread().interrupt();
			}
		}

		HashMap<String, Object> statusChkParam = new HashMap<String, Object>();
		statusChkParam.put("job_id", jobId);
		String prevStatus = faceMatchJobService.searchStopStatus(statusChkParam);

		if (prevStatus.equals("ABORTED") || prevStatus.equals("FAIL")) {
			return;
		} else {
			// ---------- job end update --------------------------
			// 완료시 상태를 COMPLETED 으로 하고, 진행률을 100%로 한다.
			faceMatchJobService.updateJobEndTime(param);
			this.logger
					.info("============================= The job of {} is completed !! ============================= ",
							jobId);
		}

	}

	@Override
	public void stop(Boolean bVal) {
		logger.info("++STOP      COMMAND      INPUT  ");
	}

	@Override
	public void updStatus(String jobId, String rsltStts) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);
		param.put("rslt_stts", rsltStts);
		if (rsltStts.equals("ABORTED")) {
			param.put("rslt_stts_desc", "ondemand aborted!");
		}
		faceMatchJobService.updateJobStatus(param);

	}

	public void destroy() {
		if (this.executor != null && !(this.executor instanceof ExecutorServiceAdapter)) {
			this.executor.shutdown();
		}
	}
}

@Immutable
class FileAnalysisTask implements Callable<Void> {

	private final String jobId;

	protected String getJobId() {
		return this.jobId;
	}

	private final String taskId;

	protected String getTaskId() {
		return this.taskId;
	}

	private final AnalysisResource analysisRsc;

	private final FilePreparer filePreparer;

	private final SParserJNI sParserAdapter;

	private final int skips;

	private final ThumbnailPersister thumbPersister;

	private final FaceDataManager faceDataManager;

	private final HbInnoParameter hbInnoParameter;

	private List<HashMap<String, Object>> faceFeatureList;

	private final FaceMatchJobService faceMatchJobService;

	private final OnDemandWithFileParameter demandWithFileParameter;

	private final String baseDir;

	private final ObserverProgressOnDemandWithFile observer;

	private HbinnoEngine hbinnoEngine;

	public void setHbinnoEngine(HbinnoEngine hbinnoEngine) {
		this.hbinnoEngine = hbinnoEngine;
	}

	private TriumiVideoStore.FileValue[] files;

	private final int threshold;

	public FileAnalysisTask(@NotBlank String jobId, @NotBlank String taskId, @Nonnull AnalysisResource analysisRsc,
			@Nonnull FilePreparer filePreparer, @Nonnull SParserJNI sParserAdapter, @Min(0) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager,
			@Nonnull HbInnoParameter hbInnoParam, List<HashMap<String, Object>> faceFeatureList,
			@Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter, @Nonnull String baseDir,
			@Nonnull ObserverProgressOnDemandWithFile observer, @Nonnull int threshold) {

		this.jobId = jobId;
		this.taskId = taskId;
		this.analysisRsc = analysisRsc;
		this.filePreparer = filePreparer;
		this.sParserAdapter = sParserAdapter;
		this.skips = skips;
		this.thumbPersister = thumbPersister;
		this.faceDataManager = faceDataManager;
		this.hbInnoParameter = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.baseDir = baseDir;
		this.observer = observer;
		this.files = files;
		this.threshold = threshold;
	}

	@Override
	public Void call() {
		FileAnalysisProcessor<AnalysisResource, FaceEvent, TriumiEventContext> task = new SParserHbInnoSearchTaskProcessor(
				this.filePreparer, this.sParserAdapter, this.thumbPersister, this.faceDataManager, this.skips,
				this.hbInnoParameter, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
				this.baseDir, this.observer, this.hbinnoEngine, this.threshold);

		((SParserHbInnoSearchTaskProcessor) task).postConstruct();
		((SParserHbInnoSearchTaskProcessor) task).process(this.jobId, this.taskId, this.analysisRsc);
		((SParserHbInnoSearchTaskProcessor) task).preDestroy();

		return null;

	}
}
