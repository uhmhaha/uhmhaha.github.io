package com.skcc.vas.frs.ondemand.vms.biz;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.event.EventContext;
import com.skcc.vas.frs.common.biz.model.SearchResult;
import com.skcc.vas.frs.common.util.base.TaskStatus;
import com.skcc.vas.frs.common.util.ondemand.TimeRangeRuler;
import com.skcc.vas.frs.ondemand.vms.db.rdb.domain.SearchCriteria;

/**
 * Task means a unit or elementary work of video analysis.
 * <p>
 * A task is specified a single specific camera and a time interval. In most
 * cases, the time interval is determined by system but it can vary from time to
 * time or analysis mode.
 *
 * @author
 * @since 2015-06-17
 */
@NotThreadSafe
public interface SearchTaskProcessor<SC extends SearchCriteria, E extends Event, EC extends EventContext> {

	// @TODO Long term todo, Review to introduce SearchContext encapsulating
	// jobId, taskId and et al.

	/**
	 * @param jobId
	 * @param taskId
	 * @param criteria
	 *            criteria on search such as event type, threshold value and so
	 *            on
	 * @return
	 */
	public SearchResult<E, EC> process(String jobId, String taskId, @Nonnull SC criteria);

	public String getJobId();

	// @TODO Review to replace with int getTaskNo()
	public String getTaskId();

	public SC getCriteria();

	public TaskStatus getStatus();

	public void setTimeRangeRuler(@Nullable TimeRangeRuler ruler);

	/**
	 * Default value for the number of frames to skip after an event is
	 * detected.
	 * <p>
	 * Later another 'process' method can be added that can control the skips at
	 * request scope.
	 *
	 * @see #defaultSkips
	 */
	public int getDefaultSkipsAfterDetect();

	/**
	 * @return
	 * @since 0.9.1
	 */
	public int getNumberOfExceptions();

}
