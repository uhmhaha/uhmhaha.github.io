package com.skcc.vas.frs.ondemand.vms.biz;

import java.util.List;

import com.skcc.vas.frs.akka.model.OndemandVMSSubJob;

public interface OndemandVMSProcessor {

	public List<OndemandVMSSubJob> splitJobs(String jobId, int numOfNode);

	public int search(OndemandVMSSubJob subJob, int nodeId, String masterAddress) throws Exception;

	public int abort(int nodeId, String masterAddress) throws Exception;

}
