package com.skcc.vas.frs.ondemand.db.biz;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.annotation.Async;

import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.db.nosql.service.FaceMatchJobNonSqlService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;

/**
 * @author suhyoung kim
 * @since 2016-09-31
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=triumiHbInnoDBSearchProcessor", description = "Process on-demand search for face recognition.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class TriumiHbInnoDBSearchProcessor extends DBSearchProcessorBase {

	public static final long threadId = Thread.currentThread().getId();// 현재의
	// 쓰레드
	// ID...
	public static final String threadName = Thread.currentThread().getName();// 현재의
	// 쓰레드
	// Name

	private HbInnoParameter hbInnoParam; // config.properties 파일에서 읽어 온 HBInno
	// parameter 값

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
	private final SearchDataManager searchDataManager;

	private final HbinnoEngine hbInnoAdapter;
	private final FaceMatchJobService faceMatchJobService;
	private final FaceMatchJobNonSqlService faceMatchJobNonSqlService;
	private final int MONGODB_LIMIT_COUNT = 30000; // mongodb 에서 3만건씩 조회

	protected HbinnoEngine getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	public TriumiHbInnoDBSearchProcessor(@Nonnull SearchDataManager searchDataMgr,
			@Nonnull FaceDataManager faceDataMgr, @Nonnull HbinnoEngine hbInnoAdapter,
			@Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull FaceMatchJobNonSqlService faceMatchJobNonSqlService, @Nonnull HbInnoParameter hbInnoParam) {

		super(searchDataMgr, faceDataMgr);

		Validate.isTrue(hbInnoAdapter != null, "The FR engine should be provided.");
		this.searchDataManager = searchDataMgr;
		this.hbInnoAdapter = hbInnoAdapter;
		this.faceMatchJobService = faceMatchJobService;
		this.faceMatchJobNonSqlService = faceMatchJobNonSqlService;
		this.hbInnoParam = hbInnoParam;

	}

	private volatile boolean stopped = false;

	@Override
	@Async
	public void search(final String jobId) {
		// 수행시간 테스트
		long startTime = System.currentTimeMillis();
		long endTime;

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);

		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		this.faceMatchJobService.updateJobStartTime(param);

		Boolean bComplete = true;

		SearchRequest req = searchDataManager.findSearchRequest(jobId);
		logger.info(">>>>>>>>>>>>>>>>>>>    START <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		logger.info(" +++++++++++++++++++    Thread Id : {}  +++++++++++++++++", threadId);
		logger.info(" +++++++++++++++++++    Thread Name : {}  +++++++++++++++++", threadName);

		if ("CONTINUOUS".equals(req.getTimeType())) {
			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType : CONTINUOUS <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			bComplete = continuousSearchTask(req);
		} else {
			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType :  Other <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			bComplete = discreteSearchTask(req);
		}

		if (bComplete) {
			// ---------- job end update --------------------------
			// 완료시 상태를 COMPLETED 으로 하고, 진행률을 100%로 한다.
			faceMatchJobService.updateJobEndTime(param);
		}

		endTime = System.currentTimeMillis();

		logger.info(">>>>>>>>>>>>>>>>>>>Total execution time : {}", endTime - startTime);

	}

	private Boolean continuousSearchTask(SearchRequest req) {
		long startTime;
		long endTime;

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", req.getId());
		param.put("job_time_type", req.getTimeType());

		// 수행시간 테스트 start
		// long jobDetailListStartTime = System.currentTimeMillis();
		// long jobDetailLisEendTime;
		// /////////////////
		List<HashMap<String, Object>> jobDetailList = this.faceMatchJobService.findJobDetailListByJobId(param);

		// 수행시간 테스트 end
		// jobDetailLisEendTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total jobDetailList time : {}",
		// jobDetailListStartTime - jobDetailLisEendTime);
		// /////////////////

		// 수행시간 테스트 start
		// long totalCountStartTime = System.currentTimeMillis();
		// long totalCountEndTime;
		// /////////////////
		long totalCount = this.faceMatchJobNonSqlService.countDetectedFaceByJobId(jobDetailList);
		// 수행시간 테스트 end
		// totalCountEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total totalCount time : {}",
		// totalCountStartTime - totalCountEndTime);
		// /////////////////

		long progressCount = 0;

		logger.debug("--------------------------------");
		logger.debug(".........totalCount : {}", totalCount);
		logger.debug("--------------------------------");

		// 진행률 update
		HashMap<String, Object> rateMap = new HashMap<String, Object>();
		rateMap.put("job_id", req.getId());

		// 페이징 처리를 위해 첫번째 id 를 조회
		DetectedFaceMatch firstDetectedFace = faceMatchJobNonSqlService.findDetectedFaceFirstId();
		String start_id = firstDetectedFace.get_id();

		List<DetectedFaceMatch> detectedFaceList;

		HashMap<String, Object> faceMatch = new HashMap<String, Object>();

		// 수행시간 테스트 start
		// long faceFeatureListStartTime = System.currentTimeMillis();
		// long faceFeatureListEndTime;
		// /////////////////
		// Concerned Face feature 조회
		List<HashMap<String, Object>> faceFeatureList = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);
		// 수행시간 테스트 end
		// faceFeatureListEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total faceFeatureList time : {}",
		// faceFeatureListStartTime - faceFeatureListEndTime);
		// /////////////////

		for (HashMap<String, Object> jobDetail : jobDetailList) {

			start_id = firstDetectedFace.get_id();
			param.put("start_id", start_id);
			param.put("start_datetime", (String) jobDetail.get("start_date") + (String) jobDetail.get("start_time"));
			param.put("end_datetime", (String) jobDetail.get("end_date") + (String) jobDetail.get("end_time"));
			param.put("vms_id", (String) jobDetail.get("vms_id"));
			param.put("cctv_id", (String) jobDetail.get("cctv_id"));

			String stopCmd = "";

			do {
				// -------------------------------------- 매번 돌때마다 aborted 인지를
				// 체크한다.

				HashMap<String, Object> stopChkParam = new HashMap<String, Object>();
				stopChkParam.put("job_id", req.getId());

				stopCmd = faceMatchJobService.searchStopStatus(stopChkParam);
				logger.debug("--------------------------------");
				logger.debug(".........stopCmd : {}", stopCmd);
				logger.debug("--------------------------------");

				if (stopCmd.equals("ABORTED")) {
					logger.error(".........STOP.......");
					// throw new
					// RuntimeException("Stopped due to stop command!");
					return false;
				}
				// -----------------------------------------------------------------------------

				// mongodb 전체 대상 데이터 조회
				// 초기화
				detectedFaceList = null;
				// 수행시간 테스트 start
				// long detectedFaceListStartTime = System.currentTimeMillis();
				// long detectedFaceListEndTime;
				// /////////////////
				detectedFaceList = faceMatchJobNonSqlService.findDetectedFaceByCctvId(param, MONGODB_LIMIT_COUNT);
				// 수행시간 테스트 end
				// detectedFaceListEndTime = System.currentTimeMillis();
				// logger.info(">>>>>>>>>>>>>>>>>>>Total detectedFaceListEndTime time : {}",
				// detectedFaceListStartTime - detectedFaceListEndTime);
				// /////////////////
				logger.debug("--------------------------------");
				logger.debug("START ID IS  : {} MONGODB_LIMIT_COUNT : {}", param.get("start_id"), MONGODB_LIMIT_COUNT);
				logger.debug("detectedFaceList SIZE IS : {} ", detectedFaceList.size());
				logger.debug("--------------------------------");

				if (detectedFaceList.size() < 1) {
					logger.info("not exist detected face data in nosql");
					break;
				}

				// 수행시간 테스트 start
				// long totalMatchAndInsertStartTime =
				// System.currentTimeMillis();
				// long totalMatchAndInsertEndTime;

				for (DetectedFaceMatch detectedFace : detectedFaceList) {

					// logger.debug("***********************************hbinno call**************************************");

					startTime = System.currentTimeMillis();
					int matchScore = 0;
					// 테이블 VAS_DETECTED_FACE 와 VAS_CNCRN_FACE 를 비교
					for (HashMap<String, Object> faceFeature : faceFeatureList) {
						/* 비교 */
						try {
							if (req.getThreshold() == -1) {
								logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}",
										detectedFace.get_id(), faceFeature.get("job_cncrn_face_id"));
								matchScore = findMatch((byte[]) faceFeature.get("feature"), detectedFace.getFeature(),
										hbInnoParam.getVerificationThreshold() * 100);
							} else {
								logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}",
										detectedFace.get_id(), faceFeature.get("job_cncrn_face_id"));
								matchScore = findMatch((byte[]) faceFeature.get("feature"), detectedFace.getFeature(),
										req.getThreshold());
							}

						} catch (Exception e) {
							logger.debug("*************************** find match Exception *************************\n"
									+ e.getMessage());
						}

						endTime = System.currentTimeMillis();
						// logger.info(">>>>>>>>>>>>>>>>>>>Compare time time : {}",
						// startTime - endTime);

						// // 수행시간 테스트 start
						// long beforeAInsertStartTime =
						// System.currentTimeMillis();
						// long AfterAInsertEndTime;
						// /////////////////
						// logger.info(">>>>>>>>>>>>>>>>>>>matches.score : {}",matchScore);

						if (matchScore > 0) {
							faceMatch = new HashMap<String, Object>();
							faceMatch.put("job_cncrn_face_id", faceFeature.get("job_cncrn_face_id"));
							faceMatch.put("detected_face_id", detectedFace.getDetectedFaceId());
							faceMatch.put("score", matchScore);

							faceMatch.put("systemId", detectedFace.getSystemId());
							faceMatch.put("cctvId", detectedFace.getCctvId());
							faceMatch.put("srvcType", detectedFace.getSrvcType());
							faceMatch.put("imgFile", detectedFace.getImgFile());
							faceMatch.put("imgW", detectedFace.getImgW());
							faceMatch.put("imgH", detectedFace.getImgH());
							faceMatch.put("imgX", detectedFace.getImgX());
							faceMatch.put("imgY", detectedFace.getImgY());
							faceMatch.put("frmFile", detectedFace.getFrmFile());
							faceMatch.put("frmW", detectedFace.getFrmW());
							faceMatch.put("frmH", detectedFace.getFrmH());
							faceMatch.put("frmTime", detectedFace.getFrmTime());

							/* 결과를 DB 에 저장 */
							this.faceMatchJobService.insertJobFaceMatch(faceMatch);
						} else {
							logger.debug("there is no data to input \n");
						}
						// AfterAInsertEndTime = System.currentTimeMillis();
						// logger.info(">>>>>>>>>>>>>>>>>>> AInsertTime time : {}",
						// beforeAInsertStartTime - AfterAInsertEndTime);
					}

				}

				// 수행시간 테스트 end
				// totalMatchAndInsertEndTime = System.currentTimeMillis();
				// logger.info(">>>>>>>>>>>>>>>>>>>Total 30000 totalMatchAndInsert time : {}",
				// totalMatchAndInsertStartTime - totalMatchAndInsertEndTime);
				// /////////////////

				// 이게 29999번 째 것을 가져온다고 보장이 어렵다?
				start_id = detectedFaceList.get(detectedFaceList.size() - 1).get_id();// for
																						// test
				// logger.info("detectedFaceList.get(detectedFaceList.size() - 30000).get_id() : {}",

				param.put("start_id", start_id);

				// 진행률 update
				progressCount += detectedFaceList.size();
				// logger.debug("++ int progress value : {}",
				// (long)((double)progressCount/totalCount * 100));
				rateMap.put("progress", (long) ((double) progressCount / totalCount * 100));
				faceMatchJobService.updateJobProgressRate(rateMap);

			} while (detectedFaceList.size() >= MONGODB_LIMIT_COUNT);
		}// End of jobDetailList

		return true;

	}

	private Boolean discreteSearchTask(SearchRequest req) {
		long startTime;
		long endTime;

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", req.getId());
		param.put("job_time_type", req.getTimeType());

		// 페이징 처리를 위해 첫번째 id 를 조회
		DetectedFaceMatch firstDetectedFace = faceMatchJobNonSqlService.findDetectedFaceFirstId();
		String start_id;

		List<DetectedFaceMatch> detectedFaceList;
		start_id = firstDetectedFace.get_id();
		param.put("start_id", start_id);

		List<HashMap<String, Object>> jobDetailList = faceMatchJobService.findJobDetailListByJobId(param);

		long totalCount = 0;
		long progressCount = 0;

		// 진행률 update
		HashMap<String, Object> rateMap = new HashMap<String, Object>();
		rateMap.put("job_id", req.getId());

		List<Pair<String, Integer>> matches = new ArrayList<Pair<String, Integer>>();
		HashMap<String, Object> faceMatch = new HashMap<String, Object>();

		// Concerned Face feature 조회
		List<HashMap<String, Object>> faceFeatureList = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		// 조회기간에 해당하는 일자 리스트
		List<String> dateList = fromToDateList(req.getStartDate(), req.getEndDate());
		totalCount = jobDetailList.size() * dateList.size();

		for (HashMap<String, Object> jobDetail : jobDetailList) {
			String start_date = (String) jobDetail.get("start_date");
			String end_date = (String) jobDetail.get("end_date");

			param.put("vms_id", (String) jobDetail.get("vms_id"));
			param.put("cctv_id", (String) jobDetail.get("cctv_id"));

			String start_time2 = (String) jobDetail.get("start_time2");

			for (String date : dateList) {

				param.put("start_datetime", date + (String) jobDetail.get("start_time"));
				param.put("end_datetime", date + (String) jobDetail.get("end_time"));

				// 2번째 조회 시간이 있을 경우 조회 조건에 추가
				if (start_time2 != null) {
					param.put("start_datetime2", date + (String) jobDetail.get("start_time2"));
					param.put("end_datetime2", date + (String) jobDetail.get("end_time2"));
				} else {
					param.put("start_datetime2", null);
				}

				logger.info("== jobDetail : start_date {} , end_date {}, vms_id{},  cctv_id{}, start_time2{} "
						+ jobDetail.get("start_date"), jobDetail.get("end_date"), jobDetail.get("vms_id"),
						jobDetail.get("cctv_id"), jobDetail.get("start_time2"));

				logger.info("== param : vms_id {} , cctv_id {}, start_datetime{},  end_datetime{}, start_datetime2{} "
						+ param.get("vms_id"), param.get("cctv_id"), param.get("start_datetime"),
						param.get("end_datetime"), param.get("start_datetime2"));

				String stopCmd = "";

				do {
					// -------------------------------------- 매번 돌때마다 aborted
					// 인지를 체크한다.
					HashMap<String, Object> stopChkParam = new HashMap<String, Object>();
					stopChkParam.put("job_id", req.getId());

					stopCmd = faceMatchJobService.searchStopStatus(stopChkParam);
					logger.debug("--------------------------------");
					logger.debug(".........stopCmd : {}", stopCmd);
					logger.debug("--------------------------------");

					if (stopCmd.equals("ABORTED")) {
						logger.error(".........STOP.......");
						// throw new
						// RuntimeException("Stopped due to stop command!");
						return false;
					}
					// -----------------------------------------------------------------------------

					// mongodb 조회
					detectedFaceList = null;
					detectedFaceList = faceMatchJobNonSqlService.findDetectedFaceByCctvId(param, MONGODB_LIMIT_COUNT);

					if (detectedFaceList.size() < 1) {
						break;
					}

					for (DetectedFaceMatch detectedFace : detectedFaceList) {

						// logger.debug("***********************************hbinno call**************************************");

						startTime = System.currentTimeMillis();
						int matchScore = 0;

						// 테이블 VAS_DETECTED_FACE 와 VAS_CNCRN_FACE 를 비교
						for (HashMap<String, Object> faceFeature : faceFeatureList) {

							/* 비교 */
							try {
								if (req.getThreshold() == -1) {
									logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}",
											detectedFace.get_id(), faceFeature.get("id"));
									matchScore = findMatch((byte[]) faceFeature.get("feature"),
											detectedFace.getFeature(), hbInnoParam.getVerificationThreshold());
								} else {
									// logger.debug("***** faceFeature get( *************************\n {}"
									// + faceFeature.get("job_cncrn_face_id"));
									// matches = findMatch((byte[])
									// faceFeature.get("feature"),
									// 30000,req.getThreshold());
									logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}",
											detectedFace.get_id(), faceFeature.get("id"));
									matchScore = findMatch((byte[]) faceFeature.get("feature"),
											detectedFace.getFeature(), req.getThreshold());
								}
							} catch (Exception e) {
								logger.debug("***********************************matches**************************************\n"
										+ e.getMessage());
							}

							endTime = System.currentTimeMillis();

							logger.info(">>>>>>>>>>>>>>>>>>>compareFeaturesOndemand 실행 시간 : {}", endTime - startTime);
							logger.info(">>>>>>>>>>>>>>>>>>>matches.size() : {}", matches.size());

							if (matchScore > 0) {

								faceMatch = new HashMap<String, Object>();

								faceMatch.put("job_cncrn_face_id", faceFeature.get("job_cncrn_face_id"));
								faceMatch.put("detected_face_id", detectedFace.getDetectedFaceId());
								faceMatch.put("score", matchScore);

								faceMatch.put("systemId", detectedFace.getSystemId());
								faceMatch.put("cctvId", detectedFace.getCctvId());
								faceMatch.put("srvcType", detectedFace.getSrvcType());
								faceMatch.put("imgFile", detectedFace.getImgFile());
								faceMatch.put("imgW", detectedFace.getImgW());
								faceMatch.put("imgH", detectedFace.getImgH());
								faceMatch.put("imgX", detectedFace.getImgX());
								faceMatch.put("imgY", detectedFace.getImgY());
								faceMatch.put("frmFile", detectedFace.getFrmFile());
								faceMatch.put("frmW", detectedFace.getFrmW());
								faceMatch.put("frmH", detectedFace.getFrmH());
								faceMatch.put("frmTime", detectedFace.getFrmTime());

								/* 결과를 DB 에 저장 */
								this.faceMatchJobService.insertJobFaceMatch(faceMatch);
							}

							logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>detectedFaceList count : {}",
									detectedFaceList.size());

						}
					}

					start_id = detectedFaceList.get(detectedFaceList.size() - 1).get_id();
					param.put("start_id", start_id);

				} while (detectedFaceList.size() >= MONGODB_LIMIT_COUNT);

				// 진행률 update
				progressCount++;
				rateMap.put("progress", (long) ((double) progressCount / totalCount * 100));

				logger.debug("totalCount : {}, progressCount : {}, progress : {}", totalCount, progressCount,
						(long) ((double) progressCount / totalCount * 100));
				faceMatchJobService.updateJobProgressRate(rateMap);
			}
		}// End of

		return true;
	}

	public List<String> fromToDateList(String strStartDate, String strEndDate) {
		List<String> dateList = new ArrayList<String>();
		DateFormat formatter = new SimpleDateFormat("yyyyMMdd"); // 2016093009

		try {
			List<Date> dates = new ArrayList<Date>();

			Date startDate = (Date) formatter.parse(strStartDate);
			Date endDate = (Date) formatter.parse(strEndDate);

			long interval = 24 * 1000 * 60 * 60; // 1 hour in millis
			long endTime = endDate.getTime();
			long curTime = startDate.getTime();

			while (curTime <= endTime) {
				dates.add(new Date(curTime));
				curTime += interval;
			}

			for (int i = 0; i < dates.size(); i++) {
				Date lDate = (Date) dates.get(i);
				String ds = formatter.format(lDate);
				dateList.add(ds);
			}

		} catch (Exception ex) {
			return null;
		}

		return dateList;
	}

	private int findMatch(@Nonnull byte[] sourceFeature, @Nonnull byte[] targetFeature, float threshold)
			throws Exception {
		// logger.info("++ findfindMatch ");
		float floatScore = this.getHbInnoAdapter().verify(sourceFeature, targetFeature); // ex.
		// limitCount
		int intScore = 0;

		if (threshold > floatScore * 100) {

			logger.debug("findMatch() , there is no score over threshold. score {}, threshold {}", floatScore * 100,
					threshold);
			return 0;

		} else {

			intScore = (int) Math.round(floatScore * 100);

			return intScore;

		}

	}

	@Override
	public void stop(Boolean bVal) {
		logger.info("++STOP      COMMAND      INPUT  ");

		// Set<Thread> setOfThread = Thread.getAllStackTraces().keySet();
		//
		// //Iterate over set to find yours
		// //전역변수에 있는 쓰레드와 같은 ID 이면 중단시켜라.
		// for(Thread thread : setOfThread){
		// if(thread.getId()==threadId){
		// thread.interrupt();//중단.
		// }
		// }

		// Future<TestClass> test = null;
		// try {
		// test = TriumiHbInnoDBSearchProcessor.testCancelFuture();
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// test.cancel(true); //중단.

	}

	@Override
	public void updStatus(String jobId, String rsltStts) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);
		param.put("rslt_stts", rsltStts);
		if (rsltStts.equals("ABORTED")) {
			param.put("rslt_stts_desc", "ondemand aborted!");
		}
		faceMatchJobService.updateJobStatus(param);

	}

}