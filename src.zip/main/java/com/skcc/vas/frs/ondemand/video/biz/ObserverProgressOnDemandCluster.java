package com.skcc.vas.frs.ondemand.video.biz;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;

import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;

public class ObserverProgressOnDemandCluster {

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private FaceMatchJobService faceMatchJobService;

	private SearchDataManager searchDataMgr;

	public SearchDataManager getSearchDataManager() {
		return this.searchDataMgr;
	}

	private String jobId;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	private Map<String, ProgressForClusterTask> progressTasks;

	public Map<String, ProgressForClusterTask> getProgressTasks() {
		return progressTasks;
	}

	// new member
	private boolean isAborted;

	public boolean isAborted() {
		return isAborted;
	}

	public void setAborted(boolean isAborted) {
		this.isAborted = isAborted;
	}

	public ObserverProgressOnDemandCluster(@Nonnull FaceMatchJobService faceMatchJobService,
			SearchDataManager searchDataMgr) {
		progressTasks = new HashMap<String, ProgressForClusterTask>();
		this.faceMatchJobService = faceMatchJobService;
		this.searchDataMgr = searchDataMgr;
		this.isAborted = false;
	}

	// 최초 영상 파일 획득시 실행함
	public synchronized void addTotalFilesForTask(String dirAndTaskId, int totalFilesCnt, float potionOfProgress) {
		ProgressForClusterTask totalFiles = new ProgressForClusterTask();
		totalFiles.setCompletedFilesCnt(0);
		totalFiles.setTotalFilesCnt(totalFilesCnt);
		totalFiles.setPortionOfProgress(potionOfProgress);
		progressTasks.put(dirAndTaskId, totalFiles);

		if (progressTasks != null && progressTasks.size() > 0) {
			for (String key1 : progressTasks.keySet()) {
				this.logger.info("key: [{}] -------------->  progressTasks: {} / {}", key1, progressTasks.get(key1)
						.getCompletedFilesCnt(), progressTasks.get(key1).getTotalFilesCnt());
			}
		}
	}

	public synchronized void setProgressCompletedFilesForTask(String dirAndTaskId, int completedFiles) {

		ProgressForClusterTask progressForTask = this.getProgressTasks().get(dirAndTaskId);

		int completedFilesCnt = progressForTask.getCompletedFilesCnt() + 1;
		progressForTask.setCompletedFilesCnt(completedFilesCnt);
		progressTasks.put(dirAndTaskId, progressForTask);

		// 퍼센테이지 산출
		int totalFilesCntForJob = 0;
		for (String key1 : progressTasks.keySet()) {
			totalFilesCntForJob += progressTasks.get(key1).getTotalFilesCnt();
		}
		this.logger.info("--------------> totalFilesCntForJob: {}", totalFilesCntForJob);

		int completedFilesCntForJob = 0;
		for (String key2 : progressTasks.keySet()) {
			completedFilesCntForJob += progressTasks.get(key2).getCompletedFilesCnt();
		}
		this.logger.info("--------------> completedFilesCntForJob: {}", completedFilesCntForJob);

		// DB에 적기
		long progressRate = (long) (((double) completedFilesCntForJob / totalFilesCntForJob) * 100);
		this.logger.info("--------------> progressRate: {}", progressRate);

		// if( progressRate > 20 ){
		// 새로이 조회를 하고 거기에다 누적으로 더해서 업데이트 치는 방식을 넣자.
		// HashMap<String, Object> rateMap = new HashMap<String, Object>();
		// rateMap.put("job_id", jobId);
		// rateMap.put("progress", progressRate);
		// faceMatchJobService.updateJobProgressRate(rateMap);
		// }

		// if( progressRate > 10 ){
		// SearchRequest jobRequestInfo =
		// this.getSearchDataManager().findSearchRequest(jobId);
		// if(jobRequestInfo == null){
		// final String msg =
		// String.format("The search job[id: %1$s] can't be found.", jobId);
		// throw new IllegalStateException(msg);
		// }
		//
		// float prevProgress = jobRequestInfo.getProgress();
		// // float nowProgress = prevProgress + (progressRate *
		// progressForTask.getPortionOfProgress());
		// float nowProgress =
		// (float)((float)(progressForTask.getPortionOfProgress() *
		// progressRate) / progressTasks.size()); //4가 필요함
		//
		// HashMap<String, Object> updateRateparam = new HashMap<String,
		// Object>();
		// updateRateparam.put("job_id", this.getJobId()); //nodeId濡�諛붽퓭����//
		// updateRateparam.put("progress", nowProgress);
		// faceMatchJobService.updateJobProgressRate(updateRateparam);
		// }
	}
}

class ProgressForClusterTask {

	private int totalFilesCnt;

	private int completedFilesCnt;

	private float portionOfProgress;

	public int getTotalFilesCnt() {
		return totalFilesCnt;
	}

	public void setTotalFilesCnt(int totalFilesCnt) {
		this.totalFilesCnt = totalFilesCnt;
	}

	public int getCompletedFilesCnt() {
		return completedFilesCnt;
	}

	public void setCompletedFilesCnt(int completedFilesCnt) {
		this.completedFilesCnt = completedFilesCnt;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}

	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}
}
