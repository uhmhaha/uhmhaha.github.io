package com.skcc.vas.frs.ondemand.vms.biz;

import java.util.Date;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.skcc.adapter.vms.incon.FsUtilTypes.TimeStamp;
import com.skcc.adapter.vms.incon.TriumiUtils;
import com.skcc.vas.frs.common.biz.event.EventContext;

/**
 * Context for the found event when using Trium-i.
 *
 * @see com.skcc.nexcore.adapter.vms.triumi.FsUtilTypes.VideoFrameHeader
 * @see com.skcc.nexcore.adapter.vms.triumi.FsUtilTypes.VideoFrameData
 * @author
 * @since 2015-06-19
 */
@Immutable
public class TriumiEventContext implements EventContext {

	/**
	 * The ID of device, usually camera.
	 */
	private int deviceId;

	/**
	 * The full absolute path for the video file containing the event.
	 */
	private String filePath;

	private long framePosition;

	private long keyFramePosition;

	/** time at server */
	private Date frameTime;

	/** time at camera */
	private Date deviceTime;

	/** size of decoded frame data */
	private long frameSize;

	private int frameWidth;

	private int frameHeight;

	public TriumiEventContext(int devId, String filePath, long frmPos, long keyFrmPos, TimeStamp frmTime,
			TimeStamp devTime, @Nonnull TimeZone tz, long frmSize, int frmWidth, int frmHeight) {
		super();
		this.deviceId = devId;
		this.filePath = filePath;
		this.framePosition = frmPos;
		this.keyFramePosition = keyFrmPos;
		this.frameSize = frmSize;
		this.frameWidth = frmWidth;
		this.frameHeight = frmHeight;

		this.frameTime = TriumiUtils.convertTimeStampToDate(frmTime, tz);
		this.deviceTime = TriumiUtils.convertTimeStampToDate(devTime, tz);
	}

	public int getDeviceId() {
		return deviceId;
	}

	public String getFilePath() {
		return filePath;
	}

	public long getFramePosition() {
		return framePosition;
	}

	public long getKeyFramePosition() {
		return keyFramePosition;
	}

	public Date getFrameTime() {
		return frameTime;
	}

	public Date getDeviceTime() {
		return deviceTime;
	}

	public long getFrameSize() {
		return frameSize;
	}

	public int getFrameWidth() {
		return frameWidth;
	}

	public int getFrameHeight() {
		return frameHeight;
	}
}
