package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.ning.http.client.AsyncHttpClient;
import com.skcc.adapter.vms.incon.FsUtilAdapter;
import com.skcc.adapter.vms.incon.InteropLiveAdapter;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngineOndemandVMSFile;
import com.skcc.vas.frs.akka.model.OndemandVMSSubJob;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.SearchProgressListener;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Cctv;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.base.Point;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.ondemand.vms.model.SimpleSearchCriteria;

@ManagedResource(objectName = "vas:type=bean,name=triumiHbInnoClusterSearchJobProcessor", description = "Process on-demand search for face recognition in cluster.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class TriumiHbInnoClusterSearchJobProcessor implements OndemandVMSProcessor {

	public static final int UNIT_TIME_DEFAULT = 10;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private String jobId;

	public String getJobId() {
		return this.jobId;
	}

	private Map<String, byte[]> faceFeatureList;

	public Map<String, byte[]> getFaceFeatureList() {
		return this.faceFeatureList;
	}

	private SearchDataManager searchDataMgr;

	public SearchDataManager getSearchDataManager() {
		return this.searchDataMgr;
	}

	private FaceMatchJobService faceMatchJobService;

	public FaceMatchJobService getFaceMatchJobService() {
		return this.faceMatchJobService;
	}

	private OnDemandWithFileParameter demandWithFileParameter;

	public OnDemandWithFileParameter getDemandWithFileParameter() {
		return demandWithFileParameter;
	}

	private HbinnoEngineOndemandVMSFile hbinnoEngineInstance;

	private volatile int skips;

	private float portionOfProgress;

	public int getSkips() {
		return this.skips;
	}

	private volatile FilePreparer filePreparer;

	public FilePreparer getFilePreparer() {
		return this.filePreparer;
	}

	private ThumbnailPersister thumbnailPersister;

	public ThumbnailPersister getThumbnailPersister() {
		return this.thumbnailPersister;
	}

	private HbInnoParameter hbInnoParam;

	public HbInnoParameter getHbInnoParam() {
		return this.hbInnoParam;
	}

	private FaceDataManager faceDataManager;

	public FaceDataManager getFaceDataManager() {
		return faceDataManager;
	}

	private ExecutorService executor;

	private List<Future<Void>> futures;

	private String pattern = DirectAccessFilePreparer.DEFAULT_DEVICE_DIR_PATTERN;

	private List<ObserverProgressOnDemandCluster> observers = new ArrayList<ObserverProgressOnDemandCluster>();

	private AsyncHttpClient asyncHttpClient;

	private int taskNum,threadCoreNum,threadMaxNum;

	public void setTaskNum(int taskNum) {
		this.taskNum = taskNum;
	}

	// @Value("${vas.ondemand.vms.thread.core}")
	private int threadNum;
	private VasConfigService configService;

	public TriumiHbInnoClusterSearchJobProcessor(SearchDataManager searchDataMgr,
			FaceMatchJobService faceMatchJobService, OnDemandWithFileParameter demandWithFileParameter,
			HbinnoEngineOndemandVMSFile hbinnoEngineInstance, @Min(0) int skips, FilePreparer filePreparer,
			ThumbnailPersister thumbnailPersister, ThreadPoolTaskExecutor taskExecutor, HbInnoParameter hbInnoParam,
			FaceDataManager faceDataManager, @Nonnull VasConfigService configService) {

		this.searchDataMgr = searchDataMgr;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.hbinnoEngineInstance = hbinnoEngineInstance;
		this.skips = skips;
		this.filePreparer = filePreparer;
		this.thumbnailPersister = thumbnailPersister;
		this.hbInnoParam = hbInnoParam;
		this.faceDataManager = faceDataManager;
		
		String threadCoreNumStr = configService.getConfigValByName("vas.ondemand.vms.thread.core");
		String threadMaxNumStr = configService.getConfigValByName("vas.ondemand.vms.thread.max");

		threadCoreNum = taskExecutor.getCorePoolSize();
		if(threadCoreNumStr != "" && threadCoreNumStr != null) {
			threadCoreNum = Integer.parseInt(threadCoreNumStr);
		}
		else {
			throw new IllegalStateException("+++++ Ondemand VMS Thread value is empty. Enter values in VAS_CONF_NODE table.");
		}
		
		threadMaxNum = taskExecutor.getMaxPoolSize();
		if(threadMaxNumStr != "" && threadMaxNumStr != null) {
			threadMaxNum = Integer.parseInt(threadMaxNumStr);
		}
		else {
			throw new IllegalStateException("+++++ Ondemand VMS Thread is value empty. Enter values in VAS_CONF_NODE table.");
		}

		taskExecutor.setCorePoolSize(threadCoreNum);
		taskExecutor.setMaxPoolSize(threadMaxNum);
		
		this.executor = new ExecutorServiceAdapter(taskExecutor);

		this.asyncHttpClient = new AsyncHttpClient();

		this.configService = configService;
	}

	public void initConfig() {
		// @Value("${vas.ondemand.vms.thread.core}")
		threadNum = Integer.parseInt(configService.getConfigValByName("vas.ondemand.vms.thread.core"));

	}

	@Override
	public List<OndemandVMSSubJob> splitJobs(String jobId, int numOfNode) {

		if (numOfNode < 1) {
			final String msg = String.format("There is no usable worker node for ondemand vms!! - numOfNoe: {}",
					numOfNode);
			throw new IllegalArgumentException(msg);
		}

		// 시간 쪼개질 때 -9시간을 해놓고 쪼갠다.
		this.jobId = jobId;

		final SearchRequest req = this.getSearchDataManager().findSearchRequest(jobId);
		if (req == null) {
			final String msg = String.format("The search job[id: %1$s] can't be found.", jobId);
			throw new IllegalStateException(msg);
		}

		final List<Cctv> cctvs = req.getCctvs();
		final String start = req.getStart();
		final String end = req.getEnd();

		if (cctvs.isEmpty()) {
			final String msg = String.format("The search job[id: %1$s] contains NO CCTV.", jobId);
			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(start)) {
			final String msg = String.format("The start time for the search is not specified.");
			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(end)) {
			final String msg = String.format("The end time for the search is not specified.");
			throw new IllegalArgumentException(msg);
		} else if (StringUtils.equals(start, end)) {
			final String msg = String.format("The time interval has NO duration. Start is same with end.");
			throw new IllegalArgumentException(msg);
		} else {
			this.logger.info(
					"Found a search job. - id: {}, name: {}, type: {}, start: {}, end: {}, cctvs: {}, threshold: {}",
					req.getId(), req.getName(), req.getType(), req.getStart(), req.getEnd(), req.getCctvs().size(),
					req.getThreshold());
		}

		// split된 job들 담음
		List<OndemandVMSSubJob> ondemandVMSSubJobs = new ArrayList<OndemandVMSSubJob>();

		for (Cctv cctv : cctvs) {
			if (cctv.getRois().size() > 1) {
				final String msg = String.format("Multiple ROIs can't be specified yet.");
				throw new IllegalArgumentException(msg);
			}

			int num = 0;
			if (cctv.getRois().size() == 1) {
				num = cctv.getRois().get(0).getPoints().size();
				if (num != 0 && num != 4) {
					final String msg = String.format("The ROI should be rectangle or entire screen.");
					throw new IllegalArgumentException(msg);
				}
			}
		}

		// in split method, the gapTime is only considered without cctv
		Date from = BaseUtils.validateYear2MinString(start);
		Date to = BaseUtils.validateYear2MinString(end);
		long gapTime = ((to.getTime() - from.getTime())) / 60000; // per minute,
																	// 복수의 cctv도
																	// 감안해야 함. *
																	// cctvs.size()
																	// task에서
																	// 해주므로 일단
																	// 배제
		double dSubJobUnitTime = gapTime / (double) numOfNode;
		int subJobUnitTime = (int) Math.ceil(dSubJobUnitTime);

		if (subJobUnitTime == 0) {
			final String msg = String.format(
					"Interval between startTime to endTime is too short!! Please, enter the long interval!! - {} ~ {}",
					start, end);
			throw new IllegalArgumentException(msg);
		}

		List<Pair<String, String>> subs = new ArrayList<Pair<String, String>>();

		if ("CONTINUOUS".equals(req.getTimeType())) {
			subs = BaseUtils.splitInterval(start, end, subJobUnitTime);
		} else {
			String startDate = (String) start.substring(0, 8);
			String endDate = (String) end.substring(0, 8);
			// 조회기간에 해당하는 일자 리스트
			List<String> dateList = BaseUtils.fromToDateList(startDate, endDate);

			for (String date : dateList) {
				String tempStartTime = date + start.substring(8, 12);
				String tempEndTime = date + end.substring(8, 12);

				List<Pair<String, String>> tmpSubs = BaseUtils
						.splitInterval(tempStartTime, tempEndTime, subJobUnitTime);
				for (Pair<String, String> sub : tmpSubs)
					subs.add(sub);
			}
		}

		this.faceFeatureList = getFeatures(req.getId());

		final int total = (subs.size()) * cctvs.size();
		final int splitTotal = subs.size();
		this.logger.info("Partitioned a face search job. - id: {}, # of time split partitions: {}, # of total: {}",
				req.getId(), splitTotal, total);

		// 여기서 total이 numOfNode보다 크면 분산처리가 불가능
		float portionOfProgress = 0.0f;
		float lastPortionOfProgress = 0.0f;
		int portionOfProgressInt = 0;
		int lastPortionOfProgressInt = 0;

		portionOfProgressInt = 100 / splitTotal; // portionOfPrgress 산출하는 로직 필요
		portionOfProgress = (float) (portionOfProgressInt * 0.01);

		// 전체 작업량이 100%가 되는지 체크
		int allPortionOfProgressInt = portionOfProgressInt * splitTotal;
		if (allPortionOfProgressInt < 100) {
			lastPortionOfProgressInt = portionOfProgressInt + (100 - allPortionOfProgressInt);
			lastPortionOfProgress = (float) (lastPortionOfProgressInt * 0.01);
		}

		SimpleSearchCriteria srchCrtr = null;
		int taskId = 1;

		for (Pair<String, String> sub : subs) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				logger.error("Sleep error");
			}

			if (faceFeatureList.size() > 0 && cctvs.size() > 0) {
				// OndemandVMSSubJob 생성
				List<Cctv> subJobCctvs = new ArrayList<SearchRequest.Cctv>();
				OndemandVMSSubJob subJob = new OndemandVMSSubJob(portionOfProgress, jobId, this.faceFeatureList, cctvs,
						req.getThreshold(), sub.getLeft(), sub.getRight(), req.getTimeType());
				ondemandVMSSubJobs.add(subJob);

			} else {
				for (Cctv cctv : cctvs) {
					logger.warn("This job for cctvId {} have no any concerned face!!", cctv.getId());
				}
			}
		}

		if (ondemandVMSSubJobs.size() > 0 && allPortionOfProgressInt < 100) {
			OndemandVMSSubJob lastSubJob = ondemandVMSSubJobs.get(ondemandVMSSubJobs.size() - 1);
			ondemandVMSSubJobs.remove(ondemandVMSSubJobs.size() - 1);
			lastSubJob.setPortionOfProgress(lastPortionOfProgress);
			ondemandVMSSubJobs.add(lastSubJob);
		}

		return ondemandVMSSubJobs;
	}

	@Override
	public int search(OndemandVMSSubJob subJob, int nodeId, String masterAddress) throws Exception {

		this.logger.info("This VMS subJob's masterAddress: {}, node: {}", masterAddress, nodeId);

		final String jobId = subJob.getJobId();
		final List<Cctv> cctvs = subJob.getCctvs();
		final String start = subJob.getAnalysisTimeFrom();
		final String end = subJob.getAnalysisTimeTo();
		final String timeType = subJob.getTimeType();

		if (cctvs.isEmpty()) {
			final String msg = String.format("The search job[id: %1$s] contains NO CCTV.", jobId);
			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(start)) {
			final String msg = String.format("The start time for the search is not specified.");
			throw new IllegalArgumentException(msg);
		} else if (StringUtils.isBlank(end)) {
			final String msg = String.format("The end time for the search is not specified.");
			throw new IllegalArgumentException(msg);
		} else {
			this.logger.info("Found a search job. - id: {}, start: {}, end: {}, cctvs: {}, threshold: {}",
					subJob.getJobId(), start, end, cctvs.size(), subJob.getThreshold());
		}

		// Observer 생성
		ObserverProgressOnDemandCluster observer = new ObserverProgressOnDemandCluster(faceMatchJobService,
				this.getSearchDataManager());
		observer.setJobId(jobId);
		observers.add(observer);

		List<ClusterSearchTask> tasks = new ArrayList<ClusterSearchTask>();

		Date from = BaseUtils.validateYear2MinString(start);
		Date to = BaseUtils.validateYear2MinString(end);
		long gapTime = (to.getTime() - from.getTime()) / 60000; // per minute
		double dUnitTime = gapTime / (double) threadNum;
		int unitTime = (int) Math.ceil(dUnitTime);
		this.logger.info("^^^^^^^^^^^^^^^^^^^^^^^^^^^^ gapTime: {}, threadNum: {}, unitTime: {}", gapTime, threadNum,
				unitTime);

		for (Cctv cctv : cctvs) {
			if (cctv.getRois().size() > 1) {
				final String msg = String.format("Multiple ROIs can't be specified yet.");
				throw new IllegalArgumentException(msg);
			}

			int num = 0;
			if (cctv.getRois().size() == 1) {
				num = cctv.getRois().get(0).getPoints().size();
				if (num != 0 && num != 4) {
					final String msg = String.format("The ROI should be rectangle or entire screen.");
					throw new IllegalArgumentException(msg);
				}
			}
		}

		List<Pair<String, String>> subs = new ArrayList<Pair<String, String>>();

		if ("CONTINUOUS".equals(timeType)) {
			subs = BaseUtils.splitInterval(start, end, unitTime);
		} else {

			String startDate = (String) start.substring(0, 8);
			String endDate = (String) end.substring(0, 8);
			// 조회기간에 해당하는 일자 리스트
			List<String> dateList = BaseUtils.fromToDateList(startDate, endDate);

			for (String date : dateList) {
				String tempStartTime = date + start.substring(8, 12);
				String tempEndTime = date + end.substring(8, 12);

				List<Pair<String, String>> tmpSubs = BaseUtils.splitInterval(tempStartTime, tempEndTime, unitTime);
				for (Pair<String, String> sub : tmpSubs)
					subs.add(sub);
			}
		}

		this.faceFeatureList = subJob.getConcernFaces();

		final int total = (subs.size()) * cctvs.size();
		this.logger.info("Partitioned a face search job. - id: {}, # of partitions: {}", jobId, total);

		List<Point<Float>> points = null;
		SimpleSearchCriteria srchCrtrForTask = null;
		int taskId = 1;

		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		HashMap<String, Object> startJobParam = new HashMap<String, Object>();
		startJobParam.put("job_id", jobId);
		this.faceMatchJobService.updateJobStartTime(startJobParam);

		int cctvIdx = 0;
		for (Cctv cctv : cctvs) {
			cctvIdx++;
			for (Pair<String, String> sub : subs) {
				points = new ArrayList<Point<Float>>(4);
				if (cctv.getRois().size() == 1) {
					for (SearchRequest.Point pt : cctv.getRois().get(0).getPoints()) {
						points.add(new Point(pt.getX(), pt.getY()));
					}
				} else {
					points.add(new Point(0.0f, 0.0f));
					points.add(new Point(0.0f, 1.0f));
					points.add(new Point(1.0f, 1.0f));
					points.add(new Point(1.0f, 0.0f));
				}

				srchCrtrForTask = new SimpleSearchCriteria(cctv.getSystemId(), cctv.getId(), sub.getLeft(),
						sub.getRight(), points.get(0), points.get(1), points.get(2), points.get(3),
						subJob.getThreshold());

				TriumiVideoStore.FileValue[] files = new TriumiVideoStore.FileValue[0];

				final InteropLiveAdapter interopLiveAdapter = new InteropLiveAdapter();
				int fileControlHandle = interopLiveAdapter.addRecordData(Integer.parseInt(cctv.getId()), sub.getLeft()
						+ "00", sub.getRight() + "00");

				// Handle 정보를 가져오기 위해 Sleep
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					logger.error("Sleep error");
				}

				ArrayList<String> filePaths = (java.util.ArrayList<String>) interopLiveAdapter.getDownloadFileInfo(
						fileControlHandle, Integer.parseInt(srchCrtrForTask.getDeviceId()));

				if (filePaths == null) {
					this.logger.warn("VMS File is not exist - CCTV ID : {}", srchCrtrForTask.getDeviceId());
					continue;
				}

				files = new TriumiVideoStore.FileValue[filePaths.size()];

				for (int j = 0; j < filePaths.size(); j++) {
					//will be deleted code, only to test!!!!!!!!!!
					String oldFilePath = filePaths.get(j).toString();
					String newFilePath = oldFilePath.replace("192.168.1.5", "10.250.46.209");
					
					//will be modified code, only to test!!!!!!!!!!
					TriumiVideoStore.FileValue file = new TriumiVideoStore.FileValue(j, newFilePath);
					logger.debug("File Path : {}", newFilePath);
					files[j] = file;
				}

				if (faceFeatureList.size() > 0 && files.length > 0) {
					// @TODO Need further implementation.
					final FsUtilAdapter fsUtilAdapter = new FsUtilAdapter();

					tasks.add(new ClusterSearchTask(jobId, String.valueOf(taskId), srchCrtrForTask, this.filePreparer,
							fsUtilAdapter, this.skips, this.thumbnailPersister, this.getFaceDataManager(), null,
							this.hbInnoParam, this.faceFeatureList, this.faceMatchJobService,
							this.demandWithFileParameter, observer, files, nodeId, masterAddress, searchDataMgr,
							this.asyncHttpClient));

					// observe 전체파일 갯수 세팅
					String dirAndTaskId = new StringBuffer().append(cctv.getSystemId()).append("_")
							.append(cctv.getId()).append("_").append(taskId).toString();
					if (files.length > 0) {
						observer.addTotalFilesForTask(dirAndTaskId, files.length, subJob.getPortionOfProgress());
					}
					taskId++;

				} else {
					logger.warn(
							"This task for cctvId {} have no any concerned face or files!!- jobId: {}, from: {} ~ to: {}",
							this.jobId, sub.getLeft(), sub.getRight());
				}
			}

			int tmpSizeOftasks = tasks.size();

			if (tmpSizeOftasks == 0) {
				String failedMessage = String
						.format("No any concerned face or files for this for cctvID {} on this subJob - jobId: {}, from: {} ~ to: {}",
								cctv.getId(), this.jobId, start, end);
				logger.warn(failedMessage);
			}

		}

		int sizeOftasks = tasks.size();
		List<Future<Void>> futures = new ArrayList<Future<Void>>(sizeOftasks);

		if (sizeOftasks == 0) {
			String failedMessage = String.format(
					"No any concerned face or files on this subJob - jobId: {}, from: {} ~ to: {}", this.jobId, start,
					end);
			// sendCompletedTaskMessage(masterAddress, "ONDEMAND_VMS_RESULT",
			// this.getJobId(), nodeId, -1, failedMessage);
			throw new RuntimeException(
					"Fail to start vms job because any task is not made or the vms path cannot access by not logining!! - "
							+ this.jobId);
		}

		int i = 0;
		for (ClusterSearchTask task : tasks) {
			try {

				i++;
				logger.info("{} 's task!!", i);
				task.setHbinnoEngine(this.hbinnoEngineInstance);
				task.setTaskNum(sizeOftasks);
				futures.add(this.executor.submit(task));

			} catch (Throwable ex) {
				String failedMessage = String.format(
						"Fail to submit a face search task for ondemand VMS. - jobId: {}, taskId: {}", task.getJobId(),
						task.getTaskId());
				sendCompletedTaskMessage(masterAddress, "ONDEMAND_VMS_RESULT", this.getJobId(), nodeId, -1,
						failedMessage);
				this.logger.error("Fail to submit a face search task. - jobId: {}, taskId: {}", task.getJobId(),
						task.getTaskId());
				this.logger.error(">>>>>>>>>>>> {}", ex);
			}

		}

		return tasks.size(); // search가 끝난 스레드의 갯수 리턴
	}

	@Override
	public int abort(int nodeId, String masterAddress) throws Exception {
		logger.info("++STOP      Ondemand VMS      COMMAND      INPUT  ");

		for (ObserverProgressOnDemandCluster observer : observers) {
			observer.setAborted(true);
		}

		String jobId = null;
		if (observers.size() > 0) {
			jobId = observers.get(0).getJobId();
		} else {
			jobId = "";
		}

		String abortMessage = String.format("nodeId {} is Aborted by user!!", nodeId);
		sendCompletedTaskMessage(masterAddress, "ONDEMAND_VMS_ABORT_RESULT", jobId, nodeId, 1, abortMessage);
		return 1;
	}

	public void destroy() {
		if (this.executor != null && !(this.executor instanceof ExecutorServiceAdapter)) {
			this.executor.shutdown();
		}
	}

	/*
	 * VAS_JOB_CNCRN_FACE의 face id 값에 해당되는 feature 정보를 VAS_CNCRN_FACE table에서
	 * 가져온다
	 */
	private Map<String, byte[]> getFeatures(String jobId) {

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);

		/*
		 * String: face id Object: byte[] feature
		 */
		List<HashMap<String, Object>> faceFeatures = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		Map<String, byte[]> concernFaces = new HashMap<String, byte[]>();
		for (HashMap<String, Object> faceFeature : faceFeatures) {
			concernFaces.put(String.valueOf(faceFeature.get("job_cncrn_face_id")), (byte[]) faceFeature.get("feature"));
		}

		return concernFaces;
	}

	private void sendCompletedTaskMessage(String masterAddress, String type, String jobId, int nodeId, int result,
			String message) {

		AsyncHttpClient.BoundRequestBuilder builder = this.asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", type);
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", result);
		loginParam.put("subJobMessage", message);

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

@Immutable
class ClusterSearchTask implements Callable<Void> {

	private final String jobId;

	protected String getJobId() {
		return this.jobId;
	}

	private final String taskId;

	protected String getTaskId() {
		return this.taskId;
	}

	private final SimpleSearchCriteria srchCrtr;

	private final FilePreparer filePreparer;

	private final FsUtilAdapter fsUtilAdapter;

	private final int skips;

	private final ThumbnailPersister thumbPersister;

	private final FaceDataManager faceDataManager;

	private final SearchProgressListener progressListener;

	private final HbInnoParameter hbInnoParameter;

	private Map<String, byte[]> faceFeatureList;

	private final FaceMatchJobService faceMatchJobService;

	private final OnDemandWithFileParameter demandWithFileParameter;

	private final ObserverProgressOnDemandCluster observer;

	public ObserverProgressOnDemandCluster getObserver() {
		return observer;
	}

	private HbinnoEngine hbinnoEngine;

	public void setHbinnoEngine(HbinnoEngine hbinnoEngine) {
		this.hbinnoEngine = hbinnoEngine;
	}

	private TriumiVideoStore.FileValue[] files;

	// http 전송용
	private int nodeId;

	private String masterAddress;

	private SearchDataManager searchDataMgr;

	public void setSearchDataMgr(SearchDataManager searchDataMgr) {
		this.searchDataMgr = searchDataMgr;
	}

	private int taskNum;

	public void setTaskNum(int taskNum) {
		this.taskNum = taskNum;
	}

	private AsyncHttpClient asyncHttpClient;

	public ClusterSearchTask(@NotBlank String jobId, @NotBlank String taskId, @Nonnull SimpleSearchCriteria srchCrtr,
			@Nonnull FilePreparer filePreparer, @Nonnull FsUtilAdapter fsUtilAdapter, @Min(0) int skips,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager,
			@Nullable SearchProgressListener progressListener, @Nonnull HbInnoParameter hbInnoParam,
			Map<String, byte[]> faceFeatureList, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter,
			@Nonnull ObserverProgressOnDemandCluster observer, TriumiVideoStore.FileValue[] files, int nodeId,
			String masterAddress, SearchDataManager searchDataMgr, AsyncHttpClient asyncHttpClient) {

		this.jobId = jobId;
		this.taskId = taskId;
		this.srchCrtr = srchCrtr;
		this.filePreparer = filePreparer;
		this.fsUtilAdapter = fsUtilAdapter;
		this.skips = skips;
		this.thumbPersister = thumbPersister;
		this.faceDataManager = faceDataManager;
		this.progressListener = progressListener;
		this.hbInnoParameter = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.observer = observer;
		this.files = files;
		this.nodeId = nodeId;
		this.masterAddress = masterAddress;
		this.searchDataMgr = searchDataMgr;
		this.taskNum = taskNum;
		this.asyncHttpClient = asyncHttpClient;
	}

	@Override
	public Void call() {
		// SearchTaskProcessor<SimpleSearchCriteria, FaceEvent,
		// TriumiEventContext> task
		// = new TriumiHbInnoClusterSearchTaskProcessor(this.filePreparer,
		// this.fsUtilAdapter, this.thumbPersister,
		// this.faceDataManager, this.skips, this.hbInnoParameter,
		// this.faceFeatureList,
		// this.faceMatchJobService, this.demandWithFileParameter, this.baseDir,
		// this.observer,
		// this.hbinnoEngine, this.files, this.nodeId, this.masterAddress);

		SearchTaskProcessor<SimpleSearchCriteria, FaceEvent, TriumiEventContext> task = new TriumiHbInnoClusterSearchTaskProcessor(
				this.filePreparer, this.fsUtilAdapter, this.thumbPersister, this.faceDataManager, this.skips,
				this.hbInnoParameter, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
				this.observer, this.hbinnoEngine, this.files, this.nodeId, this.masterAddress, this.searchDataMgr,
				this.taskNum, this.asyncHttpClient);

		((TriumiHbInnoClusterSearchTaskProcessor) task).postConstruct();
		((TriumiHbInnoClusterSearchTaskProcessor) task).setProgressListener(this.progressListener);
		((TriumiHbInnoClusterSearchTaskProcessor) task).process(this.jobId, this.taskId, this.srchCrtr);
		((TriumiHbInnoClusterSearchTaskProcessor) task).preDestroy();

		return null;

	}
}
