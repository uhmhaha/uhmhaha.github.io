package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.util.base.ImageFormat;

/**
 * @author
 * @since 2015-08-04
 */
@ManagedResource(objectName = ":type=bean,name=thumbnailFilePersister", description = "Thumbnail persister that saves thumbnails into files.")
@ThreadSafe
public class DefaultThumbnailFilePersister implements ThumbnailPersister<ThumbnailPersister.Image> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public static final ImageFormat DEFAULT_THUMBNAIL_FORMAT = ImageFormat.JPEG;

	// @TODO Is it necessary and safe to define final for those fileds to be
	// initialized in constructor?

	private final String baseDir;

	@ManagedAttribute
	public String getBaseDir() {
		return this.baseDir;
	}

	private final int thumbWidth;

	@ManagedAttribute
	public int getThumbnailWidth() {
		return this.thumbWidth;
	}

	private final int thumbHeight;

	@ManagedAttribute
	public int getThumbnailHeight() {
		return this.thumbHeight;
	}

	private ImageFormat thumbFormat = DEFAULT_THUMBNAIL_FORMAT;

	@Override
	@ManagedAttribute
	public ImageFormat getThumbnailFormat() {
		return this.thumbFormat;
	}

	public void setThumbnailFormat(@Nonnull ImageFormat format) {
		this.thumbFormat = format;
	}

	private VasConfigService configService;

	// @Value("${vas.thumbnail.saveDir}")
	private String thumbnailDir;

	/**
	 * Always returns
	 * {@link com.skcc.nexcore.vas.search.ThumbnailPersister.Type#FILE}.
	 *
	 * @see com.skcc.nexcore.vas.search.ThumbnailPersister#getType()
	 */
	@Override
	@ManagedAttribute
	public Type getType() {
		return Type.FILE;
	}

	/**
	 * @param dir
	 *            Base directory to save thumbnail files. Shouldn't end with
	 *            '/'(slash) or '\' (backslash)
	 * @param width
	 *            Width for the thumbnail image
	 * @param height
	 *            Height for the thumbnail image
	 * @throws IllegalArgumentExeption
	 */
	public DefaultThumbnailFilePersister(@NotBlank String dir, @Range(min = 1) int width, @Range(min = 1) int height) {
		this.init();
		this.validate(dir, width, height);

		this.baseDir = dir;
		this.thumbWidth = width;
		this.thumbHeight = height;

	}

	public void initConfig() {
		// @Value("${vas.thumbnail.saveDir}")
		thumbnailDir = configService.getConfigValByName("vas.thumbnail.saveDir");

	}

	/**
	 * To use this constructor, the environment variable of 'VAS_THUMBNAIL_DIR'
	 * should be defined and the directory corresponding to the value of the
	 * variable should exist.
	 *
	 * @param width
	 *            Width for the thumbnail image
	 * @param height
	 *            Height for the thumbnail image
	 * @throws IllegalStateException
	 *             When 'VAS_THUMBNAIL_DIR' is not defined or defined with blank
	 *             string.
	 * @throws IllegalArgumentException
	 * @see com.skcc.nexcore.vas.base.Constants.EnvVariable#VAS_THUMBNAIL_DIR
	 */
	public DefaultThumbnailFilePersister(@Range(min = 1) int width, @Range(min = 1) int height,
			@Nonnull VasConfigService configService) {

		String dir = thumbnailDir;
		// Validate.validState(StringUtils.isNotBlank(dir),
		// "The envrionment variable of 'VAS_THUMBNAIL_DIR' should exist.");

		// this.init();
		// this.validate(dir, width, height);

		this.baseDir = dir;
		this.thumbWidth = width;
		this.thumbHeight = height;
		this.configService = configService;
	}

	private void init() {
		try {
			System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		} catch (Throwable t) {
			this.logger.error("Fail to load native library. - {}", Core.NATIVE_LIBRARY_NAME);
			throw t;
		}
	}

	/**
	 * @param dir
	 * @param width
	 * @param height
	 * @throws IllegalArgumentException
	 */
	private void validate(@NotBlank String dir, @Range(min = 1) int width, @Range(min = 1) int height) {

		// @TODO Validate whether 'dir' end with '/' or '\'

		Validate.isTrue(StringUtils.isNotBlank(dir), "The base directory should be specified.");
		File f = new File(dir);
		Validate.isTrue(f.exists() && f.isDirectory(), "The base directory '%1$s' should exist.", f.getAbsolutePath());
		Validate.isTrue(f.canWrite(), "Current process should be able to write files to the base directory of %1$s.",
				f.getAbsolutePath());

		Validate.isTrue(width > 0, "The width of thumbnail should be positive.");
		Validate.isTrue(height > 0, "The height of thumbnail should be positive.");
	}

	/**
	 * Returns relative file name of created thumbnail file. The returned name
	 * is relative to base directory({@link #getBaseDir()}) of this instance.
	 * The base directory can be specified by constructor or specified
	 * implicitly by environment variable of 'VAS_THUMBNAIL_DIR'
	 * <p>
	 * If the specified {@code img} object is not valide, this method will throw
	 * {@code IllegalArgumentException}.
	 *
	 * @throws IllegalArgumentException
	 * @see com.skcc.nexcore.vas.search.ThumbnailPersister#persistThumbnail(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.Object)
	 */
	@Override
	public String persistThumbnail(String jobId, String taskId, String systemId, String devId,
			ThumbnailPersister.Image img) {
		Validate.isTrue(StringUtils.isNotBlank(jobId), "Job ID shoud be specified.");
		Validate.isTrue(StringUtils.isNotBlank(taskId), "Task ID shoud be specified.");
		Validate.isTrue(StringUtils.isNotBlank(systemId), "System ID shoud be specified.");
		Validate.isTrue(StringUtils.isNotBlank(devId), "Device ID shoud be specified.");
		Validate.isTrue(img != null, "The image instance should be specified.");
		Validate.isTrue(img.validate(), "The image instance should be valid one.");

		Mat mat = new Mat(img.getHeight(), img.getWidth(), img.getOpenCvType());
		mat.put(0, 0, img.getData());

		// @TODO(Done) Shrink or enlarge the image to the size of thumbnail.
		double r = ((double) this.getThumbnailWidth() / img.getWidth());
		if (r > ((double) this.getThumbnailHeight()) / img.getHeight()) {
			r = ((double) this.getThumbnailHeight()) / img.getHeight();
		}
		if (r < 1.0) {
			Mat resized = new Mat(0, 0, img.getOpenCvType());
			Imgproc.resize(mat, resized, new Size(), r, r, Imgproc.INTER_AREA);
			mat = resized;
		}

		String name = getFileName(jobId, taskId, systemId, devId, img);
		String full = this.getBaseDir() + File.separator + name;
		try {
			FileUtils.forceMkdir(new File(StringUtils.substringBeforeLast(full, "/")));
		} catch (Exception ex) {
			throw new IllegalArgumentException("Fail to make a necessary directory.", ex);
		}

		Highgui.imwrite(full, mat);

		// @TODO Check whether it is necessary to explicitly free the byte
		// buffers of Mat objects.
		return name;
	}

	/**
	 * Gets file name including path and extension but excluding base directory.
	 * For example, 'sj1234ab09\20150811093010123.jpg'
	 *
	 * @param jobId
	 * @param taskId
	 * @param systemId
	 * @param devId
	 * @param img
	 * @return
	 */
	private String getFileName(String jobId, String taskId, String systemId, String devId, ThumbnailPersister.Image img) {

		// @TODO Remove or replace improper characters that cann't be included
		// file name

		StringBuilder sb = new StringBuilder(50);
		sb.append(jobId).append("/").append(systemId).append("_").append(devId).append("/").append(img.getTimestamp())
				.append(".").append(this.getThumbnailFormat().getExtension());

		return sb.toString();
	}

}
