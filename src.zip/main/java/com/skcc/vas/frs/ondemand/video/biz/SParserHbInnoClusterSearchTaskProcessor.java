package com.skcc.vas.frs.ondemand.video.biz;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.management.ObjectName;
import javax.validation.constraints.Min;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.springframework.jmx.export.MBeanExporter;

import com.ning.http.client.AsyncHttpClient;
import com.skcc.adapter.video.sparser.CSParser;
import com.skcc.adapter.video.sparser.SFrameFormat;
import com.skcc.adapter.video.sparser.SFrameInfo;
import com.skcc.adapter.video.sparser.SParserJNI;
import com.skcc.adapter.video.sparser.SParserResult;
import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.adapter.fr.hbinno.HbInnoFace;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.model.SearchResult;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace.ImageFormat;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.base.TaskStatus;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.ondemand.vms.biz.DirectAccessFilePreparer;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiEventContext;

public class SParserHbInnoClusterSearchTaskProcessor
		extends
			AbstractSparserSearchTaskProcessor<AnalysisResource, FaceEvent> {

	private static final String SERVICE_TYPE_NAME = "FACE_RECOGNITION_NON_VMS";

	private final String[] dateFormatChars = new String[]{"-", " ", ":"};
	private final String[] emptyChars = new String[]{"", "", ""};

	@Nullable
	private MBeanExporter mBeanExporter;

	public void setMBeanExporter(@Nullable MBeanExporter exporter) {
		this.mBeanExporter = exporter;
	}

	@Nullable
	private ObjectName mBeanName;

	public void setObjectName(@Nullable ObjectName name) {
		this.mBeanName = name;
	}

	@Nonnull
	private final FaceDataManager faceDataManager;

	private final SearchResult<FaceEvent, TriumiEventContext> searchResult;

	private HbInnoParameter hbInnoParam; // config.properties 파일에서 읽어 온 HBInno
											// parameter 값

	private FaceMatchJobService faceMatchJobService;

	private Map<String, byte[]> faceFeatureList;

	private OnDemandWithFileParameter demandWithFileParameter;

	private String base;

	private String vadDir;

	private String thumbnailDirName;

	private String screenshotDir;

	private String cctvResolutionEnable;

	private String videoDataDir;

	private String mode;

	private String pattern = DirectAccessFilePreparer.DEFAULT_DEVICE_DIR_PATTERN;

	/*
	 * 시스템 환경 변수로 부터 구한 VAS_DATA_DIR 값 =
	 * Watz_Eye_VAS/data/face/vmsid/deviceid/currentdate/filename.jpg
	 */
	private String thumbBase;

	private ObserverProgressOnDemandCluster observer;

	private String jobAndTaskId;

	private HbinnoEngine hbinnoEngine;

	private int threshold;

	private int fromPositionInFile;

	private int toPositionInFile;

	private int nodeId;

	private String masterAddress;

	private SearchDataManager searchDataMgr;

	private int taskNum;

	private int cntTotalSubJobFiles;

	private AsyncHttpClient asyncHttpClient;

	private CSParser csParser;

	public SParserHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull SParserJNI sParserAdapter, @Nonnull HbInnoAdapter hbInnoAdapter,
			@Nonnull FaceDataManager faceDataManager, @Min(0) int skips) {

		this(filePreparer, sParserAdapter, hbInnoAdapter, null, faceDataManager, skips);

	}

	public SParserHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull SParserJNI sParserAdapter, @Nonnull HbInnoAdapter hbInnoAdapter,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager, @Min(0) int skips) {

		super(filePreparer, sParserAdapter, thumbPersister, skips);

		Validate.isTrue(hbInnoAdapter != null, "Adapter for HBInno's FR engine should be provided.");
		Validate.isTrue(faceDataManager != null, "Face data manager should be provided.");

		this.faceDataManager = faceDataManager;
		this.searchResult = new SearchResult<FaceEvent, TriumiEventContext>();

	}

	public SParserHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull SParserJNI sParserAdapter, @Nullable ThumbnailPersister thumbPersister,
			@Nonnull FaceDataManager faceDataManager, @Min(0) int skips, @Nonnull HbInnoParameter hbInnoParam,
			Map<String, byte[]> faceFeatureList, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter, @Nonnull String baseDir,
			@Nonnull ObserverProgressOnDemandCluster observer, @Nonnull HbinnoEngine hbinnoEngine,
			@Nonnull int threshold, int fromPositionInFile, int toPositionInFile, int nodeId, String masterAddress,
			SearchDataManager searchDataMgr, int taskNum, AsyncHttpClient asyncHttpClient) {

		super(filePreparer, sParserAdapter, thumbPersister, skips);

		Validate.isTrue(faceDataManager != null, "Face data manager should be provided.");

		this.faceDataManager = faceDataManager;
		this.searchResult = new SearchResult<FaceEvent, TriumiEventContext>();
		this.hbInnoParam = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.observer = observer;
		this.hbinnoEngine = hbinnoEngine;
		this.threshold = threshold;
		this.fromPositionInFile = fromPositionInFile;
		this.toPositionInFile = toPositionInFile;
		this.nodeId = nodeId;
		this.masterAddress = masterAddress;
		this.searchDataMgr = searchDataMgr;
		this.taskNum = taskNum;

		this.base = baseDir;
		this.vadDir = demandWithFileParameter.getVadDir();
		this.thumbnailDirName = demandWithFileParameter.getThumbnailDirName();
		this.screenshotDir = demandWithFileParameter.getScreenshotDir();
		this.cctvResolutionEnable = demandWithFileParameter.getCctvResolutionEnable();
		this.videoDataDir = demandWithFileParameter.getVideoDataDir();

		int cntTotalSubJobFiles = 0;
		Map<String, ProgressForClusterTask> progressTasks = observer.getProgressTasks();
		for (String key : progressTasks.keySet()) {
			cntTotalSubJobFiles = cntTotalSubJobFiles + progressTasks.get(key).getTotalFilesCnt();
		}
		this.cntTotalSubJobFiles = cntTotalSubJobFiles;
		this.logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>> this.cntTotalSubJobFiles: {}", this.cntTotalSubJobFiles);
		this.asyncHttpClient = asyncHttpClient;
		this.csParser = new CSParser();
	}

	@PostConstruct
	public void postConstruct() {
		Validate.isTrue(this.getSParserJNI() != null, "FsUtilAdapter should be provided at instance construction time.");
		Validate.isTrue(this.getDefaultSkipsAfterDetect() > -1, "Skip number should be nonnegative.");

		if (this.mBeanExporter != null) {
			try {
				if (this.mBeanName == null) {
					Hashtable<String, String> tbl = new Hashtable<String, String>();
					tbl.put("type", "bean");
					tbl.put("name", this.getClass().getSimpleName());
					tbl.put("hash", Integer.toHexString(this.hashCode()));

					this.mBeanName = new ObjectName("", tbl);
				}
				mBeanExporter.registerManagedResource(this, this.mBeanName);
			} catch (Exception ex) {
				this.logger.error("Fail to register MBean of TriumiVcSearchTaskProcessor intance.", ex);
			}
		}
	}

	@PreDestroy
	public void preDestroy() {
		if (this.mBeanExporter != null && this.mBeanName != null) {
			try {
				mBeanExporter.unregisterManagedResource(this.mBeanName);
			} catch (Exception ex) {
				this.logger.error("Fail to unregister MBean of TriumiVcSearchTaskProcessor intance.", ex);
			}
		}
	}
	@Override
	public SearchResult<FaceEvent, TriumiEventContext> process(String jobId, String taskId, AnalysisResource analysisRsc) {
		this.setJobId(jobId);
		this.setTaskId(taskId);
		this.setAnalysisRsc(analysisRsc);

		this.setStatus(TaskStatus.IN_PROGRESS);
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> jobId: {}, taskId: {}, RscFileNm: {}", jobId,
				taskId, analysisRsc.getRscFileNm());

		this.thumbBase = getThumbBaseDir(jobId, analysisRsc.getRscFileNm());

		// observe 전체파일 갯수 세팅
		String jobAndTaskId = new StringBuffer().append(jobId).append("_").append(analysisRsc.getRscFileNm())
				.append("_").append(taskId).toString();
		this.jobAndTaskId = jobAndTaskId;

		SearchResult<FaceEvent, TriumiEventContext> result = null;
		int cnt = 0;

		try {
			result = this.analysisFile(this.getDefaultSkipsAfterDetect(), analysisRsc);

			if (observer.isAborted() == true) {
				logger.error("[Task].........STOP.......");
				// throw new RuntimeException("Stopped due to stop command!");
				// String abortMessage =
				// String.format("nodeId {} is Aborted by user for ondemand Video!!",
				// nodeId );
				// sendCompletedTaskMessage(masterAddress,
				// "ONDEMAND_VIDEO_ABORT_RESULT", jobId, nodeId, 1,
				// abortMessage);
				return result;
			}

			for (Pair<? extends FaceEvent, TriumiEventContext> pair : result.getItems()) {
				this.searchResult.addItem(pair.getLeft(), pair.getRight());
			}

			sendCompletedTaskMessage(this.masterAddress, "ONDEMAND_VIDEO_RESULT", this.getJobId(), this.nodeId, 1,
					"success");

		} catch (Throwable ex) {
			// 하나라도 문제 생기면 전체 job을 Fail로 둠
			HashMap<String, Object> endJobParam = new HashMap<String, Object>();
			endJobParam.put("rslt_stts", "FAIL");
			endJobParam.put("rslt_stts_desc", "Exceptions occurs while processing Job!!");
			faceMatchJobService.updateJobStatus(endJobParam);
			sendCompletedTaskMessage(this.masterAddress, "ONDEMAND_VIDEO_RESULT", this.getJobId(), this.nodeId, -1,
					"Exceptions occurs while processing Job!!");
			logger.warn("Fail to analysis file {}", analysisRsc.getRscPath(), ex);
			this.addNumberOfExceptions(1);
		}

		return this.searchResult;
	}

	@Nonnull
	protected final SearchResult<FaceEvent, TriumiEventContext> analysisFile(int skips, AnalysisResource analysisRsc) {
		Validate.isTrue(analysisRsc != null, "The criteria for analysis is not specified.");
		Validate.isTrue(StringUtils.isNotBlank(analysisRsc.getRscPath()), "The file to analysis is not specified.");
		this.logger.info("Analyzing a file. - {}, skips: {}", analysisRsc.getRscPath(), skips);

		final SearchResult<FaceEvent, TriumiEventContext> srchResult = new SearchResult<FaceEvent, TriumiEventContext>();

		int verificationThreshold;
		if (this.threshold > 0) {
			verificationThreshold = this.threshold;
		} else {
			verificationThreshold = (int) (hbInnoParam.getVerificationThreshold() * 100);
		}

		HashMap<String, Object> inProcTaskparam = new HashMap<String, Object>();
		inProcTaskparam.put("job_id", this.getJobId());

		String inputFullPath = new StringBuffer().append(this.base).append(analysisRsc.getRscPath()).toString();
		// CSParser csParser = new CSParser();

		this.logger.info("+++++++++++++++++++++++++++++ > {}: {} ~ {}", inputFullPath, fromPositionInFile,
				toPositionInFile);

		int mFromPositionInFile = fromPositionInFile / 1000;
		int mToPositionInFile = toPositionInFile / 1000;

		boolean isOpen = csParser.open(inputFullPath, false, mFromPositionInFile, mToPositionInFile);
		SParserResult pResult;
		if (isOpen == false) {
			throw new RuntimeException("Fail to open from " + inputFullPath + " !!");
		}

		// 각 파일별 상태값 변경(IN_PROGRESS로)
		inProcTaskparam.put("rsc_id", analysisRsc.getId());
		inProcTaskparam.put("rslt_stts", "IN_PROGRESS");
		inProcTaskparam.put("rslt_stts_desc", "IN_PROGRESS");
		this.faceMatchJobService.updateExtSrcStatus(inProcTaskparam);

		SFrameInfo finfo = new SFrameInfo();
		boolean isWrongBufPtr = false;
		while (true) {

			if (observer.isAborted() == true) {
				logger.error("[Task].........STOP.......");
				csParser.close();
				// throw new RuntimeException("Stopped due to stop command!");
				return srchResult;
			}

			// skip을 성정으로 빼기
			pResult = csParser.get(0, 0, 10, SFrameFormat.SFRAME_BGR24, finfo);

			if (finfo.getBufPointer() < 0) {
				isWrongBufPtr = true;
				break;
			}

			if (pResult == SParserResult.SPARSER_OK) {
				this.logger
						.debug("get >>>>> width: {}, height: {}, bufSize: {}, FrmTime: {}, FrmFormat: {}, FrmIndex: {}, FrmPointer: {}",
								finfo.getWidth(), finfo.getHeight(), finfo.getBufSize(), finfo.getFrameTimeMilli(),
								finfo.getFrameFormat(), finfo.getFrameIndex(), finfo.getBufPointer());

				String frmSaveDir = getFrameSaveDir(this.getJobId(), analysisRsc.getRscFileNm());
				try {
					FileUtils.forceMkdir(new java.io.File(frmSaveDir));
				} catch (Throwable ex) {
					logger.warn("Fail to make dir saving frame : {}", analysisRsc.getRscPath(), ex);
				}

				String frmSavePath = new StringBuffer(frmSaveDir).append("/").append(finfo.getFrameIndex())
						.append(".jpeg").toString();

				// 절대경로를 상대 경로로 바꿈
				String frmSaveRelativePath = frmSavePath.replace(vadDir, "");

				for (String key : faceFeatureList.keySet()) {
					List<HbInnoFace> loadResult = hbinnoEngine.loadFrameAndVerify(finfo.getBufPointer(),
							finfo.getWidth(), finfo.getHeight(), finfo.getWidth() * 3, this.thumbBase,
							faceFeatureList.get(key), verificationThreshold);

					HashMap<String, Object> faceMatch = new HashMap<String, Object>();
					if (loadResult.size() > 0) {

						this.logger.info("}]]]]]]]]]]]]]]]]]]]]]]] loadResult size = {}, finfo.getBufPointer(): {}",
								loadResult.size(), (long) finfo.getBufPointer());

						String frmTime = String.valueOf(finfo.getFrameTimeMilli());
						// save screen shot
						String shotDir = null;
						String shotPath = null;
						String shotpath2 = null;

						Pair<String, String> pathAndDir = getScreenshotPathAndDir(this.getJobId(),
								analysisRsc.getRscFileNm());
						shotPath = pathAndDir.getLeft();
						shotDir = pathAndDir.getRight();

						try {
							FileUtils.forceMkdir(new java.io.File(shotDir));
						} catch (Exception ex) {
							throw new IllegalStateException("Unexpected fail of path resolution.", ex);
						}

						if (csParser.saveFrameToJpegFile(finfo, 0, 0, 100, frmSavePath)) {
							this.logger.debug("{} screenshot save ok", frmSavePath);
						} else {
							this.logger.debug("{} screenshot save fail", frmSavePath);
						}

						// insert result in DB
						for (HbInnoFace hbInnoFace : loadResult) {
							String imgFileAbsolutePath = hbInnoFace.getAbsolutePath();
							String imgFileComparePath = null;

							if (imgFileAbsolutePath != null)
								imgFileComparePath = imgFileAbsolutePath.replace(vadDir, "");

							faceMatch = new HashMap<String, Object>();
							faceMatch.put("job_cncrn_face_id", key);
							faceMatch.put("score", hbInnoFace.getScore());
							faceMatch.put("rscId", analysisRsc.getId());
							faceMatch.put("srvcType", SERVICE_TYPE_NAME);
							faceMatch.put("imgFile", imgFileComparePath);
							faceMatch.put("imgW", hbInnoFace.getImgWidth());
							faceMatch.put("imgH", hbInnoFace.getImgHeight());
							faceMatch.put("imgX", hbInnoFace.getImgX());
							faceMatch.put("imgY", hbInnoFace.getImgY());
							faceMatch.put("frmFile", frmSaveRelativePath);
							faceMatch.put("frmW", finfo.getWidth());
							faceMatch.put("frmH", finfo.getHeight());
							faceMatch.put("frmTime", frmTime);

							// 결과를 DB 에 저장
							this.faceMatchJobService.insertJobFaceMatchExtSrc(faceMatch);
						}
					}
				}
			} else if (pResult == SParserResult.SPARSER_EOF) {
				observer.setProgressCompletedFilesForTask(this.jobAndTaskId, 1);
				// 각 파일별 상태값 변경(completed로)
				HashMap<String, Object> completedTaskparam = new HashMap<String, Object>();
				completedTaskparam.put("job_id", this.getJobId());
				completedTaskparam.put("rsc_id", analysisRsc.getId());
				completedTaskparam.put("rslt_stts", "COMPLETED");
				completedTaskparam.put("rslt_stts_desc", SParserResult.SPARSER_OK.toString());
				this.faceMatchJobService.updateExtSrcStatus(completedTaskparam);
				this.logger.info("Analyzed a file. - {}, skips: {}", analysisRsc.getRscPath(), skips);

				break;
			} else {
				// 각 파일별 상태값 변경(Fail로)
				HashMap<String, Object> failTaskparam = new HashMap<String, Object>();
				failTaskparam.put("job_id", this.getJobId());
				failTaskparam.put("rsc_id", analysisRsc.getId());
				failTaskparam.put("rslt_stts", "FAIL");
				failTaskparam.put("rslt_stts_desc", pResult.toString());
				this.faceMatchJobService.updateExtSrcStatus(failTaskparam);
				// sendCompletedTaskMessage(this.masterAddress,
				// "ONDEMAND_VIDEO_RESULT", this.getJobId(), this.nodeId, -1,
				// pResult.toString());
				this.logger.warn("Unexpected searchResult from Sparser FR engine or parser return fail: {}",
						pResult.toString());
				break;
			}
		}

		if (isWrongBufPtr == true) {
			// log
			String failedMessage = String.format("Fail to get decoded frame or wrong buffer pointer value {} from {}",
					finfo.getBufPointer(), analysisRsc.getRscFileNm());
			this.logger.error(failedMessage);
			// update fail status for this resource
			HashMap<String, Object> failTaskparam = new HashMap<String, Object>();
			failTaskparam.put("job_id", this.getJobId());
			failTaskparam.put("rsc_id", analysisRsc.getId());
			failTaskparam.put("rslt_stts", "FAIL");
			failTaskparam.put("rslt_stts_desc", pResult.toString());
			this.faceMatchJobService.updateExtSrcStatus(failTaskparam);
			// close and throw exception
			csParser.close();
			throw new RuntimeException("Fail to get decoded frame or wrong buffer pointer value"
					+ finfo.getBufPointer() + " from" + analysisRsc.getRscFileNm());
		}

		synchronized (searchDataMgr) {
			SearchRequest jobRequestInfo = searchDataMgr.findSearchRequest(this.getJobId());
			if (jobRequestInfo == null) {
				final String msg = String.format("The search job[id: %1$s] can't be found.", this.getJobId());
				throw new IllegalStateException(msg);
			}

			Map<String, ProgressForClusterTask> observers = observer.getProgressTasks();
			ProgressForClusterTask progressForClusterTask = (ProgressForClusterTask) observers.get(this.jobAndTaskId);

			float prevProgress = jobRequestInfo.getProgress();
			float nowProgress = prevProgress
					+ (float) ((float) (progressForClusterTask.getPortionOfProgress() * 100) / this.cntTotalSubJobFiles); // 4가
																															// 필요함

			if (nowProgress > 99.990f) {
				nowProgress = Math.round(nowProgress);
			}

			HashMap<String, Object> updateRateparam = new HashMap<String, Object>();
			updateRateparam.put("job_id", this.getJobId());
			updateRateparam.put("progress", nowProgress);
			faceMatchJobService.updateJobProgressRate(updateRateparam);
		}

		csParser.close();
		return srchResult;
	}

	private Pair<String, String> getScreenshotPathAndDir(String jobId, String rscFileNm) {
		final String date = BaseUtils.formatToYear2MillisecString(new java.util.Date()); // 'yyyyMMddHHmmssSSS'
																							// format

		StringBuilder sb = new StringBuilder().append(vadDir).append(videoDataDir).append(screenshotDir).append("/")
				.append(jobId).append("/").append(rscFileNm).append("/").append(date.substring(0, 8)).append("/");
		String dir = sb.toString();
		sb.append(date.substring(8)).append(".").append(ImageFormat.JPG).toString();

		return Pair.of(sb.toString(), dir);
	}

	private String getThumbBaseDir(String jobId, String rscFileNm) {
		if (StringUtils.isBlank(vadDir)) {
			throw new IllegalStateException("The environment variables VAS_DATA_DIR and VAS_HOME are not set properly.");
		}

		String thumbbaseToVideo = new StringBuilder(vadDir).append(videoDataDir).toString();
		File thumbbaseToVideoDir = new File(thumbbaseToVideo);
		if (!thumbbaseToVideoDir.exists()) {
			thumbbaseToVideoDir.mkdir();
		}

		String thumbbaseToFace = new StringBuilder(thumbbaseToVideo).append(thumbnailDirName).toString();
		File thumbbaseToFaceDir = new File(thumbbaseToFace);
		if (!thumbbaseToFaceDir.exists()) {
			thumbbaseToFaceDir.mkdir();
		}

		String thumbbaseToJobId = new StringBuilder(thumbbaseToFace).append("/").append(jobId).toString();
		File thumbbaseToJobIdDir = new File(thumbbaseToJobId);
		if (!thumbbaseToJobIdDir.exists()) {
			thumbbaseToJobIdDir.mkdir();
		}

		String thumbaseToRscFileNm = new StringBuffer(thumbbaseToJobId).append("/").append(rscFileNm).toString();
		File thumbaseToRscFileNmDir = new File(thumbaseToRscFileNm);
		if (!thumbaseToRscFileNmDir.exists()) {
			thumbaseToRscFileNmDir.mkdir();
		}

		return thumbaseToRscFileNm;
	}

	private String getFrameSaveDir(String jobId, String rscFileNm) {
		if (StringUtils.isBlank(vadDir)) {
			throw new IllegalStateException("The environment variables VAS_DATA_DIR and VAS_HOME are not set properly.");
		}
		final String date = BaseUtils.formatToYear2MillisecString(new java.util.Date());

		String thumbbaseToVideo = new StringBuilder(vadDir).append(videoDataDir).toString();
		File thumbbaseToVideoDir = new File(thumbbaseToVideo);
		if (!thumbbaseToVideoDir.exists()) {
			thumbbaseToVideoDir.mkdir();
		}

		String thumbbaseToFace = new StringBuilder(thumbbaseToVideo).append(screenshotDir).toString();
		File thumbbaseToFaceDir = new File(thumbbaseToFace);
		if (!thumbbaseToFaceDir.exists()) {
			thumbbaseToFaceDir.mkdir();
		}

		String thumbbaseToJobId = new StringBuilder(thumbbaseToFace).append("/").append(jobId).toString();
		File thumbbaseToJobIdDir = new File(thumbbaseToJobId);
		if (!thumbbaseToJobIdDir.exists()) {
			thumbbaseToJobIdDir.mkdir();
		}

		String thumbaseToRscFileNm = new StringBuffer(thumbbaseToJobId).append("/").append(rscFileNm).toString();
		File thumbaseToRscFileNmDir = new File(thumbaseToRscFileNm);
		if (!thumbaseToRscFileNmDir.exists()) {
			thumbaseToRscFileNmDir.mkdir();
		}

		// notice: Because face is not saved as dateDir by hbInnoEngin, DateDir
		// is necessary
		String thumbaseToDate = new StringBuffer(thumbaseToRscFileNm).append("/").append(date.substring(0, 8))
				.toString();
		File thumbaseToDateDir = new File(thumbaseToDate);
		if (!thumbaseToDateDir.exists()) {
			thumbaseToDateDir.mkdir();
		}

		return thumbaseToDate;
	}

	private void sendCompletedTaskMessage(String masterAddress, String type, String jobId, int nodeId, int result,
			String message) {

		AsyncHttpClient.BoundRequestBuilder builder = this.asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", type);
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", result);
		loginParam.put("subJobMessage", message);

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
