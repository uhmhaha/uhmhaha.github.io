package com.skcc.vas.frs.ondemand.video.biz;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.event.EventContext;
import com.skcc.vas.frs.common.biz.model.SearchResult;
import com.skcc.vas.frs.common.util.base.TaskStatus;
import com.skcc.vas.frs.common.util.ondemand.TimeRangeRuler;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;

public interface FileAnalysisProcessor<SC extends AnalysisResource, E extends Event, EC extends EventContext> {

	public SearchResult<E, EC> process(String jobId, String taskId, @Nonnull SC analysisRsc);

	public String getJobId();

	// @TODO Review to replace with int getTaskNo()
	public String getTaskId();

	public SC getAnalysisRsc();

	public TaskStatus getStatus();

	public void setTimeRangeRuler(@Nullable TimeRangeRuler ruler);

	/**
	 * Default value for the number of frames to skip after an event is
	 * detected.
	 * <p>
	 * Later another 'process' method can be added that can control the skips at
	 * request scope.
	 *
	 * @see #defaultSkips
	 */
	public int getDefaultSkipsAfterDetect();

	/**
	 * @return
	 * @since 0.9.1
	 */
	public int getNumberOfExceptions();
}
