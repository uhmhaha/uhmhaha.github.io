package com.skcc.vas.frs.ondemand.vms.nosql;

public class test {

}
