package com.skcc.vas.frs.ondemand.vms.model;

import javax.annotation.Nonnull;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

import com.skcc.vas.frs.common.util.base.Point;
import com.skcc.vas.frs.common.util.base.RectangleRoi;

/**
 * @author
 * @since 2016-07-20
 *
 */
public class SimpleSearchCriteria extends AbstractSearchCriteria implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private final transient RectangleRoi<Float> roi;

	private int threshold;

	public SimpleSearchCriteria(@NotBlank String systemId, @NotBlank String devId, @NotBlank String from,
			@NotBlank String to, @Min(0) float x1, @Min(0) float y1, @Min(1) float x2, @Min(1) float y2) {
		super(systemId, devId, from, to);

		this.roi = new RectangleRoi(x1, y1, x2, y2);
	}

	public SimpleSearchCriteria(@NotBlank String systemId, @NotBlank String devId, @NotBlank String from,
			@NotBlank String to, @Nonnull Point<Float> pt1, @Nonnull Point<Float> pt2, @Nonnull Point<Float> pt3,
			@Nonnull Point<Float> pt4) {

		super(systemId, devId, from, to);
		this.roi = new RectangleRoi(pt1, pt2, pt3, pt4);
	}

	public SimpleSearchCriteria(@NotBlank String systemId, @NotBlank String devId, @NotBlank String from,
			@NotBlank String to, @Nonnull Point<Float> pt1, @Nonnull Point<Float> pt2, @Nonnull Point<Float> pt3,
			@Nonnull Point<Float> pt4, int threshold) {

		super(systemId, devId, from, to);
		this.roi = new RectangleRoi(pt1, pt2, pt3, pt4);
		this.threshold = threshold;
	}

	public SimpleSearchCriteria(@NotBlank String systemId, @NotBlank String devId, @NotBlank String from,
			@NotBlank String to, int threshold) {
		super(systemId, devId, from, to);
		this.threshold = threshold;
		this.roi = null;
	}

	public RectangleRoi<Float> getRoi() {
		return this.roi;
	}

	public int getThreshold() {
		return threshold;
	}

}
