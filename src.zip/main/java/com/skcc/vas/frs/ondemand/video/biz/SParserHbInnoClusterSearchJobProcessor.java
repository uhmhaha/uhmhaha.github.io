package com.skcc.vas.frs.ondemand.video.biz;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.ning.http.client.AsyncHttpClient;
import com.skcc.adapter.video.sparser.SParserJNI;
import com.skcc.vas.adapter.fr.hbinno.HbInnoEngineOndemandVideoFile;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.akka.model.OndemandVideoSubJob;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.ondemand.video.db.rdb.service.FileAnalysisDataManager;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiEventContext;

public class SParserHbInnoClusterSearchJobProcessor implements OndemandVideoProcessor {

	public static final int UNIT_TIME_DEFAULT = 10;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private String jobId;

	public String getJobId() {
		return this.jobId;
	}

	private Map<String, byte[]> faceFeatureList;

	public Map<String, byte[]> getFaceFeatureList() {
		return this.faceFeatureList;
	}

	private SearchDataManager searchDataMgr;

	public SearchDataManager getSearchDataManager() {
		return this.searchDataMgr;
	}

	private FileAnalysisDataManager fileAnalysisDataManager;

	public FileAnalysisDataManager getFileAnalysisDataManager() {
		return this.fileAnalysisDataManager;
	}

	private FaceMatchJobService faceMatchJobService;

	public FaceMatchJobService getFaceMatchJobService() {
		return this.faceMatchJobService;
	}

	private OnDemandWithFileParameter demandWithFileParameter;

	public OnDemandWithFileParameter getDemandWithFileParameter() {
		return demandWithFileParameter;
	}

	private HbInnoEngineOndemandVideoFile hbinnoEngineInstance;

	public HbInnoEngineOndemandVideoFile getHbinnoEngineInstance() {
		return hbinnoEngineInstance;
	}

	private FilePreparer filePreparer;

	public FilePreparer getFilePreparer() {
		return this.filePreparer;
	}

	private ThumbnailPersister thumbnailPersister;

	public ThumbnailPersister getThumbnailPersister() {
		return this.thumbnailPersister;
	}

	private HbInnoParameter hbInnoParam;

	public HbInnoParameter getHbInnoParam() {
		return this.hbInnoParam;
	}

	private FaceDataManager faceDataManager;

	public FaceDataManager getFaceDataManager() {
		return faceDataManager;
	}

	private SParserJNI sParserAdapter;

	public SParserJNI getsParserAdapter() {
		return sParserAdapter;
	}

	private volatile int skips;

	// @Value("${vas.file.analysis.baseDir}")
	private String baseDir;

	// @Value("${vas.ondemand.video.thread.core}")
	private int threadNum;

	private List<ObserverProgressOnDemandCluster> observers = new ArrayList<ObserverProgressOnDemandCluster>();

	private ExecutorService executor;

	private AsyncHttpClient asyncHttpClient;

	private int taskNum, threadCoreNum, threadMaxNum;

	private VasConfigService configService;

	public void setTaskNum(int taskNum) {
		this.taskNum = taskNum;
	}

	public SParserHbInnoClusterSearchJobProcessor(SearchDataManager searchDataMgr,
			FileAnalysisDataManager fileAnalysisDataManager, FaceMatchJobService faceMatchJobService,
			OnDemandWithFileParameter demandWithFileParameter, HbInnoEngineOndemandVideoFile hbinnoEngineInstance,
			@Min(0) int skips, FilePreparer filePreparer, ThumbnailPersister thumbnailPersister,
			ThreadPoolTaskExecutor taskExecutor, HbInnoParameter hbInnoParam, FaceDataManager faceDataManager,
			SParserJNI sParserAdapter, @Nonnull VasConfigService configService) {

		this.searchDataMgr = searchDataMgr;
		this.fileAnalysisDataManager = fileAnalysisDataManager;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.hbinnoEngineInstance = hbinnoEngineInstance;
		this.skips = skips;
		this.filePreparer = filePreparer;
		this.thumbnailPersister = thumbnailPersister;
		this.hbInnoParam = hbInnoParam;
		this.faceDataManager = faceDataManager;
		this.sParserAdapter = sParserAdapter;
		
		String threadCoreNumStr = configService.getConfigValByName("vas.ondemand.video.thread.core");
		String threadMaxNumStr = configService.getConfigValByName("vas.ondemand.video.thread.max");

		threadCoreNum = taskExecutor.getCorePoolSize();
		if(threadCoreNumStr != "" && threadCoreNumStr != null) {
			threadCoreNum = Integer.parseInt(threadCoreNumStr);
		}
		else {
			throw new IllegalStateException("+++++ Ondemand Video Thread value is empty. Enter values in VAS_CONF_NODE table.");
		}
		
		threadMaxNum = taskExecutor.getMaxPoolSize();
		if(threadMaxNumStr != "" && threadMaxNumStr != null) {
			threadMaxNum = Integer.parseInt(threadMaxNumStr);
		}
		else {
			throw new IllegalStateException("+++++ Ondemand Video Thread value is empty. Enter values in VAS_CONF_NODE table.");
		}

		taskExecutor.setCorePoolSize(threadCoreNum);
		taskExecutor.setMaxPoolSize(threadMaxNum);

		this.executor = new ExecutorServiceAdapter(taskExecutor);

		this.asyncHttpClient = new AsyncHttpClient();

		this.configService = configService;
	}

	public void initConfig() {
		// @Value("${vas.file.analysis.baseDir}")
		baseDir = configService.getConfigValByName("vas.file.analysis.baseDir");

		// @Value("${vas.ondemand.video.thread.core}")
		threadNum = Integer.parseInt(configService.getConfigValByName("vas.ondemand.video.thread.core"));
	}

	@Override
	public List<OndemandVideoSubJob> splitJobs(String jobId, int numOfNode) {

		if (numOfNode < 1) {
			final String msg = String.format("There is no usable worker node for ondemand video!! - numOfNoe: {}",
					numOfNode);
			throw new IllegalArgumentException(msg);
		}

		// 시간 쪼개질 때 -9시간을 해놓고 쪼갠다.
		this.jobId = jobId;

		// 리소스 데이터 읽어오기
		final FileAnalysisRequest req = this.getFileAnalysisDataManager().findAnalysisRequest(jobId);
		List<AnalysisResource> analysisResources = new ArrayList<AnalysisResource>();
		int totalVideosLength = 0;
		List<Pair<Integer, Integer>> portionsOfJob = new ArrayList<Pair<Integer, Integer>>();
		List<Pair<Integer, Integer>> portionsPerFile = new ArrayList<Pair<Integer, Integer>>();
		if (req == null) {
			final String msg = String.format("The search job[id: %1$s] can't be found.", jobId);
			throw new IllegalStateException(msg);
		} else {
			analysisResources = req.getAnalysisResources();
			if (analysisResources.isEmpty() == true) {
				final String msg = String.format("The resource of file analysis job[id: %1$s] contains NO.", jobId);
				throw new IllegalArgumentException(msg);
			} else {
				for (AnalysisResource analysisRsc : analysisResources) {
					this.logger
							.info("Found a search job. - jobId: {}, rscId: {}, rscTitle: {}, rsc_scene_type: {}, rsc_path: {}, rsc_thumb_path: {}, rsc_file_nm: {}",
									req.getJobId(), analysisRsc.getId(), analysisRsc.getRscTitle(),
									analysisRsc.getRscSceneType(), analysisRsc.getRscPath(),
									analysisRsc.getRscThumbPath(), analysisRsc.getRscFileNm());
					// portionsOfJob.add(Pair.of(totalVideosLength,
					// totalVideosLength+analysisRsc.getVideoLength()));
					portionsOfJob.add(Pair.of(0, totalVideosLength + analysisRsc.getVideoLength()));
					portionsPerFile.add(Pair.of(0, analysisRsc.getVideoLength()));
					totalVideosLength += analysisRsc.getVideoLength();

				}
			}
		}

		List<OndemandVideoSubJob> ondemandVideoSubJobs = new ArrayList<OndemandVideoSubJob>();

		long gapTime = totalVideosLength; // per milli-minute
		// int subJobUnitTime = ((int)gapTime / numOfNode) + 1000; // [ sum of
		// video files length for job ] / [numOfJob], 1초단위는 보정
		double dSubJobUnitTime = gapTime / (double) numOfNode;
		int subJobUnitTime = (int) Math.ceil(dSubJobUnitTime);

		if (subJobUnitTime == 0) {
			final String msg = String
					.format("Interval between startTime to endTime is too short!! Please, enter the long interval!! - totalVideosLength: {}",
							totalVideosLength);
			throw new IllegalArgumentException(msg);
		}

		// unitTime보다 크면 쪼개기
		int taskUnitTime = Integer.parseInt(demandWithFileParameter.getVideoUnitTime()) * 60 * 1000;

		Map<String, List<Pair<Integer, Integer>>> reformPortionsOfJob = new LinkedHashMap<String, List<Pair<Integer, Integer>>>();
		int cnt = 0;
		for (Pair<Integer, Integer> portion : portionsPerFile) {
			// unitTime보다 크면 쪼개기
			int fileLength = portion.getRight() - portion.getLeft();
			// if( fileLength > taskUnitTime ){ //설정에서 말하는 unitTime을 써야 할 듯
			if (fileLength > subJobUnitTime) {
				List<Pair<Integer, Integer>> splitedFile = new ArrayList<Pair<Integer, Integer>>();

				// int numSplitFile = fileLength/taskUnitTime + 1;
				int numSplitFile = fileLength / subJobUnitTime + 1;

				int fromPosition = 0;
				int toPosition = 0;
				for (int i = 0; i < numSplitFile; i++) {
					fromPosition = toPosition;

					if (i == (numSplitFile - 1)) {
						toPosition = portion.getRight();
					} else {
						// toPosition = taskUnitTime * (i+1);
						toPosition = subJobUnitTime * (i + 1);
					}
					if (toPosition > fromPosition) {
						splitedFile.add(Pair.of(fromPosition, toPosition));
					}
				}
				reformPortionsOfJob.put(String.valueOf(cnt), splitedFile);
			} else {
				List<Pair<Integer, Integer>> splitedFile2 = new ArrayList<Pair<Integer, Integer>>();

				if (portion.getRight() > portion.getLeft()) {
					splitedFile2.add(Pair.of(portion.getLeft(), portion.getRight()));
					reformPortionsOfJob.put(String.valueOf(cnt), splitedFile2);
				}
			}

			cnt++;
		}

		// 해당 파일 포함 되었는지 체크하는 Map임
		HashMap<String, Boolean> isAddSubJob = new LinkedHashMap<String, Boolean>();
		for (String key : reformPortionsOfJob.keySet()) {
			List<Pair<Integer, Integer>> reformPortionsPerfile = reformPortionsOfJob.get(key);
			int i = 0;
			for (Pair<Integer, Integer> reformPortions : reformPortionsPerfile) {
				String portionId = new StringBuffer().append(key).append("_").append(i).toString();
				isAddSubJob.put(portionId, false);
				i++;
			}
		}

		this.faceFeatureList = getFeatures(req.getJobId());

		float portionOfProgress = 0.0f;
		float lastPortionOfProgress = 0.0f;
		int portionOfProgressInt = 0;
		int lastPortionOfProgressInt = 0;
		portionOfProgressInt = 100 / numOfNode; // portionOfPrgress 산출하는 로직 필요
		portionOfProgress = (float) (portionOfProgressInt * 0.01);

		// 전체 작업량이 100%가 되는지 체크
		int allPortionOfProgressInt = portionOfProgressInt * numOfNode;
		if (allPortionOfProgressInt < 100) {
			lastPortionOfProgressInt = portionOfProgressInt + (100 - allPortionOfProgressInt);
			lastPortionOfProgress = (float) (lastPortionOfProgressInt * 0.01);
		}

		// 파일 분배 -> 1개의 subJob당 4개의 Task가 할당됨
		List<AnalysisResource> tempAnalysisResources = new ArrayList<AnalysisResource>();
		List<Pair<Integer, Integer>> tempFilePeriods = new ArrayList<Pair<Integer, Integer>>();

		long sumSubJobUnitTime = 0;
		long sumTotalVideosLength = 0;
		int fileIndexOfJob = 0;

		if (faceFeatureList.size() > 0) {
			for (String key : reformPortionsOfJob.keySet()) {
				List<Pair<Integer, Integer>> splitedFile = reformPortionsOfJob.get(key);

				int indexOfInterval = 0;
				breakOut : for (Pair<Integer, Integer> interval : splitedFile) {
					String keyOfIsAddSubJob = new StringBuffer().append(key).append("_").append(indexOfInterval)
							.toString();

					if (isAddSubJob.get(keyOfIsAddSubJob) == false) {
						AnalysisResource analysisRsc = analysisResources.get(Integer.parseInt(key));
						tempAnalysisResources.add(analysisRsc);
						tempFilePeriods.add(Pair.of(interval.getLeft(), interval.getRight()));
						isAddSubJob.put(keyOfIsAddSubJob, true);

						int videoLength = interval.getRight() - interval.getLeft();
						sumTotalVideosLength += videoLength;
						if (sumTotalVideosLength > subJobUnitTime) {

							if ((numOfNode - 1) > ondemandVideoSubJobs.size()) {
								// 직전 작업 롤백
								// /////////////////////////////////////////////////////////////
								tempFilePeriods.remove(tempAnalysisResources.size() - 1);
								tempAnalysisResources.remove(analysisRsc);
								isAddSubJob.put(keyOfIsAddSubJob, false);
								sumTotalVideosLength = sumTotalVideosLength - videoLength;
								// //////////////////////////////////////////////////////////////////////

								OndemandVideoSubJob subJob = new OndemandVideoSubJob(portionOfProgress, this.jobId,
										this.baseDir, faceFeatureList, tempAnalysisResources, tempFilePeriods,
										req.getThreshold());
								ondemandVideoSubJobs.add(subJob);

								// isAddSubJob.put(keyOfIsAddSubJob, false);
								tempAnalysisResources = new ArrayList<AnalysisResource>();
								tempFilePeriods = new ArrayList<Pair<Integer, Integer>>();
								sumTotalVideosLength = 0;

								// 이전 작업에 대해 원복 한번더
								// //////////////////////////////////////////////////////
								analysisRsc = analysisResources.get(Integer.parseInt(key));
								tempAnalysisResources.add(analysisRsc);
								tempFilePeriods.add(Pair.of(interval.getLeft(), interval.getRight()));
								isAddSubJob.put(keyOfIsAddSubJob, true);

								videoLength = interval.getRight() - interval.getLeft();
								sumTotalVideosLength += videoLength;
								// ////////////////////////////////////////////////////////////////////////
							}
						}
					}

					indexOfInterval++;
				}
			}

			// 남은 파일 용량 조사
			int remainAnalTimes = 0;
			for (Pair<Integer, Integer> tmpInterval : tempFilePeriods) {
				int remainAnalTime = tmpInterval.getRight() - tmpInterval.getLeft();
				remainAnalTimes += remainAnalTime;
			}

			if (remainAnalTimes <= subJobUnitTime) {
				OndemandVideoSubJob subJob = new OndemandVideoSubJob(portionOfProgress, this.jobId, this.baseDir,
						faceFeatureList, tempAnalysisResources, tempFilePeriods, req.getThreshold());
				ondemandVideoSubJobs.add(subJob);
			} else {

				List<AnalysisResource> lastAnalysisResources = new ArrayList<AnalysisResource>();
				List<Pair<Integer, Integer>> lastFilePeriods = new ArrayList<Pair<Integer, Integer>>();
				List<AnalysisResource> tempAnalysisResources1 = new ArrayList<AnalysisResource>();
				tempAnalysisResources1.addAll(tempAnalysisResources);
				List<Pair<Integer, Integer>> tempFilePeriods1 = new ArrayList<Pair<Integer, Integer>>();
				tempFilePeriods1.addAll(tempFilePeriods);

				int tmpRemainAnalTimes = 0;
				int idx = 0;
				for (Pair<Integer, Integer> tmpInterval : tempFilePeriods) {
					int remainAnalTime = tmpInterval.getRight() - tmpInterval.getLeft();
					tmpRemainAnalTimes += remainAnalTime;

					// AnalysisResource tempLastAnalysisRsc =
					// tempAnalysisResources1.remove(idx);
					AnalysisResource tempLastAnalysisRsc = tempAnalysisResources.get(idx);
					lastAnalysisResources.add(tempLastAnalysisRsc);
					tempAnalysisResources1.remove(tempLastAnalysisRsc);
					Pair<Integer, Integer> tmpLastInterval = tempFilePeriods.get(idx);
					lastFilePeriods.add(tmpLastInterval);
					tempFilePeriods1.remove(tmpLastInterval);
					if (tmpRemainAnalTimes >= subJobUnitTime) {
						OndemandVideoSubJob subJob = new OndemandVideoSubJob(portionOfProgress, this.jobId,
								this.baseDir, faceFeatureList, lastAnalysisResources, lastFilePeriods,
								req.getThreshold());
						ondemandVideoSubJobs.add(subJob);

						break;
					}

					idx++;
				}

				// 어제로직 넣기, 분배로직
				List<AnalysisResource> tempAnalysisResources2 = new ArrayList<AnalysisResource>();
				tempAnalysisResources2.addAll(tempAnalysisResources1);
				List<Pair<Integer, Integer>> tempFilePeriods2 = new ArrayList<Pair<Integer, Integer>>();
				tempFilePeriods2.addAll(tempFilePeriods1);
				if (ondemandVideoSubJobs.size() > 1) {
					// 보정작업, 남은 파일에 대해서임
					for (int i = 0; i < tempAnalysisResources1.size(); i++) {

						OndemandVideoSubJob tempSubJob = ondemandVideoSubJobs.get(0);

						List<AnalysisResource> tempRsc = tempSubJob.getAnalysisResources();
						AnalysisResource addingAnalysisRsc = tempAnalysisResources2.remove(tempAnalysisResources2
								.size() - 1);
						tempRsc.add(addingAnalysisRsc);

						List<Pair<Integer, Integer>> tempFPeriods = tempSubJob.getFilePeriods();
						Pair<Integer, Integer> addingFilePeriod = tempFilePeriods2.remove(tempFilePeriods2.size() - 1);
						tempFPeriods.add(addingFilePeriod);

						tempSubJob.setAnalysisResources(tempRsc);
						tempSubJob.setFilePeriods(tempFPeriods);
						ondemandVideoSubJobs.add(tempSubJob);
						ondemandVideoSubJobs.remove(0);
					}
				}
			}
		}
		if (ondemandVideoSubJobs.size() > 0 && allPortionOfProgressInt < 100) {
			OndemandVideoSubJob lastSubJob = ondemandVideoSubJobs.get(ondemandVideoSubJobs.size() - 1);
			ondemandVideoSubJobs.remove(ondemandVideoSubJobs.size() - 1);
			lastSubJob.setPortionOfProgress(lastPortionOfProgress);
			ondemandVideoSubJobs.add(lastSubJob);
		}

		return ondemandVideoSubJobs;
	}

	@Override
	public int search(OndemandVideoSubJob subJob, int nodeId, String masterAddress) throws Exception {

		this.logger.info("This video subJob's masterAddress: {}, node: {}", masterAddress, nodeId);

		final String jobId = subJob.getJobId();
		final List<AnalysisResource> analysisResources = subJob.getAnalysisResources();
		final List<Pair<Integer, Integer>> filePeriods = subJob.getFilePeriods();
		final int threshold = subJob.getThreshold();
		this.faceFeatureList = subJob.getConcernFaces();

		if (analysisResources.isEmpty()) {
			final String msg = String.format("The search job[id: %1$s] contains NO video file.", jobId);
			throw new IllegalArgumentException(msg);
		} else if (filePeriods.isEmpty()) {
			final String msg = String.format("The search job[id: %1$s] contains NO divided task.", jobId);
			throw new IllegalArgumentException(msg);
		}

		// Observer 생성
		ObserverProgressOnDemandCluster observer = new ObserverProgressOnDemandCluster(faceMatchJobService,
				this.getSearchDataManager());
		observer.setJobId(jobId);
		observers.add(observer);

		// int taskUnitTime =
		// Integer.parseInt(demandWithFileParameter.getVideoUnitTime()) * 60 *
		// 1000; //분 * 60 * 1000(=1초). db에서 msec로 나오기 때문이다.

		int totalVideoLengthForTask = 0;
		int analysisFileTime = 0;
		for (Pair<Integer, Integer> filePeriod : filePeriods) {
			analysisFileTime = filePeriod.getRight() - filePeriod.getLeft();
			totalVideoLengthForTask += analysisFileTime;
		}

		double dTaskUnitTime = totalVideoLengthForTask / (double) threadNum;
		int taskUnitTime = (int) Math.ceil(dTaskUnitTime);

		if (taskUnitTime < 1) {
			this.logger.info("totalVideoLengthForTask is very short or is zero");
			return 0;
		}

		List<ClusterFileAnalysisTask> tasks = new ArrayList<ClusterFileAnalysisTask>();
		int taskId = 1;

		if (this.faceFeatureList.size() > 0) {
			int indexOfAnalysisRcs = 0;
			for (Pair<Integer, Integer> filePeriod : filePeriods) {
				analysisFileTime = filePeriod.getRight() - filePeriod.getLeft();
				int cntDividedAnalysisFile = analysisFileTime / taskUnitTime + 1;
				AnalysisResource analysisRsc = analysisResources.get(indexOfAnalysisRcs);
				int fromPositionInFile = 0;
				int toPositionInFile = 0;

				for (int i = 0; i < cntDividedAnalysisFile; i++) {

					if (i == (cntDividedAnalysisFile - 1)) {
						fromPositionInFile = filePeriod.getLeft() + (taskUnitTime * i);
						toPositionInFile = filePeriod.getRight();
					} else {
						fromPositionInFile = filePeriod.getLeft() + (taskUnitTime * i);
						toPositionInFile = filePeriod.getLeft() + (taskUnitTime * (i + 1));
					}

					if (fromPositionInFile < toPositionInFile) {
						tasks.add(new ClusterFileAnalysisTask(jobId, String.valueOf(taskId), analysisRsc,
								this.filePreparer, sParserAdapter, this.skips, this.thumbnailPersister, this
										.getFaceDataManager(), this.hbInnoParam, this.faceFeatureList,
								this.faceMatchJobService, this.demandWithFileParameter, this.baseDir, observer,
								threshold, fromPositionInFile, toPositionInFile, nodeId, masterAddress, searchDataMgr,
								this.asyncHttpClient));
						synchronized (observer) {
							// observe 전체파일 갯수 세팅
							String dirAndTaskId = new StringBuffer().append(jobId).append("_")
									.append(analysisRsc.getRscFileNm()).append("_").append(taskId).toString();
							observer.addTotalFilesForTask(dirAndTaskId, 1, subJob.getPortionOfProgress());

						}
						taskId++;
					} else {
						this.logger.warn("This case {} ~ {} is invalid video analysis interval for {}.",
								fromPositionInFile, toPositionInFile, analysisRsc.getRscPath());
					}

				}

				indexOfAnalysisRcs++;
			}
		}

		int sizeOftasks = tasks.size();
		List<Future<Void>> futures = new ArrayList<Future<Void>>(sizeOftasks);

		if (sizeOftasks == 0) {
			String failedMessage = String.format("No any concerned face or files on this subJob - jobId: {},",
					this.jobId);
			// sendCompletedTaskMessage(masterAddress, "ONDEMAND_VIDEO_RESULT",
			// this.getJobId(), nodeId, -1, failedMessage);
			throw new RuntimeException(
					"Fail to start video job because any task is made or the vms path cannot access by not logining!! - "
							+ this.jobId);
		}

		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		HashMap<String, Object> startJobParam = new HashMap<String, Object>();
		startJobParam.put("job_id", jobId);
		this.faceMatchJobService.updateJobStartTime(startJobParam);

		int i = 0;
		for (ClusterFileAnalysisTask task : tasks) {
			try {

				i++;
				logger.info("{} 's task at {}, {} ~ {}!!", i, task.getAnalysisRsc().getRscPath(),
						task.getFromPositionInFile(), task.getToPositionInFile());
				task.setHbinnoEngine(this.hbinnoEngineInstance);
				task.setTaskNum(sizeOftasks);
				futures.add(this.executor.submit(task));

			} catch (Throwable ex) {
				String failedMessage = String.format(
						"Fail to submit a face search task for ondemand Video. - jobId: {}, taskId: {}",
						task.getJobId(), task.getTaskId());
				sendCompletedTaskMessage(masterAddress, "ONDEMAND_VIDEO_RESULT", this.getJobId(), nodeId, -1,
						failedMessage);
				this.logger.error("Fail to submit a face search task. - jobId: {}, taskId: {}", task.getJobId(),
						task.getTaskId());
				this.logger.error(">>>>>>>>>>>> {}", ex);
			}

		}

		return tasks.size(); // search가 끝난 스레드의 갯수 리턴

	}

	@Override
	public int abort(int nodeId, String masterAddress) throws Exception {
		logger.info("++STOP      Ondemand Video      COMMAND      INPUT  ");

		for (ObserverProgressOnDemandCluster observer : observers) {
			observer.setAborted(true);
		}

		String jobId = null;
		if (observers.size() > 0) {
			jobId = observers.get(0).getJobId();
		} else {
			jobId = "";
		}

		String abortMessage = String.format("nodeId {} is Aborted by user!!", nodeId);
		sendCompletedTaskMessage(masterAddress, "ONDEMAND_VIDEO_ABORT_RESULT", jobId, nodeId, 1, abortMessage);
		return 1;
	}

	public void destroy() {
		if (this.executor != null && !(this.executor instanceof ExecutorServiceAdapter)) {
			this.executor.shutdown();
		}
	}

	private List<Integer> getSumsOfCumulativeSubJob(List<Pair<Integer, Integer>> portionsOfJob, int numOfSubJob) {

		List<Integer> sumsOfCumulativeSubJob = new ArrayList<Integer>();
		int sum = 0;
		sumsOfCumulativeSubJob.add(sum);

		for (Pair<Integer, Integer> portion : portionsOfJob) {
			sum += (portion.getRight() - portion.getLeft());
			sumsOfCumulativeSubJob.add(sum);
		}

		return sumsOfCumulativeSubJob;

	}

	/*
	 * VAS_JOB_CNCRN_FACE의 face id 값에 해당되는 feature 정보를 VAS_CNCRN_FACE table에서
	 * 가져온다
	 */
	private Map<String, byte[]> getFeatures(String jobId) {

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);

		/*
		 * String: face id Object: byte[] feature
		 */
		List<HashMap<String, Object>> faceFeatures = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		Map<String, byte[]> concernFaces = new HashMap<String, byte[]>();
		for (HashMap<String, Object> faceFeature : faceFeatures) {
			concernFaces.put(String.valueOf(faceFeature.get("job_cncrn_face_id")), (byte[]) faceFeature.get("feature"));
		}

		return concernFaces;
	}

	private void sendCompletedTaskMessage(String masterAddress, String type, String jobId, int nodeId, int result,
			String message) {

		AsyncHttpClient.BoundRequestBuilder builder = this.asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", type);
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", result);
		loginParam.put("subJobMessage", message);

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

@Immutable
class ClusterFileAnalysisTask implements Callable<Void> {

	private final String jobId;

	protected String getJobId() {
		return this.jobId;
	}

	private final String taskId;

	protected String getTaskId() {
		return this.taskId;
	}

	private final AnalysisResource analysisRsc;

	protected AnalysisResource getAnalysisRsc() {
		return this.analysisRsc;
	}

	private final int fromPositionInFile;

	protected int getFromPositionInFile() {
		return this.fromPositionInFile;
	}

	private final int toPositionInFile;

	protected int getToPositionInFile() {
		return this.toPositionInFile;
	}

	private final FilePreparer filePreparer;

	private final SParserJNI sParserAdapter;

	private final int skips;

	private final ThumbnailPersister thumbPersister;

	private final FaceDataManager faceDataManager;

	private final HbInnoParameter hbInnoParameter;

	private Map<String, byte[]> faceFeatureList;

	private final FaceMatchJobService faceMatchJobService;

	private final OnDemandWithFileParameter demandWithFileParameter;

	private final String baseDir;

	private final ObserverProgressOnDemandCluster observer;

	private HbinnoEngine hbinnoEngine;

	public void setHbinnoEngine(HbinnoEngine hbinnoEngine) {
		this.hbinnoEngine = hbinnoEngine;
	}

	private final int threshold;

	// http 전송용
	private int nodeId;

	private String masterAddress;

	private SearchDataManager searchDataMgr;

	public void setSearchDataMgr(SearchDataManager searchDataMgr) {
		this.searchDataMgr = searchDataMgr;
	}

	private int taskNum;

	public void setTaskNum(int taskNum) {
		this.taskNum = taskNum;
	}

	private AsyncHttpClient asyncHttpClient;

	public ClusterFileAnalysisTask(@NotBlank String jobId, @NotBlank String taskId,
			@Nonnull AnalysisResource analysisRsc, @Nonnull FilePreparer filePreparer,
			@Nonnull SParserJNI sParserAdapter, @Min(0) int skips, @Nullable ThumbnailPersister thumbPersister,
			@Nonnull FaceDataManager faceDataManager, @Nonnull HbInnoParameter hbInnoParam,
			Map<String, byte[]> faceFeatureList, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull OnDemandWithFileParameter demandWithFileParameter, @Nonnull String baseDir,
			@Nonnull ObserverProgressOnDemandCluster observer, @Nonnull int threshold, @Nonnull int fromPositionInFile,
			@Nonnull int toPositionInFile, int nodeId, String masterAddress, SearchDataManager searchDataMgr,
			AsyncHttpClient asyncHttpClient) {

		this.jobId = jobId;
		this.taskId = taskId;
		this.analysisRsc = analysisRsc;
		this.filePreparer = filePreparer;
		this.sParserAdapter = sParserAdapter;
		this.skips = skips;
		this.thumbPersister = thumbPersister;
		this.faceDataManager = faceDataManager;
		this.hbInnoParameter = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.baseDir = baseDir;
		this.observer = observer;
		this.threshold = threshold;
		this.fromPositionInFile = fromPositionInFile;
		this.toPositionInFile = toPositionInFile;
		this.nodeId = nodeId;
		this.masterAddress = masterAddress;
		this.searchDataMgr = searchDataMgr;
		this.asyncHttpClient = asyncHttpClient;
	}

	@Override
	public Void call() {
		// FileAnalysisProcessor<AnalysisResource, FaceEvent,
		// TriumiEventContext> task
		// = new SParserHbInnoClusterSearchTaskProcessor(this.filePreparer,
		// this.sParserAdapter, this.thumbPersister,
		// this.faceDataManager, this.skips, this.hbInnoParameter,
		// this.faceFeatureList,
		// this.faceMatchJobService, this.demandWithFileParameter, this.baseDir,
		// this.observer,
		// this.hbinnoEngine, this.threshold, this.fromPositionInFile ,
		// this.toPositionInFile,
		// this.nodeId, this.masterAddress);

		FileAnalysisProcessor<AnalysisResource, FaceEvent, TriumiEventContext> task = new SParserHbInnoClusterSearchTaskProcessor(
				this.filePreparer, this.sParserAdapter, this.thumbPersister, this.faceDataManager, this.skips,
				this.hbInnoParameter, this.faceFeatureList, this.faceMatchJobService, this.demandWithFileParameter,
				this.baseDir, this.observer, this.hbinnoEngine, this.threshold, this.fromPositionInFile,
				this.toPositionInFile, this.nodeId, this.masterAddress, this.searchDataMgr, this.taskNum,
				this.asyncHttpClient);

		((SParserHbInnoClusterSearchTaskProcessor) task).postConstruct();
		((SParserHbInnoClusterSearchTaskProcessor) task).process(this.jobId, this.taskId, this.analysisRsc);
		((SParserHbInnoClusterSearchTaskProcessor) task).preDestroy();

		return null;

	}
}
