package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.concurrent.NotThreadSafe;
import javax.management.ObjectName;
import javax.validation.constraints.Min;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.mutable.MutableLong;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.json.JSONObject;
import org.springframework.jmx.export.MBeanExporter;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.ning.http.client.AsyncHttpClient;
import com.skcc.adapter.vms.incon.FsUtilAdapter;
import com.skcc.adapter.vms.incon.FsUtilTypes.Result;
import com.skcc.adapter.vms.incon.FsUtilTypes.VideoFrameData;
import com.skcc.adapter.vms.incon.FsUtilTypes.VideoFrameHeader;
import com.skcc.adapter.vms.incon.FsUtilTypes.VideoOpenParam;
import com.skcc.adapter.vms.incon.SimpleVideoFileInfo;
import com.skcc.adapter.vms.incon.TriumiUtils;
import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.adapter.fr.hbinno.HbInnoFace;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.common.biz.event.FaceEvent;
import com.skcc.vas.frs.common.biz.model.SearchProgressListener;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.model.SearchResult;
import com.skcc.vas.frs.common.biz.model.ThumbnailPersister;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace.ImageFormat;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.base.TaskStatus;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;
import com.skcc.vas.frs.common.util.ondemand.OnDemandWithFileParameter;
import com.skcc.vas.frs.common.util.ondemand.TimeRangeRuler;
import com.skcc.vas.frs.ondemand.vms.model.SimpleSearchCriteria;

@NotThreadSafe
public class TriumiHbInnoClusterSearchTaskProcessor
		extends
			AbstractTriumiSearchTaskProcessor<SimpleSearchCriteria, FaceEvent> {

	private static final String SERVICE_TYPE_NAME = "ONDEMAND_FACE_RECOG";

	@Nonnull
	private final FaceDataManager faceDataManager;

	@Nullable
	private volatile SearchProgressListener progressListener;

	@ManagedAttribute
	public boolean hasProgressListener() {
		return (this.progressListener == null) ? false : true;
	}

	public void setProgressListener(@Nullable SearchProgressListener progressListener) {
		this.progressListener = progressListener;
	}

	private final String[] dateFormatChars = new String[]{"-", " ", ":"};
	private final String[] emptyChars = new String[]{"", "", ""};

	private TimeRangeRuler timeRangeRuler;

	@Nullable
	private MBeanExporter mBeanExporter;

	public void setMBeanExporter(@Nullable MBeanExporter exporter) {
		this.mBeanExporter = exporter;
	}

	@Nullable
	private ObjectName mBeanName;

	public void setObjectName(@Nullable ObjectName name) {
		this.mBeanName = name;
	}

	// @TODO Review escalating searchResult upto parent
	private final SearchResult<FaceEvent, TriumiEventContext> searchResult;

	private HbInnoParameter hbInnoParam; // config.properties 파일에서 읽어 온 HBInno
											// parameter 값

	private FaceMatchJobService faceMatchJobService;

	private Map<String, byte[]> faceFeatureList;

	private TriumiVideoStore videoStores;

	private OnDemandWithFileParameter demandWithFileParameter;

	// @Value("${vas.dataDir}")
	private String vadDir;

	// @Value("${vas.thumbnail.saveDir}")
	private String thumbnailDirName;

	// @Value("${vas.screenshot.saveDir}")
	private String screenshotDir;

	// @Value("${vas.screenshot.cctvResolutionEnable}")
	private String cctvResolutionEnable;

	private String vmsDataDir;

	private String mode;

	private String pattern = DirectAccessFilePreparer.DEFAULT_DEVICE_DIR_PATTERN;

	/*
	 * 시스템 환경 변수로 부터 구한 VAS_DATA_DIR 값 =
	 * Watz_Eye_VAS/data/face/vmsid/deviceid/currentdate/filename.jpg
	 */
	private String thumbBase;

	private ObserverProgressOnDemandCluster observer;

	private String dirAndTaskId;

	private HbinnoEngine hbinnoEngine;

	private TriumiVideoStore.FileValue[] files;

	private int nodeId;

	private String masterAddress;

	private SearchDataManager searchDataMgr;

	private int taskNum;

	private int cntTotalSubJobFiles;

	private AsyncHttpClient asyncHttpClient;

	// statistics for jmx
	private long numDetectedFace = 0;
	private long numMatchedFace = 0;
	private long numEfficientFrame = 0;
	private long totalElapasedTimeinMsec = 0;
	private long threadStartTime = 0;

	// check invalid frame count
	private int invalidFrameCount = 0;
	private long previousFrameTime = 0;

	public TriumiHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull FsUtilAdapter fsUtilAdapter, @Nonnull HbInnoAdapter hbInnoAdapter,
			@Nonnull FaceDataManager faceDataManager, @Min(0) int skips) {

		this(filePreparer, fsUtilAdapter, hbInnoAdapter, null, faceDataManager, skips);
	}

	public TriumiHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull FsUtilAdapter fsUtilAdapter, @Nonnull HbInnoAdapter hbInnoAdapter,
			@Nullable ThumbnailPersister thumbPersister, @Nonnull FaceDataManager faceDataManager, @Min(0) int skips) {

		super(filePreparer, fsUtilAdapter, thumbPersister, skips);

		Validate.isTrue(hbInnoAdapter != null, "Adapter for HBInno's FR engine should be provided.");
		Validate.isTrue(faceDataManager != null, "Face data manager should be provided.");

		// this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.searchResult = new SearchResult<FaceEvent, TriumiEventContext>();
	}

	public TriumiHbInnoClusterSearchTaskProcessor(@Nonnull FilePreparer filePreparer,
			@Nonnull FsUtilAdapter fsUtilAdapter, @Nullable ThumbnailPersister thumbPersister,
			@Nonnull FaceDataManager faceDataManager, @Min(0) int skips, @Nonnull HbInnoParameter hbInnoParam,
			@Nonnull Map<String, byte[]> faceFeatureList, FaceMatchJobService faceMatchJobService,
			OnDemandWithFileParameter demandWithFileParameter, ObserverProgressOnDemandCluster observer,
			@Nonnull HbinnoEngine hbinnoEngine, TriumiVideoStore.FileValue[] files, int nodeId, String masterAddress,
			SearchDataManager searchDataMgr, int taskNum, AsyncHttpClient asyncHttpClient) {

		super(filePreparer, fsUtilAdapter, thumbPersister, skips);

		Validate.isTrue(faceDataManager != null, "Face data manager should be provided.");

		this.faceDataManager = faceDataManager;
		this.searchResult = new SearchResult<FaceEvent, TriumiEventContext>();
		this.hbInnoParam = hbInnoParam;
		this.faceFeatureList = faceFeatureList;
		this.faceMatchJobService = faceMatchJobService;
		this.demandWithFileParameter = demandWithFileParameter;
		this.observer = observer;
		this.hbinnoEngine = hbinnoEngine;
		this.files = files;
		this.nodeId = nodeId;
		this.masterAddress = masterAddress;
		this.searchDataMgr = searchDataMgr;
		this.taskNum = taskNum;

		this.vadDir = demandWithFileParameter.getVadDir();
		this.thumbnailDirName = demandWithFileParameter.getThumbnailDirName();
		this.screenshotDir = demandWithFileParameter.getScreenshotDir();
		this.cctvResolutionEnable = demandWithFileParameter.getCctvResolutionEnable();
		this.vmsDataDir = demandWithFileParameter.getVmsDataDir();

		int cntTotalSubJobFiles = 0;
		Map<String, ProgressForClusterTask> progressTasks = observer.getProgressTasks();
		for (String key : progressTasks.keySet()) {
			cntTotalSubJobFiles += progressTasks.get(key).getTotalFilesCnt();
		}
		this.cntTotalSubJobFiles = cntTotalSubJobFiles;
		this.asyncHttpClient = asyncHttpClient;
	}

	@PostConstruct
	public void postConstruct() {
		// Validate.isTrue(this.getFilePreparer() != null,
		// "FilePreparer should be provided at instance construction time.");
		Validate.isTrue(this.getFsUtilAdapter() != null,
				"FsUtilAdapter should be provided at instance construction time.");
		// Validate.isTrue(this.getHbInnoAdapter() != null,
		// "The adapter for HB Inno FR engine should be provided at instance construction time.");
		Validate.isTrue(this.getDefaultSkipsAfterDetect() > -1, "Skip number should be nonnegative.");

		if (this.mBeanExporter != null) {
			try {
				if (this.mBeanName == null) {
					Hashtable<String, String> tbl = new Hashtable<String, String>();
					tbl.put("type", "bean");
					tbl.put("name", this.getClass().getSimpleName());
					tbl.put("hash", Integer.toHexString(this.hashCode()));

					this.mBeanName = new ObjectName("", tbl);
				}
				mBeanExporter.registerManagedResource(this, this.mBeanName);
			} catch (Exception ex) {
				this.logger.error("Fail to register MBean of TriumiVcSearchTaskProcessor intance.", ex);
			}
		}
	}

	@PreDestroy
	public void preDestroy() {
		if (this.mBeanExporter != null && this.mBeanName != null) {
			try {
				mBeanExporter.unregisterManagedResource(this.mBeanName);
			} catch (Exception ex) {
				this.logger.error("Fail to unregister MBean of TriumiVcSearchTaskProcessor intance.", ex);
			}
		}
	}

	// @TODO Should manage search task status.
	/**
	 * Saves the found results(events and event contexts) regularly, more
	 * exactly by each video file in the middle of execution.
	 */
	@Override
	public SearchResult<FaceEvent, TriumiEventContext> process(String jobId, String taskId, SimpleSearchCriteria crtr) {
		this.setJobId(jobId);
		this.setTaskId(taskId);
		this.setCriteria(crtr);

		this.setStatus(TaskStatus.IN_PROGRESS);
		if (this.hasProgressListener()) {
			this.progressListener.taskStarted(jobId, taskId, System.currentTimeMillis());
		}

		logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> jobId: {}, taskId: {}", jobId, taskId);

		this.thumbBase = getThumbBaseDir(crtr.getSystemId(), crtr.getDeviceId());

		// observe 전체파일 갯수 세팅
		String dirAndTaskId = new StringBuffer().append(crtr.getSystemId()).append("_").append(crtr.getDeviceId())
				.append("_").append(taskId).toString();
		this.dirAndTaskId = dirAndTaskId;

		SearchResult<FaceEvent, TriumiEventContext> result = null;
		int cnt = 0;
		HashMap<String, Object> stopChkParam = new HashMap<String, Object>();
		stopChkParam.put("job_id", this.getJobId());
		for (TriumiVideoStore.FileValue f : files) {

			try {
				result = this.analysisFile(f.getFullName(), this.getDefaultSkipsAfterDetect(), crtr);

				if (observer.isAborted() == true) {
					logger.error("[Task].........STOP.......");
					// throw new
					// RuntimeException("Stopped due to stop command!");
					// String abortMessage =
					// String.format("nodeId {} is Aborted by user for ondemand vms!!",
					// this.nodeId );
					// sendCompletedTaskMessage(this.masterAddress,
					// "ONDEMAND_VMS_ABORT_RESULT", jobId, this.nodeId, 1,
					// abortMessage);
					return result;
				}

				for (Pair<? extends FaceEvent, TriumiEventContext> pair : result.getItems()) {
					this.searchResult.addItem(pair.getLeft(), pair.getRight());
				}

				Thread.sleep(2000);

				if (this.hasProgressListener()) {
					this.progressListener.setTaskProgress(jobId, taskId, ++cnt, files.length,
							this.getNumberOfExceptions(), System.currentTimeMillis());
				}

			} catch (Throwable ex) {
				String failedMessage = String.format("Fail to analysis file {}", f.getFullName());
				logger.warn("Fail to analysis file {}", f.getFullName(), ex);
				sendCompletedTaskMessage(masterAddress, "ONDEMAND_VMS_RESULT", this.getJobId(), nodeId, -1,
						failedMessage);
				this.addNumberOfExceptions(1);
			}
		}

		sendCompletedTaskMessage(this.masterAddress, "ONDEMAND_VMS_RESULT", this.getJobId(), this.nodeId, 1, "success");

		this.setStatus(TaskStatus.COMPLETED);
		if (this.hasProgressListener()) {
			this.progressListener.taskFinished(jobId, taskId, TaskStatus.COMPLETED, System.currentTimeMillis());
		}
		return this.searchResult;
	}

	/**
	 * @param path
	 *            Full path for the file to analysis
	 * @throws NullPointerException
	 * @throws IllegalArgumentException
	 */
	@Nonnull
	protected final SearchResult<FaceEvent, TriumiEventContext> analysisFile(@NotBlank String path, int skips,
			SimpleSearchCriteria crtr) {
		Validate.isTrue(StringUtils.isNotBlank(path), "The file to analysis is not specified.");
		Validate.isTrue(crtr != null, "The criteria for analysis is not specified.");
		this.logger.info("Analyzing a file. - {}, skips: {}", path, skips);

		MutableLong fHandle = new MutableLong(0);
		VideoOpenParam openParam = new VideoOpenParam();
		SimpleVideoFileInfo fileInfo = new SimpleVideoFileInfo();
		VideoFrameHeader frmHeader = new VideoFrameHeader();
		VideoFrameData frmData = new VideoFrameData();

		Result result;
		int gopCheck = 120;

		result = this.getFsUtilAdapter().openFileAndGetFirstDecodedFrame(path, true, this.getDecodingMode(),
				this.getDecodeFlag(), fHandle, openParam, fileInfo, frmHeader, frmData);

		if (result == Result.EOF) {
			// 읽다가 실패하는 곳 처리
			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("job_id", this.getJobId());
			param.put("task_id", this.getTaskId());
			param.put("file_path", path);
			param.put("anal_src_type", "FILE");
			param.put("rslt_code", "FailOpen");
			faceMatchJobService.insertFailedFile(param);

			this.getFsUtilAdapter().closeFile(fHandle.longValue());
			throw new RuntimeException("Fail to open and get first decoded frame from " + path + ", result: "
					+ result.getConstant());
		}
		this.logger.debug("++ handle value is {} of {}", fHandle.longValue(), path);
		
		// else if(result == Result.INVALID_HANDLE){
		//
		// this.getFsUtilAdapter().closeFile(fHandle.longValue());
		// try {
		// Thread.sleep(5*1000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// result =
		// this.getFsUtilAdapter().openFileAndGetFirstDecodedFrame(path, true,
		// this.getDecodingMode(), this.getDecodeFlag(), fHandle, openParam,
		// fileInfo, frmHeader, frmData);
		// }

		final SearchResult<FaceEvent, TriumiEventContext> srchResult = new SearchResult<FaceEvent, TriumiEventContext>();
		TriumiEventContext cntx = null;
		int skipNum = skips;
		String thumb = null; // thumbnail file name relative to
								// 'VAS_THUMBNAIL_DIR'

		String stopCmd = "";

		// -------------------------------------- 매번 돌때마다 aborted 인지를 체크한다.
		if (observer.isAborted() == true) {
			logger.error("[file].........STOP.......");
			// throw new RuntimeException("Stopped due to stop command!");
			return srchResult;
		}
		// -----------------------------------------------------------------------------

		int verificationThreshold;
		if (crtr.getThreshold() > 0) {
			verificationThreshold = crtr.getThreshold();
		} else {
			verificationThreshold = (int) (hbInnoParam.getVerificationThreshold() * 100);
		}

		while (true) {
			// fetch another frame
			result = this.getFsUtilAdapter().getAfterwardDecodedFrame(fHandle.longValue(), skipNum,
					this.getDecodingMode(), this.getDecodeFlag(), frmHeader, frmData);

			Date dt = TriumiUtils.convertTimeStampToDate(frmHeader.frameTime, this.getTimeZone());

			if (gopCheck-- == 0) {
				this.logger.info("openFileAndGetFirstDecodeFrame Gop Read fail.");
				break;
			}

			this.logger.debug("Analyzing next frame. getAfterwardDecodedFrame result:{}, codecResult:{}, "
					+ "frmData.decFramePtr: {}, frmData.width: {}, frmData.height: {} .", result, frmData.decResult,
					frmData.decFramePtr, frmData.width, frmData.height);

			// to detect error in incon SDK
			// if(this.getFsUtilAdapter() != null){
			// final String date2 = BaseUtils.formatToYear2MillisecString(new
			// java.util.Date());
			// StringBuilder sb2 = new
			// StringBuilder().append("E:\\\\capture_shot\\")
			// .append(date2.substring(0, 8)).append("/");
			//
			// String tempPath = sb2.toString();
			// try {
			// FileUtils.forceMkdir(new java.io.File(tempPath));
			// } catch (Exception ex) {
			// throw new
			// IllegalStateException("Unexpected fail of path resolution.", ex);
			// }
			//
			// sb2.append(date2.substring(8)).append(".").append(ImageFormat.JPG).toString();
			// getFsUtilAdapter().saveImageToFile(sb2.toString(),frmData.width,frmData.height,frmData.decFramePtr,
			// (int)frmData.decFrameSize);
			//
			// }

			if (result != Result.OK) { // EOF 나와도 나감
				this.logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}", result.getConstant());
				break;
			}

			for (String key : faceFeatureList.keySet()) {
				List<HbInnoFace> loadResult = hbinnoEngine.loadFrameAndVerify(frmData.decFramePtr, frmData.width,
						frmData.height, frmData.width * 3, this.thumbBase, faceFeatureList.get(key),
						verificationThreshold);

				HashMap<String, Object> faceMatch = new HashMap<String, Object>();
				if (loadResult.size() > 0) {

					String frmTime = BaseUtils.formatToYear2MillisecString(dt);
					// save screen shot
					String shotDir = null;
					String shotPath = null;
					String shotpath2 = null;
					if (this.getFsUtilAdapter() != null) {
						Pair<String, String> pathAndDir = getScreenshotPathAndDir(crtr.getSystemId(),
								crtr.getDeviceId());
						shotPath = pathAndDir.getLeft();
						shotDir = pathAndDir.getRight();

						final String date = BaseUtils.formatToYear2MillisecString(new java.util.Date()); // 'yyyyMMddHHmmssSSS'
																											// format
						StringBuilder sb = new StringBuilder().append(vmsDataDir).append(screenshotDir).append("/")
								.append(crtr.getSystemId()).append("/").append(crtr.getDeviceId()).append("/")
								.append(date.substring(0, 8)).append("/");
						sb.append(date.substring(8)).append(".").append(ImageFormat.JPG).toString();
						shotpath2 = sb.toString();

						try {
							FileUtils.forceMkdir(new java.io.File(shotDir));
						} catch (Exception ex) {
							throw new IllegalStateException("Unexpected fail of path resolution.", ex);
						}
						getFsUtilAdapter().saveImageToFile(shotPath, frmData.width, frmData.height,
								frmData.decFramePtr, (int) frmData.decFrameSize);

					}

					// insert result in DB
					for (HbInnoFace hbInnoFace : loadResult) {
						String imgFileAbsolutePath = hbInnoFace.getAbsolutePath();
						String imgFileComparePath = null;

						if (imgFileAbsolutePath != null)
							imgFileComparePath = imgFileAbsolutePath.replace(vadDir, "");

						faceMatch = new HashMap<String, Object>();
						faceMatch.put("job_cncrn_face_id", key);
						faceMatch.put("score", hbInnoFace.getScore());
						faceMatch.put("systemId", crtr.getSystemId());
						faceMatch.put("cctvId", crtr.getDeviceId());
						faceMatch.put("srvcType", SERVICE_TYPE_NAME);
						faceMatch.put("imgFile", imgFileComparePath);
						faceMatch.put("imgW", hbInnoFace.getImgWidth());
						faceMatch.put("imgH", hbInnoFace.getImgHeight());
						faceMatch.put("imgX", hbInnoFace.getImgX());
						faceMatch.put("imgY", hbInnoFace.getImgY());
						faceMatch.put("frmFile", shotpath2);
						faceMatch.put("frmW", frmData.width);
						faceMatch.put("frmH", frmData.height);
						faceMatch.put("frmTime", frmTime);

						/* 결과를 DB 에 저장 */
						this.faceMatchJobService.insertJobFaceMatch(faceMatch);
					}
				}

			}
		}

		if (result != Result.EOF) {
			// Even if the analysis of vms file is not completed,
			// completedFilesForTask is increased by request!!
			observer.setProgressCompletedFilesForTask(this.dirAndTaskId, 1);
			this.logger.warn("Unexpected searchResult from HbInno FR engine: {}", result.toString());
		} else {
			observer.setProgressCompletedFilesForTask(this.dirAndTaskId, 1);
			this.logger.info("Analyzed a file. - {}, skips: {}", path, skips);
		}
		
		this.logger.debug("++ Before closeFile handle {} of {}", fHandle.longValue(), path);
		File file = new File(path);
		if(file.exists()) {
			
		} else {
			this.logger.error("++ VF1 File [{}] is not exist !!!", path);
			throw new IllegalStateException("++ VF1 File [" + path + "] is not exist !!!");
		}
		
		result = this.getFsUtilAdapter().closeFile(fHandle.longValue());
		if (result != Result.OK) {
			this.logger.warn("Fail to close a file. : {}", path);
		} else {
			this.logger.info("{} is close. status: {}", path, result.getConstant());
		}

		synchronized (searchDataMgr) {
			SearchRequest jobRequestInfo = searchDataMgr.findSearchRequest(this.getJobId());
			if (jobRequestInfo == null) {
				final String msg = String.format("The search job[id: %1$s] can't be found.", this.getJobId());
				throw new IllegalStateException(msg);
			}

			Map<String, ProgressForClusterTask> observers = observer.getProgressTasks();
			ProgressForClusterTask progressForClusterTask = (ProgressForClusterTask) observers.get(this.dirAndTaskId);

			float prevProgress = jobRequestInfo.getProgress();
			float nowProgress = prevProgress
					+ (float) ((float) (progressForClusterTask.getPortionOfProgress() * 100) / this.cntTotalSubJobFiles); // 4가
																															// 필요함

			// this.logger.debug("}}}}}}}}}}}}}}}}}}}}}}}}}}}} prevProgress: {}, progressForClusterTask.getPortionOfProgress(): {}, this.cntTotalSubJobFiles: {}, nowProgress: {}",
			// prevProgress, progressForClusterTask.getPortionOfProgress(),
			// this.cntTotalSubJobFiles, nowProgress);

			if (nowProgress > 99.990f) {
				nowProgress = Math.round(nowProgress);
			}

			HashMap<String, Object> updateRateparam = new HashMap<String, Object>();
			updateRateparam.put("job_id", this.getJobId()); // nodeId濡�諛붽퓭����//
			updateRateparam.put("progress", nowProgress);
			faceMatchJobService.updateJobProgressRate(updateRateparam);
		}

		return srchResult;
	}

	private Pair<String, String> getScreenshotPathAndDir(@NotBlank String systemId, @NotBlank String devId) {
		final String date = BaseUtils.formatToYear2MillisecString(new java.util.Date()); // 'yyyyMMddHHmmssSSS'
																							// format

		StringBuilder sb = new StringBuilder().append(vadDir).append(vmsDataDir).append(screenshotDir).append("/")
				.append(systemId).append("/").append(devId).append("/").append(date.substring(0, 8)).append("/");
		String dir = sb.toString();
		sb.append(date.substring(8)).append(".").append(ImageFormat.JPG).toString();

		return Pair.of(sb.toString(), dir);
	}

	private String getThumbBaseDir(String systemId, String deviceId) {
		if (StringUtils.isBlank(vadDir)) {
			throw new IllegalStateException("The environment variables VAS_DATA_DIR and VAS_HOME are not set properly.");
		}

		String thumbbaseToVms = new StringBuilder(vadDir).append(vmsDataDir).toString();
		File thumbbaseToVmsDir = new File(thumbbaseToVms);
		if (!thumbbaseToVmsDir.exists()) {
			thumbbaseToVmsDir.mkdir();
		}

		String thumbbaseToFace = new StringBuilder(thumbbaseToVms).append(thumbnailDirName).toString();
		File thumbbaseToFaceDir = new File(thumbbaseToFace);
		if (!thumbbaseToFaceDir.exists()) {
			thumbbaseToFaceDir.mkdir();
		}

		String thumbbaseToSystemId = new StringBuilder(thumbbaseToFace).append("/").append(systemId).toString();
		File thumbbaseToSystemIdDir = new File(thumbbaseToSystemId);
		if (!thumbbaseToSystemIdDir.exists()) {
			thumbbaseToSystemIdDir.mkdir();
		}

		String thumbbaseToDeviceId = new StringBuffer(thumbbaseToSystemId).append("/").append(deviceId).toString();
		File thumbbaseToDeviceIdDir = new File(thumbbaseToDeviceId);
		if (!thumbbaseToDeviceIdDir.exists()) {
			thumbbaseToDeviceIdDir.mkdir();
		}
		return thumbbaseToDeviceId;
	}

	private void sendCompletedTaskMessage(String masterAddress, String type, String jobId, int nodeId, int result,
			String message) {

		AsyncHttpClient.BoundRequestBuilder builder = this.asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", type);
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", result);
		loginParam.put("subJobMessage", message);

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
