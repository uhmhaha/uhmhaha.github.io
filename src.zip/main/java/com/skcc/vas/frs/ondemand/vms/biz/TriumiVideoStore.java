package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.collections4.map.ListOrderedMap;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.skcc.vas.frs.common.util.base.BaseUtils;

/**
 * Acts as proxy of filesystem or file store where Trium-i VMS system stores
 * it's archived video files.
 *
 * @author
 * @since 2015-09-15
 * @see com.skcc.nexcore.vas.support.triumi.TriumiVideoStoreBuilder
 */
@Immutable
public class TriumiVideoStore {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private final String base;

	private Map<String, StoreByDevice> substores = new HashMap<String, StoreByDevice>();

	public TriumiVideoStore(@NotBlank String base, @Nonnull StoreByDevice[] substores) {
		Validate.isTrue(StringUtils.isNotBlank(base), "The base directory for this store cann'be empty.");

		this.base = base;

		Object prev = null;
		if (substores != null) {
			for (StoreByDevice sub : substores) {
				Validate.isTrue(sub != null, "The specified substore array contains null object.");

				prev = this.substores.put(sub.getDeviceId(), sub);

				if (prev != null) {
					logger.warn("The stores for device[id: {}] are more than 2." + "This is unexpected situation.",
							sub.getDeviceId());
				}
			}
		}
	}

	public String getBaseDir() {
		return this.base;
	}

	/**
	 * @return the total number of video files in this video store
	 */
	public int getNumberOfFiles() {
		int cnt = 0;

		for (StoreByDevice sub : this.substores.values()) {
			cnt = cnt + sub.getNumberOfFiles();
		}
		return cnt;
	}

	/**
	 * @param devId
	 * @return the number of files under the specified device , or 0 if the
	 *         specified ID is {@code null} or this video store doesn't contains
	 *         the specified device.
	 */
	public int getNumberOfFilesByDevice(@Nullable String devId) {

		if (devId == null) {
			return 0;
		}
		if (this.substores.containsKey(devId)) {
			return this.substores.get(devId).getNumberOfFiles();
		} else {
			return 0;
		}
	}

	/**
	 * @param devId
	 * @return the date of the first(earliest) video file for the specified
	 *         device in 'yyyyMMddHHmmss' format, or {@code null} if this store
	 *         doesn't contain the specified device or the per-device store of
	 *         the specified device has no file.
	 */
	@Nullable
	public String getFirstDateByDevice(@Nullable String devId) {
		if (devId == null) {
			return null;
		}
		if (this.substores.containsKey(devId)) {
			FileValue fv = this.substores.get(devId).getFirstFile();
			if (fv == null) {
				return null;
			} else {
				return fv.getDate();
			}
		} else {
			return null;
		}
	}

	/**
	 * @param devId
	 * @return the date of the last video file for the specified device in
	 *         'yyyyMMddHHmmss' format, or {@code null} if this store doesn't
	 *         contain the specified device or the per-device store of the
	 *         specified device has no file.
	 */
	@Nullable
	public String getLastDateByDevice(@Nullable String devId) {
		if (devId == null) {
			return null;
		}
		if (this.substores.containsKey(devId)) {
			FileValue fv = this.substores.get(devId).getLastFile();
			if (fv == null) {
				return null;
			} else {
				return fv.getDate();
			}
		} else {
			return null;
		}
	}

	/**
	 * This method treats {@code from} inclusive but for {@code to},
	 * inclusiveness can be specified as the parameter {@code inclusiveTo}
	 * <p>
	 * If this video store contains no per-device substore corresponding to the
	 * specified device ID, or the per-device substore has no file inside the
	 * specified interval, this method would return empty array.
	 * <p>
	 * When there are discontinuities in the store's end-to-end time interval,
	 * the first or the last one of found videos can be far from the search
	 * interval({@code from} ~ {@code to}), specially when {@code from} or
	 * {@code to} is inside a discontinuity. To compensate this potential
	 * mismatch the maximum time length for a video file is necessary.
	 *
	 * @param deviceId
	 * @param from
	 * @param to
	 * @param inclusiveTo
	 *            whether 'to' is inclusive or not. In other words, including
	 *            last one or not
	 * @return
	 */
	@Nonnull
	public FileValue[] findVideosByInterval(@NotBlank String deviceId, @Pattern(regexp = "[0-9]{12}") String from,
			@Pattern(regexp = "[0-9]{12}") String to, boolean inclusiveTo) {
		// @TODO 'inclusiveTo' can be translated to 'includesLast' which is more
		// semantic

		// @TODO Need compensation for the mismatch due to discontinuities
		// in the store's end-to-end time interval.
		// The correctness of the first and last videos need to be verified
		// again.

		StoreByDevice substore = substores.get(deviceId);
		if (substore == null) {
			return new FileValue[0];
		} else {
			return substore.findFilesByInterval(from, to, inclusiveTo);
		}
	}

	/**
	 * Note that internally this class adopted CPU saving strategy using
	 * additional memory for faster access of a file nearest to the specified
	 * date.
	 *
	 * @author
	 *
	 */
	@Immutable
	public static class StoreByDevice {

		private final Logger logger = LoggerFactory.getLogger(this.getClass());

		// @NOTE Adopted CPU saving strategy using more memory with 'filesByDir'
		// map object.
		// for more fast access of a file nearest to the specified date.

		private final String deviceId;

		/**
		 * @return The device ID for this per-device store.
		 */
		public String getDeviceId() {
			return this.deviceId;
		}

		/**
		 * Path for this per-device store in absolute and canonical form.
		 */
		private final String dir;

		/**
		 * @return The absolute pathname string for this per-device store.
		 */
		public String getDir() {
			return this.dir;
		}

		/**
		 * List of all files under this per-device store.
		 */
		private final FileValue[] files;

		/**
		 * Index for number for each hour in this store.
		 * <p>
		 * The key for this map corresponds 2 levels of directory under the base
		 * of this per-device store such as '2015090610'(in yyyyMMddHH format).
		 */
		private final ListOrderedMap<String, Integer> index;
		// @NOTE The order of entry addition follows the order of the key.

		/**
		 * The min. of year-2-hour value among files, in 'yyyyMMddHH' format
		 */
		@Pattern(regexp = "[0-9]{10}")
		private final String minHour;

		/**
		 * The max. of year-2-hour value among files, in 'yyyyMMddHH' format
		 */
		@Pattern(regexp = "[0-9]{10}")
		private final String maxHour;

		/**
		 * The element of {@code filePaths} is expected to be in
		 * '...\00000XXX\yyyyMMdd\HH\HHmmssSS.VF1' format and canonical form.
		 *
		 * @param devId
		 * @param dir
		 *            Path for this per-device store in absolute and canonical
		 *            form.
		 * @param fileNames
		 *            The list of full file names including path, name,
		 *            extension and drive letter
		 */
		@JsonCreator
		public StoreByDevice(@NotBlank @JsonProperty("deviceId") String devId,
				@NotBlank @JsonProperty("dir") String dir, @Nonnull @JsonProperty("files") String[] fileNames) {
			Validate.isTrue(fileNames != null,
					"The file list should NOT be null. In case of no file, empty list should be specified.");

			this.deviceId = devId;
			this.dir = dir;

			// 1st, validate file names
			List<String> wrongNames = new ArrayList<String>();
			for (String str : fileNames) {
				// file name should end with 'yyyyMMdd\HH\HHmmssSS.VF1'
				if (str == null || str.length() < 24) {
					wrongNames.add(str);
				}
			}
			if (wrongNames.size() > 0) {
				StringBuilder sb = new StringBuilder();
				for (int i = 0, n = Math.min(wrongNames.size(), 10); i < n; i++) { // n
																					// >
																					// 0
					sb.append(wrongNames.get(i)).append(", ");
				}
				throw new IllegalArgumentException("Unexpected file names are included. - "
						+ sb.substring(0, sb.length() - 2));
			}

			// 2nd, sort file names;
			String[] names = fileNames; // just a reference
			Arrays.sort(names);

			// 3rd, build file list and index;
			this.files = new FileValue[names.length];
			this.index = new ListOrderedMap<String, Integer>();
			String name = null; // full name
			FileValue fv = null;
			String key0 = null; // current directory for directory map
			String key1 = null; // directory of the file
			for (int i = 0, n = names.length; i < n; i++) {
				name = names[i]; // name is validated above, so is non-null and
									// has more than 24 letters.
				fv = new FileValue(i, name);
				this.files[i] = fv;
				key1 = name.substring(name.length() - 24, name.length() - 16)
						+ name.substring(name.length() - 15, name.length() - 13); // yyyyMMddHH
																					// format
				if (!StringUtils.equals(key1, key0)) { // when
														// directory(year-2-hour
														// value) is changed
					this.index.put(key1, i);
					key0 = key1;
				}
			}

			// 4th, find boundary hours
			name = names[0];
			this.minHour = name.substring(name.length() - 24, name.length() - 16)
					+ name.substring(name.length() - 15, name.length() - 13);
			name = names[names.length - 1];
			this.maxHour = name.substring(name.length() - 24, name.length() - 16)
					+ name.substring(name.length() - 15, name.length() - 13);
		}

		@Nonnull
		protected FileValue[] getFiles() {
			return this.files;
		}

		/**
		 * @return the earliest file in this per-device store, or {@code null}
		 *         if this store is empty.
		 */
		@Nullable
		public FileValue getFirstFile() {
			if (this.files.length == 0) {
				return null;
			} else {
				return this.files[0];
			}
		}

		/**
		 * @return the number of files in this per-device store.
		 */
		@Min(0)
		public int getNumberOfFiles() {
			return this.files.length;
		}

		/**
		 * @return the last (in time) file in this per-device store, or
		 *         {@code null} if this store is empty.
		 */
		@Nullable
		public FileValue getLastFile() {
			if (this.files.length == 0) {
				return null;
			} else {
				return this.files[this.files.length - 1];
			}
		}

		/**
		 * This method treats {@code from} inclusive but for {@code to},
		 * inclusiveness can be specified as the parameter {@code inclusiveTo}.
		 * <p>
		 * This method will throw {@link IllegalArgumentException}, if the
		 * {@code from} is equal or larger(later) than the {@code to}.
		 *
		 * @param from
		 * @param to
		 * @param inclusiveTo
		 * @return
		 */
		@Nonnull
		public FileValue[] findFilesByInterval(@Pattern(regexp = "[0-9]{12}") String from,
				@Pattern(regexp = "[0-9]{12}") String to, boolean inclusiveTo) {

			Date start = BaseUtils.validateYear2MinString(from);
			Date end = BaseUtils.validateYear2MinString(to);
			Validate.isTrue(start != null, "The specified 'from'(" + from + ") is NOT in yyyyMMddHHmm format.");
			Validate.isTrue(end != null, "The specified 'end'(" + end + ") is NOT in yyyyMMddHHmm format.");
			Validate.isTrue(end.compareTo(start) > 0, "The end(" + end
					+ ") of interval should be greater than the start(" + start + ").");

			int maxNo = this.files.length - 1;
			int startNo = this.findFileRightBefore(from);
			int endNo = (inclusiveTo) ? this.findFileRightAfter(to) : this.findFileRightBefore(to);
			if (startNo == -1) {
				startNo = 0;
			} // all files are after the 'from'
			if (endNo == -1) {
				endNo = (inclusiveTo) ? maxNo : 0;
			}

			final FileValue[] values;
			if (startNo > endNo) {
				// never expected
				this.logger.warn("The start no({}) is larger than the end no({}). {}", startNo, endNo,
						"This is never expected case and may imply the logical error in program.");
				values = new FileValue[0];
			} else if (startNo == maxNo || endNo == 0) {
				values = new FileValue[0];
			} else {
				values = new FileValue[endNo - startNo + 1];
				for (int i = startNo; i <= endNo; i++) {
					values[i - startNo] = this.files[i];
				}
			}

			this.logger.debug("Found {} files for device ID: {}, from: {}, to: {}, includesLast: {}", values.length,
					this.deviceId, from, to, inclusiveTo);
			return values;
		}

		/**
		 * Gets the number of the file right before the specified time position.
		 * <p>
		 * If the specified position is BEFORE ALL the files in this store, this
		 * method returns '-1'. Oppositely, if the specified position is AFTER
		 * ALL the files in this store, this method returns the max. no among
		 * files in this store.
		 *
		 * Note that this method is in friendly scope not private scope just for
		 * testing. So, don't use this other non-testing classes.
		 *
		 * @param str
		 *            the time position in 'yyyyMMddHHmm' format
		 * @return the no(number) of the file (in file list) right before the
		 *         specified time position or '-1' if all the files in this
		 *         store is after the specified time position.
		 */
		// @NOTE Intentionally set this method friendly not private for testing
		int findFileRightBefore(@Pattern(regexp = "[0-9]{12}") String str) {
			// validation is omitted for private method which can be more
			// controlled

			int no = -2;
			String key = str.substring(0, 10); //
			String time = str.substring(8) + "0000"; // HHmmssSS (8 digits)
														// format

			if (ObjectUtils.compare(key, this.minHour) < 0) {
				// before the min interval of this store
				return -1;
			} else if (ObjectUtils.compare(key, this.maxHour) > 0) {
				// after the max interval of this store
				return this.files.length - 1;
			}

			// @TODO Remove the following commented blocks ASAP
			// after the modified codes are confirmed to be correct and stable
			/*
			 * if(index.containsKey(key)){ for(int i = index.get(key), n =
			 * this.files.length; i < n; i++){
			 * if(ObjectUtils.compare(this.files[i].getName(), time) > 0){ no =
			 * this.files[i].getNo() - 1; break; } } if(no == -2){ no =
			 * this.files.length - 1; } //all files are before the specified
			 * time position. }else{ //strange case this.logger.warn(
			 * "The index is absolutely expected to contains the key(" + key +
			 * "), but it doesn't.");
			 * this.logger.warn("This may imply some logicall error in program."
			 * ); }
			 */

			int sign = 0;
			for (int i = 0, n = this.index.size(); i < n; i++) {
				// The time interval of video store may have discontinuity.
				// So the index may not contain the key, even if the key is
				// inside the min/max
				// range of the video store.

				sign = ObjectUtils.compare(this.index.get(i), key);
				if (sign == 0) {
					for (int j = this.index.getValue(i), m = this.files.length; j < m; j++) {
						if (ObjectUtils.compare(this.files[j].getName(), time) > 0) {
							no = j - 1;
							break;
						}
					}
					break;
				} else if (sign > 0) { // with discontinuity
					no = this.index.getValue(i) - 1;
					break;
				}
			}
			if (no == -2) {
				no = this.files.length - 1;
			} // all files are before the specified time position.

			return no;
		}

		/**
		 * Gets the number of the file right after the specified time position.
		 * <p>
		 * If the specified position is AFTER ALL the files in this store, this
		 * method returns '-1'. Oppositely, if the specified position is BEFORE
		 * ALL the files in this store, this method returns '0'.
		 *
		 * Note that this method is in friendly scope not private scope just for
		 * testing. So, don't use this other non-testing classes.
		 *
		 * @param str
		 *            the time position in 'yyyyMMddHHmm' format
		 * @return the no(number) of the file (in file list) right after the
		 *         specified time position or '-1' if all the files in this
		 *         store is before the specified time position.
		 */
		// @NOTE Intentionally set this method friendly not private for testing
		int findFileRightAfter(@Pattern(regexp = "[0-9]{12}") String str) {
			// validation is omitted for private method which can be more
			// controlled

			int no = -1;
			String key = str.substring(0, 10); //
			String time = str.substring(8) + "0000"; // HHmmssSS (8 digits)
														// format

			if (ObjectUtils.compare(key, this.minHour) < 0) {
				// before the min interval of this store
				return 0;
			} else if (ObjectUtils.compare(key, this.maxHour) > 0) {
				// after the max interval of this store
				return -1;
			}

			// @TODO Remove the following commented blocks ASAP
			// after the modified codes are confirmed to be correct and stable
			/*
			 * if(index.containsKey(key)){ for(int i = index.get(key), n =
			 * this.files.length; i < n; i++){
			 * if(ObjectUtils.compare(this.files[i].getName(), time) > 0){ no =
			 * this.files[i].getNo(); break; } } if(no == -1){ no = -1; } //all
			 * files are before the specified time position. }else{ //strange
			 * case this.logger.warn(
			 * "The index is absolutely expected to contains the key(" + key +
			 * "), but it doesn't.");
			 * this.logger.warn("This may imply some logicall error in program."
			 * ); }
			 */

			int sign = 0;
			for (int i = 0, n = this.index.size(); i < n; i++) {
				// The time interval of video store may have discontinuity.
				// So the index may not contain the key, even if the key is
				// inside the min/max
				// range of the video store.

				sign = ObjectUtils.compare(this.index.get(i), key);
				if (sign == 0) {
					for (int j = this.index.getValue(i), m = this.files.length; j < m; j++) {
						if (ObjectUtils.compare(this.files[j].getName(), time) > 0) {
							no = j;
							break;
						}
					}
					break;
				} else if (sign > 0) { // with discontinuity
					no = this.index.getValue(i);
					break;
				}
			}
			if (no == -1) {
				no = -1;
			} // all files are before the specified time position.

			return no;
		}

	}

	@Immutable
	public static class FileValue {

		/**
		 * 0-base sequence number for this file
		 */
		private int no;

		/**
		 * full name of the file containing path, extension and drive letter if
		 * any
		 */
		private String fullName;

		/**
		 * only name part of the file which doesn't include path and extension.
		 * <p>
		 * 'HHmmssSS' format(8 digits not 9 digits, eg. 12302588) is expected.
		 */
		private String name;

		/**
		 * the previous file in sequence: {@code null} for the 1st file in
		 * sequence and non-null for others.
		 */
		// @TODO Remove this ASAP.
		@Deprecated
		@Nullable
		FileValue previous;

		private String str = null; // for toString() method

		/**
		 * @param no
		 *            0-base sequence number for the file
		 * @param name
		 *            full name of the file containing path, extension and drive
		 *            letter if any
		 */
		public FileValue(@Min(0) int no, @NotBlank String name) {
			this.no = no;
			this.fullName = name;

			int pos1 = 0, pos2 = 0;
			if (name != null) {
				pos1 = name.lastIndexOf(File.separator);
				pos2 = name.lastIndexOf(".");
				this.name = name.substring(pos1 + 1, (pos2 != -1 && pos2 > pos1) ? pos2 : name.length());
			}

			this.str = (new StringBuilder()).append(String.valueOf(this.no)).append(": ").append(this.fullName)
					.toString();
		}

		/**
		 * @return 0-base sequence number for this file
		 */
		// @TODO Maybe can be removed.
		public int getNo() {
			return this.no;
		}

		/**
		 * @return full name of the file containing path, extension and drive
		 *         letter if any
		 */
		public String getFullName() {
			return this.fullName;
		}

		/**
		 * In normal case, the value in 'HHmmssSS' format(8 digits not 9 digits,
		 * eg. 12302588) is expected.
		 *
		 * @return only name part of the file which doesn't include path and
		 *         extension.
		 */
		public String getName() {
			return this.name;
		}

		/**
		 * @return the date for this file in 'yyyyMMddHHmmss' format, or
		 *         {@code null} if the date is not unknown
		 */
		@Nullable
		public String getDate() {
			if (StringUtils.isBlank(this.fullName)) {
				return null;
			}

			StringBuilder sb = new StringBuilder(14);
			int len = this.fullName.length();
			try {
				sb.append(this.fullName.substring(len - 24, len - 16)).append(
						this.fullName.substring(len - 12, len - 6));
				return sb.toString();
			} catch (Exception ex) {
				return null;
			}
		}

		@Override
		public String toString() {
			return this.str;
		}
	}

}
