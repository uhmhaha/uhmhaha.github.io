package com.skcc.vas.frs.ondemand.vms.db.rdb.repository;

import java.util.Date;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.ondemand.vms.db.rdb.domain.SearchCriteria;

/**
 * @author
 * @since 2015-07-01
 */
@Repository("searchResultMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface SearchResultMapper {
	// @NOTE Do not use transaction control(annotation) in the mapper.

	int insertSearchResult(@Param("jobId") String jobId, @Param("criteria") SearchCriteria criteria,
			@Param("roiNo") int roiNo, @Param("frmPos") long frmPos, @Param("devTime") Date devTime,
			@Param("serverTime") Date serverTime, @Param("eventType") String evType, @Param("intVal") int intVal,
			@Param("floatVal") float floatVal, @Param("thumbFile") String thumbFile);

}
