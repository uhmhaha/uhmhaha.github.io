package com.skcc.vas.frs.ondemand.vms.model;

import com.skcc.vas.frs.ondemand.vms.db.rdb.domain.SearchCriteria;

/**
 * @author
 * @since 2015-06-23
 */
public abstract class AbstractSearchCriteria implements SearchCriteria {

	private String systemId;

	private String deviceId;

	private String from;

	private String to;

	public AbstractSearchCriteria() {

	}

	public AbstractSearchCriteria(String systemId, String devId, String from, String to) {
		this.systemId = systemId;
		this.deviceId = devId;
		this.from = from;
		this.to = to;
	}

	@Override
	public String getSystemId() {
		return this.systemId;
	}

	@Override
	public String getDeviceId() {
		return this.deviceId;
	}

	@Override
	public String getFrom() {
		return this.from;
	}

	@Override
	public String getTo() {
		return this.to;
	}

}
