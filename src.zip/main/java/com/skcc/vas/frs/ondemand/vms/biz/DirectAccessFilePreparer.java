package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Queue;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.RegEx;
import javax.annotation.concurrent.NotThreadSafe;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.annotation.Scheduled;

import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.ondemand.FilePrepareState;
import com.skcc.vas.frs.common.util.ondemand.FilePreparer;

//@TODO This class seams to be thread safe or almost thread safe...
/**
 *
 * @author
 * @since 2015-09-15
 * @see com.skcc.nexcore.vas.support.triumi.TriumiVideoStore
 * @see com.skcc.nexcore.vas.support.triumi.TriumiVideoStoreBuilder
 */
@ManagedResource(objectName = ":type=bean,name=triumiDirectAccessFilePreparer", description = "FilePreparer implementation for Trium i that access the video files directly")
@ParametersAreNonnullByDefault
@NotThreadSafe
public class DirectAccessFilePreparer implements FilePreparer {

	/*
	 * @NOTE A better naming but too long TriumiVideoStore ->
	 * TriumiVideoStoreProxy TriumiVideoStoreBuilder ->
	 * TriumiVideoStoreProxyBuilder, TriumiVideoStoreScanner
	 */

	/**
	 * Default value for the directory name regex pattern of Trium-i's
	 * per-device video store.
	 */
	public static final String DEFAULT_DEVICE_DIR_PATTERN = "\\w{8}";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private FilePrepareState state;

	private final String[] baseDirs;

	/**
	 * the regex pattern for the name of per-device video store.
	 */
	private final String devDirPattern;

	@ManagedAttribute
	public String getDeviceDirPattern() {
		return this.devDirPattern;
	}

	/**
	 * the gap in minutes btw. the time-zone of video file store and the
	 * time-zone of client's request.
	 * <p>
	 * The plus value means the client's time-zone precedes and the minus value
	 * means the client's time-zone follows.
	 */
	private final int timeGap;

	/**
	 * the gap in minutes btw. the time-zone of video file store and the
	 * time-zone of client's request.
	 * <p>
	 * The plus value means the client's time-zone precedes like following. In
	 * following case, the return value is 540 (minutes)
	 * 
	 * <pre>
	 *    time-stamp of a file : 2015-11-23 09:00
	 *    client time for it   : 2015-11-23 18:00
	 * </pre>
	 *
	 * @return
	 */
	@ManagedAttribute
	public int getTimeGap() {
		return this.timeGap;
	}

	/**
	 * time-stamps for recent 10 video store proxy builds.
	 */
	private final Queue<Date> storeBuildHistory = new ArrayDeque<Date>(10);

	/**
	 * @return time-stamps for recent 10 video store proxy builds.
	 */
	@ManagedAttribute(description = "time-stamps for recent 10 video store proxy builds.")
	public Queue<Date> getVideoStoreBuildHistory() {
		return this.storeBuildHistory;
	}

	private final TriumiVideoStore[] videoStores;

	/**
	 * @param baseDirs
	 *            the base directories concatenated by path separator(';' on
	 *            Windows, ':' on UNIX or Linux ...)
	 */
	// public DirectAccessFilePreparer(@NotBlank String baseDirs){
	// this(baseDirs, DEFAULT_DEVICE_DIR_PATTERN, 0, false);
	// }

	/**
	 * @param baseDirs
	 *            the base directories concatenated by path separator(';' on
	 *            Windows, ':' on UNIX or Linux ...)
	 * @param devDirPattern
	 *            the regex pattern for the name of per-device video store.
	 * @param timeGap
	 *            the gap in minutes btw. the time-zone of video file store and
	 *            the time-zone of client's request
	 * @param startsAsync
	 *            if {@code true} the first build of video store proxy processed
	 *            async
	 */
	public DirectAccessFilePreparer(@NotBlank String baseDirs, @NotBlank @RegEx String devDirPattern, int timeGap,
			boolean startsAsync) {
		Validate.isTrue(StringUtils.isNotBlank(baseDirs), "The specified bases string can NOT be blank.");
		Validate.isTrue(StringUtils.isNotBlank(devDirPattern), "The specified pattern(" + devDirPattern
				+ ") is not valid regex pattern.");

		this.state = FilePrepareState.NOT_PREPARED;

		this.baseDirs = baseDirs.split(File.pathSeparator);
		this.devDirPattern = devDirPattern;
		this.timeGap = timeGap;
		this.videoStores = new TriumiVideoStore[this.baseDirs.length];

		// Thorough validation will be done at TriumiVideoStoreBuilder
		if (startsAsync) {
			this.logger.info("The first build of video file store proxy runs asynchronously.");
			VideoStoreBuildTask task = new VideoStoreBuildTask(this);
			// task.start();
		} else {
			this.logger
					.warn("Building video file store proxy...... The synchronous build of video file store proxy could take time more than tens of seconds or even minutes.");
			// this.buildVideoStores();
		}
	}

	@Override
	public FileValue[] prepareFiles(String systemId, String deviceId, String from, String to) {

		if (!this.state.isCompleted()) {
			this.logger
					.warn("This file preparer is not fully initialized. So, the prepared files may not be complete set.");
		}

		List<FileValue> values = new ArrayList<FileValue>();
		for (TriumiVideoStore store : this.videoStores) {
			TriumiVideoStore.FileValue[] founds = store.findVideosByInterval(deviceId,
					this.conpensateYear2MinString(from), this.conpensateYear2MinString(to), false);
			for (TriumiVideoStore.FileValue found : founds) {
				values.add(new FileValue(found.getFullName(), -1));
			}
		}

		this.logger.debug("The {} files prepared for device[id: {}, systemId: {}] from {} to {}", values.size(),
				deviceId, systemId, from, to);
		return values.toArray(new FileValue[values.size()]);
	}

	// @TODO Need implementation ASAP.
	/**
	 * Gets the compensated date by the time-gap of this preparer.
	 *
	 * @param str
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified {@code str} cann't be converted to date in
	 *             strict 'yyyyMMddHHmm' format.
	 * @see #getTimeGap()
	 */
	@Nonnull
	private String conpensateYear2MinString(@Pattern(regexp = "[0-9]{12}") String str) {

		Date d = BaseUtils.validateYear2MinString(str);
		Validate.isTrue(d != null, "The specified 'str'(" + str
				+ ") cann't be converted to date in strict 'yyyyMMddHHmm' format");

		d = DateUtils.addMinutes(d, -this.getTimeGap());
		return BaseUtils.formatToYear2MinString(d);
	}

	/**
	 * The numbers in state means total and prepared files in all video stores.
	 */
	@Override
	@ManagedAttribute
	public FilePrepareState getState() {
		return this.state;
	}

	@Scheduled(fixedDelayString = "${vas.triumiDirectAccessFilePreparer.fixedDelay}", initialDelayString = "${vas.triumiDirectAccessFilePreparer.initialDelay}")
	public void buildVideoStores() {
		// The following enhancements are long term issues.
		// @TODO Apply concurrent rebuild using multi-threads (thread per
		// per-device store)
		// @TODO Apply incremental rebuild - requires additional time-stamp
		// related filed on domain objects.
		// @TODO Apply file system visitor to continuous update of vidoe store
		// proxy.

		logger.info("Starting to build {} Trium-i video store proxy(s) for {} dir(s)({}).", this.getClass()
				.getSimpleName(), this.baseDirs.length, baseDirs);

		TriumiVideoStoreBuilder builder = null;
		int total = 0;
		for (int i = 0, n = this.baseDirs.length; i < n; i++) {
			builder = new TriumiVideoStoreBuilder(this.baseDirs[i], this.getDeviceDirPattern());
			this.videoStores[i] = builder.build();
			total = total + this.videoStores[i].getNumberOfFiles();
		}
		this.storeBuildHistory.add(new Date());
		this.state = new FilePrepareState(total, total);
		logger.info("Successfully built {} Trium-i video store proxy(s) for {} dir(s)({}). - {} files are found.", this
				.getClass().getSimpleName(), this.baseDirs.length, baseDirs, total);

	}
}

class VideoStoreBuildTask extends Thread {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private final DirectAccessFilePreparer target;

	public VideoStoreBuildTask(@Nullable DirectAccessFilePreparer target) {
		this.target = target;
	}

	@Override
	public void run() {
		if (target != null) {
			target.buildVideoStores();
			this.logger.info("Successfully built the video store proxy for DirectAccessFilePreparer[hash: {}]",
					target.hashCode());
		} else {
			this.logger.warn("VideoStoreBuildTask instance[hash: {}] has no target to run rebuild video store proxy.",
					this.hashCode());
		}
	}

}
