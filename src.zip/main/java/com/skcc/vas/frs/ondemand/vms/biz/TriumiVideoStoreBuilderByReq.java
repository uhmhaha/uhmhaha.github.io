package com.skcc.vas.frs.ondemand.vms.biz;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.RegEx;
import javax.validation.constraints.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.ondemand.vms.biz.TriumiVideoStore.StoreByDevice;

/**
 * Builds a instance of the immutable
 * {@link com.skcc.nexcore.vas.support.triumi.TriumiVideoStore} class.
 * <p>
 * This class assumes that the Trium-i VMS stores its archived video files into
 * the filesystem like the following directory structure.
 * 
 * <pre>
 * \\triumiserver\\data\video
 *                       |--------00000026
 *                       |--------00000029
 *                       +--------00000030
 * </pre>
 * 
 * @author
 * @since 2015-09-16
 * @see com.skcc.nexcore.vas.support.triumi.TriumiVideoStore
 */
public class TriumiVideoStoreBuilderByReq {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private final File base;

	/**
	 *
	 * @return the canonical absolute pathname for the base directory, or
	 *         {@code null} if a proper base directory is not yet set.
	 */
	public String getBaseDir() {
		String dir = null;
		try {
			dir = this.base.getCanonicalPath();
		} catch (Exception ex) {
			dir = null;
		}

		return dir;
	}

	/**
	 * Regex pattern for the directories for devices which are assumed to be
	 * located right below the base direcotry.
	 * <p>
	 * For example
	 * 
	 * <pre>
	 * \\triumiserver\\data\video
	 *                       |--------00000026
	 *                       |--------00000029
	 *                       +--------00000030
	 * </pre>
	 */
	private final String devDirPattern;

	/**
	 * @return regex pattern for the right subdirectories under the base
	 *         directory
	 */
	public String getSubDirPattern() {
		return this.devDirPattern;
	}

	private final int timeGap;

	/**
	 * the gap in minutes btw. the time-zone of video file store and the
	 * time-zone of client's request.
	 * <p>
	 * The plus value means the client's time-zone precedes like following. In
	 * following case, the return value is 540 (minutes)
	 * 
	 * <pre>
	 *    time-stamp of a file : 2015-11-23 09:00
	 *    client time for it   : 2015-11-23 18:00
	 * </pre>
	 *
	 * @return
	 */
	@ManagedAttribute
	public int getTimeGap() {
		return this.timeGap;
	}

	/**
	 * @param base
	 *            the full path for the base directory of the video store to
	 *            build
	 * @param pattern
	 *            regex pattern for the directories for devices
	 */
	public TriumiVideoStoreBuilderByReq(String base, @NotBlank @RegEx String pattern, int timeGap) {

		// @TODO More robust validation is possible compiling the regex.
		Validate.isTrue(pattern != null && pattern.length() > 0,
				"The pattern for device directory should NOT be blank.");

		this.devDirPattern = pattern;
		this.timeGap = timeGap;

		File f = new File(base);
		if (!f.exists()) {
			logger.error("The specified base direcotry({}) does NOT exist.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") does NOT exist.");
		} else if (!f.isDirectory()) {
			logger.error("The specified base direcotry({}) is NOT directory.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") is NOT directory.");
		} else if (!f.canRead()) {
			logger.error("The specified base direcotry({}) is NOT readable.", base);
			throw new IllegalArgumentException("The specified base direcotry(" + base + ") is NOT readable.");
		} else {
			this.base = f;
		}

	}

	// @NOTE Concurrency should be considered, 'cause build method is kind of
	// lazy initialization.
	// 아래의 method는 시(o'clock)까지만 취급한다. from, to에는 처음부터 -9시간 보정된 시간으로 들어가야 함.
	public TriumiVideoStore buildByCctv(String deviceId, String from, String to) {
		final StoreByDevice[] substores = new StoreByDevice[1];

		StoreByDevice substore = null;
		String subdirPath = null;
		File subdir = null;
		String[] fileNames = null; // list of the absolute file names
		Collection<File> files = null; // list of video files
		long t1 = 0, t2 = 0;
		try {
			String formDeviceId = String.format("%08d", Integer.parseInt(deviceId));
			subdirPath = new StringBuffer(this.base.getCanonicalPath()).append("\\").append(formDeviceId).toString();
			subdir = new File(subdirPath);

			t1 = System.currentTimeMillis();
			// files = getTargetVideosList(subdirPath,
			// this.conpensateYear2MinString(from),
			// this.conpensateYear2MinString(to));
			files = getTargetVideosList(subdirPath, from, to);
			if (files == null || files.size() == 0) {
				return null;
			}
			fileNames = new String[files.size()];
			int cnt = 0;
			for (File f : files) {
				try {
					fileNames[cnt++] = f.getCanonicalPath();
				} catch (Exception ex) {
					throw new IllegalStateException("Unexpected fail of path resolution.", ex);
				}
			}
			t2 = System.currentTimeMillis();
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			// throw new
			// IllegalStateException("Fail to create per-device store.", ex);
			this.logger.error("Fail to create per-device store. {}", ex);
			return null;
		}

		logger.info("Trium i per-device video store scan - dir: {}, duration: {} milliseconds",
				subdir.getAbsolutePath(), t2 - t1);

		try {
			if (fileNames.length > 0)
				substores[0] = new StoreByDevice(deviceId, subdir.getCanonicalPath(), fileNames);
			else
				return null;
		} catch (Exception ex) {
			throw new IllegalStateException("Fail to create per-device store.", ex);
		}

		return new TriumiVideoStore(this.getBaseDir(), substores);
	}

	// 아래의 method는 시(o'clock)까지만 취급한다. from, to에는 처음부터 -9시간 보정된 시간으로 들어가야 함.
	private Collection<File> getTargetVideosList(String basePath, String from, String to) {

		String between = from;
		Date start = BaseUtils.validateYear2MinString(from);
		Date end = BaseUtils.validateYear2MinString(to);
		Date middle = BaseUtils.validateYear2MinString(between);
		Validate.isTrue(start != null, "The specified 'from'(" + from + ") is NOT in yyyyMMddHHmm format.");
		Validate.isTrue(end != null, "The specified 'end'(" + end + ") is NOT in yyyyMMddHHmm format.");
		Validate.isTrue(end.compareTo(start) > 0, "The end(" + end + ") of interval should be greater than the start("
				+ start + ").");

		Calendar btwCalenar = Calendar.getInstance();
		String subdir = null;

		List<String> subdirList = new ArrayList<String>();
		List<File> fileList = new ArrayList<File>();

		subdir = getVideoFilePath(basePath, between, false);
		if (subdir != null) {
			subdirList.add(subdir);
		} else {
			return null;
		}

		while (!compareDate(between, to)) {
			btwCalenar.setTime(middle);
			btwCalenar.add(Calendar.DAY_OF_MONTH, 1);
			between = BaseUtils.formatToYear2MinString(btwCalenar.getTime());

			subdir = getVideoFilePath(basePath, between, false);
			subdirList.add(subdir);
			middle = BaseUtils.validateYear2MinString(between);
		}

		int fromHour = Integer.parseInt(from.substring(8, 10));
		int toHour = Integer.parseInt(to.substring(8, 10));

		if (subdirList.size() == 1) { // ex. 201701230900 ~ 201701231230 ( 하루 내에
										// 검색 )
			for (int i = fromHour; i <= toHour; i++) {
				subdir = new StringBuffer(subdirList.get(0)).append("\\").append(String.format("%02d", i)).toString();

				// 폴더가 있는 지 체크
				if (!isExistedDirectory(subdir))
					continue;

				if (fromHour == toHour) {
					List<File> fromFileList = new ArrayList<File>();
					List<File> toFileList = new ArrayList<File>();

					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)), true);

					for (int j = 0; j < files.length; j++)
						fromFileList.add(files[j]);

					files = getVideoFilesForDir(subdir, Integer.parseInt(to.substring(10, 12)), false);

					for (int j = 0; j < files.length; j++)
						toFileList.add(files[j]);

					for (int j = 0; j < fromFileList.size(); j++) {
						for (int k = 0; k < toFileList.size(); k++) {
							if (fromFileList.get(j).getAbsolutePath().equals(toFileList.get(k).getAbsolutePath())) {
								fileList.add(fromFileList.get(j));
							}
						}
					}

					break;
				}

				if (i == fromHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)), true);

					for (int j = 0; j < files.length; j++) {
						fileList.add(files[j]);
					}
				} else if (i == toHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(to.substring(10, 12)), false);

					for (int j = 0; j < files.length; j++) {
						fileList.add(files[j]);
					}
				} else {
					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int j = 0; j < files.length; j++) {
						fileList.add(files[j]);
					}
				}
			}
		} else if (subdirList.size() == 2) { // ex. 201701232200 ~ 201701240330
												// ( 하루 건너임 )
			for (int i = fromHour; i <= 23; i++) {
				subdir = new StringBuffer(subdirList.get(0)).append("\\").append(String.format("%02d", i)).toString();

				// 폴더가 있는 지 체크
				if (!isExistedDirectory(subdir))
					continue;

				if (i == fromHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)), true);

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				} else {
					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				}
			}

			for (int i = 0; i <= toHour; i++) {
				subdir = new StringBuffer(subdirList.get(1)).append("\\").append(String.format("%02d", i)).toString();

				// 폴더가 있는 지 체크
				if (!isExistedDirectory(subdir))
					continue;

				if (i == toHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(to.substring(10, 12)), false);

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				} else {
					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				}
			}
		} else if (subdirList.size() > 2) {
			for (int i = fromHour; i <= 23; i++) {
				subdir = new StringBuffer(subdirList.get(0)).append("\\").append(String.format("%02d", i)).toString();

				// 폴더가 있는 지 체크
				if (!isExistedDirectory(subdir))
					continue;

				if (i == fromHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)), true);

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				} else {
					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				}
			}

			for (int i = 1; i < subdirList.size() - 1; i++) {
				for (int j = 0; j < 23; j++) {
					subdir = new StringBuffer(subdirList.get(i)).append("\\").append(String.format("%02d", j))
							.toString();

					// 폴더가 있는 지 체크
					if (!isExistedDirectory(subdir))
						continue;

					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int k = 0; k < files.length; k++)
						fileList.add(files[k]);

				}
			}

			for (int i = 0; i <= toHour; i++) {
				subdir = new StringBuffer(subdirList.get(subdirList.size() - 1)).append("\\")
						.append(String.format("%02d", i)).toString();

				// 폴더가 있는 지 체크
				if (!isExistedDirectory(subdir))
					continue;

				if (i == toHour) {
					File[] files = getVideoFilesForDir(subdir, Integer.parseInt(to.substring(10, 12)), false);

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);

				} else {
					File[] files = getAllVideoFilesForDir(subdir, Integer.parseInt(from.substring(10, 12)));

					for (int j = 0; j < files.length; j++)
						fileList.add(files[j]);
				}
			}
		}

		return fileList;
	}

	private String getVideoFilePath(String basePath, String dateTime, boolean isHour) {

		StringBuffer videoFilePath = new StringBuffer(basePath);
		String dateDir = null;
		String hourDir = null;

		String strHour = dateTime.substring(8, 10);
		int hour = Integer.parseInt(strHour);

		dateDir = dateTime.substring(0, 8);
		hourDir = String.format("%02d", hour);

		if (isHour == true)
			videoFilePath.append(dateDir).append("\\").append(hourDir);
		else
			videoFilePath.append("\\").append(dateDir);

		logger.debug("File PATH : {}", videoFilePath);

		File f = new File(videoFilePath.toString());
		if (f.isDirectory() == false) {
			logger.debug("The specified 'dir' should be a directory.");
			return null;
		}

		return videoFilePath.toString();
	}

	private boolean compareDate(String between, String to) {

		String strBetween = between.substring(0, 8);
		String strTo = to.substring(0, 8);

		if (strBetween.equals(strTo))
			return true;
		return false;
	}

	// 폴더가 있는 지 체크하는 함수 추가
	private boolean isExistedDirectory(String path) {
		File file = new File(path);
		if (!file.exists()) {
			logger.error("=============> " + path + " does not exist");
			return false;
		}

		return true;
	}

	private File[] getVideoFilesForDir(String subdir, int criteraMinute, boolean isFrom) {

		Collection<File> files = FileUtils.listFiles(new File(subdir), new String[]{"VF1", "vf1"}, true);
		ArrayList<File> filterFileList = new ArrayList<File>();
		String name = null;
		for (File file : files) {
			try {
				name = file.getCanonicalPath();
				name = name.substring(name.lastIndexOf("\\") + 1);
			} catch (Exception ex) {
				throw new IllegalStateException("Unexpected fail of path resolution.", ex);
			}

			String strMinute = name.substring(2, 4);
			int minute = Integer.parseInt(strMinute);

			if (isFrom == true) {
				if (minute >= criteraMinute) {
					filterFileList.add(file);
				}
			} else {
				if (minute < criteraMinute) {
					filterFileList.add(file);
				}
			}

		}

		File[] filteredFiles = filterFileList.toArray(new File[filterFileList.size()]);
		return filteredFiles;
	}

	private File[] getAllVideoFilesForDir(String subdir, int criteraMinute) {

		Collection<File> files = FileUtils.listFiles(new File(subdir), new String[]{"VF1", "vf1"}, true);
		String name = null;
		for (File file : files) {
			try {
				name = file.getCanonicalPath();
				name = name.substring(name.lastIndexOf("\\") + 1);
			} catch (Exception ex) {
				throw new IllegalStateException("Unexpected fail of path resolution.", ex);
			}

			String strMinute = name.substring(2, 4);
			int minute = Integer.parseInt(strMinute);
		}

		File[] filteredFiles = files.toArray(new File[files.size()]);
		return filteredFiles;
	}

	// 아래의 내용은 TaskExcutor에 넣는게 맞을듯. 최초 입력하는 곳이므로.
	// @TODO Need implementation ASAP.
	/**
	 * Gets the compensated date by the time-gap of this preparer.
	 *
	 * @param str
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified {@code str} cann't be converted to date in
	 *             strict 'yyyyMMddHHmm' format.
	 * @see #getTimeGap()
	 */
	@Nonnull
	private String conpensateYear2MinString(@Pattern(regexp = "[0-9]{12}") String str) {

		Date d = BaseUtils.validateYear2MinString(str);
		Validate.isTrue(d != null, "The specified 'str'(" + str
				+ ") cann't be converted to date in strict 'yyyyMMddHHmm' format");

		d = DateUtils.addMinutes(d, -this.getTimeGap());
		return BaseUtils.formatToYear2MinString(d);
	}
}
