package com.skcc.vas.frs.ondemand.video.db.rdb.service;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.db.repository.SearchMasterMapper;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.ondemand.video.db.rdb.repository.FileAnalysisResourceMapper;

@ThreadSafe
public class FileAnalysisDataManager {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private SearchMasterMapper masterMapper;

	private FileAnalysisResourceMapper fileAnalysisResourceMapper;

	public SearchMasterMapper getSearchMasterMapper() {
		return this.masterMapper;
	}

	public FileAnalysisResourceMapper getFileAnalysisResourceMapper() {
		return fileAnalysisResourceMapper;
	}

	public FileAnalysisDataManager(@Nonnull SearchMasterMapper masterMapper,
			@Nonnull FileAnalysisResourceMapper fileAnalysisResourceMapper) {
		Validate.isTrue(masterMapper != null, "masterMapper instance should be provided.");
		Validate.isTrue(fileAnalysisResourceMapper != null, "fileAnalysisResourceMapper instance should be provided.");

		this.masterMapper = masterMapper;
		this.fileAnalysisResourceMapper = fileAnalysisResourceMapper;
	}

	@Nullable
	public FileAnalysisRequest findAnalysisRequest(String jobId) {
		SearchRequest reqMaster = this.masterMapper.selectSearchMaster(jobId);
		FileAnalysisRequest req = null;

		if (reqMaster == null) {
			logger.info("Fail to find search request[id: {}].", jobId);
		} else {

			req = new FileAnalysisRequest();
			req.setJobId(jobId);
			req.setThreshold(reqMaster.getThreshold());
			List<AnalysisResource> analysisResources = this.fileAnalysisResourceMapper
					.selectFileAnalysisResourcesByJob(jobId);

			for (AnalysisResource analysisResource : analysisResources) {
				req.addAnalysisResources(analysisResource);
			}
		}
		return req;
	}

}
