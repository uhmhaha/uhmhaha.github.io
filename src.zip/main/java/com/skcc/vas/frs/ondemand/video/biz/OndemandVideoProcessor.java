package com.skcc.vas.frs.ondemand.video.biz;

import java.util.List;

import com.skcc.vas.frs.akka.model.OndemandVideoSubJob;

public interface OndemandVideoProcessor {

	public List<OndemandVideoSubJob> splitJobs(String jobId, int numOfNode);

	public int search(OndemandVideoSubJob subJob, int nodeId, String masterAddress) throws Exception;

	public int abort(int nodeId, String masterAddress) throws Exception;

}
