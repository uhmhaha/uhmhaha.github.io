package com.skcc.vas.frs.ondemand.db.biz;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.Validate;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.ning.http.client.AsyncHttpClient;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.akka.model.OndemandDBSubJob;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.nosql.service.FaceMatchJobNonSqlService;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.db.service.SearchDataManager;
import com.skcc.vas.frs.common.util.base.SpringApplicationContext;

public class OndemandDBProcessorImpl implements OndemandDBProcessor {

	// 쓰레드
	// Name
	public static final long threadId = Thread.currentThread().getId();// 현재의
	// 쓰레드
	// ID...
	public static final String threadName = Thread.currentThread().getName();// 현재의

	// @Value("${vas.ondemandDB.threadsNum}")
	private int onDemandDBUsingthreadsNum;

	private List<Ondemandthread> ondemandThreads;

	private String masterAddress = null;
	private String jobId = null;
	private ExecutorService executor;
	private long startTime;
	private long endTime;

	private HbInnoParameter hbInnoParam; // config.properties 파일에서 읽어 온 HBInno
	// parameter 값

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
	private final SearchDataManager searchDataManager;

	private final HbinnoEngine hbInnoAdapter;
	private final FaceMatchJobService faceMatchJobService;
	
	private final FaceMatchJobNonSqlService faceMatchJobNonSqlService;

	private AsyncHttpClient asyncHttpClient;
	private VasConfigService configService;

	public String getMasterAddress() {
		return masterAddress;
	}

	public void setMasterAddress(String masterAddress) {
		this.masterAddress = masterAddress;
	}

	protected HbinnoEngine getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	public OndemandDBProcessorImpl(@Nonnull SearchDataManager searchDataMgr, @Nonnull FaceDataManager faceDataMgr,
			@Nonnull HbinnoEngine hbInnoAdapter, @Nonnull FaceMatchJobService faceMatchJobService,
			@Nonnull FaceMatchJobNonSqlService faceMatchJobNonSqlService, @Nonnull HbInnoParameter hbInnoParam,
			ThreadPoolTaskExecutor taskExecutor, @Nonnull VasConfigService configService) {

		Validate.isTrue(hbInnoAdapter != null, "The FR engine should be provided.");
		this.searchDataManager = searchDataMgr;
		this.hbInnoAdapter = hbInnoAdapter;
		this.faceMatchJobService = faceMatchJobService;
		this.faceMatchJobNonSqlService = faceMatchJobNonSqlService;
		this.hbInnoParam = hbInnoParam;
		taskExecutor.setCorePoolSize(Integer.parseInt(configService.getConfigValByName("vas.ondemandDB.threadsNum")));
		taskExecutor.setMaxPoolSize(Integer.parseInt(configService.getConfigValByName("vas.ondemandDB.threadsNum")));
		this.executor = new ExecutorServiceAdapter(taskExecutor);

		this.asyncHttpClient = new AsyncHttpClient();
		this.configService = configService;

	}

	public void initConfig() {
		// @Value("${vas.ondemandDB.threadsNum}")
		onDemandDBUsingthreadsNum = Integer.parseInt(configService.getConfigValByName("vas.ondemandDB.threadsNum"));
	}

	@Override
	public List<OndemandDBSubJob> splitJobs(@Nonnull String jobId, @Nonnull int numOfNode) {
		this.jobId = jobId;
		SearchRequest req = searchDataManager.findSearchRequest(jobId);

		List<OndemandDBSubJob> ondemandDBSubJobList = new ArrayList<OndemandDBSubJob>();
		OndemandDBSubJob ondemandDBSubJob = null;

		if ("CONTINUOUS".equals(req.getTimeType())) {
			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType : CONTINUOUS, splitJobs start!! <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

			startTime = System.currentTimeMillis();

			Map<String, byte[]> faceFeatureMap = new HashMap<String, byte[]>();

			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("job_id", jobId);

			// detail info List
			List<HashMap<String, Object>> jobDetailList = this.faceMatchJobService.findJobDetailListByJobId(param);
			// concern feature info List
			List<HashMap<String, Object>> faceFeatureList = faceMatchJobService
					.findConcernedFaceFeatureListByJobId(param);

			// 2. set ondemandDBSubJob feature
			for (HashMap<String, Object> faceFeature : faceFeatureList) {
				faceFeatureMap.put(String.valueOf(faceFeature.get("cncrn_face_id")),
						(byte[]) faceFeature.get("feature"));
			}
			// initial start_id
			String start_id = faceMatchJobNonSqlService.findDetectedFaceFirstId().get_id();

			// 2. detail list를 가지고 총 건수를 가지고 subjob으로 나누어보자
			// 2-1. 총 건수를 가져온다.
			int totalCount = (int) this.faceMatchJobNonSqlService.countDetectedFaceByJobId(jobDetailList);

			if (totalCount == 0) {
				return null;
			}
			// 2-2. 노드개수로 동일하게 나눈다.
			int subCount = totalCount / numOfNode;
			// 마지막노드에 몇 개 더 부여한다. 마지막 노드의 처리개수는 타 노드에 비해서 numOfNode 개수를 넘지 않는다.
			int subLastOneCount = totalCount % numOfNode + totalCount / numOfNode;

			for (int j = 0; j < numOfNode; j++) {
				// initial ondemandDBSubJob
				ondemandDBSubJob = new OndemandDBSubJob();
				// 1. set job id
				ondemandDBSubJob.setJobId(jobId);
				// 2. set ondemandDBSubJob feature
				ondemandDBSubJob.setConcernFaces(faceFeatureMap);
				// 3.set start_id, subcount, portion
				// 첫 id fffffffffffff...
				if (j == 0) {
					ondemandDBSubJob.setStartId(start_id);
					ondemandDBSubJob.setDetectedFaceCount(subCount);
					ondemandDBSubJob.setPortionOfProgress((int) (((float) (1) / (float) numOfNode) * 100));
					jobDetailList.get(0).put("start_id", start_id);
					if (numOfNode == 1) {

					} else {
						start_id = this.faceMatchJobNonSqlService.findDetectedFaceIds(jobDetailList, subCount);
						start_id = start_id.split(":")[2].split("}")[0].split("\"")[1];
					}

				} else {
					// 두번째 id ....

					if (j == numOfNode - 1) {

						ondemandDBSubJob.setStartId(start_id);
						ondemandDBSubJob.setDetectedFaceCount(subLastOneCount);
						ondemandDBSubJob.setPortionOfProgress((int) (((float) (1) / (float) numOfNode) * 100) + 100
								% numOfNode);

					} else {
						ondemandDBSubJob.setStartId(start_id);
						ondemandDBSubJob.setDetectedFaceCount(subCount);
						ondemandDBSubJob.setPortionOfProgress((int) (((float) (1) / (float) numOfNode) * 100));

						jobDetailList.get(0).put("start_id", start_id);
						start_id = this.faceMatchJobNonSqlService.findDetectedFaceIds(jobDetailList, subCount);
						start_id = start_id.split(":")[2].split("}")[0].split("\"")[1];
					}
				}

				// 4. set req time type
				ondemandDBSubJob.setTimeType(req.getTimeType());
				ondemandDBSubJobList.add(ondemandDBSubJob);
			}

			endTime = System.currentTimeMillis();

			logger.info(">>>>>>>>>>>>>>>>>>>Total splitJobs execution time : {}", endTime - startTime);

			return ondemandDBSubJobList;
		} else {

			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType : DISCRETE, splitJobs start!! <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

			startTime = System.currentTimeMillis();

			Map<String, byte[]> faceFeatureMap = new HashMap<String, byte[]>();
			// Map<Integer, String> detectedFaceIdMap = new HashMap<Integer,
			// String>();

			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("job_id", jobId);

			// detail info List
			List<HashMap<String, Object>> jobDetailList = this.faceMatchJobService.findJobDetailListByJobId(param);
			// concern feature info List
			List<HashMap<String, Object>> faceFeatureList = faceMatchJobService
					.findConcernedFaceFeatureListByJobId(param);

			// 2. set ondemandDBSubJob feature
			for (HashMap<String, Object> faceFeature : faceFeatureList) {
				faceFeatureMap.put(String.valueOf(faceFeature.get("cncrn_face_id")),
						(byte[]) faceFeature.get("feature"));
			}

			List<String> dateList = fromToDateList(req.getStartDate(), req.getEndDate());
			param.put("vms_id", (String) jobDetailList.get(0).get("vms_id"));

			int partNum = 0;
			int lastPartNum = 0;
			int roofNum = 0;
			String modStatus = "";

			// partNum setting
			if (dateList.size() % numOfNode > 0) {
				// 딱 나누어 떨어지지 않을경우 +1 개 만큼분리
				partNum = dateList.size() / numOfNode + 1;
				//partNum = dateList.size() / numOfNode; 이게 맞을 거 같은데..
				lastPartNum = dateList.size() / numOfNode + dateList.size() % numOfNode;
				roofNum = numOfNode;
				modStatus = "MODEEXIST";
			} else {
				//
				partNum = dateList.size() / numOfNode;
				lastPartNum = 0;
				roofNum = numOfNode;
				modStatus = "MODEZERO";
			}

			for (int k = 0; k < roofNum; k++) {

				// initial ondemandDBSubJob
				ondemandDBSubJob = new OndemandDBSubJob();

				if (dateList.size() > k) {
					// 1. set job id
					ondemandDBSubJob.setJobId(jobId);
					// 1-1 setTimeType
					ondemandDBSubJob.setTimeType(req.getTimeType());
					// 2. set ondemandDBSubJob feature
					ondemandDBSubJob.setConcernFaces(faceFeatureMap);
					// 3.set start_id, subcount, portion
					// DISCRETE에서는 DATALIST를 가지고 ,NODE수만큼 쪼개는 걸로 수행을 하게되는데
					// START_ID는 SUBLIST의 FROM INDEX , detectedFaceCount는 TO
					// INDEX
					if ("MODEEXIST".equals(modStatus)) {
						if (roofNum == k + 1) {
							ondemandDBSubJob.setStartId(Integer.toString(k * partNum));
							ondemandDBSubJob.setDetectedFaceCount(k * partNum + lastPartNum);
						} else {
							ondemandDBSubJob.setStartId(Integer.toString(k * partNum));
							ondemandDBSubJob.setDetectedFaceCount((k + 1) * partNum);
						}

						if (roofNum == k + 1) {
							ondemandDBSubJob.setPortionOfProgress((int) (((float) (1) / (float) roofNum) * 100) + 100
									% roofNum);
						} else {
							ondemandDBSubJob.setPortionOfProgress((int) (1.0f / (float) roofNum * 100.0f));
						}
					} else if ("MODEZERO".equals(modStatus)) {

						ondemandDBSubJob.setStartId(Integer.toString(k * partNum));
						ondemandDBSubJob.setDetectedFaceCount((k + 1) * partNum);
						ondemandDBSubJob.setPortionOfProgress(1.0f / (float) roofNum * 100.0f);

					}

					ondemandDBSubJobList.add(ondemandDBSubJob);
				} else {
					ondemandDBSubJob.setJobId(jobId);
					// 1-1 setTimeType
					ondemandDBSubJob.setTimeType(req.getTimeType());
					// 2. set ondemandDBSubJob feature
					ondemandDBSubJob.setConcernFaces(faceFeatureMap);

					ondemandDBSubJob.setStartId("NONE");
					ondemandDBSubJob.setDetectedFaceCount(0);
					ondemandDBSubJob.setPortionOfProgress((k + 1) * partNum);

					ondemandDBSubJobList.add(ondemandDBSubJob);

				}

			}

			return ondemandDBSubJobList;
		}

	}

	@Override
	public int search(OndemandDBSubJob subJob, int nodeId, String masterAddress) throws Exception {

		ondemandThreads = new ArrayList<Ondemandthread>();

		// 1. job을
		// 수행시간 테스트
		long startTime = System.currentTimeMillis();
		long endTime;

		this.masterAddress = masterAddress;

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", subJob.getJobId());
		this.jobId = subJob.getJobId();
		// detail info List
		List<HashMap<String, Object>> jobDetailList = this.faceMatchJobService.findJobDetailListByJobId(param);
		jobDetailList.get(0).put("start_id", subJob.getStartId());
		// List<DetectedFaceInfo> detectedFacesInfo =
		// this.faceMatchJobNonSqlService.findDetectedFacesNosqlInfo(jobDetailList,
		// subJob.getDetectedFaceCount());
		// job start update
		// DB 에 상태를 IN_PROGRESS , 시간은 0 으로 업뎃을 한다.
		this.faceMatchJobService.updateJobStartTime(param);

		Boolean bComplete = true;

		SearchRequest req = searchDataManager.findSearchRequest(subJob.getJobId());
		logger.info(">>>>>>>>>>>>>>>>>>>    START <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		logger.info(" +++++++++++++++++++    Thread Id : {}  +++++++++++++++++", threadId);
		logger.info(" +++++++++++++++++++    Thread Name : {}  +++++++++++++++++", threadName);

		if ("CONTINUOUS".equals(req.getTimeType())) {
			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType : CONTINUOUS <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			bComplete = continuousSearchTask(req, subJob, nodeId, masterAddress);
		} else {
			logger.info(">>>>>>>>>>>>>>>>>>>    ondemand TimeType :  Other <<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			bComplete = discreteSearchTask(req, subJob, nodeId, masterAddress);
		}

		// if (bComplete) {
		// // ---------- job end update --------------------------
		// // 완료시 상태를 COMPLETED 으로 하고, 진행률을 100%로 한다.
		// faceMatchJobService.updateSubJobEndTime(param);
		// }

		endTime = System.currentTimeMillis();

		logger.info(">>>>>>>>>>>>>>>>>>>Total continuousSearchTask() or discreteSearchTask() end time : {}", endTime - startTime);

		return onDemandDBUsingthreadsNum;
	}

	private Boolean continuousSearchTask(SearchRequest req, OndemandDBSubJob subJob, int nodeId, String masterAddress) {

		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", req.getId());

		// 수행시간 테스트 start
		// long jobDetailListStartTime = System.currentTimeMillis();
		// long jobDetailLisEendTime;
		// /////////////////
		List<HashMap<String, Object>> jobDetailList = this.faceMatchJobService.findJobDetailListByJobId(param);

		// 수행시간 테스트 end
		// jobDetailLisEendTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total jobDetailList time : {}",
		// jobDetailListStartTime - jobDetailLisEendTime);
		// /////////////////

		// 수행시간 테스트 start
		// long totalCountStartTime = System.currentTimeMillis();
		// long totalCountEndTime;
		// /////////////////
		long totalCount = subJob.getDetectedFaceCount();
		// 수행시간 테스트 end
		// totalCountEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total totalCount time : {}",
		// totalCountStartTime - totalCountEndTime);
		// /////////////////

		logger.debug("--------------------------------");
		logger.debug(".........totalCount : {}", totalCount);
		logger.debug("--------------------------------");

		// 페이징 처리를 위해 첫번째 id 를 조회
		String start_id = subJob.getStartId();

		List<DetectedFaceMatch> detectedFaceList;

		HashMap<String, Object> faceMatch = new HashMap<String, Object>();

		// 수행시간 테스트 start
		// long faceFeatureListStartTime = System.currentTimeMillis();
		// long faceFeatureListEndTime;
		// /////////////////
		// Concerned Face feature 조회
		List<HashMap<String, Object>> faceFeatureList = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);
		// 수행시간 테스트 end
		// faceFeatureListEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total faceFeatureList time : {}",
		// faceFeatureListStartTime - faceFeatureListEndTime);
		// /////////////////

		// -----------------------------------------------------------------------------

		// mongodb 전체 대상 데이터 조회
		// 초기화
		detectedFaceList = null;
		// 수행시간 테스트 start
		// long detectedFaceListStartTime = System.currentTimeMillis();
		// long detectedFaceListEndTime;
		// /////////////////
		jobDetailList.get(0).put("start_id", start_id);
		detectedFaceList = faceMatchJobNonSqlService.findDetectedFaces(jobDetailList, subJob.getDetectedFaceCount());
		// 수행시간 테스트 end
		// detectedFaceListEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total detectedFaceListEndTime time : {}",
		// detectedFaceListStartTime - detectedFaceListEndTime);
		// /////////////////
		logger.debug("--------------------------------");
		logger.debug("START ID IS  : {} MONGODB_LIMIT_COUNT : {}", jobDetailList.get(0).get("start_id"),
				subJob.getDetectedFaceCount());
		logger.debug("detectedFaceList SIZE IS : {} ", detectedFaceList.size());
		logger.debug("--------------------------------");

		// if (detectedFaceList.size() < 1) {
		// logger.info("not exist detected face data in nosql");
		// return false;
		// }

		// 수행시간 테스트 start
		// long totalMatchAndInsertStartTime =
		// System.currentTimeMillis();
		// long totalMatchAndInsertEndTime;
		int threadsCount = subJob.getDetectedFaceCount() / onDemandDBUsingthreadsNum;
		logger.info("  subJob.getDetectedFaceCount() : {} , onDemandDBUsingthreadsNum : {} , threadsCount : {} ",
				subJob.getDetectedFaceCount(), onDemandDBUsingthreadsNum, threadsCount);

		for (int i = 0; i < onDemandDBUsingthreadsNum; i++) {
			//FaceMatchJobService faceMatchJobService1 = (FaceMatchJobService)SpringApplicationContext.getBean("faceMatchJobService");
			//OndemandDBService ondemandDBService = (OndemandDBService)SpringApplicationContext.getBean("ondemandDBService");
			if (i + 1 == onDemandDBUsingthreadsNum) {
				float threadSubportion = subJob.getPortionOfProgress() / (float) onDemandDBUsingthreadsNum;
				// ExecutorService executor =
				// Executors.newSingleThreadExecutor();
				//
				// Future<String> future = executor.submit(new
				// Ondemandthread(detectedFaceList.subList(i * threadsCount ,
				// detectedFaceList.size()-1),
				// faceFeatureList, req.getThreshold(), subJob.getJobId(),
				// subJob.getTimeType(), threadSubportion,nodeId, masterAddress,
				// hbInnoParam, faceMatchJobService, hbInnoAdapter ));
				logger.info(
						" detectedFaceList.subList ==> i * threadsCount : {} , detectedFaceList.size() : {},  faceFeatureList.size() : {}, (detectedFaceList.subList(i * threadsCount, threadsCount * (i+1) ) : {}",
						i * threadsCount, detectedFaceList.size(), faceFeatureList.size(),
						detectedFaceList.subList(i * threadsCount, threadsCount * (i + 1)).size());
				ondemandThreads.add(new Ondemandthread(detectedFaceList.subList(i * threadsCount,
						detectedFaceList.size()), faceFeatureList, req.getThreshold(), subJob.getJobId(), subJob
						.getTimeType(), threadSubportion, nodeId, masterAddress, hbInnoParam, faceMatchJobService,
						hbInnoAdapter, asyncHttpClient));
			} else {
				float threadSubportion = subJob.getPortionOfProgress() / (float) onDemandDBUsingthreadsNum
						+ subJob.getPortionOfProgress() % (float) onDemandDBUsingthreadsNum;
				// ExecutorService executor =
				// Executors.newSingleThreadExecutor();
				//
				// Future<String> future = executor.submit(new
				// Ondemandthread(detectedFaceList.subList(i * threadsCount,
				// threadsCount * (i+1) -1),
				// faceFeatureList, req.getThreshold(), subJob.getJobId(),
				// subJob.getTimeType(), threadSubportion,nodeId, masterAddress,
				// hbInnoParam, faceMatchJobService, hbInnoAdapter ));
				logger.info(
						" detectedFaceList.subList ==> i * threadsCount : {} , threadsCount * (i+1)  : {} , faceFeatureList.size() : {}, (detectedFaceList.subList(i * threadsCount, threadsCount * (i+1) ) : {}",
						i * threadsCount, threadsCount * (i + 1), faceFeatureList.size(),
						detectedFaceList.subList(i * threadsCount, threadsCount * (i + 1)).size());

				ondemandThreads.add(new Ondemandthread(detectedFaceList.subList(i * threadsCount, threadsCount
						* (i + 1)), faceFeatureList, req.getThreshold(), subJob.getJobId(), subJob.getTimeType(),
						threadSubportion, nodeId, masterAddress, hbInnoParam, faceMatchJobService, hbInnoAdapter,
						asyncHttpClient));
			}

		}

		for (Ondemandthread ondemandThread : ondemandThreads) {
			this.executor.submit(ondemandThread);
		}

		// 수행시간 테스트 end
		// totalMatchAndInsertEndTime = System.currentTimeMillis();
		// logger.info(">>>>>>>>>>>>>>>>>>>Total 30000 totalMatchAndInsert time : {}",
		// totalMatchAndInsertStartTime - totalMatchAndInsertEndTime);
		// /////////////////

		// 진행률 update
		// progressCount += detectedFaceList.size();
		// logger.debug("++ int progress value : {}",
		// (long)((double)progressCount/totalCount * 100));
		// rateMap.put("progress", (long) ((double) progressCount / totalCount *
		// 100));
		// faceMatchJobService.updateJobProgressRate(rateMap);

		return true;

	}

	private Boolean discreteSearchTask(SearchRequest req, OndemandDBSubJob subJob, int nodeId, String masterAddress) {

		if (subJob.getStartId() == "NONE") {

			// threads수만큼만 허수 threads생성
			for (int n = 0; n < onDemandDBUsingthreadsNum; n++) {

				ondemandThreads.add(new Ondemandthread(new ArrayList<DetectedFaceMatch>(),
						new ArrayList<HashMap<String, Object>>(), req.getThreshold(), subJob.getJobId(), subJob
								.getTimeType(), subJob.getPortionOfProgress(), nodeId, masterAddress, hbInnoParam,
						faceMatchJobService, hbInnoAdapter, asyncHttpClient));
			}

			for (Ondemandthread ondemandThread : ondemandThreads) {
				this.executor.submit(ondemandThread);
			}

			// progress생성 따로
			HashMap<String, Object> rateMap = new HashMap<String, Object>();

			rateMap.put("job_id", jobId);
			rateMap.put("progress", subJob.getPortionOfProgress());

			faceMatchJobService.updateDiscretedJobProgressRate(rateMap);

		} else {

			List<DetectedFaceMatch> detectedFaceList = new ArrayList<DetectedFaceMatch>();
			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("job_id", req.getId());

			List<HashMap<String, Object>> jobDetailList = faceMatchJobService.findJobDetailListByJobId(param);

			List<String> dateList = fromToDateList(req.getStartDate(), req.getEndDate());

			detectedFaceList = new ArrayList<DetectedFaceMatch>();

			List<HashMap<String, Object>> faceFeatureList = faceMatchJobService
					.findConcernedFaceFeatureListByJobId(param);
			HashMap<String, Object> jobDetail = jobDetailList.get(0);

			param.put("vms_id", (String) jobDetail.get("vms_id"));
			param.put("cctv_id", (String) jobDetail.get("cctv_id"));

			String start_time2 = (String) jobDetail.get("start_time2");
			int i = 1;

			List<String> subjobDateList = dateList.subList(Integer.parseInt(subJob.getStartId()),
					subJob.getDetectedFaceCount());

			int roofNum = -1;
			int lastNum = 1;

			float threadSubportion;

			if (subjobDateList.size() % onDemandDBUsingthreadsNum == 0) {
				roofNum = subjobDateList.size() / onDemandDBUsingthreadsNum;
				threadSubportion = ((float) subJob.getPortionOfProgress() / (float) onDemandDBUsingthreadsNum);
			} else {
				roofNum = subjobDateList.size() / onDemandDBUsingthreadsNum + 1;
				threadSubportion = ((float) subJob.getPortionOfProgress() / (float) onDemandDBUsingthreadsNum);
			}

			for (String date : subjobDateList) {

				// 2번째 조회 시간이 있을 경우 조회 조건에 추가
				if (start_time2 != null) {
					param.put("start_datetime2", date + (String) jobDetail.get("start_time2"));
					param.put("end_datetime2", date + (String) jobDetail.get("end_time2"));
					jobDetailList.get(0).put("start_datetime2", param.get("start_datetime2"));
					jobDetailList.get(0).put("end_datetime2", param.get("end_datetime2"));
				} else {
					param.put("start_datetime2", null);
					jobDetailList.get(0).put("start_datetime2", param.get("start_datetime2"));
				}

				detectedFaceList.addAll(faceMatchJobNonSqlService.findDetectedFaces(jobDetailList,
						subJob.getDetectedFaceCount()));

				if (roofNum == i || subjobDateList.size() == lastNum) {

					ondemandThreads.add(new Ondemandthread(detectedFaceList, faceFeatureList, req.getThreshold(),
							subJob.getJobId(), subJob.getTimeType(), threadSubportion, nodeId, masterAddress,
							hbInnoParam, faceMatchJobService, hbInnoAdapter, asyncHttpClient));

					detectedFaceList = new ArrayList<DetectedFaceMatch>();

					i = 1;
				} else {

					i++;
				}
				lastNum++;

			}

			// 설정한 thread수보다 적은 ondemandThreads를 생성할 경우 httprequest를 위해 비어있는
			// ondemands 객체를 생성한다.
			for (int m = 0; m < onDemandDBUsingthreadsNum - ondemandThreads.size(); m++) {
				ondemandThreads.add(new Ondemandthread(detectedFaceList, faceFeatureList, req.getThreshold(), subJob
						.getJobId(), subJob.getTimeType(), threadSubportion, nodeId, masterAddress, hbInnoParam,
						faceMatchJobService, hbInnoAdapter, asyncHttpClient));
			}

			for (Ondemandthread ondemandThread : ondemandThreads) {
				this.executor.submit(ondemandThread);
			}

		}

		return true;

	}

	public List<String> fromToDateList(String strStartDate, String strEndDate) {
		List<String> dateList = new ArrayList<String>();
		DateFormat formatter = new SimpleDateFormat("yyyyMMdd"); // 2016093009

		try {
			List<Date> dates = new ArrayList<Date>();

			Date startDate = (Date) formatter.parse(strStartDate);
			Date endDate = (Date) formatter.parse(strEndDate);

			long interval = 24 * 1000 * 60 * 60; // 1 hour in millis
			long endTime = endDate.getTime();
			long curTime = startDate.getTime();

			while (curTime <= endTime) {
				dates.add(new Date(curTime));
				curTime += interval;
			}

			for (int i = 0; i < dates.size(); i++) {
				Date lDate = (Date) dates.get(i);
				String ds = formatter.format(lDate);
				dateList.add(ds);
			}

		} catch (Exception ex) {
			return null;
		}

		return dateList;
	}

	@Override
	public int abort(int nodeId, String masterAddress) throws Exception {
		// TODO Auto-generated method stub
		logger.debug("---------Abort Call!!!!!!----------");
		for (Ondemandthread ondemandThread : ondemandThreads) {
			ondemandThread.setAbort(true);
		}

		logger.debug("---------send to masterAddress {}----------", masterAddress);
		AsyncHttpClient.BoundRequestBuilder builder = asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", "ONDEMAND_DB_ABORT_RESULT");
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", 1);
		loginParam.put("subJobMessage", "Abort");

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 1;
	}

}

class Ondemandthread implements Callable<String> {

	private final List<DetectedFaceMatch> sourceFeatureList;
	private final List<HashMap<String, Object>> targetFeatureList;
	private final float threshold;
	private final String jobId;
	private final String timeType;
	private final float perPortion;
	private final int nodeId;
	private final String masterAddress;
	private final HbInnoParameter hbInnoParam;
	private final FaceMatchJobService faceMatchJobService;
	private final AsyncHttpClient asyncHttpClient;
	private boolean isAborted = false;
	private final HbinnoEngine hbInnoAdapter;
	private long startTime;
	private long endTime;
	private long progressCount;
	private float floatScore;
	private int intScore;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	public Ondemandthread(List<DetectedFaceMatch> detectedFaceList, List<HashMap<String, Object>> faceFeatureList,
			int threshold, String jobId, String timeType, float threadSubPortion, int nodeId, String masterAddress,
			HbInnoParameter hbInnoParam, FaceMatchJobService faceMatchJobService, HbinnoEngine hbInnoAdapter,
			AsyncHttpClient asyncHttpClient) {
		this.sourceFeatureList = detectedFaceList;
		this.targetFeatureList = faceFeatureList;

		if (threshold == -1) {
			this.threshold = hbInnoParam.getVerificationThreshold() * 100;
		} else {
			this.threshold = threshold;

		}

		this.jobId = jobId;
		this.timeType = timeType;
		this.perPortion = Float.parseFloat(String.format("%.4f", (float) ((double) threadSubPortion / (sourceFeatureList.size()))));
		this.nodeId = nodeId;
		this.masterAddress = masterAddress;
		this.hbInnoParam = hbInnoParam;
		this.faceMatchJobService = faceMatchJobService;
		this.hbInnoAdapter = hbInnoAdapter;
		this.asyncHttpClient = asyncHttpClient;
	}

	@Override
	public String call() throws Exception {

		// TODO Auto-generated method stub
		// this.findMatch(sourceFeatureList, targetFeatureList, threshold);
		startTime = System.currentTimeMillis();
		progressCount = 0;
		// for 진행률 update
		HashMap<String, Object> rateMap = new HashMap<String, Object>();

		logger.debug("--------------------------------");
		// logger.debug("START ID IS  : {} MONGODB_LIMIT_COUNT : {}",
		// param.get("start_id"), MONGODB_LIMIT_COUNT);
		logger.debug("a thread detectedFaceList SIZE IS : {} ", sourceFeatureList.size());
		logger.debug("--------------------------------");

		for (DetectedFaceMatch detectedFace : sourceFeatureList) {

			// logger.debug("***********************************hbinno call**************************************");

			startTime = System.currentTimeMillis();
			int matchScore = 0;
			// 테이블 VAS_DETECTED_FACE 와 VAS_CNCRN_FACE 를 비교
			for (HashMap<String, Object> faceFeature : targetFeatureList) {
				/* 비교 */
				// try {

				if (threshold == -1) {
					logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}", detectedFace.get_id(),
							faceFeature.get("job_cncrn_face_id"));
					// logger.debug("--------------faceFeature.get(feature) : {}  ",
					// faceFeature.get("feature"));
					// logger.debug("--------------detectedFace.getFeature() : {}  ",
					// detectedFace.getFeature());

					matchScore = findMatch((byte[]) faceFeature.get("feature"), detectedFace.getFeature(), threshold);
				} else {
					logger.debug("--------------detectedFace.id : {}  faceFeature.id : {}", detectedFace.get_id(),
							faceFeature.get("job_cncrn_face_id"));
					// logger.debug("--------------faceFeature.get(feature) : {}  ",
					// faceFeature.get("feature"));
					// logger.debug("--------------detectedFace.getFeature() : {}  ",
					// detectedFace.getFeature());
					matchScore = findMatch((byte[]) faceFeature.get("feature"), detectedFace.getFeature(), threshold);
				}

				// } catch (Exception e) {
				// logger.debug("*************************** find match Exception *************************\n"
				// + e.getMessage());
				// }

				endTime = System.currentTimeMillis();
				logger.info(">>>>>>>>>>>>>>>>>>>A Compare time : {}", endTime - startTime);

				HashMap<String, Object> faceMatch = new HashMap<String, Object>();
				if (matchScore > 0) {
					faceMatch = new HashMap<String, Object>();
					faceMatch.put("job_cncrn_face_id", faceFeature.get("job_cncrn_face_id"));
					faceMatch.put("detected_face_id", detectedFace.getDetectedFaceId());
					faceMatch.put("score", matchScore);

					faceMatch.put("systemId", detectedFace.getSystemId());
					faceMatch.put("cctvId", detectedFace.getCctvId());
					faceMatch.put("srvcType", detectedFace.getSrvcType());
					faceMatch.put("imgFile", detectedFace.getImgFile());
					faceMatch.put("imgW", detectedFace.getImgW());
					faceMatch.put("imgH", detectedFace.getImgH());
					faceMatch.put("imgX", detectedFace.getImgX());
					faceMatch.put("imgY", detectedFace.getImgY());
					faceMatch.put("frmFile", detectedFace.getFrmFile());
					faceMatch.put("frmW", detectedFace.getFrmW());
					faceMatch.put("frmH", detectedFace.getFrmH());
					faceMatch.put("frmTime", detectedFace.getFrmTime());

					startTime = System.currentTimeMillis();
					/* 결과를 DB 에 저장 */
					faceMatchJobService.insertJobFaceMatch(faceMatch);
					endTime = System.currentTimeMillis();
					logger.info(">>>>>>>>>>>>>>>>>>>faceMatchJobService.insertJobFaceMatch time : {}", endTime
							- startTime);
				} else {
					logger.debug("there is no data to input \n");
				}
				// AfterAInsertEndTime = System.currentTimeMillis();
				// logger.info(">>>>>>>>>>>>>>>>>>> AInsertTime time : {}",
				// beforeAInsertStartTime - AfterAInsertEndTime);

				// PROGRESS UPDATE
				// targetFeatureList, sourceFeatureList

			}

			if ("CONTINUOUS".equals(this.timeType)) {
				// 진행률 update
				// logger.debug("++ int progress value : {}",
				// (long)((double)progressCount/totalCount * 100));
				rateMap.put("job_id", jobId);
				rateMap.put("progress", perPortion);
				// rateMap.put("progress", portion);
			} else {
				rateMap.put("job_id", jobId);
				rateMap.put("progress", perPortion);
			}

			faceMatchJobService.updateDiscretedJobProgressRate(rateMap);

			// -------------------------------------- 매번 돌때마다 aborted 인지를
			// 체크한다.
			endTime = System.currentTimeMillis();
			logger.info(">>>>>>>>>>>>>>>>>>>feature loop time : {}", endTime - startTime);

			if (isAborted) {
				logger.debug("--------------------------------");
				logger.debug(".........isAborted : {}", isAborted);
				logger.debug("--------------------------------");
				logger.error(".........STOP.......");
				// throw new
				// RuntimeException("Stopped due to stop command!");
				sendThreadJobAbortResultToMasterNode();
				break;
			}
			// if (stopCmd.equals("ABORTED")) {
			// logger.error(".........STOP.......");
			// // throw new
			// // RuntimeException("Stopped due to stop command!");
			// sendThreadJobAbortResultToMasterNode();
			// break;
			// }
			// if("CONTINUOUS".equals(this.timeType)){
			// // 진행률 update
			// progressCount += sourceFeatureList.size();
			// // logger.debug("++ int progress value : {}",
			// // (long)((double)progressCount/totalCount * 100));
			// rateMap.put("job_id", jobId);
			// rateMap.put("progress", (long) ((double) progressCount /
			// (sourceFeatureList.size() * targetFeatureList.size() *
			// hbInnoParam.getOnDemandDBUsingthreadsNum()) * 100));
			// }else{
			// rateMap.put("job_id", jobId);
			// rateMap.put("progress", this.portion / targetFeatureList.size());
			// }

			// faceMatchJobService.updateDiscretedJobProgressRate(rateMap);
		}

		if (!isAborted) {

			// 수행시간 테스트 end
//			endTime = System.currentTimeMillis();
//			logger.info(">>>>>>>>>>>>>>>>>>>A subjob threads time : {}", endTime - startTime);
			// /////////////////
			// search() 완료시 master node에 http로 전송

			sendThreadJobSuccessResultToMasterNode();
		}
		endTime = System.currentTimeMillis();
		logger.info(">>>>>>>>>>>>>>>>>>>A subjob a threads end time : {}", endTime - startTime);
		return null;
	}

	private int findMatch(@Nonnull byte[] sourceFeature, @Nonnull byte[] targetFeature, float threshold)
			throws Exception {
		// Assert.isNull(sourceFeature, "sourceFeature is Null");
		// Assert.isNull(targetFeature, "targetFeature is Null");
		// Assert.isNull(threshold, "threshold is Null");

		// logger.info("++ findfindMatch ");
		floatScore = getHbInnoAdapter().verify(sourceFeature, targetFeature); // ex.
		// limitCount
		intScore = 0;

		if (threshold > floatScore * 100) {

			logger.debug("findMatch() , there is no score over threshold. score {}, threshold {}", floatScore * 100,
					threshold);
			return 0;

		} else {

			intScore = (int) Math.round(floatScore * 100);

			return intScore;

		}

	}

	public void sendThreadJobSuccessResultToMasterNode() {

		logger.debug("---------send to masterAddress {}----------", masterAddress);
		AsyncHttpClient.BoundRequestBuilder builder = asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", "ONDEMAND_DB_RESULT");
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", 1);
		loginParam.put("subJobMessage", "success");

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sendThreadJobAbortResultToMasterNode() {

		logger.debug("---------send to masterAddress {}----------", masterAddress);
		AsyncHttpClient.BoundRequestBuilder builder = asyncHttpClient.preparePost(masterAddress);
		builder.addHeader("Content-Type", "application/json");

		JSONObject loginParam = new JSONObject();
		loginParam.put("type", "ONDEMAND_DB_ABORT_RESULT");
		loginParam.put("id", jobId);
		loginParam.put("nodeId", nodeId);
		loginParam.put("subJobResult", 1);
		loginParam.put("subJobMessage", "Abort");

		builder.setBody(loginParam.toString());

		try {
			builder.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<DetectedFaceMatch> getSourceFeatureList() {
		return sourceFeatureList;
	}
	public List<HashMap<String, Object>> getTargetFeatureList() {
		return targetFeatureList;
	}
	public float getThreshold() {
		return threshold;
	}
	protected HbinnoEngine getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	public void setAbort(boolean isAbort) {
		isAborted = isAbort;
	}
	
	public void testFunctino(){
		
		List<DetectedFace> faces = new ArrayList<DetectedFace>();
		
		Collections.sort(faces, new Comparator<DetectedFace>(){

			@Override
			public int compare(DetectedFace o1, DetectedFace o2) {
				// TODO Auto-generated method stub
				return 0;
			}
			
		});
	}

}
