package com.skcc.vas.frs.common.db.nosql.domain;

import org.bson.types.Binary;

public class NConcernPersonAndFace {

	private String personId; // long으로 바꾸어야 함

	private String name;

	private String gender;

	private String concernType;

	private String isValid;

	private String cpRemarks;

	private String lastUpdateBy;

	private String lastUpdateAt;

	private String birthday;

	private String nationality;

	private String passportNo;

	private String firstName;

	private String middleName;

	private String lastName;

	private String faceId; // long으로 바꾸어야 함

	private String isValidFace;

	private Binary img;

	private String imgFormat;

	private String imgW;

	private String imgH;

	private Binary feature;

	private String landmarks;

	private String cfRemarks;

	private String imgPath;

	private byte[] byteImage;

	private byte[] byteFeature;

	private String remarks;

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getConcernType() {
		return concernType;
	}

	public void setConcernType(String concernType) {
		this.concernType = concernType;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getCpRemarks() {
		return cpRemarks;
	}

	public void setCpRemarks(String cpRemarks) {
		this.cpRemarks = cpRemarks;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getLastUpdateAt() {
		return lastUpdateAt;
	}

	public void setLastUpdateAt(String lastUpdateAt) {
		this.lastUpdateAt = lastUpdateAt;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getfaceId() {
		return faceId;
	}

	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}

	public String getIsValidFace() {
		return isValidFace;
	}

	public void setIsValidFace(String isValidFace) {
		this.isValidFace = isValidFace;
	}

	public Binary getImg() {
		return img;
	}

	public void setImg(Binary img) {
		this.img = img;
	}

	public String getImgFormat() {
		return imgFormat;
	}

	public void setImgFormat(String imgFormat) {
		this.imgFormat = imgFormat;
	}

	public String getImgW() {
		return imgW;
	}

	public void setImgW(String imgW) {
		this.imgW = imgW;
	}

	public String getImgH() {
		return imgH;
	}

	public void setImgH(String imgH) {
		this.imgH = imgH;
	}

	public Binary getFeature() {
		return feature;
	}

	public void setFeature(Binary feature) {
		this.feature = feature;
	}

	public String getLandmarks() {
		return landmarks;
	}

	public void setLandmarks(String landmarks) {
		this.landmarks = landmarks;
	}

	public String getCfRemarks() {
		return cfRemarks;
	}

	public void setCfRemarks(String cfRemarks) {
		this.cfRemarks = cfRemarks;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public byte[] getByteImage() {
		return byteImage;
	}

	public void setByteImage(byte[] byteImage) {
		this.byteImage = byteImage;
	}

	public byte[] getByteFeature() {
		return byteFeature;
	}

	public void setByteFeature(byte[] byteFeature) {
		this.byteFeature = byteFeature;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
