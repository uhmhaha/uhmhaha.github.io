package com.skcc.vas.frs.common.biz.event;

public class AccessEvent {

	private String id;

	private String passNo;

	public enum EntrantType {
		PERSONNEL, VISITOR;
	}

	private String prsnnlId;

	private String visitorId;

	private String gateId;

	private EntrantType entrantType;

	private String entrantId;

	/**
	 * 'yyyyMMddHHmmss' format
	 */
	private String accessAt;

	/**
	 * enter or exit
	 */
	private boolean isEntrance;

	public AccessEvent() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public AccessEvent setId(String id) {
		this.id = id;
		return this;
	}

	public String getPassNo() {
		return passNo;
	}

	public AccessEvent setPassNo(String passNo) {
		this.passNo = passNo;
		return this;
	}

	public String getPrsnnlId() {
		return prsnnlId;
	}

	public AccessEvent setPrsnnlId(String prsnnlId) {
		this.prsnnlId = prsnnlId;
		return this;
	}

	public String getVisitorId() {
		return visitorId;
	}

	public AccessEvent setVisitorId(String visitorId) {
		this.visitorId = visitorId;
		return this;
	}

	public String getGateId() {
		return gateId;
	}

	public AccessEvent setGateId(String gateId) {
		this.gateId = gateId;
		return this;
	}

	public EntrantType getEntrantType() {
		return this.entrantType;
	}

	public AccessEvent setEntrantType(EntrantType type) {
		this.entrantType = type;
		return this;
	}

	public String getEntrantId() {
		return entrantId;
	}

	public AccessEvent setEntrantId(String entrantId) {
		this.entrantId = entrantId;
		return this;
	}

	public String getAccessAt() {
		return accessAt;
	}

	public AccessEvent setAccessAt(String accessAt) {
		this.accessAt = accessAt;
		return this;
	}

	/**
	 * @return {@code true} if the access is enter, or {@code false} if the
	 *         access is exit.
	 */
	public boolean getIsEntrance() {
		return isEntrance;
	}

	/**
	 * @param isEntrance
	 *            {@code true} for enter, or {@code false} for exit
	 * @return
	 */
	public AccessEvent setIsEntrance(boolean isEntrance) {
		this.isEntrance = isEntrance;
		return this;
	}

}
