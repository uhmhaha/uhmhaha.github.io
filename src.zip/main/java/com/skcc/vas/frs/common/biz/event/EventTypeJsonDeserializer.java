package com.skcc.vas.frs.common.biz.event;

import java.io.IOException;

import javax.annotation.Nullable;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

/**
 * @author
 * @since 2015-08-10
 */
public class EventTypeJsonDeserializer extends StdDeserializer<EventType> {

	/**
	 *
	 */
	private static final long serialVersionUID = -1575075023222042804L;

	public EventTypeJsonDeserializer() {
		super(EventType.class);
	}

	/**
	 * Gets proper EventType object from the JSON string. Returns {@code null},
	 * if there's no corresponding type in {@link VideoEventType} and
	 * {@link AudioEventType}.
	 *
	 * @see com.fasterxml.jackson.databind.JsonDeserializer#deserialize(com.fasterxml.jackson.core.JsonParser,
	 *      com.fasterxml.jackson.databind.DeserializationContext)
	 * @see EventType
	 * @see VideoEventType
	 * @see AudioEventType
	 */
	@Override
	@Nullable
	public EventType deserialize(JsonParser jp, DeserializationContext cntx) throws IOException {

		EventType type = null;
		String text = jp.getText();
		try {
			type = VideoEventType.valueOf(text);
		} catch (IllegalArgumentException iae) {
			type = null;
		} catch (NullPointerException npe) {
			type = null;
		}

		if (type == null) {
			try {
				type = AudioEventType.valueOf(text);
			} catch (IllegalArgumentException iae) {
				type = null;
			} catch (NullPointerException npe) {
				type = null;
			}
		}

		return type;
	}

}
