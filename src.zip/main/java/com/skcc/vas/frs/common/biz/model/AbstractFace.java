package com.skcc.vas.frs.common.biz.model;

import javax.validation.constraints.Min;

/**
 *
 * @author
 * @since 2016-01-22
 */
public abstract class AbstractFace {

	private String id;

	private byte[] img;

	private String imgFormat;

	@Min(0)
	private int imgWidth;

	@Min(0)
	private int imgHeight;

	private byte[] feature;

	private String landmarks;

	/**
	 * @return the the identifier for this face
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the identifier for this face
	 */
	public AbstractFace setId(String id) {
		this.id = id;
		return this;
	}

	/**
	 * The binary data of the image file for this face.
	 * <p>
	 * The binary include all the contents of image file not only pixel data.
	 *
	 * @return the binary data of the image file for this face
	 */
	public byte[] getImg() {
		return img;
	}

	/**
	 * @param img
	 *            the binary data of the image file for this face
	 */
	public AbstractFace setImg(byte[] img) {
		this.img = img;
		return this;
	}

	/**
	 * @return the format of face image - "BMP", "JPG" or "GIF"
	 */
	public String getImgFormat() {
		return imgFormat;
	}

	/**
	 * @param format
	 *            the format of face image - "BMP", "JPG" or "GIF"
	 */
	public AbstractFace setImgFormat(String format) {
		this.imgFormat = format;
		return this;
	}

	/**
	 * @return pixel width of the face image
	 */
	public int getImgWidth() {
		return imgWidth;
	}

	/**
	 * @param width
	 *            pixel width of the face image
	 */
	public AbstractFace setImgWidth(int width) {
		this.imgWidth = width;
		return this;
	}

	/**
	 * @return pixel height of the face image
	 */
	public int getImgHeight() {
		return imgHeight;
	}

	/**
	 * @param height
	 *            pixel height of the face image
	 */
	public AbstractFace setImgHeight(int height) {
		this.imgHeight = height;
		return this;
	}

	/**
	 * @return the face feature in binary
	 */
	public byte[] getFeature() {
		return feature;
	}

	/**
	 * @param feature
	 *            the face feature in binary
	 */
	public AbstractFace setFeature(byte[] feature) {
		this.feature = feature;
		return this;
	}

	/**
	 * @return semantic facial points including the eyes, nose, mouth and et al.
	 *         (in JSON string format without enclosing currly braces)
	 */
	public String getLandmarks() {
		return landmarks;
	}

	/**
	 * @param landmarks
	 *            semantic facial points including the eyes, nose, mouth and et
	 *            al. (in JSON string format without enclosing currly braces)
	 */
	public AbstractFace setLandmarks(String landmarks) {
		this.landmarks = landmarks;
		return this;
	}

}
