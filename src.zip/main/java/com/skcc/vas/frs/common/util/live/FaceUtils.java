package com.skcc.vas.frs.common.util.live;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.tuple.Pair;

import com.skcc.vas.frs.common.db.rdb.domain.DetectedRoi;

/**
 * All public methods in this utility are expected to be
 * {@code public final static}.
 *
 * @author
 * @since 2016-07-18
 *
 */
public class FaceUtils {

	public final static void sortFaceMatches(List<Pair<String, Integer>> matches, boolean descending) {
		Collections.sort(matches, MatchComparator.getInstance());
		if (!descending)
			Collections.reverse(matches);
	}

	static class MatchComparator implements Comparator<Pair<String, Integer>> {

		// @TODO Is this threadsafe ?

		@Override
		public final int compare(Pair<String, Integer> t1, Pair<String, Integer> t2) {
			return NumberUtils.compare(t2.getRight(), t1.getRight());
		}

		private final static MatchComparator singleton = new MatchComparator();

		private MatchComparator() {
		}

		public final static MatchComparator getInstance() {
			return singleton;
		}
	}

	/*
	 * roi rate list -> left top point, right bottom point return
	 */
	public final static HashMap<String, Object> roiRateToPoint(int imgWidth, int imgHeight, List<DetectedRoi> roiList) {
		// roi 의 4개의 좌표가 있어야 가능함
		/*
		 * deviceId roi 순서 좌표순서 x좌표 y좌표 (전체 width, height을 1로 했을때의 값) 1449 1 1
		 * 0.25 0.25 1449 1 2 0.53 0.25 1449 1 3 0.53 0.65 1449 1 4 0.25 0.65
		 */
		if (roiList == null || roiList.size() < 4) {
			return null;
		}

		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		// top left 좌표
		int topleftX = (int) ((roiList.get(0).getPointX() * imgWidth));
		int topleftY = (int) ((roiList.get(0).getPointY() * imgHeight));

		// bottom left 좌표
		int bottomrightX = (int) ((roiList.get(2).getPointX() * imgWidth)) - 1;
		int bottomrightY = (int) ((roiList.get(2).getPointY() * imgHeight)) - 1;

		resultMap.put("topleftX", topleftX);
		resultMap.put("topleftY", topleftY);
		resultMap.put("bottomrightX", bottomrightX);
		resultMap.put("bottomrightY", bottomrightY);

		return resultMap;
	}

	public final static List<DetectedRoi> reviceRoiRate(List<DetectedRoi> roiList) {

		if (roiList == null || roiList.size() != 4) {
			return null;
		}

		List<DetectedRoi> reviceRoiList = new ArrayList<DetectedRoi>();
		float pointX[] = new float[4];
		float pointY[] = new float[4];

		if (roiList.get(0).getPointX() > roiList.get(3).getPointX()) {
			pointX[0] = roiList.get(3).getPointX();
			pointX[3] = roiList.get(3).getPointX();
		} else {
			pointX[0] = roiList.get(0).getPointX();
			pointX[3] = roiList.get(0).getPointX();
		}

		if (roiList.get(1).getPointX() > roiList.get(2).getPointX()) {
			pointX[1] = roiList.get(1).getPointX();
			pointX[2] = roiList.get(1).getPointX();
		} else {
			pointX[1] = roiList.get(2).getPointX();
			pointX[2] = roiList.get(2).getPointX();
		}

		if (roiList.get(0).getPointY() > roiList.get(1).getPointY()) {
			pointY[0] = roiList.get(1).getPointY();
			pointY[1] = roiList.get(1).getPointY();
		} else {
			pointY[0] = roiList.get(0).getPointY();
			pointY[1] = roiList.get(0).getPointY();
		}

		if (roiList.get(2).getPointY() > roiList.get(3).getPointY()) {
			pointY[2] = roiList.get(2).getPointY();
			pointY[3] = roiList.get(2).getPointY();
		} else {
			pointY[2] = roiList.get(3).getPointY();
			pointY[3] = roiList.get(3).getPointY();
		}

		for (DetectedRoi detectedRoi : roiList) {
			int pointNo = detectedRoi.getPointNo();
			detectedRoi.setPointX(pointX[pointNo - 1]);
			detectedRoi.setPointY(pointY[pointNo - 1]);

			reviceRoiList.add(detectedRoi);
		}

		return reviceRoiList;
	}
}