package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * @author Hong yongman
 * @since 2016. 3. 9.
 *
 */
@Repository("face.PersonnelMatchMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface PersonnelMatchMapper {

	int insertPersonnelMatch(@Param("prsnnlFaceId") String prsnnlFaceId, @Param("detectedFaceId") String detectedFaceId,
			@Param("score") int score, @Param("passNo") String passNo, @Param("accessAt") String accessAt,
			@Param("updateBy") String userId, @Param("rank") int rank);

}
