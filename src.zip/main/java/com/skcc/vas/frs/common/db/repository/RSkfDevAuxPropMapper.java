package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

@Repository("rSkfDevAuxPropMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface RSkfDevAuxPropMapper {

	int countCCTVNumForVAS();
}
