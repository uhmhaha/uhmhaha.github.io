package com.skcc.vas.frs.common.db.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;

@Repository("face.DetectedFaceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface DetectedFaceMapper {

	ConcernedFace selectPersonById(@Param("id") int id);

	List<ConcernedFace> selectActivePersons();

	/**
	 * Insert a row for a new concerned face.
	 *
	 * This method would assign {@code face.id} with the key value which is auto
	 * generated at database.
	 *
	 * @param face
	 * @return
	 */
	int insertDetectedFace(@Param("face") DetectedFace face);

	@Deprecated
	int insertConcernedFaceMatch(@Param("face") DetectedFace face);

	@Deprecated
	int updateConcernedFace(@Param("face") ConcernedFace face);

	@Deprecated
	int updateFeatureExtracted(@Param("id") int id, @Param("feature") byte[] feature);

	int insertJobFaceMatch(@Param("face") DetectedFace face);
}
