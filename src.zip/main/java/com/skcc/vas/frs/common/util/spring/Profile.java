package com.skcc.vas.frs.common.util.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component("spring.Profile")
public class Profile {

	@Autowired
	private Environment environment;

	@Autowired
	private ApplicationContext applicationContext;

	public String[] getSpringProfiles() {

		return environment.getActiveProfiles();
	}

	public String[] getSpringBeans() {

		return applicationContext.getBeanDefinitionNames();
	}
	
	public String getBeanClassName(String beanName) {
		
		return applicationContext.getBean(beanName).getClass().toString();
	}
}
