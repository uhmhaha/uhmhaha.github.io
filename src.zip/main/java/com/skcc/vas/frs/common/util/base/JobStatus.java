package com.skcc.vas.frs.common.util.base;

/**
 * @author
 * @since 2015-09-02
 * @see javax.batch.runtime.BatchStatus
 * @see TaskStatus
 */
public enum JobStatus {
	SUBMITTED, IN_PROGRESS, COMPLETED, ABORTED, FAIL

}
