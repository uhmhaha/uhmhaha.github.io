package com.skcc.vas.frs.common.db.nosql.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bson.types.ObjectId;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.skcc.vas.frs.ondemand.db.biz.DetectedFaceInfo;
import com.skcc.vas.frs.ondemand.db.biz.DetectedFaceMatch;

@Service("faceMatchJobNonSqlService")
public class FaceMatchJobNonSqlService {
	@Autowired
	private MongoTemplate mongoTemplate;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	public List<DetectedFaceMatch> findDetectedFaceByCctvId(HashMap<String, Object> param, int pageLimit) {
		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("systemId").is(param.get("vms_id")));
		query.addCriteria(Criteria.where("cctvId").is((String) param.get("cctv_id")));

		// query.addCriteria(Criteria.where("frmTime").gte(param.get("start_datetime")).lte(param.get("end_datetime")));
		// query.addCriteria(Criteria.where("_id").gt(new
		// ObjectId((String)param.get("start_id"))));
		// Criteria.where("frmTime").orOperator(Criteria.gte(param.get("start_datetime")));

		if ("DISCRETE".equals(param.get("job_time_type"))) {
			if (param.get("start_datetime2") != null && !"".equals(param.get("start_datetime2"))) {
				Criteria criteria = new Criteria();
				criteria.orOperator(
						Criteria.where("frmTime").gte(param.get("start_datetime")).lte(param.get("end_datetime")),
						Criteria.where("frmTime").gte(param.get("start_datetime2")).lte(param.get("end_datetime2")));
				query.addCriteria(criteria);
			} else {
				query.addCriteria(
						Criteria.where("frmTime").gte(param.get("start_datetime")).lte(param.get("end_datetime")));
			}
		} else {
			query.addCriteria(
					Criteria.where("frmTime").gte(param.get("start_datetime")).lte(param.get("end_datetime")));
			query.addCriteria(Criteria.where("_id").lt(new ObjectId((String) param.get("start_id"))));
		}

		query.limit(pageLimit);
		query.fields().include("feature");
		query.fields().include("frmTime");
		query.fields().include("detectedFaceId");
		query.fields().include("_id");
		// 한방쿼리로 해결
		query.fields().include("systemId");
		query.fields().include("cctvId");
		query.fields().include("srvcType");
		query.fields().include("imgFile");
		query.fields().include("imgW");
		query.fields().include("imgH");
		query.fields().include("imgX");
		query.fields().include("imgY");
		query.fields().include("frmFile");
		query.fields().include("frmW");
		query.fields().include("frmH");
		query.fields().include("frmTime");
		// query.with(new Sort(Sort.Direction.ASC, "_id"));

		logger.info("== findDetectedFaceByCctvId == " + query.toString());

		return mongoTemplate.find(query, DetectedFaceMatch.class, "VAS_DETECTED_FACE_NOSQL");

	}

	public String findDetectedFaceIds(List<HashMap<String, Object>> params, int subCount) {
		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("systemId").is(params.get(0).get("vms_id")));
		// query.addCriteria(Criteria.where("cctvId").is((String)params.get(0).get("cctv_id")));
		ArrayList<String> cctvIds = new ArrayList<String>();

		for (HashMap<String, Object> param : params) {
			cctvIds.add((String) param.get("cctv_id"));
		}

		query.addCriteria(Criteria.where("cctvId").in(cctvIds));

		if ("DISCRETE".equals(params.get(0).get("job_time_type"))) {
			if (params.get(0).get("start_datetime2") != null && !"".equals(params.get(0).get("start_datetime2"))) {
				Criteria criteria = new Criteria();
				criteria.orOperator(
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
								.lte(params.get(0).get("end_datetime")),
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime2"))
								.lte(params.get(0).get("end_datetime2")));
				query.addCriteria(criteria);
			}
		} else {
			query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
					.lte(params.get(0).get("end_datetime")));
			query.addCriteria(Criteria.where("_id").lte(new ObjectId((String) params.get(0).get("start_id"))));
		}

		query.skip(subCount);
		query.limit(1);
		query.fields().include("_id");
		query.with(new Sort(Sort.Direction.DESC, "_id"));
		// 한방쿼리로 해결
		// db.getCollection('VAS_DETECTED_FACE_NOSQL').find().skip(3000).limit(1)

		List<String> startIdList = mongoTemplate.find(query, String.class, "VAS_DETECTED_FACE_NOSQL");
		return startIdList.get(0);

	}

	public List<DetectedFaceMatch> findDetectedFaces(List<HashMap<String, Object>> params, int subCount) {

		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("systemId").is(params.get(0).get("vms_id")));
		// query.addCriteria(Criteria.where("cctvId").is((String)params.get(0).get("cctv_id")));
		ArrayList<String> cctvIds = new ArrayList<String>();

		for (HashMap<String, Object> param : params) {
			cctvIds.add((String) param.get("cctv_id"));
		}

		query.addCriteria(Criteria.where("cctvId").in(cctvIds));

		if ("DISCRETE".equals(params.get(0).get("job_time_type"))) {
			if (params.get(0).get("start_datetime2") != null && !"".equals(params.get(0).get("start_datetime2"))) {
				Criteria criteria = new Criteria();
				criteria.orOperator(
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
								.lte(params.get(0).get("end_datetime")),
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime2"))
								.lte(params.get(0).get("end_datetime2")));
				query.addCriteria(criteria);
			} else {
				query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
						.lte(params.get(0).get("end_datetime")));
			}
		} else {
			query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
					.lte(params.get(0).get("end_datetime")));
			query.addCriteria(Criteria.where("_id").lte(new ObjectId((String) params.get(0).get("start_id"))));
			query.limit(subCount);
			query.with(new Sort(Sort.Direction.DESC, "_id"));
		}

		// 한방쿼리로 해결
		// db.getCollection('VAS_DETECTED_FACE_NOSQL').find().skip(3000).limit(1)
		logger.info("!!!!== findDetectedFaces == " + query.toString());

		return mongoTemplate.find(query, DetectedFaceMatch.class, "VAS_DETECTED_FACE_NOSQL");
	}

	public List<DetectedFaceMatch> findDiscretedDetectedFaces(List<HashMap<String, Object>> params, int subCount) {
		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("systemId").is(params.get(0).get("vms_id")));
		// query.addCriteria(Criteria.where("cctvId").is((String)params.get(0).get("cctv_id")));
		ArrayList<String> cctvIds = new ArrayList<String>();

		for (HashMap<String, Object> param : params) {
			cctvIds.add((String) param.get("cctv_id"));
		}

		query.addCriteria(Criteria.where("cctvId").in(cctvIds));

		if ("DISCRETE".equals(params.get(0).get("job_time_type"))) {
			if (params.get(0).get("start_datetime2") != null && !"".equals(params.get(0).get("start_datetime2"))) {
				Criteria criteria = new Criteria();
				criteria.orOperator(
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
								.lte(params.get(0).get("end_datetime")),
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime2"))
								.lte(params.get(0).get("end_datetime2")));
				query.addCriteria(criteria);
			}
		} else {
			query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
					.lte(params.get(0).get("end_datetime")));
			query.addCriteria(Criteria.where("_id").lt(new ObjectId((String) params.get(0).get("start_id"))));
		}

		query.limit(subCount);
		// 한방쿼리로 해결
		// db.getCollection('VAS_DETECTED_FACE_NOSQL').find().skip(3000).limit(1)
		logger.info("== findDetectedFaceIds == " + query.toString());

		return mongoTemplate.find(query, DetectedFaceMatch.class, "VAS_DETECTED_FACE_NOSQL");

	}

	public DetectedFaceMatch findDetectedFaceFirstId() {
		Query query = new Query();

		query.with(new Sort(Sort.Direction.DESC, "_id"));
		query.limit(1);

		DetectedFaceMatch firstNo = new DetectedFaceMatch();
		firstNo.set_id("ffffffffffffffffffffffff");
		// firstNo.set_id("000000000000000000000000");
		// return mongoTemplate.findOne(query, DetectedFaceMatch.class,
		// "VAS_DETECTED_FACE_NOSQL_");
		return firstNo;
	}
	public long countDetectedFaceByJobId(List<HashMap<String, Object>> params) {
		ArrayList<String> systemIds = new ArrayList<String>();
		ArrayList<String> cctvIds = new ArrayList<String>();

		Query query = new Query();
		for (HashMap<String, Object> hmap : params) {
			systemIds.add((String) hmap.get("vms_id"));
			cctvIds.add((String) hmap.get("cctv_id"));
		}

		// where 절
		query.addCriteria(Criteria.where("systemId").in(systemIds));
		query.addCriteria(Criteria.where("cctvId").in(cctvIds));
		query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
				.lte(params.get(0).get("end_datetime")));

		logger.info("Query : " + query.toString());

		return mongoTemplate.count(query, "VAS_DETECTED_FACE_NOSQL");

	}

	public List<DetectedFaceMatch> findAllConcernedFace(HashMap<String, Object> param, int pageCount, int pageLimit) {
		Query query = new Query();
		// where 절
		query.fields().include("feature");
		query.addCriteria(Criteria.where("isValid").is("Y"));
		query.addCriteria(Criteria.where("cctvId").is(param.get("cctv_id")));

		return mongoTemplate.find(query, DetectedFaceMatch.class, "VAS_CNCRN_PERSON_N_FACE_NOSQL");

	}

	public List<DetectedFaceMatch> findAllTest() {
		Query query = new Query();
		query.fields().include("feature");
		return mongoTemplate.find(query, DetectedFaceMatch.class, "VAS_CNCRN_PERSON_N_FACE_NOSQL");

	}

	// mongodb 에 있는 정보를 mssql 에 저장한다. (2016.11.07)
	public List<DetectedFaceInfo> findDetectedFaceNosqlInfo(String detectedFaceId) {
		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("detectedFaceId").is(detectedFaceId));

		query.limit(1);
		query.fields().include("systemId");
		query.fields().include("cctvId");
		query.fields().include("srvcType");
		query.fields().include("imgFile");
		query.fields().include("imgW");
		query.fields().include("imgH");
		query.fields().include("imgX");
		query.fields().include("imgY");
		query.fields().include("frmFile");
		query.fields().include("frmW");
		query.fields().include("frmH");
		query.fields().include("frmTime");

		logger.info("★★★★★★★★★★★★ " + query.toString());

		return mongoTemplate.find(query, DetectedFaceInfo.class, "VAS_DETECTED_FACE_NOSQL");
	}

	public List<DetectedFaceInfo> findDetectedFacesNosqlInfo(List<HashMap<String, Object>> params, int subCount) {
		Query query = new Query();
		// where 절
		query.addCriteria(Criteria.where("systemId").is(params.get(0).get("vms_id")));

		ArrayList<String> cctvIds = new ArrayList<String>();

		for (HashMap<String, Object> param : params) {
			cctvIds.add((String) param.get("cctv_id"));
		}

		query.addCriteria(Criteria.where("cctvId").in(cctvIds));

		if ("DISCRETE".equals(params.get(0).get("job_time_type"))) {
			if (params.get(0).get("start_datetime2") != null && !"".equals(params.get(0).get("start_datetime2"))) {
				Criteria criteria = new Criteria();
				criteria.orOperator(
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
								.lte(params.get(0).get("end_datetime")),
						Criteria.where("frmTime").gte(params.get(0).get("start_datetime2"))
								.lte(params.get(0).get("end_datetime2")));
				query.addCriteria(criteria);
			}
		} else {
			query.addCriteria(Criteria.where("frmTime").gte(params.get(0).get("start_datetime"))
					.lte(params.get(0).get("end_datetime")));
			query.addCriteria(Criteria.where("_id").lt(new ObjectId((String) params.get(0).get("start_id"))));
		}

		query.skip(subCount);
		query.limit(1);
		query.fields().include("_id");
		// 한방쿼리로 해결
		// db.getCollection('VAS_DETECTED_FACE_NOSQL').find().skip(3000).limit(1)
		logger.info("== findDetectedFacesNosqlInfo == " + query.toString());

		return mongoTemplate.find(query, DetectedFaceInfo.class, "VAS_DETECTED_FACE_NOSQL");
	}

}
