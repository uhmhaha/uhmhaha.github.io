package com.skcc.vas.frs.common.util.base;

/**
 * @author
 * @since 2015-09-14
 * @see javax.batch.runtime.BatchStatus
 * @see JobStatus
 */
public enum TaskUseStatus {
	IDLE, BUSY
}
