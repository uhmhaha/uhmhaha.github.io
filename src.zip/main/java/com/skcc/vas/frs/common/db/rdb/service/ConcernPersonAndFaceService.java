package com.skcc.vas.frs.common.db.rdb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.skcc.vas.frs.common.db.nosql.dao.ConcernPersonAndFaceDao;
import com.skcc.vas.frs.common.db.nosql.domain.NConcernPersonAndFace;

@Service("face.ConcernPersonAndFaceService")
public class ConcernPersonAndFaceService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ConcernPersonAndFaceDao concernPersonAndFaceDao;

	public NConcernPersonAndFace insertConcernPersonAndFace(NConcernPersonAndFace concernPersonAndFaceProfile)
			throws Exception {

		NConcernPersonAndFace concernPersonAndFaceItem = new NConcernPersonAndFace();

		concernPersonAndFaceItem.setPersonId(concernPersonAndFaceProfile.getPersonId());
		concernPersonAndFaceItem.setName(concernPersonAndFaceProfile.getName());
		concernPersonAndFaceItem.setGender(concernPersonAndFaceProfile.getGender());
		concernPersonAndFaceItem.setConcernType(concernPersonAndFaceProfile.getConcernType());
		concernPersonAndFaceItem.setIsValid(concernPersonAndFaceProfile.getIsValid());
		concernPersonAndFaceItem.setCpRemarks(concernPersonAndFaceProfile.getCfRemarks());
		concernPersonAndFaceItem.setLastUpdateBy(concernPersonAndFaceProfile.getLastUpdateBy());
		concernPersonAndFaceItem.setLastUpdateAt(concernPersonAndFaceProfile.getLastUpdateAt());
		concernPersonAndFaceItem.setBirthday(concernPersonAndFaceProfile.getBirthday());
		concernPersonAndFaceItem.setNationality(concernPersonAndFaceProfile.getNationality());
		concernPersonAndFaceItem.setPassportNo(concernPersonAndFaceProfile.getPassportNo());
		concernPersonAndFaceItem.setFirstName(concernPersonAndFaceProfile.getFirstName());
		concernPersonAndFaceItem.setMiddleName(concernPersonAndFaceProfile.getMiddleName());
		concernPersonAndFaceItem.setLastName(concernPersonAndFaceProfile.getLastName());
		concernPersonAndFaceItem.setFaceId(concernPersonAndFaceProfile.getfaceId());
		concernPersonAndFaceItem.setIsValidFace(concernPersonAndFaceProfile.getIsValidFace());
		concernPersonAndFaceItem.setImg(concernPersonAndFaceProfile.getImg());
		concernPersonAndFaceItem.setImgFormat(concernPersonAndFaceProfile.getImgFormat());
		concernPersonAndFaceItem.setImgW(concernPersonAndFaceProfile.getImgW());
		concernPersonAndFaceItem.setImgH(concernPersonAndFaceProfile.getImgH());
		concernPersonAndFaceItem.setFeature(concernPersonAndFaceProfile.getFeature());
		concernPersonAndFaceItem.setCfRemarks(concernPersonAndFaceProfile.getCfRemarks());
		concernPersonAndFaceItem.setLandmarks(concernPersonAndFaceProfile.getLandmarks());
		concernPersonAndFaceItem.setImgPath(concernPersonAndFaceProfile.getImgPath());

		concernPersonAndFaceDao.insert(concernPersonAndFaceItem);
		return concernPersonAndFaceItem;
	}

	public NConcernPersonAndFace updateConcernPersonAndFace(NConcernPersonAndFace concernPersonAndFaceProfile)
			throws Exception {

		NConcernPersonAndFace concernPersonAndFaceItem = new NConcernPersonAndFace();

		concernPersonAndFaceItem.setPersonId(concernPersonAndFaceProfile.getPersonId());
		concernPersonAndFaceItem.setName(concernPersonAndFaceProfile.getName());
		concernPersonAndFaceItem.setGender(concernPersonAndFaceProfile.getGender());
		concernPersonAndFaceItem.setConcernType(concernPersonAndFaceProfile.getConcernType());
		concernPersonAndFaceItem.setIsValid(concernPersonAndFaceProfile.getIsValid());
		concernPersonAndFaceItem.setCpRemarks(concernPersonAndFaceProfile.getCfRemarks());
		concernPersonAndFaceItem.setLastUpdateBy(concernPersonAndFaceProfile.getLastUpdateBy());
		concernPersonAndFaceItem.setLastUpdateAt(concernPersonAndFaceProfile.getLastUpdateAt());
		concernPersonAndFaceItem.setBirthday(concernPersonAndFaceProfile.getBirthday());
		concernPersonAndFaceItem.setNationality(concernPersonAndFaceProfile.getNationality());
		concernPersonAndFaceItem.setPassportNo(concernPersonAndFaceProfile.getPassportNo());
		concernPersonAndFaceItem.setFirstName(concernPersonAndFaceProfile.getFirstName());
		concernPersonAndFaceItem.setMiddleName(concernPersonAndFaceProfile.getMiddleName());
		concernPersonAndFaceItem.setLastName(concernPersonAndFaceProfile.getLastName());
		concernPersonAndFaceItem.setFaceId(concernPersonAndFaceProfile.getfaceId());
		concernPersonAndFaceItem.setIsValidFace(concernPersonAndFaceProfile.getIsValidFace());
		concernPersonAndFaceItem.setImg(new Binary(concernPersonAndFaceProfile.getByteImage()));
		concernPersonAndFaceItem.setImgFormat(concernPersonAndFaceProfile.getImgFormat());
		concernPersonAndFaceItem.setImgW(concernPersonAndFaceProfile.getImgW());
		concernPersonAndFaceItem.setImgH(concernPersonAndFaceProfile.getImgH());
		concernPersonAndFaceItem.setFeature(new Binary(concernPersonAndFaceProfile.getByteFeature()));
		concernPersonAndFaceItem.setCfRemarks(concernPersonAndFaceProfile.getCfRemarks());
		concernPersonAndFaceItem.setLandmarks(concernPersonAndFaceProfile.getLandmarks());
		concernPersonAndFaceItem.setImgPath(concernPersonAndFaceProfile.getImgPath());

		Query query = new Query();
		query.addCriteria(Criteria.where("faceId").exists(false));// 만족하면
																	// update/
																	// 있으면
																	// insert
		query.addCriteria(Criteria.where("personId").is(concernPersonAndFaceItem.getPersonId()));// 만족하면
																									// update/
																									// 있으면
																									// insert

		Update update = new Update();

		update.set("personId", concernPersonAndFaceItem.getPersonId());
		update.set("name", concernPersonAndFaceItem.getName());
		update.set("genger", concernPersonAndFaceItem.getGender());
		update.set("concernType", concernPersonAndFaceItem.getConcernType());
		update.set("isValid", concernPersonAndFaceItem.getIsValid());
		update.set("lastUpdateAt", concernPersonAndFaceItem.getLastUpdateAt());
		update.set("firstName", concernPersonAndFaceItem.getFirstName());
		update.set("lastName", concernPersonAndFaceItem.getLastName());
		update.set("nationality", concernPersonAndFaceItem.getNationality());

		update.set("img", concernPersonAndFaceItem.getImg());
		update.set("imgFormat", concernPersonAndFaceItem.getImgFormat());
		update.set("feature", concernPersonAndFaceItem.getFeature());
		update.set("landmarks", concernPersonAndFaceItem.getLandmarks());
		update.set("imgPath", concernPersonAndFaceItem.getImgPath());
		update.set("faceId", concernPersonAndFaceItem.getfaceId());
		update.set("isValidFace", concernPersonAndFaceItem.getIsValidFace());

		concernPersonAndFaceDao.update(query, update);

		return concernPersonAndFaceItem;
	}

	public List<NConcernPersonAndFace> selectConcernPersonAndFaceListByCondition(Map<String, Object> input)
			throws Exception {

		String pTargetId = (String) input.get("TARGET_ID");
		String[] targetIds;
		List<String> targetIdList = new ArrayList<String>();

		if (pTargetId != null) {
			targetIds = pTargetId.split(",");

			for (int i = 0; i < targetIds.length; i++) {
				targetIdList.add(targetIds[i]);
			}
		}

		String pWantedType = (String) input.get("WANTED_TYPE");
		String[] wantedTypes;
		List<String> wantedTypeList = new ArrayList<String>();

		if (pWantedType != null) {
			wantedTypes = pWantedType.split(",");

			for (int i = 0; i < wantedTypes.length; i++) {
				wantedTypeList.add(wantedTypes[i]);
			}
		}

		if (targetIdList.size() == 0 && wantedTypeList.size() == 0) {
			return null;
		}

		Query query = new Query();

		if (targetIdList.size() > 0) {
			query.addCriteria(Criteria.where("personId").in(targetIdList));
		}

		if (wantedTypeList.size() > 0) {
			query.addCriteria(Criteria.where("concernType").in(wantedTypeList));
		}

		List<NConcernPersonAndFace> findConcernPersonAndFaceItemList = null;

		System.out.println("0000000000000000000000000000000000000000000000000001");
		long t1 = System.currentTimeMillis();
		System.out
				.println("::::::::::::::::::::::::::::::::::::::::::::::::::::" + concernPersonAndFaceDao.count(query));
		findConcernPersonAndFaceItemList = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query);

		long t2 = System.currentTimeMillis();

		String x = String.valueOf(t2 - t1);
		String y = String.valueOf((t2 - t1) / 1000);
		System.out.println("\n77777777777777777777777777777777777 y : " + y + "\t sec");
		System.out.println("0000000000000000000000000000000000000000000000000002");

		return findConcernPersonAndFaceItemList;

	}

	public NConcernPersonAndFace selectConcernPersonAndFaceByCncrnFaceId(String cncrnFaceId) throws Exception {
		NConcernPersonAndFace nConcernPersonAndFace = null;

		Query query = new Query();
		query.addCriteria(Criteria.where("faceId").is(cncrnFaceId));

		nConcernPersonAndFace = (NConcernPersonAndFace) concernPersonAndFaceDao.findOne(query);
		return nConcernPersonAndFace;
	}

	public List<NConcernPersonAndFace> selectRecentOne() throws Exception {
		List<NConcernPersonAndFace> nConcernPersonAndFaces = null;

		// Query query = new Query();
		// query.addCriteria(Criteria.where("personId").is(personId));
		//// query.with(new Sort(Sort.Direction.DESC, "frmTime"));
		//// query.limit(1);
		Query query = new Query();
		query.addCriteria(Criteria.where("personId").is("84"));
		query.with(new Sort(Sort.Direction.DESC, "lastUpdateAt"));
		query.fields().exclude("faceId");
		query.limit(1);

		nConcernPersonAndFaces = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query);
		logger.debug("????????????????????????????????????????????????????");
		return nConcernPersonAndFaces;

	}

	public void removePerson(String personId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("personId").is(personId));// 만족하면
																	// update/
																	// 있으면
																	// insert

		Update update = new Update();
		update.set("isValid", "N");
		update.set("isValidFace", "N");

		try {
			concernPersonAndFaceDao.update(query, update);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void removeFaces(String[] faceId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("faceId").in(faceId));// 만족하면 update/
																// 있으면 insert

		Update update = new Update();
		update.set("isValidFace", "N");

		try {
			concernPersonAndFaceDao.update(query, update);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
