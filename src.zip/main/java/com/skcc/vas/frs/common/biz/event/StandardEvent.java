package com.skcc.vas.frs.common.biz.event;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * @author
 * @since 2016-07-20
 *
 */
@Immutable
public class StandardEvent implements Event {

	private final EventType type;

	public StandardEvent(@Nonnull EventType type) {
		this.type = type;
	}

	@Override
	public EventType getType() {
		return this.type;
	}

}
