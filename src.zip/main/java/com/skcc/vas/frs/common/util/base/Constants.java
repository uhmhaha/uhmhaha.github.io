package com.skcc.vas.frs.common.util.base;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Contains all constants on which VAS module depends or uses.
 *
 * @author
 * @since 2015-04-24
 */
public class Constants {

	/**
	 * Contains constants corresponding Environment Variables on which VAS
	 * modules depends.
	 *
	 * @author
	 */
	public static enum EnvVariable {

		// @TODO Update application and unit test launcher and remove deprecated
		// ones

		/**
		 *
		 */
		VAS_HOME,

		/**
		 *
		 */
		VAS_DATA_DIR,

		/**
		 *
		 */
		VAS_LOG_DIR,

		/**
		 * Directory where thumbnail files for the found events are stored. The
		 * value should not end with directory separator('/' or '\' depending on
		 * OS).
		 */
		VAS_THUMBNAIL_DIR,

		/**
		 * The value should be 'true' or 'false'(default)
		 */
		VAS_SHOWS_FRAMES,

		/**
		 * The value should be 'true' or 'false'(default)
		 */
		SKT_VA_SHOWS_FRAMES,

		/**
		 * The value should be 'true' or 'false'(default)
		 */
		SKT_VA_SHOWS_EVENTED_FRAMES,

		/**
		 * Full file name of the log4cxx configuration file in properties
		 * format.
		 *
		 * @see #SKT_VA_LOG4CXX_XML_FILE
		 */
		SKT_VA_LOG4CXX_PROPS_FILE,

		/**
		 * Full file name of the log4cxx configuration file in XML format.
		 *
		 * If both of {@code SKT_VA_LOG4CXX_PROPS_FILE} and
		 * {@code SKT_VA_LOG4CXX_XML_FILE} are specified,
		 * {@code SKT_VA_LOG4CXX_XML_FILE} would be ignored.
		 *
		 * @see #SKT_VA_LOG4CXX_PROPS_FILE
		 */
		SKT_VA_LOG4CXX_XML_FILE,

		/**
		 *
		 */
		SKT_VA_LOG4CXX_ROOT_LEVEL,

		/**
		 * The value should be 'true' or 'false'(default)
		 */
		TRIUMI_SHOWS_FRAMES,

		/**
		 * Full file name of the log4cxx configuration file in properties
		 * format.
		 *
		 * @see #TRIUMI_LOG4CXX_XML_FILE
		 */
		TRIUMI_LOG4CXX_PROPS_FILE,

		/**
		 * Full file name of the log4cxx configuration file in XML format.
		 *
		 * If both of {@code TRIUMI_LOG4CXX_PROPS_FILE} and
		 * {@code TRIUMI_LOG4CXX_XML_FILE} are specified,
		 * {@code TRIUMI_LOG4CXX_XML_FILE} would be ignored.
		 *
		 * @see #TRIUMI_LOG4CXX_PROPS_FILE
		 */
		TRIUMI_LOG4CXX_XML_FILE,

		/**
		 *
		 */
		TRIUMI_LOG4CXX_ROOT_LEVEL,

		@Deprecated
		TRIUMI_VIDEOS_DIR,

		/**
		 * License key to enable the HBInno's face recognition library at
		 * run-time.
		 * <p>
		 * Usually the value is in
		 * "[0-9A-E]{5}(\-[0-9A-E]{5}){6}\([0-9A-E]{2}\)" pattern
		 *
		 */
		HBINNO_LICENSE_KEY;

	}

	/**
	 * Contains constants corresponding System Properties on which VAS modules
	 * depends
	 */
	public static enum SystemProperty {

		// key, default, type, validator, ...

		LOG_FILE_DIR, LOG_FILE_NAME, LOG_ROOT_LEVEL, LOG_SPRING_LEVEL, LOG_MYBATIS_LEVEL, JNI_LIB_NAME_SKT_VA(
				"va_skt_adapter_jni"), JNI_LIB_NAME_TRIUMI(
						"vms_triumi_adapter_jni.dll"), TRIUMI_DIRECTACCESS_FILEPREPARER_STARTS_ASYNC(
								"vas.triumiDirectAccessFilePreparer.startsAsync", "false"),

		/**
		 * The value for this system property should be classpath relative.
		 * <p>
		 * The file can be located in JAR file.
		 */
		SPRING_CONFIG_LOCATION("com/skcc/nexcore/vas/spring.xml"),

		/**
		 * The classpath relative location of Spring configuration for
		 * multithreaded on-demand service.
		 */
		VAS_MULTITHREAD_SPRING_CONF_LOC("vas.multithread.springConfLoc", "com/skcc/nexcore/vas/multithread/spring.xml"),

		/**
		 * The classpath relative location of Spring configuration for
		 * stand-alone live face server.
		 */
		VAS_FACE_SPRING_CONF_LOC("vas.face.springConfLoc", "com/skcc/nexcore/vas/face/spring.xml");

		private final String key;

		private final String defaultValue;

		private SystemProperty() {
			this(null);
		}

		/**
		 * @param value
		 *            default value for this system property
		 */
		private SystemProperty(@Nullable String value) {
			this.key = StringUtils.replace(StringUtils.lowerCase(this.name()), "_", ".");
			this.defaultValue = value;
		}

		private SystemProperty(@NotBlank String key, @Nullable String value) {
			Validate.isTrue(key != null && key.trim().length() > 0, "The 'key' is invalid.");

			this.key = key;
			this.defaultValue = value;
		}

		/**
		 * Gets the key of the system property.
		 * <p>
		 * The key is all in lower-case and '_'(undersoce) in the enum name is
		 * replaced by '.'(dot). For example, the key for the enum
		 * {@code LOG_FILE_DIR} is {@code log.file.dir}
		 *
		 * @return
		 */
		@Nonnull
		public String getKey() {
			return this.key;
		}

		/**
		 * @return default value for this system property or {@code null} if
		 *         there's no default value
		 */
		@Nullable
		public String getDefaultValue() {
			return this.defaultValue;
		}

	}
}
