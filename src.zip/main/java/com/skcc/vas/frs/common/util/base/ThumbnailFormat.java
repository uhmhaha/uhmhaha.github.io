package com.skcc.vas.frs.common.util.base;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import javax.validation.constraints.Min;

/**
 *
 * @author
 * @since 2015-11-30
 *
 */
@Immutable
public class ThumbnailFormat {

	public final static int THUMBNAIL_WIDTH_DEFAULT = 1920;

	public final static int THUMBNAIL_HEIGHT_DEFAULT = 1080;

	@Min(1)
	private final int width;

	@Min(1)
	private final int height;

	private final boolean keepsRatio;

	private final boolean shrinksOnly;

	private final ImageFormat imageFormat;

	/**
	 * The format implies <strong>keep ratio</strong> and <strong>shrink
	 * only</strong>
	 *
	 */
	public ThumbnailFormat(@Min(1) int width, @Min(1) int height, @Nonnull ImageFormat format) {
		this.width = width;
		this.height = height;
		this.keepsRatio = true;
		this.shrinksOnly = true;
		this.imageFormat = format;
	}

	/**
	 * Creates the format with specified width and height.
	 * <p>
	 * The format implies <strong>keep ratio</strong> and <strong>shrink
	 * only</strong> in <strong>JPEG</strong> image.
	 *
	 * @param width
	 * @param height
	 */
	public ThumbnailFormat(@Min(1) int width, @Min(1) int height) {
		this(width, height, ImageFormat.JPEG);
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public boolean keepsRatio() {
		return keepsRatio;
	}

	public boolean shrinksOnly() {
		return shrinksOnly;
	}

	public ImageFormat getImageFormat() {
		return imageFormat;
	}
}
