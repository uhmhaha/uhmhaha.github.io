package com.skcc.vas.frs.common.util.base;

import java.util.List;

/**
 * @author
 * @since 2016-07-20
 *
 * @param <T>
 */
public interface Roi<T extends Number> {

	List<Point<T>> getPoints();

}
