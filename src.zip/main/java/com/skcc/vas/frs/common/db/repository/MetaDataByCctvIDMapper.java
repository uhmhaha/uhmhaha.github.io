package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.nosql.domain.MetaDataByCctvID;

@Repository(value = "metaDataByCctvIDMapper")
@ParametersAreNonnullByDefault
public interface MetaDataByCctvIDMapper {

	MetaDataByCctvID selectMetaDataByCctvID(@Param("cctvId") String cctvId);
}
