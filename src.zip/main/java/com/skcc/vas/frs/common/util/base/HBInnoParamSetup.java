package com.skcc.vas.frs.common.util.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;

public class HBInnoParamSetup {

	private final Logger logger = LoggerFactory.getLogger(HBInnoParamSetup.class);
	private HbInnoParameter hbInnoParam;
	private VasConfigService vasConfig;

	public HBInnoParamSetup(HbInnoParameter hbInnoParam, VasConfigService vasConfig) {
		this.hbInnoParam = hbInnoParam;
		this.vasConfig = vasConfig;
	}

	private void init() {

		// set license
		String licenseKey = vasConfig.getConfigValByName("vas.licenseKey");
		if (licenseKey == null) {
			logger.error("++ HBinno license key is [null]. please check VAS_CONFIG_HBINNO_LICENSE table");
			throw new RuntimeException("HBinno license key is [null]. please check VAS_CONFIG_HBINNO_LICENSE table");
		}
		else
		{
			logger.info("++ HBinno license key is " + licenseKey);
		}

		hbInnoParam.setLicenseKey(licenseKey);
	}

}
