package com.skcc.vas.frs.common.db.service;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.skcc.vas.frs.common.biz.event.VideoEventType;
import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Cctv;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Param;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Point;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Roi;
import com.skcc.vas.frs.common.db.repository.SearchMasterMapper;
import com.skcc.vas.frs.common.util.base.JobStatus;
import com.skcc.vas.frs.ondemand.vms.db.rdb.repository.SearchDetailMapper;
import com.skcc.vas.frs.ondemand.vms.db.rdb.repository.SearchRoiMapper;
import com.skcc.vas.frs.ondemand.vms.db.rdb.repository.SearchRoiParamMapper;
import com.skcc.vas.frs.ondemand.vms.db.rdb.repository.SearchRoiPointMapper;

/**
 * Deals with search job related data in database.
 * <p>
 * Finds, adds, removes or modifies the search job data in database.
 *
 * @author
 * @since 2015-09-01
 */
@ThreadSafe
public class SearchDataManager {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private SearchMasterMapper masterMapper;

	private SearchDetailMapper detailMapper;

	private SearchRoiMapper roiMapper;

	private SearchRoiPointMapper roiPointMapper;

	private SearchRoiParamMapper roiParamMapper;

	public SearchMasterMapper getSearchMasterMapper() {
		return this.masterMapper;
	}

	public SearchDetailMapper getSearchDetailMapper() {
		return this.detailMapper;
	}

	public SearchRoiMapper getSearchRoiMapper() {
		return this.roiMapper;
	}

	public SearchRoiPointMapper getSearchRoiPointMapper() {
		return this.roiPointMapper;
	}

	public SearchRoiParamMapper getSearchRoiParamMapper() {
		return this.roiParamMapper;
	}

	public SearchDataManager(@Nonnull SearchMasterMapper masterMapper, @Nonnull SearchDetailMapper detailMapper,
			@Nonnull SearchRoiMapper roiMapper, @Nonnull SearchRoiPointMapper roiPointMapper,
			@Nonnull SearchRoiParamMapper roiParamMapper) {
		Validate.isTrue(masterMapper != null, "SearchMasterMapper instance should be provided.");
		Validate.isTrue(detailMapper != null, "SearchDetailMapper instance should be provided.");
		Validate.isTrue(roiMapper != null, "SearchRoiMapper instance should be provided.");
		Validate.isTrue(roiPointMapper != null, "SearchRoiPointMapper instance should be provided.");
		Validate.isTrue(roiParamMapper != null, "SearchRoiParamMapper instance should be provided.");

		this.masterMapper = masterMapper;
		this.detailMapper = detailMapper;
		this.roiMapper = roiMapper;
		this.roiPointMapper = roiPointMapper;
		this.roiParamMapper = roiParamMapper;
	}

	/**
	 * The type of ROI parameter(if any) is {@code java.lang.Float}
	 * <p>
	 * Note that the event type defined at job level would be propagated into
	 * each ROI inside the job, so that the processors like search task
	 * processor would only need task level data.
	 *
	 * @param jobId
	 * @return
	 */
	@Nullable
	public SearchRequest findSearchRequest(String jobId) {

		SearchRequest req = this.masterMapper.selectSearchMaster(jobId);
		List<Cctv> cctvs = this.detailMapper.selectSearchDetailsByJob(jobId);

		List<Roi> rois = null;
		List<Point> points = null;
		List<Param> params = null;
		for (Cctv cctv : cctvs) {
			req.addCctv(cctv);
			rois = this.roiMapper.selectSearchRoisByCctv(jobId, cctv.getSystemId(), cctv.getId());
			for (Roi roi : rois) {

				// @TODO Enhancement is necessary to cover non-video event type
				// propagate the event type into each roi.
				roi.setEventType(VideoEventType.valueOf(req.getEventType()));

				cctv.addRoi(roi);
				points = this.roiPointMapper.selectSearchRoiPointsByRoi(jobId, cctv.getSystemId(), cctv.getId(),
						roi.getNo());
				for (Point pt : points) {
					roi.addPoint(pt);
				}
				params = this.roiParamMapper.selectSearchRoiParamsByRoi(jobId, cctv.getSystemId(), cctv.getId(),
						roi.getNo());
				for (Param param : params) {
					param.setValue(Float.valueOf(param.getValue().toString()));
				}

				// @TODO This is just temporary code. The default ROI parameter
				// should be
				// specified and stored at client or session layer.
				if (params.isEmpty()) {
					params = SearchRequest.getDefaultParams(VideoEventType.valueOf(req.getEventType()));
				}
				for (Param param : params) {
					roi.addParam(param);
				}
			}
		}

		if (req != null) {
			logger.info("A search request[id: {}] is found.", jobId);
		} else {
			logger.info("Fail to find search request[id: {}].", jobId);
		}

		return req;
	}

	// @TODO Need a test of transaction roll-back
	@Transactional
	public boolean addSearchRequest(@Nonnull SearchRequest req) {

		int cnt = this.masterMapper.insertSearchMaster(req);

		for (Cctv cctv : req.getCctvs()) {
			this.detailMapper.insertSearchDetail(req.getId(), cctv);

			for (Roi roi : cctv.getRois()) {
				this.roiMapper.insertSearchRoi(req.getId(), cctv.getSystemId(), cctv.getId(), roi);

				for (Param param : roi.getParams()) {
					this.roiParamMapper.insertSearchRoiParam(req.getId(), cctv.getSystemId(), cctv.getId(), roi.getNo(),
							param);
				}

				for (Point pt : roi.getPoints()) {
					this.roiPointMapper.insertSearchRoiPoint(req.getId(), cctv.getSystemId(), cctv.getId(), roi.getNo(),
							pt);
				}
			}
		}

		if (cnt == 1) {
			logger.info("A search request[id: {}] is added successfully.", req.getId());
		} else {
			logger.warn("Fail to add search request[id: {}].", req.getId());
		}

		return (cnt == 1);
	}

	/**
	 * Updates the status of specified job to {@code COMPLETED}.
	 *
	 * Returns {@code true} if the update is successful or the job is already in
	 * COMPLETED status.
	 *
	 * @param jobId
	 * @return
	 */
	@Transactional
	public boolean setSearchCompleted(@Nonnull String jobId) {

		int cnt = this.masterMapper.setSearchStatus(jobId, JobStatus.COMPLETED);

		// @TODO The update statement returns 1, in case of no change is applied
		// to the specified row.
		// Need to check, this is general agreement or depends on database
		// products.

		if (cnt > 1) {
			logger.warn(
					"The update statement for a specific job seems to change more than one rows in database which is never expected.");
		}

		// Actually cnt == 1 is the most normal result and cnt > 1 is abnoraml
		// and unknown result.
		return (cnt > 0) ? true : false;
	}

	/**
	 * Updates the status of specified job to {@code FAIL}.
	 *
	 * Returns {@code true} if the update is successful or the job is already in
	 * FAIL status.
	 *
	 * @param jobId
	 * @return
	 */
	@Transactional
	public boolean setSearchFail(@Nonnull String jobId) {

		int cnt = this.masterMapper.setSearchStatus(jobId, JobStatus.FAIL);
		if (cnt > 1) {
			logger.warn(
					"The update statement for a specific job seems to change more than one rows in database which is never expected.");
		}

		return (cnt > 0) ? true : false;
	}

}
