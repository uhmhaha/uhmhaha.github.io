package com.skcc.vas.frs.common.util.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

//@Service("springApplicationContext")
public class SpringApplicationContext implements ApplicationContextAware{
	
	private final static Logger logger = LoggerFactory.getLogger(SpringApplicationContext.class);
	
	private static ApplicationContext context; 
	
	public SpringApplicationContext() { 
		logger.info("init SpringApplicationContext"); 
	} 
	
	public void setApplicationContext(ApplicationContext context) throws BeansException { 
		this.context = context; 
	} 
	
	public static Object getBean(String beanName) { 
		return context.getBean(beanName); 
	} 
	
	public static <T> T getBean(String beanName, Class<T> requiredType) { 
		return context.getBean(beanName, requiredType); 
	}
}
