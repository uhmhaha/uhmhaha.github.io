package com.skcc.vas.frs.common.db.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.rdb.domain.DetectedRoi;

/**
 * @author Suhyoung kim
 * @since 2016. 9. 6.
 *
 */
@Repository("face.CctvServiceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface CctvServiceMapper {

	List<DetectedRoi> selectDetectedRoiList(@Param("cctvId") String cctvId);

	int insertCctvServiceStart(@Param("systemId") String systemId, @Param("cctvId") String cctvId,
			@Param("srvcType") String srvcType);

	int updateCctvServiceEnd(@Param("cctvId") String cctvId);
}
