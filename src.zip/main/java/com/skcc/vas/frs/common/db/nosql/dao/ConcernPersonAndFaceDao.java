package com.skcc.vas.frs.common.db.nosql.dao;

import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.nosql.domain.NConcernPersonAndFace;

@Repository
public class ConcernPersonAndFaceDao extends GenericMongoDao {
	public ConcernPersonAndFaceDao() {
		collectionName = "VAS_CNCRN_PERSON_N_FACE_NOSQL";
		cls = NConcernPersonAndFace.class;
	}
}
