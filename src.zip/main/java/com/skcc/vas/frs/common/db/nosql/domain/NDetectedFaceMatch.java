package com.skcc.vas.frs.common.db.nosql.domain;

import org.bson.types.Binary;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "VAS_DETECTED_FACE_N_MATCH_NOSQL")
public class NDetectedFaceMatch {

	private String detectedFaceId;

	private String systemId;

	private String cctvId;

	private String srvcType;

	private String imgFile;

	private int imgW;

	private int imgH;

	private int imgX;

	private int imgY;

	private Binary feature;

	private String landmarks;

	private String frmFile;

	private int frmW;

	private int frmH;

	private String frmTime;

	private String lastUpdateBy;

	private String lastUpdateAt;

	private String detectedDate;

	private String cncrnFaceId;

	private int score;

	private int rank;

	private String lastUpdateMatchBy;

	private String lastUpdateMatchAt;

	private String resultType;

	public String getDetectedFaceId() {
		return detectedFaceId;
	}

	public void setDetectedFaceId(String detectedFaceId) {
		this.detectedFaceId = detectedFaceId;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getCctvId() {
		return cctvId;
	}

	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}

	public String getSrvcType() {
		return srvcType;
	}

	public void setSrvcType(String srvcType) {
		this.srvcType = srvcType;
	}

	public String getImgFile() {
		return imgFile;
	}

	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}

	public int getImgW() {
		return imgW;
	}

	public void setImgW(int imgW) {
		this.imgW = imgW;
	}

	public int getImgH() {
		return imgH;
	}

	public void setImgH(int imgH) {
		this.imgH = imgH;
	}

	public int getImgX() {
		return imgX;
	}

	public void setImgX(int imgX) {
		this.imgX = imgX;
	}

	public int getImgY() {
		return imgY;
	}

	public void setImgY(int imgY) {
		this.imgY = imgY;
	}

	public Binary getFeature() {
		return feature;
	}

	public void setFeature(Binary feature) {
		this.feature = feature;
	}

	public String getLandmarks() {
		return landmarks;
	}

	public void setLandmarks(String landmarks) {
		this.landmarks = landmarks;
	}

	public String getFrmFile() {
		return frmFile;
	}

	public void setFrmFile(String frmFile) {
		this.frmFile = frmFile;
	}

	public int getFrmW() {
		return frmW;
	}

	public void setFrmW(int frmW) {
		this.frmW = frmW;
	}

	public int getFrmH() {
		return frmH;
	}

	public void setFrmH(int frmH) {
		this.frmH = frmH;
	}

	public String getFrmTime() {
		return frmTime;
	}

	public void setFrmTime(String frmTime) {
		this.frmTime = frmTime;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getLastUpdateAt() {
		return lastUpdateAt;
	}

	public void setLastUpdateAt(String lastUpdateAt) {
		this.lastUpdateAt = lastUpdateAt;
	}

	public String getDetectedDate() {
		return detectedDate;
	}

	public void setDetectedDate(String detectedDate) {
		this.detectedDate = detectedDate;
	}

	public String getCncrnFaceId() {
		return cncrnFaceId;
	}

	public void setCncrnFaceId(String cncrnFaceId) {
		this.cncrnFaceId = cncrnFaceId;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getLastUpdateMatchBy() {
		return lastUpdateMatchBy;
	}

	public void setLastUpdateMatchBy(String lastUpdateMatchBy) {
		this.lastUpdateMatchBy = lastUpdateMatchBy;
	}

	public String getLastUpdateMatchAt() {
		return lastUpdateMatchAt;
	}

	public void setLastUpdateMatchAt(String lastUpdateMatchAt) {
		this.lastUpdateMatchAt = lastUpdateMatchAt;
	}

	public String getResultType() {
		return resultType;
	}

	public void setResultType(String resultType) {
		this.resultType = resultType;
	}

}
