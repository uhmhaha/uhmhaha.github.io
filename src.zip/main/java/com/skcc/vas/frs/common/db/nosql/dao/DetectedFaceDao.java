package com.skcc.vas.frs.common.db.nosql.dao;

import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFace;

@Repository
public class DetectedFaceDao extends GenericMongoDao {

	public DetectedFaceDao() {
		collectionName = "VAS_DETECTED_FACE_NOSQL";
		cls = NDetectedFace.class;
	}
}
