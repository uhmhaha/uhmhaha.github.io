package com.skcc.vas.frs.common.util.base;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.util.base.Constants.SystemProperty;

/**
 * Provides the most basic utility functions.
 *
 * @author
 * @since
 */
public class BaseUtils {

	private final static Logger logger = LoggerFactory.getLogger(BaseUtils.class);

	private final static FastDateFormat year2DayFormat = FastDateFormat.getInstance("yyyyMMdd");

	// @TODO(Done) Need more consideration on time-zone -> new java.util.Date()
	// reflects user.timezone system variable.
	private final static FastDateFormat year2MinFormat = FastDateFormat.getInstance("yyyyMMddHHmm");

	private final static FastDateFormat year2SecFormat = FastDateFormat.getInstance("yyyyMMddHHmmss");

	private final static FastDateFormat year2MillisecFormat = FastDateFormat.getInstance("yyyyMMddHHmmssSSS");

	/**
	 * Make the current console wait for user to press any key.
	 * <p>
	 * Block the console without any polling, so this method doesn't threaten
	 * performance.
	 *
	 * @since 1.0
	 */
	public final static void waitKeyPress() {
		System.out.println("Press [Enter] key to end this test method(testSetStreamHandler1).");
		int cnt;
		try {
			while ((cnt = System.in.available()) < 1) {
				Thread.currentThread().sleep(500);
			}
			while (cnt-- > 0)
				System.in.read();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * The classpath relative location of Spring configuration.
	 *
	 * @return
	 */
	public final static String getSpringConfigLocation() {
		String key = SystemProperty.SPRING_CONFIG_LOCATION.getKey();

		String value = System.getProperty(key);
		if (value == null)
			value = SystemProperty.SPRING_CONFIG_LOCATION.getDefaultValue();

		return value;
	}

	/**
	 * Splits the specified interval into sub-intervals using the specified
	 * unit.
	 * <p>
	 * Returns the sub-intervals.
	 *
	 * @param start
	 *            the start of interval to split in 'yyyyMMddHHmm' format
	 * @param end
	 *            the end of interval to split in 'yyyyMMddHHmm' format
	 * @param unit
	 *            duration in minutes for sub-intervals.
	 * @return the list of sub-intervals in forms of
	 *         {@code Pair<String start, String end>}
	 */
	@Nonnull
	public final static List<Pair<String, String>> splitInterval(@Pattern(regexp = "[1-9][0-9]{11}") String start,
			@Pattern(regexp = "[1-9][0-9]{11}") String end, @Min(1) int unit) {
		Validate.isTrue(start != null, "The start of interval should be specified.");
		Validate.isTrue(end != null, "The end of interval should be specified.");
		Validate.isTrue(unit > 0, "The duration for sub-interval should be positive.");

		Date from = validateYear2MinString(start);
		Date to = validateYear2MinString(end);

		Validate.isTrue(from != null && to != null,
				"The specified start(" + start + ") or end(" + end + ") is NOT strictly in 'yyyyMMddHHmm' format");
		Validate.isTrue(ObjectUtils.compare(to, from) >= 0,
				"The end(" + end + ") of interval should be equal or greater than the start(" + start + ").");

		final List<Pair<String, String>> subs = new ArrayList<Pair<String, String>>();
		Date cusor0 = from;
		Date cusor1 = cusor0;

		while (true) {
			cusor1 = DateUtils.addMinutes(cusor1, unit);
			if (cusor1.before(to)) {
				subs.add(Pair.of(year2MinFormat.format(cusor0), year2MinFormat.format(cusor1)));
				cusor0 = cusor1;
			} else { // at the last sub-interval
				subs.add(Pair.of(year2MinFormat.format(cusor0), end));
				break;
			}
		}

		return subs;
	}

	public static List<String> fromToDateList(String strStartDate, String strEndDate) {
		List<String> dateList = new ArrayList<String>();
		DateFormat formatter = new SimpleDateFormat("yyyyMMdd"); // 2016093009

		try {
			List<Date> dates = new ArrayList<Date>();

			Date startDate = (Date) formatter.parse(strStartDate);
			Date endDate = (Date) formatter.parse(strEndDate);

			long interval = 24 * 1000 * 60 * 60; // 1 hour in millis
			long endTime = endDate.getTime();
			long curTime = startDate.getTime();

			while (curTime <= endTime) {
				dates.add(new Date(curTime));
				curTime += interval;
			}

			for (int i = 0; i < dates.size(); i++) {
				Date lDate = (Date) dates.get(i);
				String ds = formatter.format(lDate);
				dateList.add(ds);
			}

		} catch (Exception ex) {
			return null;
		}

		return dateList;
	}

	/**
	 * Validate the specified string is in 'yyyyMMddHHmm' format and convert it
	 * to {@link java.util.Date} object if valid.
	 * <p>
	 * Only 12 digit string that match 'yyyyMMddHHmm' are said to be valid. No
	 * implicit trimming of white-spaces around the string or conversion inside
	 * string are applied.
	 * <P>
	 * For example, strings such as '197111231200', '000011231200',
	 * '000111231200', '001011231200', and '010011231200' are to be valid, but
	 * strings such as ' 197111231200', '197111231200 ', '1971112312 ' and '
	 * 7111231200' are to be invalid.
	 * <p>
	 * Note that this method is absolutely exception free except errors.
	 *
	 * @param str
	 *            the string to validate
	 * @return the parsed {@code Data} object if the string is in 'yyyyMMddHHmm'
	 *         format, or {@code null} otherwise
	 */
	@Nullable
	public final static Date validateYear2MinString(@Pattern(regexp = "[0-9]{12}") String str) {
		Date d = null;

		if (str != null && str.trim().length() == 12) {
			try {
				d = DateUtils.parseDateStrictly(str, "yyyyMMddHHmm");
			} catch (Exception ex) {
				d = null;
			}
		} else {
			d = null;
		}

		return d;
	}

	/**
	 * Formats the specified date into 'yyyyMMdd'(from year to day) format
	 * string.
	 *
	 * @param d
	 *            date object to format
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified date is {@code null}
	 */
	@Nonnull
	public final static String formatToYear2DayString(@Nonnull Date d) {
		Validate.isTrue(d != null, "The specified date should NOT be null.");

		return year2DayFormat.format(d);
	}

	/**
	 * Formats the specified date into 'yyyyMMddHHmm'(from year to minute)
	 * format string.
	 *
	 * @param d
	 *            date object to format
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified date is {@code null}
	 */
	@Nonnull
	public final static String formatToYear2MinString(@Nonnull Date d) {
		Validate.isTrue(d != null, "The specified date shoud NOT be null.");

		return year2MinFormat.format(d);
	}

	/**
	 * Formats the specified date into 'yyyyMMddHHmmss'(from year to second)
	 * format string.
	 *
	 * @param d
	 *            date object to format
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified date is {@code null}
	 */
	@Nonnull
	public final static String formatToYear2SecString(@Nonnull Date d) {
		Validate.isTrue(d != null, "The specified date shoud NOT be null.");

		return year2SecFormat.format(d);
	}

	/**
	 * Formats the specified date into 'yyyyMMddHHmmssSSS'(from year to
	 * millisecond) format string.
	 *
	 * @param d
	 *            date object to format
	 * @return
	 * @throws IllegalArgumentException
	 *             if the specified date is {@code null}
	 */
	@Nonnull
	public final static String formatToYear2MillisecString(@Nonnull Date d) {
		Validate.isTrue(d != null, "The specified date shoud NOT be null");

		return year2MillisecFormat.format(d);
	}

	/**
	 * Gets the current time in 'yyyyMMddHHmmss' format
	 *
	 * @return
	 */
	@NotBlank
	public final static String getNowString() {
		return formatToYear2SecString(new java.util.Date());
	}

	/**
	 * Removes all occurrences of specified characters.
	 * {@link org.apache.commons.lang3.StringUtils} provides method to remove
	 * all occurrences of single char but doesn't provide method to specify
	 * multiple characters at the same time.
	 * <p>
	 * If the specified {@code str} is {@code null}, this method returns
	 * {@code null}.
	 *
	 * @param str
	 * @param chars
	 * @return
	 * @see org.apache.commons.lang3.StringUtils.remove(String, char)
	 * @since 1.0.3
	 */
	@Nullable
	public final static String removeCharsFromString(@Nullable final String str, @Nullable final char[] chars) {
		if (StringUtils.isEmpty(str) || ArrayUtils.isEmpty(chars)) {
			return str;
		}

		final char[] strChars = str.toCharArray();
		int pos = 0;
		int num = chars.length;
		boolean unmatched = true;
		for (int i = 0, n = strChars.length; i < n; i++) {
			unmatched = true;
			for (int j = 0; j < num; j++) {
				if (strChars[i] == chars[j]) {
					unmatched = false;
					break;
				}
			}
			if (unmatched)
				strChars[pos++] = strChars[i];
		}
		return new String(strChars, 0, pos);
	}

	public static String getHexString(byte[] src) {
		// String hex = "0x";
		String hex = "";
		String tmp = "";

		for (int i = 0; i < src.length; i++) {
			tmp = Integer.toHexString(src[i] & 0xff).toUpperCase();
			if (tmp.length() == 1)
				tmp = "0" + tmp;

			hex += tmp;
		}

		return hex;
	}

	/**
	 * hex code string=>byte
	 */
	public static byte getHexCodeToByte(String src, int offset) {
		int start = offset * 2;
		int b = Integer.parseInt(src.substring(start, start + 2), 16);
		return (byte) b;
	}

	/**
	 * hex code string=>byte[]
	 */
	public static byte[] getHexCodeToBytes(String src) {
		int size = src.length() / 2;
		byte[] bytes = new byte[size];
		for (int i = 0; i < size; i++) {
			bytes[i] = getHexCodeToByte(src, i);
		}
		return bytes;
	}

}
