package com.skcc.vas.frs.common.biz.service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.transaction.annotation.Transactional;

import com.skcc.vas.frs.common.biz.domain.ConfigEnv;
import com.skcc.vas.frs.common.biz.domain.ConfigProperty;
import com.skcc.vas.frs.common.biz.repository.VasConfigMapper;

@EnableCaching
// @Configuration
// @Service("config.vasConfigService")
public class VasConfigService {
	// public class VasConfigService implements ConfigService {

	private VasConfigMapper dao;

	private String param;

	private String ipAddr;
	private String nodeId;

	private static List<ConfigProperty> ConfigProperties;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public VasConfigService(VasConfigMapper vasConfigmapper, String nodeId) {
		this.dao = vasConfigmapper;
		this.nodeId = nodeId;
	}

	public void vasConfigInitService() {
		// TODO Auto-generated constructor stub
		logger.info(">>>>>>>>>>>> ConfigService Loadding!!");

		if (nodeId.equalsIgnoreCase("nodeId")) {
			try {

				ipAddr = InetAddress.getLocalHost().getHostAddress();
				ConfigProperties = dao.selectVASConfigPropertyIpBased(ipAddr);

			} catch (UnknownHostException e) {
				throw new IllegalStateException("failed to get local IP address in VasConfig service !!!");
			}

		} else {

			ConfigProperties = dao.selectVASConfigPropertyMyNode(nodeId);

			if (ConfigProperties.size() > 1) {
				logger.info("My node Id = [{}] and My config info is in VAS_CONF table", nodeId);
			} else {
				logger.info("My node Id = [{}] and My config info is not in VAS_CONF table. So will use master node config",
						nodeId);
				ConfigProperties = dao.selectVASConfigPropertyMasterNode(nodeId);
			}

		}

		if (ConfigProperties.isEmpty()) {
			String errorMsg = " Can not get node config infos from VAS_CONF_NODE, VAS_NODE !!!";
			errorMsg += " Most case, this caused by sys_id ";
			if (nodeId.equalsIgnoreCase("nodeId")) {
				errorMsg += " (1) check whether node id exists in VAS_NODE table. current IP address = [" + ipAddr
						+ "]";
			} else {
				errorMsg += "(1) check whether node id exists in VAS_NODE table. current IP address = [" + ipAddr + "]"
						+ " node Id = [" + nodeId + "]";
			}
			errorMsg += "(2) check whether master node id with same [sys_id] exists in VAS_CONF_NODE table";
			errorMsg += "(3) if master node id with same [sys_id] doen't exist, check node id [" + nodeId
					+ "] exists in VAS_CONF_NODE table";

			throw new IllegalStateException(errorMsg);
		}

	}

	@Transactional
	// HashMap<String, Object> param
	public List<ConfigProperty> findVASConfigProperty(String param) {
		return dao.selectVASConfigProperty(param);
	}

	// @Override
	@Cacheable(value = "ConfigProperty", key = "#var", unless = "#result==null")
	public ConfigProperty getConfigPropertyByName(String name) {

		logger.info("<!----------Entering getConfigPropertyByName()--------------------->");
		for (ConfigProperty c : ConfigProperties) {
			if (c.getVar().equalsIgnoreCase(name))
				return c;
		}
		logger.info("<!----------getConfigPropertyByName() Error------------------->");
		return null;

	}

	public String getConfigValByName(String name) {
		if (getConfigPropertyByName(name) == null)
			return "";
		else
			return getConfigPropertyByName(name).getValue();

	}
	// @Override
	@CacheEvict(value = "ConfigProperty", allEntries = true)
	public void refreshAllConfigEnv() {
		// TODO Auto-generated method stub
	}

	// @Override
	@Cacheable(value = "ConfigProperty", key = "#var", unless = "#result==null")
	public ConfigProperty updateConfigProperty(ConfigEnv configEnv) {
		logger.info("<!----------Entering updateConfigProperty ------------------->");
		for (ConfigProperty c : ConfigProperties) {
			if (c.getVar().equalsIgnoreCase(configEnv.getVar()))
				c.setValue(configEnv.getValue());
			return c;
		}
		logger.info("<!----------updateConfigProperty Error------------------->");
		return null;
	}

}
