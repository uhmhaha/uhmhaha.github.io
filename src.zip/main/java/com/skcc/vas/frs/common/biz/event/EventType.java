package com.skcc.vas.frs.common.biz.event;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * Marker interface
 *
 * @author
 * @since 2015-05-15
 */
@JsonDeserialize(using = EventTypeJsonDeserializer.class)
public interface EventType extends java.io.Serializable {

}
