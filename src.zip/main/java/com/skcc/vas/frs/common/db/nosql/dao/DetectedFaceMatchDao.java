package com.skcc.vas.frs.common.db.nosql.dao;

import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatch;

@Repository
public class DetectedFaceMatchDao extends GenericMongoDao {

	public DetectedFaceMatchDao() {
		collectionName = "VAS_DETECTED_FACE_N_MATCH_NOSQL";
		cls = NDetectedFaceMatch.class;
	}
}
