package com.skcc.vas.frs.common.biz.event;

/**
 * Types of events that video analytics
 *
 * @author
 * @since 2015-05-15
 * @see <a href=
 *      "http://www.intuvisiontech.com/products/events.php">http://www.intuvisiontech.com/products/events.php</a>
 * @see <a href=
 *      "http://www.puretechsystems.com/video-analytics.html">http://www.puretechsystems.com/video-analytics.html</a>
 */
public enum VideoEventType implements EventType {

	INTRUSION, LINE_CROSSING, PEOPLE_COUNT, CROWD_DENSITY, LOITERING, CAMERA_TAMPERING, FACE_RECOGNITION, UNKNOWN;
}
