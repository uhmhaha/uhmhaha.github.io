package com.skcc.vas.frs.common.db.repository;

import java.util.HashMap;
import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * @author suhyoung kims
 * @since 2016-09-25
 */
@Repository("faceMatchJobMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface FaceMatchJobMapper {

	List<HashMap<String, Object>> selectJobDetailList(@Param("param") HashMap<String, Object> param);
	List<HashMap<String, Object>> selectConcernedFaceFeatureList(@Param("param") HashMap<String, Object> param);
	List<HashMap<String, Object>> selectSqlServerTest();
	List<HashMap<String, Object>> selectNonCompletedVmsFileJob(@Param("param") HashMap<String, Object> param);
	List<HashMap<String, Object>> selectNonCompletedVideoJob(@Param("param") HashMap<String, Object> param);
	List<HashMap<String, Object>> selectFailFileList(@Param("param") HashMap<String, Object> param);
	List<HashMap<String, Object>> selectConcernFaceList(@Param("param") HashMap<String, Object> param);

	int updateJobStartTime(@Param("param") HashMap<String, Object> param);
	int updateJobEndTime(@Param("param") HashMap<String, Object> param);
	int updateSubJobEndTime(@Param("param") HashMap<String, Object> param);

	int updateJobProgressRate(@Param("param") HashMap<String, Object> param);
	int updateDiscretedJobProgressRate(@Param("param") HashMap<String, Object> param);

	int updateExtSrcStatus(@Param("param") HashMap<String, Object> param);
	int insertJobFaceMatch(@Param("param") HashMap<String, Object> param);
	int updateJobStatus(@Param("param") HashMap<String, Object> param);
	String searchStopStatus(@Param("param") HashMap<String, Object> param);
	int updateJobOndemandNodeTime(@Param("param") HashMap<String, Object> param);
	
	int insertFailedFile(@Param("param") HashMap<String, Object> param);
	int deleteFailedFile(@Param("param") HashMap<String, Object> param);
	int insertJobFaceMatchExtSrc(@Param("param") HashMap<String, Object> param);
	int insertOndemandSubJob(@Param("param") HashMap<String, Object> param);

	List<Integer> selectNumOfOndemandDBStanbyNode();
	List<Integer> selectNumOfOndemandVMSStanbyNode();
	List<Integer> selectNumOfOndemandVideoStanbyNode();
	int updateOndemandFailStatus(@Param("jobId") String jobId, @Param("failReason") String failReason);
	
}
