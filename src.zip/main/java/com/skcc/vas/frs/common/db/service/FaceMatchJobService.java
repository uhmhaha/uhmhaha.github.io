package com.skcc.vas.frs.common.db.service;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skcc.vas.frs.common.db.repository.FaceMatchJobMapper;

@Service("faceMatchJobService")
public class FaceMatchJobService {
	@Autowired
	private FaceMatchJobMapper dao;

	private static final Logger logger = LoggerFactory.getLogger(FaceMatchJobService.class);

	@Transactional
	public List<HashMap<String, Object>> findJobDetailListByJobId(HashMap<String, Object> param) {
		return dao.selectJobDetailList(param);
	}

	@Transactional
	public List<HashMap<String, Object>> findConcernFaceListByJobId(HashMap<String, Object> param) {
		return dao.selectConcernFaceList(param);
	}
	
	@Transactional
	public List<HashMap<String, Object>> findConcernedFaceFeatureListByJobId(HashMap<String, Object> param) {
		return dao.selectConcernedFaceFeatureList(param);
	}
	@Transactional
	public List<HashMap<String, Object>> selectSqlServerTest() {
		return dao.selectSqlServerTest();
	}
	@Transactional
	public List<HashMap<String, Object>> selectNonCompletedVmsFileJob(HashMap<String, Object> param) {
		return dao.selectNonCompletedVmsFileJob(param);
	}
	@Transactional
	public List<HashMap<String, Object>> selectNonCompletedVideoJob(HashMap<String, Object> param) {
		return dao.selectNonCompletedVideoJob(param);
	}
	@Transactional
	public List<HashMap<String, Object>> selectFailFileList(HashMap<String, Object> param) {
		return dao.selectFailFileList(param);
	}
	@Transactional
	public int updateJobStartTime(HashMap<String, Object> param) {
		return dao.updateJobStartTime(param);
	}
	@Transactional
	public int updateJobEndTime(HashMap<String, Object> param) {
		return dao.updateJobEndTime(param);
	}

	@Transactional
	public int updateSubJobEndTime(HashMap<String, Object> param) {
		return dao.updateSubJobEndTime(param);
	}

	@Transactional
	public int updateJobProgressRate(HashMap<String, Object> param) {
		return dao.updateJobProgressRate(param);
	}

	@Transactional
	public int updateDiscretedJobProgressRate(HashMap<String, Object> param) {
		return dao.updateDiscretedJobProgressRate(param);
	}

	@Transactional
	public int updateExtSrcStatus(HashMap<String, Object> param) {
		return dao.updateExtSrcStatus(param);
	}
	@Transactional
	public int insertJobFaceMatch(HashMap<String, Object> param) {
		return dao.insertJobFaceMatch(param);
	}
	@Transactional
	public int updateJobStatus(HashMap<String, Object> param) {
		return dao.updateJobStatus(param);
	}
	@Transactional
	public String searchStopStatus(HashMap<String, Object> param) {
		return dao.searchStopStatus(param);
	}

	@Transactional
	public int insertFailedFile(HashMap<String, Object> param) {
		return dao.insertFailedFile(param);
	}

	@Transactional
	public int deleteFailedFile(HashMap<String, Object> param) {
		return dao.deleteFailedFile(param);
	}
	@Transactional
	public int insertJobFaceMatchExtSrc(HashMap<String, Object> param) {
		return dao.insertJobFaceMatchExtSrc(param);
	}

	@Transactional
	public int insertOndemandSubJob(HashMap<String, Object> param) {
		return dao.insertOndemandSubJob(param);
	}

	@Transactional
	public List<Integer> selectNumOfOndemandDBStanbyNode() {
		return dao.selectNumOfOndemandDBStanbyNode();
	}

	@Transactional
	public List<Integer> selectNumOfOndemandVMSStanbyNode() {
		return dao.selectNumOfOndemandVMSStanbyNode();
	}

	@Transactional
	public List<Integer> selectNumOfOndemandVideoStanbyNode() {
		return dao.selectNumOfOndemandVideoStanbyNode();
	}

	@Transactional
	public int updateOndmenadFailStatus(String jobId, String failReason) {
		return dao.updateOndemandFailStatus(jobId, failReason);
	}
	
	@Transactional
	public int updateJobOndemandNodeTime(HashMap<String, Object> param) {
		return dao.updateJobOndemandNodeTime(param);
	}
	
}
