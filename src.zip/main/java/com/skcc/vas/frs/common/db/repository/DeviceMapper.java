package com.skcc.vas.frs.common.db.repository;

import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

//@Repository("face.DeviceMapper")
//@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
//@ParametersAreNonnullByDefault
public interface DeviceMapper {

	List<Pair<String, String>> selectFRSAllCctvsForStart();

}
