package com.skcc.vas.frs.common.util.ondemand;

import javax.annotation.concurrent.Immutable;
import javax.validation.constraints.Min;

/**
 * @author
 * @since 2015-06-19
 *
 */
@Immutable
public class FilePrepareState {
	// @TODO(Done) Rename this class to FilePrepareState according to the naming
	// btw. 'state' and 'status'
	// where the 'status' is just code and the 'state' can have summary.

	public static final FilePrepareState UNKNOWN_STATUS = new FilePrepareState();

	public static final FilePrepareState NOT_PREPARED = new FilePrepareState(1, 0);

	private int totalFiles = -1;

	private int preparedFiles = -1;

	private String str;

	private FilePrepareState() {
	}

	public FilePrepareState(@Min(0) int total, @Min(0) int prepared) {
		this.totalFiles = total;
		this.preparedFiles = prepared;
	}

	public int getTotalFiles() {
		return this.totalFiles;
	}

	public int getPreparedFiles() {
		return this.preparedFiles;
	}

	public boolean isCompleted() {
		return (this.totalFiles == this.preparedFiles);
	}

	@Override
	public String toString() {
		// Note that this class is immutable and trivial value object
		if (this.str == null) {
			this.str = new StringBuilder(50).append("{").append("total files:").append(this.totalFiles)
					.append(", prepared files:").append(this.preparedFiles).append("}").toString();
		}
		return this.str;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + preparedFiles;
		result = prime * result + totalFiles;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilePrepareState other = (FilePrepareState) obj;
		if (preparedFiles != other.preparedFiles)
			return false;
		if (totalFiles != other.totalFiles)
			return false;
		return true;
	}
}
