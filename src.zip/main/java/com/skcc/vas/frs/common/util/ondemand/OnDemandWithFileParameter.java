package com.skcc.vas.frs.common.util.ondemand;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.biz.service.VasConfigService;

public class OnDemandWithFileParameter {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	// @Value("${vas.multithread.predefined.dir}")
	private String base;

	// @Value("${vas.triumiDirectAccessFilePreparer.timeGap}")
	private int timeGap;

	// @Value("${vas.dataDir}")
	private String vadDir;

	// @Value("${vas.thumbnail.saveDir}")
	private String thumbnailDirName;

	// @Value("${vas.screenshot.saveDir}")
	private String screenshotDir;

	// @Value("${vas.screenshot.cctvResolutionEnable}")
	private String cctvResolutionEnable;

	private String videoDataDir;

	private String vmsDataDir;

	private String mode;

	private String vmsUnitTime;

	private String vmsSubJobUnitTime;

	private String responseTimeout;

	private String videoUnitTime;

	private String videoSubJobUnitTime;

	private VasConfigService configService;

	public OnDemandWithFileParameter(@Nonnull VasConfigService configService) {

		this.configService = configService;

	}

	public void initConfig() {

		// <constructor-arg value="${vas.multithread.predefined.dir}"/>
		// base =
		// configService.getConfigValByName("vas.multithread.predefined.dir");
		// <constructor-arg
		// value="${vas.triumiDirectAccessFilePreparer.timeGap}"/>
		// timeGap =
		// Integer.parseInt(configService.getConfigValByName("vas.triumiDirectAccessFilePreparer.timeGap"));
		// <constructor-arg value="${vas.dataDir}"/>
		vadDir = configService.getConfigValByName("vas.dataDir");
		// <constructor-arg value="${vas.thumbnail.saveDir}"/>
		thumbnailDirName = configService.getConfigValByName("vas.thumbnail.saveDir");
		// <constructor-arg value="${vas.screenshot.saveDir}"/>
		screenshotDir = configService.getConfigValByName("vas.screenshot.saveDir");
		// <constructor-arg value="${vas.screenshot.cctvResolutionEnable}"/>
		// mode =
		// configService.getConfigValByName("vas.screenshot.cctvResolutionEnable");
		// <constructor-arg value="${vas.ondemand.video.saveDir}"/>
		vmsDataDir = configService.getConfigValByName("vas.ondemand.vms.saveDir");
		// <constructor-arg value="${vas.multithread.mode}"/>
		videoDataDir = configService.getConfigValByName("vas.ondemand.video.saveDir");

		// <constructor-arg value="${vas.ondemand.vms.saveDir}"/>
		if (configService.getConfigValByName("vas.ondemand.vms.saveDir") == null) {
			setVmsUnitTime("10");
		} else {
			setVmsUnitTime(configService.getConfigValByName("vas.ondemand.vms.saveDir"));
		}
		// <constructor-arg value="${vas.multithread.vms.subJobUnitTime}"/>
		if (configService.getConfigValByName("vas.multithread.vms.subJobUnitTime") == null) {
			setVmsSubJobUnitTime("20");
		} else {
			setVmsSubJobUnitTime(configService.getConfigValByName("vas.multithread.vms.subJobUnitTime"));
		}
		// <constructor-arg value="${http.response.timeout.second}"/>
		setResponseTimeout(configService.getConfigValByName("http.response.timeout.second"));
		// <constructor-arg value="${vas.multithread.video.unitTime}" />
		if (configService.getConfigValByName("vas.multithread.video.unitTime") == null) {
			setVideoUnitTime("10");
		} else {
			setVideoUnitTime(configService.getConfigValByName("vas.multithread.video.unitTime"));
		}
		// <constructor-arg value="${vas.multithread.video.subJobUnitTime}" />
		if (configService.getConfigValByName("vas.multithread.video.subJobUnitTime") == null) {
			setVideoSubJobUnitTime("20");
		} else {
			setVideoSubJobUnitTime(configService.getConfigValByName("vas.multithread.video.subJobUnitTime"));
		}

	}

	public String getBase() {
		return base;
	}

	public void setBase(String base) {
		this.base = base;
	}

	public int getTimeGap() {
		return timeGap;
	}

	public void setTimeGap(int timeGap) {
		this.timeGap = timeGap;
	}

	public String getVadDir() {
		return vadDir;
	}

	public void setVadDir(String vadDir) {
		this.vadDir = vadDir;
	}

	public String getThumbnailDirName() {
		return thumbnailDirName;
	}

	public void setThumbnailDirName(String thumbnailDirName) {
		this.thumbnailDirName = thumbnailDirName;
	}

	public String getScreenshotDir() {
		return screenshotDir;
	}

	public void setScreenshotDir(String screenshotDir) {
		this.screenshotDir = screenshotDir;
	}

	public String getCctvResolutionEnable() {
		return cctvResolutionEnable;
	}

	public void setCctvResolutionEnable(String cctvResolutionEnable) {
		this.cctvResolutionEnable = cctvResolutionEnable;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getVmsUnitTime() {
		return vmsUnitTime;
	}

	public void setVmsUnitTime(String vmsUnitTime) {
		this.vmsUnitTime = vmsUnitTime;
	}

	public String getVideoDataDir() {
		return videoDataDir;
	}

	public void setVideoDataDir(String videoDataDir) {
		this.videoDataDir = videoDataDir;
	}

	public String getVmsDataDir() {
		return vmsDataDir;
	}

	public void setVmsDataDir(String vmsDataDir) {
		this.vmsDataDir = vmsDataDir;
	}

	public String getVmsSubJobUnitTime() {
		return vmsSubJobUnitTime;
	}

	public void setVmsSubJobUnitTime(String vmsSubJobUnitTime) {
		this.vmsSubJobUnitTime = vmsSubJobUnitTime;
	}

	public String getResponseTimeout() {
		return responseTimeout;
	}

	public void setResponseTimeout(String responseTimeout) {
		this.responseTimeout = responseTimeout;
	}

	public String getVideoUnitTime() {
		return videoUnitTime;
	}

	public void setVideoUnitTime(String videoUnitTime) {
		this.videoUnitTime = videoUnitTime;
	}

	public String getVideoSubJobUnitTime() {
		return videoSubJobUnitTime;
	}

	public void setVideoSubJobUnitTime(String videoSubJobUnitTime) {
		this.videoSubJobUnitTime = videoSubJobUnitTime;
	}
}
