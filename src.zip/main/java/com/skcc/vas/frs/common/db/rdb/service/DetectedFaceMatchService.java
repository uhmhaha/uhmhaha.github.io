package com.skcc.vas.frs.common.db.rdb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.skcc.vas.frs.common.db.nosql.dao.ConcernPersonAndFaceDao;
import com.skcc.vas.frs.common.db.nosql.dao.DetectedFaceDao;
import com.skcc.vas.frs.common.db.nosql.dao.DetectedFaceMatchDao;
import com.skcc.vas.frs.common.db.nosql.domain.MetaDataByCctvID;
import com.skcc.vas.frs.common.db.nosql.domain.NConcernPersonAndFace;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectectedTotalResult;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatch;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatchWithMetaData;
import com.skcc.vas.frs.common.db.repository.MetaDataByCctvIDMapper;
import com.skcc.vas.frs.matching.biz.MongoTemplateManager;

@Service("face.DetectedFaceMatchService")
public class DetectedFaceMatchService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ConcernPersonAndFaceService concernPersonAndFaceService;

	@Autowired
	private ConcernPersonAndFaceDao concernPersonAndFaceDao;

	@Autowired
	private DetectedFaceMatchDao detectedFaceMatchDao;

	@Autowired
	private DetectedFaceDao detectedFaceDao;

	// @Resource(name="metaDataByCctvIDMapper")
	@Autowired
	private MetaDataByCctvIDMapper metaDataByCctvIDMapper;

	public NDetectedFaceMatch insertConcernedFaceMatch(NDetectedFaceMatch detectedFaceMatchProfile) throws Exception {

		NDetectedFaceMatch detectedFaceMatchItem = new NDetectedFaceMatch();

		detectedFaceMatchItem.setDetectedFaceId(detectedFaceMatchProfile.getDetectedFaceId());
		detectedFaceMatchItem.setSystemId(detectedFaceMatchProfile.getSystemId());
		detectedFaceMatchItem.setCctvId(detectedFaceMatchProfile.getCctvId());
		detectedFaceMatchItem.setSrvcType(detectedFaceMatchProfile.getSrvcType());
		detectedFaceMatchItem.setImgFile(detectedFaceMatchProfile.getImgFile());
		detectedFaceMatchItem.setImgW(detectedFaceMatchProfile.getImgW());
		detectedFaceMatchItem.setImgH(detectedFaceMatchProfile.getImgH());
		detectedFaceMatchItem.setImgX(detectedFaceMatchProfile.getImgX());
		detectedFaceMatchItem.setImgY(detectedFaceMatchProfile.getImgY());
		detectedFaceMatchItem.setFeature(detectedFaceMatchProfile.getFeature());
		detectedFaceMatchItem.setLandmarks(detectedFaceMatchProfile.getLandmarks());
		detectedFaceMatchItem.setFrmFile(detectedFaceMatchProfile.getFrmFile());
		detectedFaceMatchItem.setFrmW(detectedFaceMatchProfile.getFrmW());
		detectedFaceMatchItem.setFrmH(detectedFaceMatchProfile.getFrmH());
		detectedFaceMatchItem.setFrmTime(detectedFaceMatchProfile.getFrmTime());
		detectedFaceMatchItem.setLastUpdateBy(detectedFaceMatchProfile.getLastUpdateBy());
		detectedFaceMatchItem.setLastUpdateAt(detectedFaceMatchProfile.getLastUpdateAt());
		detectedFaceMatchItem.setDetectedDate(detectedFaceMatchProfile.getDetectedDate());
		detectedFaceMatchItem.setCncrnFaceId(detectedFaceMatchProfile.getCncrnFaceId());
		detectedFaceMatchItem.setScore(detectedFaceMatchProfile.getScore());
		detectedFaceMatchItem.setRank(detectedFaceMatchProfile.getRank());
		detectedFaceMatchItem.setLastUpdateMatchBy(detectedFaceMatchProfile.getLastUpdateMatchBy());
		detectedFaceMatchItem.setLastUpdateMatchAt(detectedFaceMatchProfile.getLastUpdateMatchAt());

		detectedFaceMatchDao.insert(detectedFaceMatchItem);
		return detectedFaceMatchItem;
	}
	
	public NDetectedFaceMatch insertConcernedFaceMatch(NDetectedFaceMatch detectedFaceMatchProfile, MongoTemplateManager mongoTemplateManager) throws Exception {

		NDetectedFaceMatch detectedFaceMatchItem = new NDetectedFaceMatch();

		detectedFaceMatchItem.setDetectedFaceId(detectedFaceMatchProfile.getDetectedFaceId());
		detectedFaceMatchItem.setSystemId(detectedFaceMatchProfile.getSystemId());
		detectedFaceMatchItem.setCctvId(detectedFaceMatchProfile.getCctvId());
		detectedFaceMatchItem.setSrvcType(detectedFaceMatchProfile.getSrvcType());
		detectedFaceMatchItem.setImgFile(detectedFaceMatchProfile.getImgFile());
		detectedFaceMatchItem.setImgW(detectedFaceMatchProfile.getImgW());
		detectedFaceMatchItem.setImgH(detectedFaceMatchProfile.getImgH());
		detectedFaceMatchItem.setImgX(detectedFaceMatchProfile.getImgX());
		detectedFaceMatchItem.setImgY(detectedFaceMatchProfile.getImgY());
		detectedFaceMatchItem.setFeature(detectedFaceMatchProfile.getFeature());
		detectedFaceMatchItem.setLandmarks(detectedFaceMatchProfile.getLandmarks());
		detectedFaceMatchItem.setFrmFile(detectedFaceMatchProfile.getFrmFile());
		detectedFaceMatchItem.setFrmW(detectedFaceMatchProfile.getFrmW());
		detectedFaceMatchItem.setFrmH(detectedFaceMatchProfile.getFrmH());
		detectedFaceMatchItem.setFrmTime(detectedFaceMatchProfile.getFrmTime());
		detectedFaceMatchItem.setLastUpdateBy(detectedFaceMatchProfile.getLastUpdateBy());
		detectedFaceMatchItem.setLastUpdateAt(detectedFaceMatchProfile.getLastUpdateAt());
		detectedFaceMatchItem.setDetectedDate(detectedFaceMatchProfile.getDetectedDate());
		detectedFaceMatchItem.setCncrnFaceId(detectedFaceMatchProfile.getCncrnFaceId());
		detectedFaceMatchItem.setScore(detectedFaceMatchProfile.getScore());
		detectedFaceMatchItem.setRank(detectedFaceMatchProfile.getRank());
		detectedFaceMatchItem.setLastUpdateMatchBy(detectedFaceMatchProfile.getLastUpdateMatchBy());
		detectedFaceMatchItem.setLastUpdateMatchAt(detectedFaceMatchProfile.getLastUpdateMatchAt());

		//detectedFaceMatchDao.insert(detectedFaceMatchItem);
		
		mongoTemplateManager.sendMongoDBJob(detectedFaceMatchItem, "VAS_DETECTED_FACE_N_MATCH_NOSQL");
		
		return detectedFaceMatchItem;
	}
	
	public List<NDetectedFaceMatch> selectDetectedList(Map<String, Object> variableMap, Sort.Direction direction)
			throws Exception {

		List<NDetectedFaceMatch> findDetectedFaceMatchItemList = null;

		Query query = new Query();
		query.addCriteria(Criteria.where("cctvId").is(variableMap.get("cctvId")));

		if (variableMap.get("systemId") != null) {
			query.addCriteria(Criteria.where("systemId").is(variableMap.get("systemId")));
		}

		query.addCriteria(Criteria.where("frmTime").gte(variableMap.get("frmTime")));
		query.with(new Sort(direction, "imgFile"));
		query.limit(Integer.parseInt((String) variableMap.get("topNum")));

		findDetectedFaceMatchItemList = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query);
		return findDetectedFaceMatchItemList;

	}

	public int selectDetectedResultHistoryCountV2(Map<String, Object> variableMap, Map<String, Object> input)
			throws Exception {

		Integer scoreUp = (Integer) variableMap.get("SCORE_UP");
		Integer scoreDown = (Integer) variableMap.get("SCORE_DOWN");
		String fromDate = (String) variableMap.get("FROM_DATE");
		String toDate = (String) variableMap.get("TO_DATE");

		String pCctvId = (String) input.get("CCTV_ID");
		String[] cctvIds;
		List<String> cctvIdList = new ArrayList<String>();

		if (pCctvId != null) {
			cctvIds = pCctvId.split(",");

			for (int i = 0; i < cctvIds.length; i++) {
				cctvIdList.add(cctvIds[i]);
			}
		}

		String pTargetId = (String) input.get("TARGET_ID");
		String[] targetIds;
		List<String> targetIdList = new ArrayList<String>();

		if (pTargetId != null) {
			targetIds = pTargetId.split(",");

			for (int i = 0; i < targetIds.length; i++) {
				targetIdList.add(targetIds[i]);
			}
		}

		String pWantedType = (String) input.get("WANTED_TYPE");
		String[] wantedTypes;
		List<String> wantedTypeList = new ArrayList<String>();

		if (pWantedType != null) {
			wantedTypes = pWantedType.split(",");

			for (int i = 0; i < wantedTypes.length; i++) {
				wantedTypeList.add(wantedTypes[i]);
			}
		}

		int count = 0;
		// case01 : CP와FM칼럼이 없는 경우
		if ((scoreUp == null || scoreDown == null) || (targetIdList.size() == 0 || wantedTypeList.size() == 0)) {
			System.out.println("LLLLLLLLLLLLLLLLLLLLLLLLLLLL       ");
			count = selectDetectedResultHistoryCountWithoutConcernPeronAndFaceMatchColumn(cctvIdList, fromDate, toDate);
		} else {
			// case02 : CP와FM칼럼이 있는 경우
			System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPPPP       ");
			count = selectDetectedResultHistoryCountWithConcernPeronAndFaceMatchColumn(scoreDown, scoreUp, targetIdList,
					wantedTypeList, cctvIdList, fromDate, toDate);
		}
		return count;

	}

	private int selectDetectedResultHistoryCountWithoutConcernPeronAndFaceMatchColumn(List<String> cctvIdList,
			String fromDate, String toDate) throws Exception {
		int count = 0;
		Query query = new Query();

		if (cctvIdList.size() > 0) {
			query.addCriteria(Criteria.where("cctvId").in(cctvIdList));
		}

		if (toDate != null && fromDate != null) {
			System.out.println(">>>>>>>>>>>>>>>>>> not null toDate V2");
			query.addCriteria(Criteria.where("frmTime").lte(toDate).gte(fromDate));
		}

		count = (int) detectedFaceMatchDao.count(query);

		return count;

	}

	private int selectDetectedResultHistoryCountWithConcernPeronAndFaceMatchColumn(Integer scoreDown, Integer scoreUp,
			List<String> targetIdList, List<String> wantedTypeList, List<String> cctvIdList, String fromDate,
			String toDate) throws Exception {
		List<NDetectectedTotalResult> detectectedTotalResults = new ArrayList<NDetectectedTotalResult>();

		Query query1 = new Query();
		query1.addCriteria(Criteria.where("score").lte(scoreUp).gte(scoreDown));
		// NoSQL에서는 이미 Detected_Face와 Face_Match 테이블이 join이 되어 있으므로 where절을 선
		// 반영해도 됨
		query1.addCriteria(Criteria.where("cctvId").in(cctvIdList));
		query1.addCriteria(Criteria.where("frmTime").lte(toDate).gte(fromDate));
		List<NDetectedFaceMatch> detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query1);

		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {
			Query query2 = new Query();
			query2.addCriteria(Criteria.where("personId").in(targetIdList));
			query2.addCriteria(Criteria.where("concernType").in(wantedTypeList));
			// query2.addCriteria(Criteria.where("faceId").is(Long.toString(detectedFaceMatch.getCncrnFaceId())));
			query2.addCriteria(Criteria.where("faceId").is(detectedFaceMatch.getCncrnFaceId()));

			List<NConcernPersonAndFace> findConcernPersonAndFaceItemList = null;
			findConcernPersonAndFaceItemList = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query2);

			for (NConcernPersonAndFace concernPersonAndFace : findConcernPersonAndFaceItemList) {
				NDetectectedTotalResult detectectedTotalResult = new NDetectectedTotalResult(detectedFaceMatch,
						concernPersonAndFace);
				detectectedTotalResults.add(detectectedTotalResult);
			}
		}

		// print
		for (NDetectectedTotalResult detectectedTotalResult : detectectedTotalResults) {
			logger.debug("========> " + detectectedTotalResult.getDetectedFaceMatch().getDetectedFaceId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCncrnFaceId() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getName() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getGender() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getConcernType() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getPersonId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCctvId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getSystemId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getFrmTime());
		}

		return detectectedTotalResults.size();
	}

	public int selectDetectedResultHistoryCount(Map<String, Object> variableMap, Map<String, Object> input)
			throws Exception {

		Integer scoreUp = (Integer) variableMap.get("SCORE_UP");
		Integer scoreDown = (Integer) variableMap.get("SCORE_DOWN");
		String fromDate = (String) variableMap.get("FROM_DATE");
		String toDate = (String) variableMap.get("TO_DATE");

		String pCctvId = (String) input.get("CCTV_ID");
		String[] cctvIds;
		List<String> cctvIdList = new ArrayList<String>();

		if (pCctvId != null) {
			cctvIds = pCctvId.split(",");

			for (int i = 0; i < cctvIds.length; i++) {
				cctvIdList.add(cctvIds[i]);
			}
		}

		List<NDetectectedTotalResult> detectectedTotalResults = new ArrayList<NDetectectedTotalResult>();

		// VAS_CNCRN_PERSON, VAS_CNCRN_FACE부터 추룰
		// CP나 CF쪽 조건이 아에 없으면 아래의 쿼리가 아무 의미가 없음. 실행하지 말기
		List<NConcernPersonAndFace> concernPersonAndFaceList = concernPersonAndFaceService
				.selectConcernPersonAndFaceListByCondition(input);

		if (concernPersonAndFaceList == null) {
			Query query = new Query();

			if (cctvIdList.size() > 0) {
				query.addCriteria(Criteria.where("cctvId").in(cctvIdList));
			}

			if (scoreUp != null && scoreDown != null) {
				query.addCriteria(Criteria.where("score").lte(scoreUp).gte(scoreDown));
			}

			if (toDate != null && fromDate != null) {
				query.addCriteria(Criteria.where("frmTime").lte(toDate).gte(fromDate));
			}

			// List<DetectedFaceMatch> detectedFaceMatchs=
			// (List<DetectedFaceMatch>) detectedFaceMatchDao.find(query);
			// count 갯수가 50000개가 넘어가니까 Exception in thread "main"
			// java.lang.OutOfMemoryError: Java heap space 발생
			int count = (int) detectedFaceMatchDao.count(query);
			return count;
		} else {

			for (NConcernPersonAndFace concernPersonAndFace : concernPersonAndFaceList) {

				Query query = new Query();
				query.addCriteria(Criteria.where("cncrnFaceId").is(Integer.parseInt(concernPersonAndFace.getfaceId())));

				if (cctvIdList.size() > 0) {
					query.addCriteria(Criteria.where("cctvId").in(cctvIdList));
				}

				if (scoreUp != null && scoreDown != null) {
					query.addCriteria(Criteria.where("score").lte(scoreUp).gte(scoreDown));
				}

				if (toDate != null && fromDate != null) {
					query.addCriteria(Criteria.where("frmTime").lte(toDate).gte(fromDate));
				}

				List<NDetectedFaceMatch> detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao
						.find(query);

				for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {
					NDetectectedTotalResult detectectedTotalResult = new NDetectectedTotalResult(detectedFaceMatch,
							concernPersonAndFace);
					detectectedTotalResults.add(detectectedTotalResult);
				}
			}
		}

		// print
		for (NDetectectedTotalResult detectectedTotalResult : detectectedTotalResults) {
			logger.debug("========> " + detectectedTotalResult.getConcernPersonAndFace().getName() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getGender() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getConcernType() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getPersonId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCncrnFaceId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCctvId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getSystemId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getFrmTime());
		}

		return detectectedTotalResults.size();
	}

	private List<NDetectedFaceMatch> selectMatchedResultingNoScore(Map<String, Object> input, Sort.Direction direction)
			throws Exception {
		String systemId = (String) input.get("SYSTEM_ID");
		String cctvId = (String) input.get("CCTV_ID");
		String frmTime = (String) input.get("FRM_TIME");

		Query query = new Query();
		query.addCriteria(Criteria.where("systemId").is(systemId));
		query.addCriteria(Criteria.where("cctvId").is(cctvId));
		query.addCriteria(Criteria.where("frmTime").gte(frmTime));
		query.with(new Sort(direction, "detectedFaceId"));
		query.limit(4);

		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query);

		return detectedFaceMatchs;

	}

	private List<NDetectedFaceMatch> selectDetectedFaceMatch(Sort.Direction direction) throws Exception {

		Query query = new Query();
		query.with(new Sort(direction, "detectedFaceId"));
		query.limit(4);

		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query);

		return detectedFaceMatchs;
	}

	private List<NDetectedFaceMatch> selectMatchedResultingNoSystemInfo(Map<String, Object> input) throws Exception {
		String cctvId = (String) input.get("CCTV_ID");
		String frmTime = (String) input.get("FRM_TIME");

		List<NDetectedFaceMatch> detectedFaceMatchs = selectDetectedFaceMatch(Sort.Direction.DESC);
		List<NDetectedFaceMatch> detectedFaceMatchsNoSystemInfo = new ArrayList<NDetectedFaceMatch>();

		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {

			Query query = new Query();
			query.addCriteria(Criteria.where("faceId").is(detectedFaceMatch.getDetectedFaceId()));
			// 아래 부분이 아닐까????
			// query.addCriteria(Criteria.where("cncrnFaceId").is(detectedFaceMatch.getDetectedFaceId()));
			query.addCriteria(Criteria.where("cctvId").is(cctvId));
			query.addCriteria(Criteria.where("frmTime").gte(frmTime));
			query.limit(4);

			detectedFaceMatchsNoSystemInfo = (List<NDetectedFaceMatch>) concernPersonAndFaceDao.find(query);
			// 아래 부분이 아닐까????
			// detectedFaceMatchsNoSystemInfo =
			// (List<NDetectedFaceMatch>)detectedFaceMatchDao.find(query);
		}
		return detectedFaceMatchsNoSystemInfo;
	}

	public List<NDetectedFaceMatch> selectMatchedResulting(Map<String, Object> input) throws Exception {

		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		List<NDetectedFaceMatch> detectedFaceMatchsNoScore = new ArrayList<NDetectedFaceMatch>();
		List<NDetectedFaceMatch> detectedFaceMatchsNoSystemInfo = new ArrayList<NDetectedFaceMatch>();

		detectedFaceMatchsNoScore = selectMatchedResultingNoScore(input, Sort.Direction.DESC);
		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchsNoScore) {
			detectedFaceMatch.setDetectedFaceId(String.valueOf(0));
			detectedFaceMatch.setCncrnFaceId("");
			detectedFaceMatch.setScore(-1);
			// detectedFaceMatch.setimg("0x00");
			detectedFaceMatch.setResultType("DETECTED");
			detectedFaceMatchs.add(detectedFaceMatch);
		}

		detectedFaceMatchsNoSystemInfo = selectMatchedResultingNoSystemInfo(input);
		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchsNoSystemInfo) {
			detectedFaceMatch.setSystemId("");
			detectedFaceMatch.setCctvId("");;
			detectedFaceMatch.setSrvcType("");
			detectedFaceMatch.setImgFile("");
			detectedFaceMatch.setFrmTime("");
			detectedFaceMatch.setResultType("MATCHED");
			detectedFaceMatchs.add(detectedFaceMatch);
		}

		// print
		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {
			logger.debug("1========> " + detectedFaceMatch.getSystemId() + ", " + detectedFaceMatch.getCctvId() + ", "
					+ detectedFaceMatch.getSrvcType() + ", " + detectedFaceMatch.getImgFile() + ", "
					+ detectedFaceMatch.getFrmFile() + ", " + detectedFaceMatch.getFrmTime() + ", "
					+ detectedFaceMatch.getDetectedFaceId() + ", " + detectedFaceMatch.getCncrnFaceId() + ", "
					+ detectedFaceMatch.getScore() + ", " + detectedFaceMatch.getResultType());
		}

		return detectedFaceMatchs;
	}

	public List<NDetectectedTotalResult> selectRecentConcernedFaceV2(Map<String, Object> input) throws Exception {

		String srvcType = (String) input.get("srvcType");
		Integer score = (Integer) input.get("threasHold");
		String isValid = (String) input.get("isValid");

		List<NDetectectedTotalResult> detectectedTotalResults = new ArrayList<NDetectectedTotalResult>();
		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		List<NConcernPersonAndFace> concernPersonAndFaces = new ArrayList<NConcernPersonAndFace>();

		Query query1 = new Query();
		query1.addCriteria(Criteria.where("srvcType").is(srvcType));
		query1.addCriteria(Criteria.where("score").gte(score));
		query1.with(new Sort(Sort.Direction.DESC, "frmTime"));
		query1.limit(4);

		detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query1);

		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>.. " + detectedFaceMatchs.size());

		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {
			Query query2 = new Query();
			query2.addCriteria(Criteria.where("isValidFace").is(isValid)); // 현재
																			// 몽고DB의
																			// 데이터가
																			// 불환전하게
																			// PERSON데이터가
																			// 들어가
																			// 있음.
																			// 정상적으로
																			// 다
																			// 넣으면
																			// 이게
																			// 가능할
																			// 듯
			query2.addCriteria(Criteria.where("faceId").is(String.valueOf(detectedFaceMatch.getCncrnFaceId())));

			concernPersonAndFaces = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query2);

			for (NConcernPersonAndFace concernPersonAndFace : concernPersonAndFaces) {
				NDetectectedTotalResult detectectedTotalResult = new NDetectectedTotalResult(detectedFaceMatch,
						concernPersonAndFace);
				detectectedTotalResults.add(detectectedTotalResult);
			}

		}

		// print
		for (NDetectectedTotalResult detectectedTotalResult : detectectedTotalResults) {
			logger.debug("========> " + detectectedTotalResult.getDetectedFaceMatch().getSystemId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCctvId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getSrvcType() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getImgFile() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getImgW() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getImgH() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getImgX() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getImgY() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getFrmFile() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getFrmTime() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getName() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getGender() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getConcernType() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getPersonId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCncrnFaceId() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getIsValid()

			);
		}

		return detectectedTotalResults;

	}

	public List<NDetectectedTotalResult> selectRecentConcernedFace(Map<String, Object> input) throws Exception {

		String frmTime = (String) input.get("lastUpdateTime");
		Integer score = (Integer) input.get("threasHold");
		Integer topNum = (Integer) input.get("TOP_NUM");
		int topNumInt = topNum.intValue();

		List<NDetectectedTotalResult> detectectedTotalResults = new ArrayList<NDetectectedTotalResult>();
		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		List<NConcernPersonAndFace> concernPersonAndFaces = new ArrayList<NConcernPersonAndFace>();

		Query query1 = new Query();
		query1.addCriteria(Criteria.where("srvcType").is("LIVE_FACE_RECOG"));
		query1.addCriteria(Criteria.where("score").gte(score));
		query1.addCriteria(Criteria.where("frmTime").gte(frmTime));
		query1.with(new Sort(Sort.Direction.DESC, "detectedFaceId"));
		query1.limit(topNumInt * 10);

		long t1 = System.currentTimeMillis();
		detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query1);
		long count = detectedFaceMatchDao.count(query1);

		long t2 = System.currentTimeMillis();

		String x = String.valueOf(t2 - t1);
		String y = String.valueOf((t2 - t1) / 1000);
		System.out.println("\n77777777777777777777777777777777777 y : " + y + "\t sec, count: " + count);

		int i = 0;
		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {

			if (i >= topNumInt) {
				break;
			} else {
				i++;
			}

			Query query2 = new Query();
			// query2.addCriteria(Criteria.where("isValidFace").is("Y"));
			// //faceId 340번은 N로 되어 있음. 향후 데이터 다 쌓고 주석풀고 확인해야 함
			query2.addCriteria(Criteria.where("faceId").is(String.valueOf(detectedFaceMatch.getCncrnFaceId())));

			concernPersonAndFaces = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query2);

			for (NConcernPersonAndFace concernPersonAndFace : concernPersonAndFaces) {
				NDetectectedTotalResult detectectedTotalResult = new NDetectectedTotalResult(detectedFaceMatch,
						concernPersonAndFace);
				detectectedTotalResults.add(detectectedTotalResult);
			}
		}

		// print
		for (NDetectectedTotalResult detectectedTotalResult : detectectedTotalResults) {
			logger.debug("========> " + detectectedTotalResult.getConcernPersonAndFace().getName() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getGender() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getConcernType() + ", "
					+ detectectedTotalResult.getConcernPersonAndFace().getPersonId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCncrnFaceId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getCctvId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getSystemId() + ", "
					+ detectectedTotalResult.getDetectedFaceMatch().getFrmTime());
		}

		return detectectedTotalResults;
	}

	private List<NDetectectedTotalResult> selectDetectedFaceMatchAndConcernPersonFace(Map<String, Object> input)
			throws Exception {

		String frmTime = (String) input.get("FRM_TIME");
		String cctvId = (String) input.get("CCTV_ID");

		List<NDetectectedTotalResult> detectectedTotalResults = new ArrayList<NDetectectedTotalResult>();
		List<NDetectedFaceMatch> detectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();
		List<NConcernPersonAndFace> concernPersonAndFaces = new ArrayList<NConcernPersonAndFace>();

		Query query1 = new Query();
		query1.addCriteria(Criteria.where("frmTime").gte(frmTime));
		// query1.addCriteria(Criteria.where("frmTime").is(frmTime));
		query1.addCriteria(Criteria.where("cctvId").is(cctvId));
		query1.with(new Sort(Sort.Direction.DESC, "score"));
		query1.limit(2 * 10);

		int count = (int) detectedFaceMatchDao.count(query1);
		System.out.println("KKKKKKKKKKKKKKKKKKKKKKKKKKKKK " + count);
		detectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query1);

		int i = 0;
		for (NDetectedFaceMatch detectedFaceMatch : detectedFaceMatchs) {
			if (i >= 2) {
				break;
			} else {
				i++;
			}
			Query query2 = new Query();
			query2.addCriteria(Criteria.where("faceId").is(String.valueOf(detectedFaceMatch.getCncrnFaceId()))); // join지점

			concernPersonAndFaces = (List<NConcernPersonAndFace>) concernPersonAndFaceDao.find(query2);

			for (NConcernPersonAndFace concernPersonAndFace : concernPersonAndFaces) {
				NDetectectedTotalResult detectectedTotalResult = new NDetectectedTotalResult(detectedFaceMatch,
						concernPersonAndFace);
				detectectedTotalResults.add(detectectedTotalResult);
			}
		}

		return detectectedTotalResults;
	}

	public List<NDetectedFaceMatchWithMetaData> selectAnalysisResult(Map<String, Object> input) throws Exception {

		String cctvId = (String) input.get("CCTV_ID");

		MetaDataByCctvID metaDataByCctvID = metaDataByCctvIDMapper.selectMetaDataByCctvID(cctvId); // 1개

		System.out.println("99999999999999999999999999 " + metaDataByCctvID.getSiteNm());

		List<NDetectectedTotalResult> detectectedTotalResults = selectDetectedFaceMatchAndConcernPersonFace(input); // 2개
		List<NDetectedFaceMatchWithMetaData> detectedFaceMatchWithMetaDatas = new ArrayList<NDetectedFaceMatchWithMetaData>();

		for (NDetectectedTotalResult detectectedTotalResult : detectectedTotalResults) {
			NDetectedFaceMatchWithMetaData detectedFaceMatchWithMetaData = new NDetectedFaceMatchWithMetaData(
					detectectedTotalResult, metaDataByCctvID);
			detectedFaceMatchWithMetaDatas.add(detectedFaceMatchWithMetaData);
		}

		// print
		for (NDetectedFaceMatchWithMetaData detectedFaceMatchWithMetaData : detectedFaceMatchWithMetaDatas) {
			logger.debug("========> " + detectedFaceMatchWithMetaData.getMetaDataByCctvID().getDevTypeId() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getVmsId() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getDevNm() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getDevId() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getSiteNm() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getBldNm() + ", "
					+ detectedFaceMatchWithMetaData.getMetaDataByCctvID().getFlrNm() + ", "
					// +
					// detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getImg()
					// + ", " //너무 많아서 일단 주석처리함
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getImgFormat()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getDetectedFaceMatch()
							.getDetectedFaceId()
					+ ", " + detectedFaceMatchWithMetaData.getDetectectedTotalResult().getDetectedFaceMatch().getScore()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getName()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getGender()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace()
							.getConcernType()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getCfRemarks()
					+ ", "
					+ detectedFaceMatchWithMetaData.getDetectectedTotalResult().getConcernPersonAndFace().getfaceId());
		}

		return detectedFaceMatchWithMetaDatas;
	}

	public void deleteAllDocuments(String deletedDate) throws Exception {

		Query query = new Query();
		query.addCriteria(Criteria.where("frmTime").lt(deletedDate));

		detectedFaceMatchDao.remove(query);
	}

	public List<NDetectedFaceMatch> selectRecentOne() throws Exception {
		List<NDetectedFaceMatch> nDetectedFaceMatchs = null;

		Query query = new Query();
		query.with(new Sort(Sort.Direction.DESC, "frmTime"));
		query.limit(1);

		nDetectedFaceMatchs = (List<NDetectedFaceMatch>) detectedFaceMatchDao.find(query);
		return nDetectedFaceMatchs;

	}

}
