package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

@Repository("face.ConcernedFaceMatchMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface ConcernedFaceMatchMapper {

	int insertConcernedFaceMatch(@Param("concernedFaceId") String concernedFaceId,
			@Param("detectedFaceId") String detectedFaceId, @Param("score") int score, @Param("rank") int rank,
			@Param("updateBy") String updateBy);
}
