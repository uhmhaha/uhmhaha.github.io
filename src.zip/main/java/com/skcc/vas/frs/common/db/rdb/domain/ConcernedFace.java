package com.skcc.vas.frs.common.db.rdb.domain;

import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * Represents the face in concern which is usually an item in black list or
 * white list.
 *
 * @author
 * @since 2015-11-11
 */
public class ConcernedFace {

	public enum ImageFormat {
		BMP("BMP"), JPG("JPG");

		private String code;

		private ImageFormat(@NotEmpty String code) {
			this.code = code;
		}

		@NotEmpty
		public final String getCode() {
			return this.code;
		}

		public final ImageFormat getImageFormat() {
			if (this == BMP)
				return ImageFormat.BMP;
			else
				return ImageFormat.JPG;
		}

		public static final ImageFormat valueFromCode(@NotEmpty String code) {
			ImageFormat found = null;
			for (ImageFormat value : values()) {
				if (value.getCode().equals(code)) {
					found = value;
					break;
				}
			}
			return found;
		}
	}

	private String id; // auto incremented by MySQL

	public String getId() {
		return this.id;
	}

	public ConcernedFace setId(String id) {
		this.id = id;
		return this;
	}

	private String personId;

	public String getPersonId() {
		return this.personId;
	}

	public ConcernedFace setPersonId(String personId) {
		this.personId = personId;
		return this;
	}

	private boolean isValid = true;

	private String isValidFace;

	public boolean isValid() {
		return this.isValid;
	}

	public ConcernedFace setValid(boolean isValid) {
		this.isValid = isValid;
		return this;
	}

	private byte[] img;

	public byte[] getImg() {
		return this.img;
	}

	public ConcernedFace setImg(byte[] img) {
		this.img = img;
		return this;
	}
	// 상대경로 ex)/face/1126/20160920/20160920092058585-1.jpg
	private String imgPath;

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	private String imgName;

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	private String imgFormat = ImageFormat.BMP.getCode(); // 1 for BMP and 2 for
															// JPG

	public String getImgFormat() {
		return this.imgFormat;
	}

	public ConcernedFace setImgFormat(String imgFormat) {
		this.imgFormat = imgFormat;
		return this;
	}

	private int imgWidth = 0;

	@Min(0)
	public int getImgWidth() {
		return this.imgWidth;
	}

	public ConcernedFace setImgWidth(@Min(1) int imgWidth) {
		this.imgWidth = imgWidth;
		return this;
	}

	private int imgHeight = 0;

	@Min(0)
	public int getImgHeight() {
		return this.imgHeight;
	}

	public ConcernedFace setImgHeight(@Min(1) int imgHeight) {
		this.imgHeight = imgHeight;
		return this;
	}

	private byte[] feature;

	public byte[] getFeature() {
		return this.feature;
	}

	public ConcernedFace setFeature(byte[] feature) {
		this.feature = feature;
		return this;
	}

	private String landmarks;

	public String getLandmarks() {
		return this.landmarks;
	}

	public void setLandmarks(String landmarks) {
		this.landmarks = landmarks;
	}

	private String remarks;

	public String getRemarks() {
		return this.remarks;
	}

	public ConcernedFace setRemarks(String remarks) {
		this.remarks = remarks;
		return this;
	}

	private String userId;

	public String getUserId() {
		return this.userId;
	}

	public ConcernedFace setUserId(String userId) {
		this.userId = userId;
		return this;
	}

	private String name;

	public String getName() {
		return name;
	}

	private String firstName;

	public String getFirstName() {
		return firstName;
	}

	private String lastName;

	public String getLastName() {
		return lastName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getConcernType() {
		return concernType;
	}

	public void setConcernType(String concernType) {
		this.concernType = concernType;
	}

	public String getIsValidFace() {
		return isValidFace;
	}

	public void setIsValidFace(String isValidFace) {
		this.isValidFace = isValidFace;
	}

	private String gender;

	private String concernType;
	
	private String passportNo;
	
	private String birthday;
	
	private String nationality;
		
	private String middleName;

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	

}
