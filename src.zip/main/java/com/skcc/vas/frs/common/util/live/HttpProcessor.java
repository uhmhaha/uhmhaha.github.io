package com.skcc.vas.frs.common.util.live;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.annotation.Nonnull;

import org.json.JSONObject;

import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;
import com.skcc.vas.frs.common.biz.service.VasConfigService;

/**
 * @author SKYANG
 * @since 2016-08-23
 *
 */
public class HttpProcessor {

	private String loginUrl;

	private String httpUrl;

	private AsyncHttpClient asyncHttpClient;

	private VasConfigService configService;

	public HttpProcessor(@Nonnull VasConfigService configService) {

		this.configService = configService;
	}

	public void initConfig() {
		// <constructor-arg value="${vas.ccs.address}" />
		// <constructor-arg value="${vas.ccs.httpPort}" />
		this.httpUrl = "http://" + configService.getConfigValByName("vas.ccs.address") + ":"
				+ configService.getConfigValByName("vas.ccs.httpPort") + "/json2/bizOperation";
		this.loginUrl = "http://" + configService.getConfigValByName("vas.ccs.address") + ":"
				+ configService.getConfigValByName("vas.ccs.httpPort") + "json2/loginServlet";

		this.asyncHttpClient = new AsyncHttpClient();

		try {
			this.initHttpConn(loginUrl);
		} catch (IOException | InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void initHttpConn(String loginUrl) throws IOException, InterruptedException, ExecutionException {

		AsyncHttpClient.BoundRequestBuilder builder = asyncHttpClient.preparePost(loginUrl);

		builder.addHeader("Content-Type", "application/json");
		JSONObject loginParam = new JSONObject();
		loginParam.put("bid", "2001");
		loginParam.put("operation", "IN");
		loginParam.put("id", "gisUser");
		loginParam.put("pwd", "!gisUser1234");
		loginParam.put("encryptCallYN", "N");

		builder.setBody(loginParam.toString());
		// Future<Response> f = builder.execute();

		// Response r = f.get();
		// FluentCaseInsensitiveStringsMap headers = r.getHeaders();
		// Set-Cookie=JSESSIONID=D26079139BA06DD36DF4CD72AEB70618

		// Header[] headers = response.getAllHeaders();
	}

	public void pushData(String jsonStr) throws IOException, InterruptedException, ExecutionException {

		AsyncHttpClient.BoundRequestBuilder builder = asyncHttpClient.preparePost(httpUrl);

		builder.addHeader("Content-Type", "application/json");
		builder.setBody(jsonStr);

		Future<Response> f = builder.execute();

	}
}
