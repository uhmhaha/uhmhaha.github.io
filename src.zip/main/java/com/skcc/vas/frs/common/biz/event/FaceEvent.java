package com.skcc.vas.frs.common.biz.event;

import javax.annotation.concurrent.Immutable;

import com.skcc.vas.frs.ondemand.video.biz.StandardEvent;

/**
 * @author
 * @since 2016-07-20
 *
 */
@Immutable
public class FaceEvent extends StandardEvent {

	public FaceEvent() {
		super(VideoEventType.FACE_RECOGNITION);
		// TODO Auto-generated constructor stub
	}

}
