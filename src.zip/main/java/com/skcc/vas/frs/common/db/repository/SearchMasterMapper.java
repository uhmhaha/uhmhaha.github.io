package com.skcc.vas.frs.common.db.repository;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.biz.model.SearchRequest;
import com.skcc.vas.frs.common.util.base.JobStatus;

/**
 * @author
 *
 */
@Repository("searchMasterMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface SearchMasterMapper {
	// @NOTE Do not use transaction control(annotation) in the mapper.

	@Nullable
	SearchRequest selectSearchMaster(@Param("jobId") String jobId);

	@Min(0)
	@Max(1)
	int insertSearchMaster(SearchRequest srchReq);

	@Min(0)
	@Max(1)
	int setSearchStatus(@Param("jobId") String jobId, @Param("status") JobStatus status);

}
