package com.skcc.vas.frs.common.db.rdb.domain;

/**
 * @author Suhyoung kim
 * @since 2016-09-06
 *
 */
public class DetectedRoi {
	private String cctvId;
	private int roiNo;
	private int pointNo;
	private float pointX;
	private float pointY;

	public String getCctvId() {
		return cctvId;
	}
	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}
	public int getRoiNo() {
		return roiNo;
	}
	public void setRoiNo(int roiNo) {
		this.roiNo = roiNo;
	}
	public int getPointNo() {
		return pointNo;
	}
	public void setPointNo(int pointNo) {
		this.pointNo = pointNo;
	}
	public float getPointX() {
		return pointX;
	}
	public void setPointX(float pointX) {
		this.pointX = pointX;
	}
	public float getPointY() {
		return pointY;
	}
	public void setPointY(float pointY) {
		this.pointY = pointY;
	}

}
