package com.skcc.vas.frs.common.util.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nonnull;
import org.apache.commons.lang3.Validate;

/**
 * @author
 * @since 2016-07-20
 *
 * @param <T>
 */
public class RectangleRoi<T extends Number> implements Roi<T>, java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private final List<Point<T>> points = new ArrayList<Point<T>>(4);

	public RectangleRoi(@Nonnull Point<T> pt1, @Nonnull Point<T> pt2, @Nonnull Point<T> pt3, @Nonnull Point<T> pt4) {

		Validate.isTrue(pt1 != null && pt2 != null && pt3 != null && pt4 != null,
				"The point of ROI shouldn't be null.");

		List<Point<T>> points = new ArrayList<Point<T>>(4);
		points.add(pt1);
		points.add(pt2);
		points.add(pt3);
		points.add(pt4);

		Collections.sort(points, VetexComparator.getInstance());

		Validate.isTrue(
				points.get(0).getX().equals(points.get(1).getX()) && !points.get(0).getY().equals(points.get(1).getY())
						&& points.get(1).getY().equals(points.get(3).getY())
						&& !points.get(1).getX().equals(points.get(3).getX())
						&& points.get(3).getX().equals(points.get(2).getX())
						&& !points.get(3).getY().equals(points.get(2).getY())
						&& points.get(2).getY().equals(points.get(0).getY())
						&& !points.get(2).getX().equals(points.get(0).getX()),
				"The ROI is not rectangle.");

		this.points.add(points.get(0));
		this.points.add(points.get(1));
		this.points.add(points.get(3));
		this.points.add(points.get(2));
	}

	public RectangleRoi(@Nonnull T x1, @Nonnull T y1, @Nonnull T x2, @Nonnull T y2) {
		this(new Point<T>(x1, y1), new Point<T>(x2, y1), new Point<T>(x2, y2), new Point<T>(x1, y2));
	}

	public List<Point<T>> getPoints() {
		return this.points;
	}
}

/**
 * @author
 * @since 2016-07-27
 *
 * @param <T>
 */
class VetexComparator<T extends Number> implements Comparator<Point<T>> {

	@Override
	public final int compare(@Nonnull Point<T> v1, @Nonnull Point<T> v2) {
		Validate.isTrue(v1 != null && v2 != null, "The operands should be non-null.");

		double x1 = v1.getX().doubleValue();
		double y1 = v1.getY().doubleValue();
		double x2 = v2.getX().doubleValue();
		double y2 = v2.getY().doubleValue();

		if (x1 == x2) {
			if (y1 == y2)
				return 0;
			else if (y1 > y2)
				return 1;
			else
				return -1;
		} else if (x1 > x2) {
			return 1;
		} else {
			return -1;
		}
	}

	private final static VetexComparator singleton = new VetexComparator();

	private VetexComparator() {
	}

	public final static VetexComparator getInstance() {
		return singleton;
	}
}
