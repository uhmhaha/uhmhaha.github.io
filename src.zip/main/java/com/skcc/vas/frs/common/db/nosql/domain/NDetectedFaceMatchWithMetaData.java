package com.skcc.vas.frs.common.db.nosql.domain;

public class NDetectedFaceMatchWithMetaData {

	private NDetectectedTotalResult detectectedTotalResult;

	private MetaDataByCctvID metaDataByCctvID;

	public NDetectedFaceMatchWithMetaData(NDetectectedTotalResult detectectedTotalResult,
			MetaDataByCctvID metaDataByCctvID) {
		this.detectectedTotalResult = detectectedTotalResult;
		this.metaDataByCctvID = metaDataByCctvID;
	}

	public NDetectectedTotalResult getDetectectedTotalResult() {
		return detectectedTotalResult;
	}

	public void setDetectectedTotalResult(NDetectectedTotalResult detectectedTotalResult) {
		this.detectectedTotalResult = detectectedTotalResult;
	}

	public MetaDataByCctvID getMetaDataByCctvID() {
		return metaDataByCctvID;
	}

	public void setMetaDataByCctvID(MetaDataByCctvID metaDataByCctvID) {
		this.metaDataByCctvID = metaDataByCctvID;
	}

}
