package com.skcc.vas.frs.common.db.nosql.domain;

import org.bson.types.Binary;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "VAS_DETECTED_FACE_NOSQL")
public class NDetectedFace {

	// @Id
	protected String _id;

	protected String detectedFaceId; // detectedFaceId

	protected String systemId;

	protected String cctvId;

	protected String srvcType;

	protected String imgFile;

	protected int imgW;

	protected int imgH;

	protected int imgX;

	protected int imgY;

	protected Binary feature;

	protected String landmarks;

	protected String frmFile;

	protected int frmW;

	protected int frmH;

	protected String frmTime;

	protected String lastUpdateBy;

	protected String lastUpdateAt;

	protected String detectedDate;

	// @Deprecated
	// public NDetectedFace(long detectedFaceId, String systemId, String cctvId,
	// String srvcType, String imgFile, int imgW,
	// int imgH, int imgX, int imgY, String feature, String landmarks, String
	// frmFile, int frmW, int frmH,
	// String frmTime, String lastUpdateBy, String lastUpdateAt, String
	// detectedDate) {
	// super();
	// this.detectedFaceId = detectedFaceId;
	// this.systemId = systemId;
	// this.cctvId = cctvId;
	// this.srvcType = srvcType;
	// this.imgFile = imgFile;
	// this.imgW = imgW;
	// this.imgH = imgH;
	// this.imgX = imgX;
	// this.imgY = imgY;
	// this.feature = feature;
	// this.landmarks = landmarks;
	// this.frmFile = frmFile;
	// this.frmW = frmW;
	// this.frmH = frmH;
	// this.frmTime = frmTime;
	// this.lastUpdateBy = lastUpdateBy;
	// this.lastUpdateAt = lastUpdateAt;
	// this.detectedDate = detectedDate;
	// }

	public String getDetectedFaceId() {
		return detectedFaceId;
	}

	public void setDetectedFaceId(String detectedFaceId) {
		this.detectedFaceId = detectedFaceId;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getCctvId() {
		return cctvId;
	}

	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}

	public String getSrvcType() {
		return srvcType;
	}

	public void setSrvcType(String srvcType) {
		this.srvcType = srvcType;
	}

	public String getImgFile() {
		return imgFile;
	}

	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}

	public int getImgW() {
		return imgW;
	}

	public void setImgW(int imgW) {
		this.imgW = imgW;
	}

	public int getImgH() {
		return imgH;
	}

	public void setImgH(int imgH) {
		this.imgH = imgH;
	}

	public int getImgX() {
		return imgX;
	}

	public void setImgX(int imgX) {
		this.imgX = imgX;
	}

	public int getImgY() {
		return imgY;
	}

	public void setImgY(int imgY) {
		this.imgY = imgY;
	}

	public Binary getFeature() {
		return feature;
	}

	public void setFeature(Binary feature) {
		this.feature = feature;
	}

	public String getLandmarks() {
		return landmarks;
	}

	public void setLandmarks(String landmarks) {
		this.landmarks = landmarks;
	}

	public String getFrmFile() {
		return frmFile;
	}

	public void setFrmFile(String frmFile) {
		this.frmFile = frmFile;
	}

	public int getFrmW() {
		return frmW;
	}

	public void setFrmW(int frmW) {
		this.frmW = frmW;
	}

	public int getFrmH() {
		return frmH;
	}

	public void setFrmH(int frmH) {
		this.frmH = frmH;
	}

	public String getFrmTime() {
		return frmTime;
	}

	public void setFrmTime(String frmTime) {
		this.frmTime = frmTime;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getLastUpdateAt() {
		return lastUpdateAt;
	}

	public void setLastUpdateAt(String lastUpdateAt) {
		this.lastUpdateAt = lastUpdateAt;
	}

	public String getDetectedDate() {
		return detectedDate;
	}

	public void setDetectedDate(String detectedDate) {
		this.detectedDate = detectedDate;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

}
