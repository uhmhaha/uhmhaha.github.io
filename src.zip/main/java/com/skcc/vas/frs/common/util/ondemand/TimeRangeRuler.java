package com.skcc.vas.frs.common.util.ondemand;

import javax.validation.constraints.Pattern;

/**
 * @author
 * @since 2015-06-17
 */
public interface TimeRangeRuler {

	/**
	 * @param from
	 *            yyyyMMddHHmm format
	 * @param to
	 *            yyyyMMddHHmm format
	 * @return
	 */
	boolean validate(@Pattern(regexp = "[1-9][0-9]{11}") String from, @Pattern(regexp = "[1-9][0-9]{11}") String to);

}
