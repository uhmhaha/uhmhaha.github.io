package com.skcc.vas.frs.common.biz.event;

/**
 * @author
 * @since 2015-05-15
 */
public enum AudioEventType implements EventType {

};