package com.skcc.vas.frs.common.biz.model;

import javax.annotation.concurrent.Immutable;

/**
 * Contains the minimal data for the face for various analytic operations such
 * as verification, identification or et al.
 * <p>
 * This class is specially useful for caching the face data.
 *
 * @author
 * @since 2016-01-29
 *
 */
@Immutable
public class AnalyticFace implements java.io.Serializable {

	/**
	*
	*/
	private static final long serialVersionUID = 1L;

	private String id;

	public String getId() {
		return this.id;
	}

	private byte[] feature;

	public byte[] getFeature() {
		return this.feature;
	}

	/**
	 * the time when this face is acquired or analyzed in 'yyyyMMddHHmmss'
	 * format
	 */
	private long timestamp;

	/**
	 * This value may be 0(zero) when it is unknown
	 *
	 * @return the time when this face is acquired or analyzed in
	 *         'yyyyMMddHHmmss' format
	 */
	public long getTimestamp() {
		return this.timestamp;
	}

	public AnalyticFace(String id, byte[] feature, long timestamp) {
		this.id = id;
		this.feature = feature;
		this.timestamp = timestamp;
	}

	public AnalyticFace(Integer id, byte[] feature) {
		this(String.valueOf(id), feature, 0);
	}

	public AnalyticFace(String id, byte[] feature) {
		this(id, feature, 0);
	}

	@Override
	public int hashCode() {
		if (this.id == null)
			return 0;
		else
			return this.id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		if (this.id == null)
			return false;

		AnalyticFace other = (AnalyticFace) obj;
		return this.id.equals(other.getId());
	}

}
