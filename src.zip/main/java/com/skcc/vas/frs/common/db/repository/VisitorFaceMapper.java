package com.skcc.vas.frs.common.db.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.rdb.domain.VisitorFace;

/**
 * @author
 * @since 2016-01-26
 */
@Repository("face.VisitorFaceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface VisitorFaceMapper {

	/**
	 * Gets the valid faces for the specified visitor
	 *
	 * @param visitorId
	 * @return
	 */
	List<VisitorFace> selectVisitorFacesByVisitor(@Param("visitorId") String visitorId);

	/**
	 * Sets the feature and landmarks for the specified visitor face
	 *
	 * @param id
	 *            the ID of visitor face
	 * @param feature
	 * @param landmarks
	 * @return
	 */
	int setFeatureAndLandmarks(@Param("id") String id, @Param("feature") byte[] feature,
			@Param("landmarks") String landmarks);

}
