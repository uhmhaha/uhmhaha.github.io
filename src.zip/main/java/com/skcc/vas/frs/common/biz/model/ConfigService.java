package com.skcc.vas.frs.common.biz.model;

import com.skcc.vas.frs.common.biz.domain.ConfigEnv;
import com.skcc.vas.frs.common.biz.domain.ConfigProperty;

public interface ConfigService {
	public ConfigProperty getConfigPropertyByName(String name);
	public void refreshAllConfigEnv();
	public ConfigProperty updateConfigProperty(ConfigEnv configEnv);
}
