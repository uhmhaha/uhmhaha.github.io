package com.skcc.vas.frs.common.biz.event;

/**
 * @author
 * @since 2015-06-19
 */
public interface EventContext {

}
