package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

@Repository("face.ConcernedPersonMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface ConcernedPersonMapper {

	int setValidity(@Param("id") String id, @Param("isValid") boolean isValid);

}
