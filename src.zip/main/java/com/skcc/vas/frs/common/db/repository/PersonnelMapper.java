package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.rdb.domain.Personnel;
import com.skcc.vas.frs.common.db.rdb.domain.Visitor;

/**
 * @author Hong yongman
 * @since 2016-03-08
 */
@Repository("face.PersonnelMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface PersonnelMapper {

	@Deprecated
	int insertVisitor(@Param("visitor") Visitor visitor);

	Personnel selectPersonnelById(@Param("id") String id);

}
