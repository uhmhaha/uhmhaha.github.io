package com.skcc.vas.frs.common.db.nosql.domain;

public class DetectedFaceMatch {

	private byte[] feature;
	private String frmTime;
	private String _id;
	private String detectedFaceId;

	private String systemId;
	private String cctvId;
	private String srvcType;
	private String imgFile;
	private int imgW;
	private int imgH;
	private int imgX;
	private int imgY;
	private String frmFile;
	private int frmW;
	private int frmH;

	public byte[] getFeature() {
		return feature;
	}
	public void setFeature(byte[] feature) {
		this.feature = feature;
	}
	public String getFrmTime() {
		return frmTime;
	}
	public void setFrmTime(String frmTime) {
		this.frmTime = frmTime;
	}
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getDetectedFaceId() {
		return detectedFaceId;
	}
	public void setDetectedFaceId(String detectedFaceId) {
		this.detectedFaceId = detectedFaceId;
	}
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getCctvId() {
		return cctvId;
	}
	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}
	public String getSrvcType() {
		return srvcType;
	}
	public void setSrvcType(String srvcType) {
		this.srvcType = srvcType;
	}
	public String getImgFile() {
		return imgFile;
	}
	public void setImgFile(String imgFile) {
		this.imgFile = imgFile;
	}
	public int getImgW() {
		return imgW;
	}
	public void setImgW(int imgW) {
		this.imgW = imgW;
	}
	public int getImgH() {
		return imgH;
	}
	public void setImgH(int imgH) {
		this.imgH = imgH;
	}
	public int getImgX() {
		return imgX;
	}
	public void setImgX(int imgX) {
		this.imgX = imgX;
	}
	public int getImgY() {
		return imgY;
	}
	public void setImgY(int imgY) {
		this.imgY = imgY;
	}
	public String getFrmFile() {
		return frmFile;
	}
	public void setFrmFile(String frmFile) {
		this.frmFile = frmFile;
	}
	public int getFrmW() {
		return frmW;
	}
	public void setFrmW(int frmW) {
		this.frmW = frmW;
	}
	public int getFrmH() {
		return frmH;
	}
	public void setFrmH(int frmH) {
		this.frmH = frmH;
	}

}
