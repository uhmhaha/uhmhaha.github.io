package com.skcc.vas.frs.common.util.base;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * @author
 * @since 2016-07-20
 *
 * @param <T>
 */
@Immutable
public class Point<T extends Number> {

	private final T x;

	private final T y;

	public Point(@Nonnull final T x, @Nonnull final T y) {
		this.x = x;
		this.y = y;
	}

	public T getX() {
		return this.x;
	}

	public T getY() {
		return this.y;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((x == null) ? 0 : x.hashCode());
		result = prime * result + ((y == null) ? 0 : y.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Point other = (Point) obj;
		if (x.getClass() != other.getX().getClass())
			return false;
		if (x == null) {
			if (other.x != null)
				return false;
		} else if (!x.equals(other.x))
			return false;
		if (y == null) {
			if (other.y != null)
				return false;
		} else if (!y.equals(other.y))
			return false;
		return true;
	}
}
