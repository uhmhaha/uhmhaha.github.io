package com.skcc.vas.frs.common.biz.model;

import java.util.Date;
import java.util.TimeZone;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.time.FastDateFormat;
import org.hibernate.validator.constraints.NotBlank;
import org.opencv.core.CvType;

import com.skcc.vas.frs.common.util.base.ImageFormat;

/**
 * @author
 * @since 2015-08-04
 *
 * @param <T>
 */
@ThreadSafe
@ParametersAreNonnullByDefault
public interface ThumbnailPersister<T> {

	public enum Type {
		FILE,
		DATABASE,
	}

	Type getType();

	ImageFormat getThumbnailFormat();

	/**
	 *
	 * @return a string to identify the persisted thumbnail or something
	 *         meaningless, depends on implementations
	 */
	String persistThumbnail(@NotBlank String jobId, @NotBlank String taskId, @NotBlank String systemId,
			@NotBlank String devId, T img);

	/**
	 * @version 1.0, 2015-08-12, Sangmoon Oh, Added another constructor
	 * @author
	 * @since 2015-08-06
	 */
	@Immutable
	public static class Image {

		private int width;

		private int height;

		private int cvType;

		/**
		 * Time-stamp for this image in yyyyMMddHHmmssSSS format
		 */
		private @Pattern(regexp = "[1-9][0-8]{16}") String timestamp;

		/**
		 * TimeZone for the time-stamp of this image
		 *
		 * @see java.util.TimeZone
		 */
		private String timeZoneId;

		private byte[] data;

		/**
		 * @param w
		 *            width of image
		 * @param h
		 *            height of image
		 * @param cvType
		 *            type of the image as CvType of OpenCV
		 * @param data
		 *            pixel data
		 * @param timestamp
		 *            time-stamp for the image in yyyyMMddHHmmssSSS format
		 * @param tzId
		 *            Time-zone ID
		 */
		public Image(@Min(1) int w, @Min(1) int h, int cvType, byte[] data,
				@Pattern(regexp = "[1-9][0-8]{16}") String timestamp, @NotBlank String tzId) {
			this.width = w;
			this.height = h;
			this.cvType = cvType;
			this.data = data;
			this.timestamp = timestamp;
			this.timeZoneId = tzId;

			// @TODO Needs validation on cvType and the size of data
		}

		/**
		 * @param w
		 *            width of image
		 * @param h
		 *            height of image
		 * @param cvType
		 *            type of the image as CvType of OpenCV
		 * @param data
		 *            pixel data
		 * @param date
		 *            time-stamp for the image
		 * @param tzId
		 *            Time-zone ID
		 */
		public Image(@Min(1) int w, @Min(1) int h, int cvType, byte[] data, Date date, @NotBlank String tzId) {
			FastDateFormat df = FastDateFormat.getInstance("yyyyMMddHHmmssSSS", TimeZone.getTimeZone(tzId));

			this.width = w;
			this.height = h;
			this.cvType = cvType;
			this.data = data;
			this.timestamp = df.format(date);
			this.timeZoneId = tzId;
		}

		public int getWidth() {
			return this.width;
		}

		public int getHeight() {
			return this.height;
		}

		/**
		 * @return integer represents image type as a CvType of OpenCV
		 * @see org.opencv.core.CvType
		 */
		public int getOpenCvType() {
			return this.cvType;
		}

		public byte[] getData() {
			return this.data;
		}

		/**
		 * @return Time-stamp for this image in yyyyMMddHHmmssSSS format
		 */
		public String getTimestamp() {
			return this.timestamp;
		}

		/**
		 * @return TimeZone for the time-stamp of this image
		 * @see java.util.TimeZone#getID()
		 */
		public String getTimeZoneId() {
			return this.timeZoneId;
		}

		/**
		 * Validates this image instance.
		 * <p>
		 * If the either width or height is not positive integer, the type is
		 * not the one among the values defined in
		 * {@link org.opencv.core.CvType}, or the size of the raster data is not
		 * equal with the computed size using width, height and type, this
		 * methods will return {@code false}.
		 *
		 * @return
		 */
		public boolean validate() {
			if (this.getWidth() < 1) {
				return false;
			}
			if (this.getHeight() < 1) {
				return false;
			}

			int eleSz = 0;
			try {
				eleSz = CvType.ELEM_SIZE(this.getOpenCvType());
			} catch (Exception ex) {
				return false;
			}

			if (this.data == null) {
				return false;
			}
			if (this.data.length != this.getWidth() * this.getHeight() * eleSz) {
				return false;
			}

			return true;
		}
	}
}
