package com.skcc.vas.frs.common.biz.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.Validate;

import com.skcc.vas.frs.common.biz.event.EventType;
import com.skcc.vas.frs.common.biz.event.VideoEventType;

/**
 * @author
 *
 */
public class SearchRequest {

	private String id;

	private String name;

	private String type;

	private String userId;

	// @TODO Needs to be set EventType type instead of String.
	private String eventType;

	private String timeType;

	@Pattern(regexp = "[1-9][0-9]{7}")
	private String startDate;

	@Pattern(regexp = "[0-9]{4}")
	private String startTime;

	@Pattern(regexp = "[0-9]{4}")
	private String startTime2;

	@Pattern(regexp = "[1-9][0-9]{7}")
	private String endDate;

	@Pattern(regexp = "[0-9]{4}")
	private String endTime;

	@Pattern(regexp = "[0-9]{4}")
	private String endTime2;

	private float progress;

	private int threshold;

	@Nonnull
	private final List<Cctv> cctvs = new ArrayList<Cctv>();

	public SearchRequest() {
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public SearchRequest setId(String id) {
		this.id = id;
		return this;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public SearchRequest setName(String name) {
		this.name = name;
		return this;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public SearchRequest setType(String type) {
		this.type = type;
		return this;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public SearchRequest setUserId(String userId) {
		this.userId = userId;
		return this;
	}

	public String getEventType() {
		return this.eventType;
	}

	public SearchRequest setEventType(String type) {
		this.eventType = type;
		return this;
	}

	public String getTimeType() {
		return this.timeType;
	}

	public SearchRequest setTimeType(String type) {
		this.timeType = type;
		return this;
	}

	/**
	 * @return the start date in {@code yyyyMMdd} format
	 */
	public String getStartDate() {
		return this.startDate;
	}

	/**
	 * @param startDate
	 *            the start date to set in {@code yyyyMMdd} format
	 */
	public SearchRequest setStartDate(String startDate) {
		this.startDate = startDate;
		return this;
	}

	/**
	 * @return the start time in {@code HHmm} format
	 */
	public String getStartTime() {
		return this.startTime;
	}

	/**
	 * @param startTime
	 *            the start time to set in {@code HHmm} format
	 */
	public SearchRequest setStartTime(String startTime) {
		this.startTime = startTime;
		return this;
	}

	/**
	 * @return the 2nd start time in {@code HHmm} format
	 */
	public String getStartTime2() {
		return this.startTime2;
	}

	/**
	 * @param startTime
	 *            the 2nd start time to set in {@code HHmm} format
	 */
	public SearchRequest setStartTime2(String startTime) {
		this.startTime2 = startTime;
		return this;
	}

	/**
	 * @return the end date in {@code yyyyMMdd} format
	 */
	public String getEndDate() {
		return this.endDate;
	}

	/**
	 * @param endDate
	 *            the end date to set in {@code yyyyMMdd} format
	 */
	public SearchRequest setEndDate(String endDate) {
		this.endDate = endDate;
		return this;
	}

	/**
	 * @return the end time in {@code HHmm} format
	 */
	public String getEndTime() {
		return this.endTime;
	}

	/**
	 * @param endTime
	 *            the end time to set in {@code HHmm} format
	 */
	public SearchRequest setEndTime(String endTime) {
		this.endTime = endTime;
		return this;
	}

	/**
	 * @return the 2nd end time in {@code HHmm} format
	 */
	public String getEndTime2() {
		return this.endTime2;
	}

	/**
	 * @param endTime
	 *            the 2nd end time to set in {@code HHmm} format
	 */
	public SearchRequest setEndTime2(String endTime) {
		this.endTime2 = endTime;
		return this;
	}

	/**
	 * @return start date-time in {@code yyyyMMddHHmm} format
	 */
	public String getStart() {
		if (this.startDate != null && this.startTime != null) {
			return this.startDate + this.startTime;
		} else {
			return null;
		}
	}

	/**
	 * @return 2nd start date-time in {@code yyyyMMddHHmm} format
	 */
	public String getStart2() {
		if (this.startDate != null && this.startTime2 != null) {
			return this.startDate + this.startTime2;
		} else {
			return null;
		}
	}

	/**
	 * @return end date-time in {@code yyyyMMddHHmm} format
	 */
	public String getEnd() {
		if (this.endDate != null && this.endTime != null) {
			return this.endDate + this.endTime;
		} else {
			return null;
		}
	}

	/**
	 * @return 2nd end date-time in {@code yyyyMMddHHmm} format
	 */
	public String getEnd2() {
		if (this.endDate != null && this.endTime2 != null) {
			return this.endDate + this.endTime2;
		} else {
			return null;
		}
	}

	public float getProgress() {
		return progress;
	}

	public void setProgress(float progress) {
		this.progress = progress;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	@Nonnull
	public List<Cctv> getCctvs() {
		return this.cctvs;
	}

	public SearchRequest addCctv(@Nonnull Cctv cctv) {
		if (cctv != null)
			this.cctvs.add(cctv);
		return this;
	}

	public static class Cctv implements java.io.Serializable {

		private String id;

		private String globalId;

		private String systemId;

		@Nonnull
		final private List<Roi> rois = new ArrayList<Roi>();

		public Cctv() {
		}

		public String getId() {
			return this.id;
		}

		public Cctv setId(String id) {
			this.id = id;
			return this;
		}

		public String getGlobalId() {
			return this.globalId;
		}

		public Cctv setGlobalId(String id) {
			this.globalId = id;
			return this;
		}

		public String getSystemId() {
			return systemId;
		}

		public Cctv setSystemId(String systemId) {
			this.systemId = systemId;
			return this;
		}

		@Nonnull
		public List<Roi> getRois() {
			return rois;
		}

		public Cctv addRoi(@Nonnull Roi roi) {
			if (roi != null)
				this.rois.add(roi);
			return this;
		}
	}

	/**
	 * Event type is strongly expected to be defined for each ROI, although the
	 * client specified it at larger scope such as CCTV or search job.
	 *
	 * @author
	 */
	public static class Roi implements java.io.Serializable {

		private int no;

		private EventType eventType;

		private String shapeType;

		private String direction;

		@Nonnull
		private final List<Point> points = new ArrayList<Point>();

		@Nonnull
		private final List<Param<Float>> params = new ArrayList<Param<Float>>();

		public Roi() {
		}

		/**
		 * @return the no
		 */
		public int getNo() {
			return no;
		}

		/**
		 * @param no
		 *            the no to set
		 */
		public Roi setNo(int no) {
			this.no = no;
			return this;
		}

		/**
		 * @return the eventType
		 */
		public EventType getEventType() {
			return eventType;
		}

		/**
		 * @param eventType
		 *            the eventType to set
		 */
		public Roi setEventType(EventType eventType) {
			this.eventType = eventType;
			return this;
		}

		/**
		 * @return the shapeType
		 */
		public String getShapeType() {
			return shapeType;
		}

		/**
		 * @param shapeType
		 *            the shapeType to set
		 */
		public Roi setShapeType(String shapeType) {
			this.shapeType = shapeType;
			return this;
		}

		/**
		 * @return the direction
		 */
		public String getDirection() {
			return direction;
		}

		/**
		 * @param direction
		 *            the direction to set
		 */
		public Roi setDirection(String direction) {
			this.direction = direction;
			return this;
		}

		/**
		 * @return the points
		 */
		@Nonnull
		public List<Point> getPoints() {
			return points;
		}

		public Roi addPoint(@Nonnull Point pt) {
			if (pt != null)
				this.points.add(pt);
			return this;
		}

		/**
		 * @return the params
		 */
		@Nonnull
		public List<Param<Float>> getParams() {
			return params;
		}

		public Roi addParam(@Nonnull Param<Float> param) {
			if (param != null)
				this.params.add(param);
			return this;
		}

	}

	public static class Point implements java.io.Serializable {

		private int no;

		private float x;

		private float y;

		public Point() {
		}

		public int getNo() {
			return this.no;
		}

		public Point setNo(int no) {
			this.no = no;
			return this;
		}

		public float getX() {
			return this.x;
		}

		public Point setX(float x) {
			this.x = x;
			return this;
		}

		public float getY() {
			return this.y;
		}

		public Point setY(float y) {
			this.y = y;
			return this;
		}

	}

	public static class Param<T> {

		private int no;

		private T value;

		public Param() {
		}

		public int getNo() {
			return this.no;
		}

		public Param<T> setNo(int no) {
			this.no = no;
			return this;
		}

		public T getValue() {
			return this.value;
		}

		public Param<T> setValue(T val) {
			this.value = val;
			return this;
		}

	}

	// @TODO Move static methods for TEST programs to test scope class such as
	// TestUtils.
	/**
	 * Note that this methods is only for <strong>TEST</strong> programs.
	 * <p>
	 * Gets a new {@code SearchRequest} instance with a single CCTV and a single
	 * rectangular ROI.
	 *
	 * @return
	 */
	public static SearchRequest createSampleSearchRequest(String id, String name, String userId, String eventType,
			String startDate, String startTime, String endDate, String endTime, String sysId, String cctvId,
			String cctvGlobalId, String roiShapeType, String roiDirection, float roiX0, float roiY0, float roiX1,
			float roiY1) {

		SearchRequest req = new SearchRequest().setId(id).setName(name).setUserId(userId).setType("ADHOC")
				.setEventType(eventType).setTimeType("CONTINUOUS").setStartDate(startDate).setEndDate(endDate)
				.setStartTime(startTime).setEndTime(endTime);

		Cctv cctv = new Cctv().setId(cctvId).setSystemId(sysId).setGlobalId(cctvGlobalId);
		req.addCctv(cctv);

		List<Param> params = getDefaultParams(VideoEventType.valueOf(eventType));
		float[] params2 = new float[params.size()];
		for (int i = 0, n = params.size(); i < n; i++) {
			params2[i] = (Float) params.get(i).getValue();
		}

		Roi roi = getSingleRectRoi(0, VideoEventType.valueOf(eventType), roiShapeType, roiDirection, roiX0, roiY0,
				roiX1, roiY1, params2);
		cctv.addRoi(roi);

		return req;
	}

	/**
	 * Note that this methods is only for <strong>TEST</strong> programs.
	 * <p>
	 * Creates {@link Roi} object whose {@code no} is {@code 0}, event type is
	 * {@link VideoEventType#INTRUSION} and area is entire frame.
	 *
	 *
	 * @return
	 */
	public static Roi getSimplestRoi() {
		return getSimplestRoi(0);
	}

	/**
	 * Note that this methods is only for <strong>TEST</strong> programs.
	 * <p>
	 * Creates {@link Roi} object whose {@code no} is a specified one, event
	 * type is {@link VideoEventType#INTRUSION} and area is entire frame.
	 *
	 * @param no
	 *            the {@code no} of the roi created. 0-base
	 * @return
	 */
	public static Roi getSimplestRoi(@Min(0) int no) {
		Validate.isTrue(no >= 0, "Roi no shoud be non-negative.");

		Point[] pts = new Point[4];
		pts[0] = new Point().setNo(0).setX(0.0f).setY(0.0f);
		pts[1] = new Point().setNo(1).setX(0.0f).setY(1.0f);
		pts[2] = new Point().setNo(2).setX(1.0f).setY(1.0f);
		pts[3] = new Point().setNo(3).setX(1.0f).setY(0.0f);

		Param<Float>[] params = new Param[4];
		params[0] = new Param<Float>().setNo(0).setValue(0.03f);
		params[1] = new Param<Float>().setNo(1).setValue(0.06f);
		params[2] = new Param<Float>().setNo(2).setValue(0.2f);
		params[3] = new Param<Float>().setNo(3).setValue(0.4f);

		Roi roi = new Roi().setNo(no).setShapeType("AREA").setDirection("1");

		for (Point pt : pts) {
			roi.addPoint(pt);
		}
		for (Param param : params) {
			roi.addParam(param);
		}

		return roi;
	}

	/**
	 * Note that this methods is only for <strong>TEST</strong> programs.
	 * <p>
	 * Gets the default ROI parameters according to the specified event type.
	 * Currently this method covers only SKT VA engine.
	 *
	 * @param type
	 * @return
	 */
	@Nonnull
	public static List<Param> getDefaultParams(VideoEventType type) {

		final List<Param> params = new ArrayList<Param>();

		switch (type) {
			case CAMERA_TAMPERING :
				// no parameter is expected for camera tampering
				break;
			case CROWD_DENSITY :
				// no parameter is expected for camera tampering
				break;
			case INTRUSION :
				// 4 parameters are expected
				params.add(new Param<Float>().setNo(0).setValue(0.03f)); // minimum
																			// width
																			// of
																			// object
																			// (0~1)
				params.add(new Param<Float>().setNo(1).setValue(0.06f)); // minimum
																			// height
																			// of
																			// object
																			// (0~1)
				params.add(new Param<Float>().setNo(2).setValue(0.2f)); // maximum
																		// width
																		// of
																		// object
																		// (0~1)
				params.add(new Param<Float>().setNo(3).setValue(0.4f)); // maximum
																		// height
																		// of
																		// object
																		// (0~1)
				break;
			case PEOPLE_COUNT :
				// 2 parameters are expected
				params.add(new Param<Float>().setNo(0).setValue(0.1f)); // one
																		// person’s
																		// width
																		// (0~1)
				params.add(new Param<Float>().setNo(0).setValue(0.1f)); // one
																		// person’s
																		// height
																		// (0~1)
				break;
			default :
				break;
		}

		return params;
	}

	public static Roi getSingleRectRoi(int no, EventType type, String shapeType, String direction, float x0, float y0,
			float x1, float y1, float... params) {
		Point[] pts = new Point[4];
		pts[0] = new Point().setNo(0).setX(x0).setY(y0);
		pts[1] = new Point().setNo(1).setX(x1).setY(y0);
		pts[2] = new Point().setNo(2).setX(x1).setY(y1);
		pts[3] = new Point().setNo(3).setX(x0).setY(y1);

		Roi roi = new Roi().setNo(no).setEventType(type).setShapeType(shapeType).setDirection(direction);

		for (Point pt : pts) {
			roi.addPoint(pt);
		}
		Param<Float> param = null;
		for (int i = 0; i < params.length; i++) {
			param = new Param<Float>().setNo(i).setValue(params[i]);
			roi.addParam(param);
		}

		return roi;
	}

}
