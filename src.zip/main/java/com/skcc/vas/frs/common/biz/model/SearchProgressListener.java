package com.skcc.vas.frs.common.biz.model;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

import com.skcc.vas.frs.common.util.base.JobStatus;
import com.skcc.vas.frs.common.util.base.TaskStatus;

/**
 * @author
 * @since 2016-07-27
 *
 */
@ParametersAreNonnullByDefault
public interface SearchProgressListener {

	/**
	 * @param jobId
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void jobAccepted(@NotBlank String jobId, @Min(0) long when);

	/**
	 * @param jobId
	 * @param tasks
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void jobStarted(@NotBlank String jobId, @Min(0) int tasks, @Min(0) long when);

	/**
	 * @param jobId
	 * @param taskId
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void taskStarted(@NotBlank String jobId, @NotBlank String taskId, @Min(0) long when);

	/**
	 * @param jobId
	 * @param taskId
	 * @param numberator
	 * @param denominator
	 * @param exceptions
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void setTaskProgress(@NotBlank String jobId, @NotBlank String taskId, @Min(0) int numberaor,
			@Min(1) int denominator, @Min(0) int exceptions, @Min(0) long when);

	/**
	 * @param jobId
	 * @param taskId
	 * @param status
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void taskFinished(@NotBlank String jobId, @NotBlank String taskId, @Nullable TaskStatus status, @Min(0) long when);

	/**
	 * @param jobId
	 * @param taskId
	 * @param status
	 * @param message
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void taskFinished(@NotBlank String jobId, @NotBlank String taskId, @Nullable TaskStatus status,
			@Nullable String message, @Min(0) long when);

	/**
	 * @param jobId
	 * @param status
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void jobFinished(@NotBlank String jobId, @Nullable JobStatus status, @Min(0) long when);

	/**
	 * @param jobId
	 * @param status
	 * @param message
	 * @param when
	 *            POSIX time in milliseconds
	 */
	void jobFinished(@NotBlank String jobId, @Nullable JobStatus status, @Nullable String message, @Min(0) long when);

}
