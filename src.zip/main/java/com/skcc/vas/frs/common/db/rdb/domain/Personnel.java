package com.skcc.vas.frs.common.db.rdb.domain;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Pattern;

/**
 * @author Hong yongman
 * @since 2016-03-08
 *
 */
public class Personnel {

	private String id;

	public String getId() {
		return id;
	}

	public Personnel setId(String id) {
		this.id = id;
		return this;
	}

	private String name;

	public String getName() {
		return name;
	}

	public Personnel setName(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Determines whether this personnel is valid or not regardless of the time
	 * interval defined by {@link #validFrom} and {@link #validTo}.
	 */
	private boolean isValid = true;

	/**
	 * Gets the validity of this personnel which determines the validity
	 * regardless of the time interval defined by {@link #getValidFrom()} and
	 * {@link #getValidTo()}.
	 *
	 * @return
	 */
	public boolean isValid() {
		return isValid;
	}

	public Personnel setValid(boolean isValid) {
		this.isValid = isValid;
		return this;
	}

	@Pattern(regexp = "[1-9][0-9]{11}")
	private String validFrom;

	/**
	 * @return the start time of the allowed time interval in 'yyyyMMddHHmm'
	 *         format
	 */
	public String getValidFrom() {
		return validFrom;
	}

	public Personnel setValidFrom(String validFrom) {
		this.validFrom = validFrom;
		return this;
	}

	@Pattern(regexp = "[1-9][0-9]{11}")
	private String validTo;

	/**
	 * @return the end time of the allowed time interval in 'yyyyMMddHHmm'
	 *         format
	 */
	public String getValidTo() {
		return validTo;
	}

	public Personnel setValidTo(String validTo) {
		this.validTo = validTo;
		return this;
	}

	private String passNo;

	public String getPassNo() {
		return passNo;
	}

	public Personnel setPassNo(String passNo) {
		this.passNo = passNo;
		return this;
	}

	/**
	 * the company, organization, or institute where the personnel is working
	 * for
	 */
	@Nullable
	private String company;

	public String getCompany() {
		return company;
	}

	public Personnel setCompany(String company) {
		this.company = company;
		return this;
	}

	/**
	 * the telephone (usually mobile telephone) number of this personnel
	 */
	@Nullable
	private String telephone;

	public String getTelephone() {
		return telephone;
	}

	public Personnel setTelephone(String telephone) {
		this.telephone = telephone;
		return this;
	}

	@Nullable
	private String personnelId;

	public String getPersonnelId() {
		return personnelId;
	}

	public Personnel setPersonnelId(String personnelId) {
		this.personnelId = personnelId;
		return this;
	}

	/**
	 * remarks for the personnel such as the purpose of the visit, related
	 * event, more details on the personnel and so on.
	 */
	@Nullable
	private String remarks;

	public String getRemarks() {
		return remarks;
	}

	public Personnel setRemarks(String remarks) {
		this.remarks = remarks;
		return this;
	}

	private byte[] img;

	public byte[] getImg() {
		return img;
	}

	public Personnel setImg(byte[] img) {
		this.img = img;
		return this;
	}

	public Personnel() {
		// TODO Auto-generated constructor stub
	}

	private final List<PersonnelFace> faces = new ArrayList<PersonnelFace>();

	@Nonnull
	public List<PersonnelFace> getFaces() {
		return this.faces;
	}

	public Personnel addFace(@Nonnull PersonnelFace face) {
		this.faces.add(face);
		return this;
	}

	public Personnel removeAllFaces() {
		this.faces.clear();
		return this;
	}

}
