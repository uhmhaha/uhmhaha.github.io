package com.skcc.vas.frs.common.util.base;

/**
 * Represents well-known extension for image files such as JPEG, PNG, GIF et al.
 *
 * @author
 *
 */
public enum ImageFormat {

	JPEG("jpg"), PNG("png"), GIF("gif"), BMP("bmp");

	/**
	 * File name extension for this format
	 */
	private final String ext;

	private ImageFormat(String ext) {
		this.ext = ext;
	}

	public String getExtension() {
		return this.ext;
	}

}
