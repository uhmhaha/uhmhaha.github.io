package com.skcc.vas.frs.common.db.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.apache.ibatis.annotations.Param;
import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.skcc.vas.frs.common.biz.event.AccessEvent;
import com.skcc.vas.frs.common.biz.model.AnalyticFace;
import com.skcc.vas.frs.common.db.nosql.domain.NConcernPersonAndFace;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFace;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceAndMatchWithProfile;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatch;
import com.skcc.vas.frs.common.db.nosql.service.DetectedFaceService;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedRoi;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;
import com.skcc.vas.frs.matching.biz.MongoTemplateManager;
import com.skcc.vas.frs.common.db.rdb.domain.Personnel;
import com.skcc.vas.frs.common.db.rdb.domain.PersonnelFace;
import com.skcc.vas.frs.common.db.rdb.domain.Visitor;
import com.skcc.vas.frs.common.db.rdb.domain.VisitorFace;
import com.skcc.vas.frs.common.db.rdb.service.ConcernPersonAndFaceService;
import com.skcc.vas.frs.common.db.rdb.service.DetectedFaceAndLowMatchWithProfileService;
import com.skcc.vas.frs.common.db.rdb.service.DetectedFaceAndMatchWithProfileService;
import com.skcc.vas.frs.common.db.rdb.service.DetectedFaceMatchService;
import com.skcc.vas.frs.common.db.repository.AccessEventMapper;
import com.skcc.vas.frs.common.db.repository.CctvServiceMapper;
import com.skcc.vas.frs.common.db.repository.ConcernedFaceMapper;
import com.skcc.vas.frs.common.db.repository.ConcernedFaceMatchMapper;
import com.skcc.vas.frs.common.db.repository.ConcernedPersonMapper;
import com.skcc.vas.frs.common.db.repository.DetectedFaceMapper;
import com.skcc.vas.frs.common.db.repository.PersonnelFaceMapper;
import com.skcc.vas.frs.common.db.repository.PersonnelMapper;
import com.skcc.vas.frs.common.db.repository.PersonnelMatchMapper;
import com.skcc.vas.frs.common.db.repository.VisitorFaceMapper;
import com.skcc.vas.frs.common.db.repository.VisitorMapper;
import com.skcc.vas.frs.common.db.repository.VisitorMatchMapper;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;
import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.akka.db.rdb.domain.Node;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandDBSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVMSSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVideoSubJobVO;
import com.skcc.vas.frs.akka.db.repository.NodeMapper;

/**
 * @author
 *
 */
@ParametersAreNonnullByDefault
public class FaceDataManager {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private final ConcernedPersonMapper concernedPersonMapper;

	private final ConcernedFaceMapper concernedFaceMapper;

	private final DetectedFaceMapper detectedFaceMapper;

	private final ConcernedFaceMatchMapper concernedFaceMatchMapper;

	private final VisitorMapper visitorMapper;

	private final VisitorFaceMapper visitorFaceMapper;

	private final VisitorMatchMapper visitorMatchMapper;

	private final PersonnelMapper personnelMapper;

	private final PersonnelFaceMapper personnelFaceMapper;

	private final PersonnelMatchMapper personnelMatchMapper;

	private final AccessEventMapper accessEventMapper;

	private final DetectedFaceService detectedFaceService;

	private final DetectedFaceMatchService detectedFaceMatchService;

	private final ConcernPersonAndFaceService concernPersonAndFaceService;

	private final DetectedFaceAndMatchWithProfileService detectedFaceAndMatchWithProfileService;

	private final DetectedFaceAndLowMatchWithProfileService detectedFaceAndLowMatchWithProfileService;

	private final CctvServiceMapper cctvServiceMapper;

	private MongoTemplateManager mongoTemplateManager;

	private long queryTime = 0;

	/*
	 * AKKA에서 node 동적 상태 관리시에 사용되는 mapper VAS_NODE_SRVC table에 대한 DB CRUD
	 */
	private final NodeMapper nodeMapper;

	// private final DeviceMapper deviceMapper;

	// @TODO Remove deprecated mappers (2016-02-02, Sangmoon Oh)

	public FaceDataManager(ConcernedPersonMapper concernedPersonMapper, ConcernedFaceMapper concernedFaceMapper,
			DetectedFaceMapper detectedFaceMapper, ConcernedFaceMatchMapper concernedFaceMatchMapper,
			PersonnelMapper personnelMapper, PersonnelFaceMapper personnelFaceMapper,
			PersonnelMatchMapper personnelMatchMapper, VisitorMapper visitorMapper,
			VisitorFaceMapper visitorFaceMapper, VisitorMatchMapper visitorMatchMapper,
			AccessEventMapper accessEventMapper, CctvServiceMapper cctvServiceMapper,
			DetectedFaceService detectedFaceService, DetectedFaceMatchService detectedFaceMatchService,
			NodeMapper nodeMapper, ConcernPersonAndFaceService concernPersonAndFaceService,
			DetectedFaceAndMatchWithProfileService detectedFaceAndMatchWithProfileService,
			DetectedFaceAndLowMatchWithProfileService detectedFaceAndLowMatchWithProfileService) {

		this.concernedPersonMapper = concernedPersonMapper;
		this.concernedFaceMapper = concernedFaceMapper;
		this.detectedFaceMapper = detectedFaceMapper;
		this.concernedFaceMatchMapper = concernedFaceMatchMapper;
		this.personnelMapper = personnelMapper;
		this.personnelFaceMapper = personnelFaceMapper;
		this.personnelMatchMapper = personnelMatchMapper;
		this.visitorMapper = visitorMapper;
		this.visitorFaceMapper = visitorFaceMapper;
		this.visitorMatchMapper = visitorMatchMapper;
		this.accessEventMapper = accessEventMapper;
		this.cctvServiceMapper = cctvServiceMapper;
		// this.deviceMapper = deviceMapper;
		this.detectedFaceService = detectedFaceService;
		this.detectedFaceMatchService = detectedFaceMatchService;
		this.nodeMapper = nodeMapper;
		this.concernPersonAndFaceService = concernPersonAndFaceService;
		this.detectedFaceAndMatchWithProfileService = detectedFaceAndMatchWithProfileService;
		this.detectedFaceAndLowMatchWithProfileService = detectedFaceAndLowMatchWithProfileService;
	}

	/**
	 * @param personId
	 * @since 1.1
	 */
	@Transactional
	public void removeConcernedPerson(String personId) {
		this.concernedPersonMapper.setValidity(personId, false);
		this.concernedFaceMapper.setValidityByPerson(personId, false);
	}

	@Transactional
	public ConcernedFace findConcernedFaceById(String faceId) {
		return this.concernedFaceMapper.selectConcernedFaceById(faceId);
	}

	@Transactional
	public byte[] findConcernedFaceImageBinaryByCncrnfaceId(String cncrnfaceId) {
		Map<String, Object> result = this.concernedFaceMapper.selectACncrnImageBinary(cncrnfaceId);
		return (byte[]) result.get("img");
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public List<ConcernedFace> findValidConcernedFaces() {
		long tm = 0;
		if (this.logger.isInfoEnabled()) {
			this.logger
			.debug("Starting to find all active concerned faces. It may takes a few minutes depending the number of concerened faces.");
			tm = System.currentTimeMillis();
		}

		List<ConcernedFace> faces = this.concernedFaceMapper.selectValidConcernedFaces();

		if (this.logger.isDebugEnabled()) {
			tm = System.currentTimeMillis() - tm;
			this.logger.debug("Finished finding all {} active concerned faces in {} milli-seconds", faces.size(), tm);
		}

		return faces;
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public Map<String, String> findConcernedFaceVolume(String nodeId) {

		Map<String, String> volumeInfo = this.concernedFaceMapper.selectConcernedFaceVolume(nodeId);

		return volumeInfo;
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public List<ConcernedFace> findValidScopeConcernedFaces(String from, String to) {
		long tm = 0;
		if (this.logger.isInfoEnabled()) {
			this.logger
			.debug("Starting to find all active concerned faces. It may takes a few minutes depending the number of concerened faces.");
			tm = System.currentTimeMillis();
		}

		HashMap param = new HashMap<String, String>();
		param.put("from_idx", from);
		param.put("to_idx", to);
		logger.info("findValidScopeConcernedFaces from : {}, to :{} ", from, to);

		List<ConcernedFace> faces = this.concernedFaceMapper.selectValidScopeConcernedFaces(param);

		if (this.logger.isDebugEnabled()) {
			tm = System.currentTimeMillis() - tm;
			this.logger.debug("Finished finding all {} active concerned faces in {} milli-seconds", faces.size(), tm);
		}

		return faces;
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public int findAllValidConcernedFacesCount() {
		long tm = 0;
		if (this.logger.isInfoEnabled()) {
			this.logger
			.debug("Starting to find all active concerned faces count. It may takes a few minutes depending the number of concerened faces.");
			tm = System.currentTimeMillis();
		}

		String facesCount = this.concernedFaceMapper.selectAllValidConcernedFacesCount();

		if (this.logger.isDebugEnabled()) {
			tm = System.currentTimeMillis() - tm;
			this.logger.debug("Finished finding all {} active concerned faces count in {} milli-seconds", facesCount,
					tm);
		}

		return Integer.parseInt(facesCount);
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public List<AnalyticFace> findValidConceredFeatures() {
		long tm = 0;
		if (this.logger.isInfoEnabled()) {
			this.logger
			.debug("Starting to find all active concerned features. It may takes a few minutes depending the number of concerened faces.");
			tm = System.currentTimeMillis();
		}

		List<AnalyticFace> faces = this.concernedFaceMapper.selectValidConcernedFeatures();

		if (this.logger.isDebugEnabled()) {
			tm = System.currentTimeMillis() - tm;
			this.logger.debug("Finished finding all {} active concerned faces in {} milli-seconds", faces.size(), tm);
		}

		return faces;
	}

	@Nonnull
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public List<ConcernedFace> findOnlyValidConcernedFaces() {
		long tm = 0;
		if (this.logger.isInfoEnabled()) {
			this.logger
			.debug("Starting to find all active concerned faces. It may takes a few minutes depending the number of concerened faces.");
			tm = System.currentTimeMillis();
		}

		List<ConcernedFace> faces = this.concernedFaceMapper.selectOnlyValidConcernedFaces();

		if (this.logger.isDebugEnabled()) {
			tm = System.currentTimeMillis() - tm;
			this.logger.debug("Finished finding all {} active concerned faces in {} milli-seconds", faces.size(), tm);
		}

		return faces;
	}

	/**
	 * @param personId
	 *            the ID of concerned person
	 * @param activeOnly
	 *            when {@code true}, the selection include only active faces
	 */
	@Transactional
	public List<ConcernedFace> findConcernedFacesWithoutMetaByPerson(String personId, boolean activeOnly) {
		return this.concernedFaceMapper.selectConcernedFacesWithoutMetaByPerson(personId, activeOnly);
	}

	@Transactional
	public int addConcernedFace(ConcernedFace concernedFace) {
		return this.concernedFaceMapper.insertConcernedFace(concernedFace);
	}

	@Transactional
	public void updateConcernedFace(ConcernedFace concernedFace) {
		this.concernedFaceMapper.updateConcernedFace(concernedFace);
	}

	@Transactional
	public void setMetaOfConcernedFace(String faceId, @NotEmpty byte[] feature, @Nullable String landmarks) {

		Validate.isTrue(ArrayUtils.isNotEmpty(feature), "");
		this.concernedFaceMapper.setMetaOfConcernedFace(faceId, feature, landmarks);

	}

	@Deprecated
	@Transactional
	public void setConcernedFaceFeature(int id, @Nonnull byte[] feature) {
		this.concernedFaceMapper.updateFeatureExtracted(id, feature);
	}

	/**
	 *
	 * @param person_id
	 *            관심인물id
	 * @param id
	 *            img seq
	 * @param feature
	 *            사진관련 특징정보
	 *
	 * @author 06740 skyang
	 * @since Added 2016-04-18
	 */
	@Deprecated
	@Transactional
	public void setConcernedFaceFeature(int personId, int faceId, @Nonnull byte[] feature) {
		this.concernedFaceMapper.updateFaceFeatureInfo(personId, faceId, feature);
	}

	@Transactional
	public void removeConcernedFaces(@Nonnull String[] faceIds) {
		Validate.isTrue(faceIds != null, "The array of IDs to remove shouldn't be null.");
		for (String id : faceIds) {
			this.concernedFaceMapper.setValidity(id, false);
		}
	}

	@Transactional
	public void addConcernedFaceMatches(String detectedFaceId, @Nonnull List<Pair<String, Integer>> matches) {

		if (CollectionUtils.isEmpty(matches)) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return;
		}

		int rank = 1;
		Pair<String, Integer> match = null;
		for (int i = 0; i < matches.size(); i++) {
			match = matches.get(i);

			concernedFaceMatchMapper.insertConcernedFaceMatch(match.getLeft(), detectedFaceId, match.getRight(), i + 1,
					null);
		}
		this.logger.debug("Successfully saved {} Concerned face matches", matches.size());
	}

	/**
	 * @param personId
	 *            the ID of concerned person
	 * @param activeOnly
	 *            when {@code true}, the selection include only active faces
	 */
	@Transactional
	public List<ConcernedFace> findConcernedFacesByJobId(String jobId) {
		return this.concernedFaceMapper.selectConcernedFacesByJobId(jobId);
	}

	/**
	 * @param personId
	 *            the ID of concerned person
	 */
	@Transactional
	public List<String> findConcernedFaceIdsByPersonId(String personId) {

		List<String> faceIds = new ArrayList<String>();
		List<ConcernedFace> concernedFaces = this.concernedFaceMapper.selectConcernedFaceIdsByPersonId(personId);

		for (int i = 0; i < concernedFaces.size(); i++) {
			faceIds.add(concernedFaces.get(i).getId());
		}

		return faceIds;
	}

	public void addNConcernedFaceMatchWithProfile(DetectedFace detectedFace,
			List<NDetectedFaceMatch> nDetectedFaceMatchs) throws Exception {

		if (nDetectedFaceMatchs == null) {
			NDetectedFaceAndMatchWithProfile nDetectedFaceNoMatchAndProfile = new NDetectedFaceAndMatchWithProfile();

			nDetectedFaceNoMatchAndProfile.setDETECTED_FACE_ID(detectedFace.getId()); // be
			// caution!!
			nDetectedFaceNoMatchAndProfile.setSYSTEM_ID(detectedFace.getSystemId());
			nDetectedFaceNoMatchAndProfile.setCCTV_ID(detectedFace.getCctvId());
			nDetectedFaceNoMatchAndProfile.setSRVC_TYPE(detectedFace.getSrvcType());
			nDetectedFaceNoMatchAndProfile.setIMG_FILE(detectedFace.getImgFile());
			nDetectedFaceNoMatchAndProfile.setIMG_W(detectedFace.getImgWidth());
			nDetectedFaceNoMatchAndProfile.setIMG_H(detectedFace.getImgHeight());
			nDetectedFaceNoMatchAndProfile.setIMG_X(detectedFace.getImgX());
			nDetectedFaceNoMatchAndProfile.setIMG_Y(detectedFace.getImgY());
			nDetectedFaceNoMatchAndProfile.setDF_FEATURE(new Binary(detectedFace.getFeature()));
			nDetectedFaceNoMatchAndProfile.setFRM_FILE(detectedFace.getFrmFile());
			nDetectedFaceNoMatchAndProfile.setFRM_W(detectedFace.getFrmWidth());
			nDetectedFaceNoMatchAndProfile.setFRM_H(detectedFace.getFrmHeight());
			nDetectedFaceNoMatchAndProfile.setFRM_TIME(detectedFace.getFrmTime());
			nDetectedFaceNoMatchAndProfile.setDETECTED_DATE(BaseUtils.formatToYear2DayString(new java.util.Date()));
			nDetectedFaceNoMatchAndProfile.setLAST_UPDATE_AT(detectedFace.getLastUpdateAt());

			detectedFaceAndMatchWithProfileService
			.insertDetectedFaceAndMatchWithProfile(nDetectedFaceNoMatchAndProfile);

			logger.info("insert only DetectedFace: {}", nDetectedFaceNoMatchAndProfile);

		} else {

			for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
				NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfile = new NDetectedFaceAndMatchWithProfile();

				nDetectedFaceAndMatchWithProfile.setDETECTED_FACE_ID(nDetectedFaceMatch.getDetectedFaceId());
				nDetectedFaceAndMatchWithProfile.setSYSTEM_ID(nDetectedFaceMatch.getSystemId());
				nDetectedFaceAndMatchWithProfile.setCCTV_ID(nDetectedFaceMatch.getCctvId());
				nDetectedFaceAndMatchWithProfile.setSRVC_TYPE(nDetectedFaceMatch.getSrvcType());
				nDetectedFaceAndMatchWithProfile.setIMG_FILE(nDetectedFaceMatch.getImgFile());
				nDetectedFaceAndMatchWithProfile.setIMG_W(nDetectedFaceMatch.getImgW());
				nDetectedFaceAndMatchWithProfile.setIMG_H(nDetectedFaceMatch.getImgH());
				nDetectedFaceAndMatchWithProfile.setIMG_X(nDetectedFaceMatch.getImgX());
				nDetectedFaceAndMatchWithProfile.setIMG_Y(nDetectedFaceMatch.getImgY());
				nDetectedFaceAndMatchWithProfile.setDF_FEATURE(nDetectedFaceMatch.getFeature());
				nDetectedFaceAndMatchWithProfile.setFRM_FILE(nDetectedFaceMatch.getFrmFile());
				nDetectedFaceAndMatchWithProfile.setFRM_W(nDetectedFaceMatch.getFrmW());
				nDetectedFaceAndMatchWithProfile.setFRM_H(nDetectedFaceMatch.getFrmH());
				nDetectedFaceAndMatchWithProfile.setFRM_TIME(nDetectedFaceMatch.getFrmTime());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_AT(nDetectedFaceMatch.getLastUpdateAt());
				nDetectedFaceAndMatchWithProfile.setDETECTED_DATE(nDetectedFaceMatch.getDetectedDate());
				nDetectedFaceAndMatchWithProfile.setCNCRN_FACE_ID(nDetectedFaceMatch.getCncrnFaceId());
				nDetectedFaceAndMatchWithProfile.setSCORE(nDetectedFaceMatch.getScore());
				nDetectedFaceAndMatchWithProfile.setRANK(nDetectedFaceMatch.getRank());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_BY(nDetectedFaceMatch.getLastUpdateMatchBy());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_AT(nDetectedFaceMatch.getLastUpdateMatchAt());

				// profile 조회
				// NConcernPersonAndFace nConcernPersonAndFace = null;
				// nConcernPersonAndFace =
				// concernPersonAndFaceService.selectConcernPersonAndFaceByCncrnFaceId(nDetectedFaceMatch.getCncrnFaceId());
				NConcernPersonAndFace nConcernPersonAndFace = null;
				nConcernPersonAndFace = concernedFaceMapper.seleectConcernedFaceAndPerson(nDetectedFaceMatch
						.getCncrnFaceId());

				if (nConcernPersonAndFace != null) {
					logger.info("1>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}, {}",
							nConcernPersonAndFace.getPersonId(), nDetectedFaceMatch.getScore());
					nDetectedFaceAndMatchWithProfile.setPERSON_ID(nConcernPersonAndFace.getPersonId());
					nDetectedFaceAndMatchWithProfile.setNAME(nConcernPersonAndFace.getName());
					nDetectedFaceAndMatchWithProfile.setGENDER(nConcernPersonAndFace.getGender());
					nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(nConcernPersonAndFace.getConcernType());
					nDetectedFaceAndMatchWithProfile.setCP_IS_VALID(nConcernPersonAndFace.getIsValid());
					nDetectedFaceAndMatchWithProfile.setCP_REMARKS(nConcernPersonAndFace.getCpRemarks());
					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_AT(nConcernPersonAndFace.getLastUpdateAt());
					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_BY(nConcernPersonAndFace.getLastUpdateBy());
					nDetectedFaceAndMatchWithProfile.setBIRTHDAY(nConcernPersonAndFace.getBirthday());
					nDetectedFaceAndMatchWithProfile.setNATIONALITY(nConcernPersonAndFace.getNationality());
					nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(nConcernPersonAndFace.getPassportNo());
					nDetectedFaceAndMatchWithProfile.setFIRST_NAME(nConcernPersonAndFace.getFirstName());
					nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(nConcernPersonAndFace.getMiddleName());
					nDetectedFaceAndMatchWithProfile.setLAST_NAME(nConcernPersonAndFace.getLastName());
					nDetectedFaceAndMatchWithProfile.setFACE_ID(nConcernPersonAndFace.getfaceId());
					nDetectedFaceAndMatchWithProfile.setCF_IS_VALID(nConcernPersonAndFace.getIsValidFace());
					// nDetectedFaceAndMatchWithProfile.setImg(nConcernPersonAndFace.getImg());
					nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(nConcernPersonAndFace.getImgFormat());
					if (nConcernPersonAndFace.getImgH() != null) {
						nDetectedFaceAndMatchWithProfile.setCF_IMG_H(Integer.parseInt(nConcernPersonAndFace.getImgH()));
					}

					if (nConcernPersonAndFace.getImgW() != null) {
						nDetectedFaceAndMatchWithProfile.setCF_IMG_W(Integer.parseInt(nConcernPersonAndFace.getImgW()));
					}
					// nDetectedFaceAndMatchWithProfile.setCfFeature(nConcernPersonAndFace.getFeature());
					nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(nConcernPersonAndFace.getLandmarks());
					nDetectedFaceAndMatchWithProfile.setREMARKS(nConcernPersonAndFace.getCfRemarks());
					nDetectedFaceAndMatchWithProfile.setIMG_PATH(nConcernPersonAndFace.getImgPath());
				}

				detectedFaceAndMatchWithProfileService
				.insertDetectedFaceAndMatchWithProfile(nDetectedFaceAndMatchWithProfile);

				logger.info("insert DetectedFace, Match and profile: {}", nDetectedFaceAndMatchWithProfile);
			}
		}
	}

	public void addNConcernedFaceMatchWithProfile(DetectedFace detectedFace,
			List<NDetectedFaceMatch> nDetectedFaceMatchs, 
			MongoTemplateManager mongoTemplateManager, List<ConcernedFace> faces) throws Exception {

		if (nDetectedFaceMatchs == null) {
			NDetectedFaceAndMatchWithProfile nDetectedFaceNoMatchAndProfile = new NDetectedFaceAndMatchWithProfile();

			nDetectedFaceNoMatchAndProfile.setDETECTED_FACE_ID(detectedFace.getId()); // be
			// caution!!
			nDetectedFaceNoMatchAndProfile.setSYSTEM_ID(detectedFace.getSystemId());
			nDetectedFaceNoMatchAndProfile.setCCTV_ID(detectedFace.getCctvId());
			nDetectedFaceNoMatchAndProfile.setSRVC_TYPE(detectedFace.getSrvcType());
			nDetectedFaceNoMatchAndProfile.setIMG_FILE(detectedFace.getImgFile());
			nDetectedFaceNoMatchAndProfile.setIMG_W(detectedFace.getImgWidth());
			nDetectedFaceNoMatchAndProfile.setIMG_H(detectedFace.getImgHeight());
			nDetectedFaceNoMatchAndProfile.setIMG_X(detectedFace.getImgX());
			nDetectedFaceNoMatchAndProfile.setIMG_Y(detectedFace.getImgY());
			nDetectedFaceNoMatchAndProfile.setDF_FEATURE(new Binary(detectedFace.getFeature()));
			nDetectedFaceNoMatchAndProfile.setFRM_FILE(detectedFace.getFrmFile());
			nDetectedFaceNoMatchAndProfile.setFRM_W(detectedFace.getFrmWidth());
			nDetectedFaceNoMatchAndProfile.setFRM_H(detectedFace.getFrmHeight());
			nDetectedFaceNoMatchAndProfile.setFRM_TIME(detectedFace.getFrmTime());
			nDetectedFaceNoMatchAndProfile.setDETECTED_DATE(BaseUtils.formatToYear2DayString(new java.util.Date()));
			nDetectedFaceNoMatchAndProfile.setLAST_UPDATE_AT(detectedFace.getLastUpdateAt());

			detectedFaceAndMatchWithProfileService
			.insertDetectedFaceAndMatchWithProfile(nDetectedFaceNoMatchAndProfile, mongoTemplateManager);

			logger.info("insert only DetectedFace: {}", nDetectedFaceNoMatchAndProfile);

		} else {

			for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
				NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfile = new NDetectedFaceAndMatchWithProfile();

				nDetectedFaceAndMatchWithProfile.setDETECTED_FACE_ID(nDetectedFaceMatch.getDetectedFaceId());
				nDetectedFaceAndMatchWithProfile.setSYSTEM_ID(nDetectedFaceMatch.getSystemId());
				nDetectedFaceAndMatchWithProfile.setCCTV_ID(nDetectedFaceMatch.getCctvId());
				nDetectedFaceAndMatchWithProfile.setSRVC_TYPE(nDetectedFaceMatch.getSrvcType());
				nDetectedFaceAndMatchWithProfile.setIMG_FILE(nDetectedFaceMatch.getImgFile());
				nDetectedFaceAndMatchWithProfile.setIMG_W(nDetectedFaceMatch.getImgW());
				nDetectedFaceAndMatchWithProfile.setIMG_H(nDetectedFaceMatch.getImgH());
				nDetectedFaceAndMatchWithProfile.setIMG_X(nDetectedFaceMatch.getImgX());
				nDetectedFaceAndMatchWithProfile.setIMG_Y(nDetectedFaceMatch.getImgY());
				nDetectedFaceAndMatchWithProfile.setDF_FEATURE(nDetectedFaceMatch.getFeature());
				nDetectedFaceAndMatchWithProfile.setFRM_FILE(nDetectedFaceMatch.getFrmFile());
				nDetectedFaceAndMatchWithProfile.setFRM_W(nDetectedFaceMatch.getFrmW());
				nDetectedFaceAndMatchWithProfile.setFRM_H(nDetectedFaceMatch.getFrmH());
				nDetectedFaceAndMatchWithProfile.setFRM_TIME(nDetectedFaceMatch.getFrmTime());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_AT(nDetectedFaceMatch.getLastUpdateAt());
				nDetectedFaceAndMatchWithProfile.setDETECTED_DATE(nDetectedFaceMatch.getDetectedDate());
				nDetectedFaceAndMatchWithProfile.setCNCRN_FACE_ID(nDetectedFaceMatch.getCncrnFaceId());
				nDetectedFaceAndMatchWithProfile.setSCORE(nDetectedFaceMatch.getScore());
				nDetectedFaceAndMatchWithProfile.setRANK(nDetectedFaceMatch.getRank());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_BY(nDetectedFaceMatch.getLastUpdateMatchBy());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_AT(nDetectedFaceMatch.getLastUpdateMatchAt());

				//NConcernPersonAndFace nConcernPersonAndFace = null;
				//				nConcernPersonAndFace = concernedFaceMapper.seleectConcernedFaceAndPerson(nDetectedFaceMatch
				//						.getCncrnFaceId());


				//NConcernPersonAndFace nConcernPersonAndFace = null;
				for(ConcernedFace cf : faces){
					if(cf.getId().equals(nDetectedFaceMatch.getCncrnFaceId())){
						nDetectedFaceAndMatchWithProfile.setPERSON_ID(cf.getPersonId());
						nDetectedFaceAndMatchWithProfile.setNAME(cf.getName());
						nDetectedFaceAndMatchWithProfile.setGENDER(cf.getGender());
						nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(cf.getConcernType());
						nDetectedFaceAndMatchWithProfile.setCP_REMARKS(cf.getRemarks());
						nDetectedFaceAndMatchWithProfile.setBIRTHDAY(cf.getBirthday());
						nDetectedFaceAndMatchWithProfile.setNATIONALITY(cf.getNationality());
						nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(cf.getPassportNo());
						nDetectedFaceAndMatchWithProfile.setFIRST_NAME(cf.getFirstName());
						nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(cf.getMiddleName());
						nDetectedFaceAndMatchWithProfile.setLAST_NAME(cf.getLastName());
						nDetectedFaceAndMatchWithProfile.setFACE_ID(cf.getId());
						nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(cf.getImgFormat());
						nDetectedFaceAndMatchWithProfile.setCF_IMG_H(cf.getImgHeight());
						nDetectedFaceAndMatchWithProfile.setCF_IMG_W(cf.getImgWidth());
						nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(cf.getLandmarks());
						nDetectedFaceAndMatchWithProfile.setREMARKS(cf.getRemarks());
						nDetectedFaceAndMatchWithProfile.setIMG_PATH(cf.getImgPath());

						break;
					}
				}

				//				if (nConcernPersonAndFace != null) {
				//					logger.info("1>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}, {}",
				//							nConcernPersonAndFace.getPersonId(), nDetectedFaceMatch.getScore());
				//					nDetectedFaceAndMatchWithProfile.setPERSON_ID(nConcernPersonAndFace.getPersonId());
				//					nDetectedFaceAndMatchWithProfile.setNAME(nConcernPersonAndFace.getName());
				//					nDetectedFaceAndMatchWithProfile.setGENDER(nConcernPersonAndFace.getGender());
				//					nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(nConcernPersonAndFace.getConcernType());
				//					nDetectedFaceAndMatchWithProfile.setCP_IS_VALID(nConcernPersonAndFace.getIsValid());
				//					nDetectedFaceAndMatchWithProfile.setCP_REMARKS(nConcernPersonAndFace.getCpRemarks());
				//					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_AT(nConcernPersonAndFace.getLastUpdateAt());
				//					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_BY(nConcernPersonAndFace.getLastUpdateBy());
				//					nDetectedFaceAndMatchWithProfile.setBIRTHDAY(nConcernPersonAndFace.getBirthday());
				//					nDetectedFaceAndMatchWithProfile.setNATIONALITY(nConcernPersonAndFace.getNationality());
				//					nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(nConcernPersonAndFace.getPassportNo());
				//					nDetectedFaceAndMatchWithProfile.setFIRST_NAME(nConcernPersonAndFace.getFirstName());
				//					nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(nConcernPersonAndFace.getMiddleName());
				//					nDetectedFaceAndMatchWithProfile.setLAST_NAME(nConcernPersonAndFace.getLastName());
				//					nDetectedFaceAndMatchWithProfile.setFACE_ID(nConcernPersonAndFace.getfaceId());
				//					nDetectedFaceAndMatchWithProfile.setCF_IS_VALID(nConcernPersonAndFace.getIsValidFace());
				//					// nDetectedFaceAndMatchWithProfile.setImg(nConcernPersonAndFace.getImg());
				//					nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(nConcernPersonAndFace.getImgFormat());
				//					if (nConcernPersonAndFace.getImgH() != null) {
				//						nDetectedFaceAndMatchWithProfile.setCF_IMG_H(Integer.parseInt(nConcernPersonAndFace.getImgH()));
				//					}
				//
				//					if (nConcernPersonAndFace.getImgW() != null) {
				//						nDetectedFaceAndMatchWithProfile.setCF_IMG_W(Integer.parseInt(nConcernPersonAndFace.getImgW()));
				//					}
				//					// nDetectedFaceAndMatchWithProfile.setCfFeature(nConcernPersonAndFace.getFeature());
				//					nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(nConcernPersonAndFace.getLandmarks());
				//					nDetectedFaceAndMatchWithProfile.setREMARKS(nConcernPersonAndFace.getCfRemarks());
				//					nDetectedFaceAndMatchWithProfile.setIMG_PATH(nConcernPersonAndFace.getImgPath());
				//				}

				detectedFaceAndMatchWithProfileService
				.insertDetectedFaceAndMatchWithProfile(nDetectedFaceAndMatchWithProfile, mongoTemplateManager);

				logger.info("insert DetectedFace, Match and profile: {}", nDetectedFaceAndMatchWithProfile);
			}
		}
	}


	public void addNConcernedFaceLowMatchWithProfile(DetectedFace detectedFace,
			List<NDetectedFaceMatch> nDetectedFaceMatchs) throws Exception {

		if (nDetectedFaceMatchs == null) {
			// NDetectedFaceAndMatchWithProfile nDetectedFaceNoMatchAndProfile =
			// new NDetectedFaceAndMatchWithProfile();
			//
			// nDetectedFaceNoMatchAndProfile.setDETECTED_FACE_ID(detectedFace.getId());
			// //be caution!!
			// nDetectedFaceNoMatchAndProfile.setSYSTEM_ID(detectedFace.getSystemId());
			// nDetectedFaceNoMatchAndProfile.setCCTV_ID(detectedFace.getCctvId());
			// nDetectedFaceNoMatchAndProfile.setSRVC_TYPE(detectedFace.getSrvcType());
			// nDetectedFaceNoMatchAndProfile.setIMG_FILE(detectedFace.getImgFile());
			// nDetectedFaceNoMatchAndProfile.setIMG_W(detectedFace.getImgWidth());
			// nDetectedFaceNoMatchAndProfile.setIMG_H(detectedFace.getImgHeight());
			// nDetectedFaceNoMatchAndProfile.setIMG_X(detectedFace.getImgX());
			// nDetectedFaceNoMatchAndProfile.setIMG_Y(detectedFace.getImgY());
			// nDetectedFaceNoMatchAndProfile.setDF_FEATURE(new
			// Binary(detectedFace.getFeature()));
			// nDetectedFaceNoMatchAndProfile.setFRM_FILE(detectedFace.getFrmFile());
			// nDetectedFaceNoMatchAndProfile.setFRM_W(detectedFace.getFrmWidth());
			// nDetectedFaceNoMatchAndProfile.setFRM_H(detectedFace.getFrmHeight());
			// nDetectedFaceNoMatchAndProfile.setFRM_TIME(detectedFace.getFrmTime());
			// nDetectedFaceNoMatchAndProfile.setDETECTED_DATE(BaseUtils.formatToYear2DayString(new
			// java.util.Date()));
			// nDetectedFaceNoMatchAndProfile.setLAST_UPDATE_AT(detectedFace.getLastUpdateAt());
			//
			// detectedFaceAndMatchWithProfileService.insertDetectedFaceAndMatchWithProfile(nDetectedFaceNoMatchAndProfile);

			logger.info("There is no low matched face for : {}", detectedFace.getId());

		} else {

			for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
				NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfile = new NDetectedFaceAndMatchWithProfile();

				nDetectedFaceAndMatchWithProfile.setDETECTED_FACE_ID(nDetectedFaceMatch.getDetectedFaceId());
				nDetectedFaceAndMatchWithProfile.setSYSTEM_ID(nDetectedFaceMatch.getSystemId());
				nDetectedFaceAndMatchWithProfile.setCCTV_ID(nDetectedFaceMatch.getCctvId());
				nDetectedFaceAndMatchWithProfile.setSRVC_TYPE(nDetectedFaceMatch.getSrvcType());
				nDetectedFaceAndMatchWithProfile.setIMG_FILE(nDetectedFaceMatch.getImgFile());
				nDetectedFaceAndMatchWithProfile.setIMG_W(nDetectedFaceMatch.getImgW());
				nDetectedFaceAndMatchWithProfile.setIMG_H(nDetectedFaceMatch.getImgH());
				nDetectedFaceAndMatchWithProfile.setIMG_X(nDetectedFaceMatch.getImgX());
				nDetectedFaceAndMatchWithProfile.setIMG_Y(nDetectedFaceMatch.getImgY());
				nDetectedFaceAndMatchWithProfile.setDF_FEATURE(nDetectedFaceMatch.getFeature());
				nDetectedFaceAndMatchWithProfile.setFRM_FILE(nDetectedFaceMatch.getFrmFile());
				nDetectedFaceAndMatchWithProfile.setFRM_W(nDetectedFaceMatch.getFrmW());
				nDetectedFaceAndMatchWithProfile.setFRM_H(nDetectedFaceMatch.getFrmH());
				nDetectedFaceAndMatchWithProfile.setFRM_TIME(nDetectedFaceMatch.getFrmTime());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_AT(nDetectedFaceMatch.getLastUpdateAt());
				nDetectedFaceAndMatchWithProfile.setDETECTED_DATE(nDetectedFaceMatch.getDetectedDate());
				nDetectedFaceAndMatchWithProfile.setCNCRN_FACE_ID(nDetectedFaceMatch.getCncrnFaceId());
				nDetectedFaceAndMatchWithProfile.setSCORE(nDetectedFaceMatch.getScore());
				nDetectedFaceAndMatchWithProfile.setRANK(nDetectedFaceMatch.getRank());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_BY(nDetectedFaceMatch.getLastUpdateMatchBy());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_AT(nDetectedFaceMatch.getLastUpdateMatchAt());

				// profile 조회
				// NConcernPersonAndFace nConcernPersonAndFace = null;
				// nConcernPersonAndFace =
				// concernPersonAndFaceService.selectConcernPersonAndFaceByCncrnFaceId(nDetectedFaceMatch.getCncrnFaceId());
				NConcernPersonAndFace nConcernPersonAndFace = null;
				nConcernPersonAndFace = concernedFaceMapper.seleectConcernedFaceAndPerson(nDetectedFaceMatch
						.getCncrnFaceId());

				if (nConcernPersonAndFace != null) {
					logger.info("2>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}, {}",
							nConcernPersonAndFace.getPersonId(), nDetectedFaceMatch.getScore());
					nDetectedFaceAndMatchWithProfile.setPERSON_ID(nConcernPersonAndFace.getPersonId());
					nDetectedFaceAndMatchWithProfile.setNAME(nConcernPersonAndFace.getName());
					nDetectedFaceAndMatchWithProfile.setGENDER(nConcernPersonAndFace.getGender());
					nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(nConcernPersonAndFace.getConcernType());
					nDetectedFaceAndMatchWithProfile.setCP_IS_VALID(nConcernPersonAndFace.getIsValid());
					nDetectedFaceAndMatchWithProfile.setCP_REMARKS(nConcernPersonAndFace.getCpRemarks());
					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_AT(nConcernPersonAndFace.getLastUpdateAt());
					nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_BY(nConcernPersonAndFace.getLastUpdateBy());
					nDetectedFaceAndMatchWithProfile.setBIRTHDAY(nConcernPersonAndFace.getBirthday());
					nDetectedFaceAndMatchWithProfile.setNATIONALITY(nConcernPersonAndFace.getNationality());
					nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(nConcernPersonAndFace.getPassportNo());
					nDetectedFaceAndMatchWithProfile.setFIRST_NAME(nConcernPersonAndFace.getFirstName());
					nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(nConcernPersonAndFace.getMiddleName());
					nDetectedFaceAndMatchWithProfile.setLAST_NAME(nConcernPersonAndFace.getLastName());
					nDetectedFaceAndMatchWithProfile.setFACE_ID(nConcernPersonAndFace.getfaceId());
					nDetectedFaceAndMatchWithProfile.setCF_IS_VALID(nConcernPersonAndFace.getIsValidFace());
					// nDetectedFaceAndMatchWithProfile.setImg(nConcernPersonAndFace.getImg());
					nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(nConcernPersonAndFace.getImgFormat());
					if (nConcernPersonAndFace.getImgH() != null) {
						nDetectedFaceAndMatchWithProfile.setCF_IMG_H(Integer.parseInt(nConcernPersonAndFace.getImgH()));
					}

					if (nConcernPersonAndFace.getImgW() != null) {
						nDetectedFaceAndMatchWithProfile.setCF_IMG_W(Integer.parseInt(nConcernPersonAndFace.getImgW()));
					}
					// nDetectedFaceAndMatchWithProfile.setCfFeature(nConcernPersonAndFace.getFeature());
					nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(nConcernPersonAndFace.getLandmarks());
					nDetectedFaceAndMatchWithProfile.setREMARKS(nConcernPersonAndFace.getCfRemarks());
					nDetectedFaceAndMatchWithProfile.setIMG_PATH(nConcernPersonAndFace.getImgPath());
				}

				detectedFaceAndLowMatchWithProfileService
				.insertDetectedFaceAndLowMatchWithProfile(nDetectedFaceAndMatchWithProfile);

				logger.info("insert DetectedFace, Match and profile: {}", nDetectedFaceAndMatchWithProfile);
			}
		}
	}



	public void addNConcernedFaceLowMatchWithProfile(DetectedFace detectedFace,	List<NDetectedFaceMatch> nDetectedFaceMatchs, 
			MongoTemplateManager mongoTemplateManager, List<ConcernedFace> faces) throws Exception {

		if (nDetectedFaceMatchs == null) {
			logger.info("There is no low matched face for : {}", detectedFace.getId());

		} else {

			for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
				NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfile = new NDetectedFaceAndMatchWithProfile();

				nDetectedFaceAndMatchWithProfile.setDETECTED_FACE_ID(nDetectedFaceMatch.getDetectedFaceId());
				nDetectedFaceAndMatchWithProfile.setSYSTEM_ID(nDetectedFaceMatch.getSystemId());
				nDetectedFaceAndMatchWithProfile.setCCTV_ID(nDetectedFaceMatch.getCctvId());
				nDetectedFaceAndMatchWithProfile.setSRVC_TYPE(nDetectedFaceMatch.getSrvcType());
				nDetectedFaceAndMatchWithProfile.setIMG_FILE(nDetectedFaceMatch.getImgFile());
				nDetectedFaceAndMatchWithProfile.setIMG_W(nDetectedFaceMatch.getImgW());
				nDetectedFaceAndMatchWithProfile.setIMG_H(nDetectedFaceMatch.getImgH());
				nDetectedFaceAndMatchWithProfile.setIMG_X(nDetectedFaceMatch.getImgX());
				nDetectedFaceAndMatchWithProfile.setIMG_Y(nDetectedFaceMatch.getImgY());
				nDetectedFaceAndMatchWithProfile.setDF_FEATURE(nDetectedFaceMatch.getFeature());
				nDetectedFaceAndMatchWithProfile.setFRM_FILE(nDetectedFaceMatch.getFrmFile());
				nDetectedFaceAndMatchWithProfile.setFRM_W(nDetectedFaceMatch.getFrmW());
				nDetectedFaceAndMatchWithProfile.setFRM_H(nDetectedFaceMatch.getFrmH());
				nDetectedFaceAndMatchWithProfile.setFRM_TIME(nDetectedFaceMatch.getFrmTime());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_AT(nDetectedFaceMatch.getLastUpdateAt());
				nDetectedFaceAndMatchWithProfile.setDETECTED_DATE(nDetectedFaceMatch.getDetectedDate());
				nDetectedFaceAndMatchWithProfile.setCNCRN_FACE_ID(nDetectedFaceMatch.getCncrnFaceId());
				nDetectedFaceAndMatchWithProfile.setSCORE(nDetectedFaceMatch.getScore());
				nDetectedFaceAndMatchWithProfile.setRANK(nDetectedFaceMatch.getRank());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_BY(nDetectedFaceMatch.getLastUpdateMatchBy());
				nDetectedFaceAndMatchWithProfile.setLAST_UPDATE_MATCH_AT(nDetectedFaceMatch.getLastUpdateMatchAt());

				// profile 조회
				// NConcernPersonAndFace nConcernPersonAndFace = null;
				// nConcernPersonAndFace =
				// concernPersonAndFaceService.selectConcernPersonAndFaceByCncrnFaceId(nDetectedFaceMatch.getCncrnFaceId());
				//				NConcernPersonAndFace nConcernPersonAndFace = null;
				//				nConcernPersonAndFace = concernedFaceMapper.seleectConcernedFaceAndPerson(nDetectedFaceMatch
				//						.getCncrnFaceId());


				for(ConcernedFace cf : faces){
					if(cf.getId().equals(nDetectedFaceMatch.getCncrnFaceId())){
						nDetectedFaceAndMatchWithProfile.setPERSON_ID(cf.getPersonId());
						nDetectedFaceAndMatchWithProfile.setNAME(cf.getName());
						nDetectedFaceAndMatchWithProfile.setGENDER(cf.getGender());
						nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(cf.getConcernType());
						nDetectedFaceAndMatchWithProfile.setCP_REMARKS(cf.getRemarks());
						nDetectedFaceAndMatchWithProfile.setBIRTHDAY(cf.getBirthday());
						nDetectedFaceAndMatchWithProfile.setNATIONALITY(cf.getNationality());
						nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(cf.getPassportNo());
						nDetectedFaceAndMatchWithProfile.setFIRST_NAME(cf.getFirstName());
						nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(cf.getMiddleName());
						nDetectedFaceAndMatchWithProfile.setLAST_NAME(cf.getLastName());
						nDetectedFaceAndMatchWithProfile.setFACE_ID(cf.getId());
						nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(cf.getImgFormat());
						nDetectedFaceAndMatchWithProfile.setCF_IMG_H(cf.getImgHeight());
						nDetectedFaceAndMatchWithProfile.setCF_IMG_W(cf.getImgWidth());
						nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(cf.getLandmarks());
						nDetectedFaceAndMatchWithProfile.setREMARKS(cf.getRemarks());
						nDetectedFaceAndMatchWithProfile.setIMG_PATH(cf.getImgPath());

						break;
					}
				}


				//if (nConcernPersonAndFace != null) {
//				logger.info("2>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}, {}",
//						nConcernPersonAndFace.getPersonId(), nDetectedFaceMatch.getScore());
//				nDetectedFaceAndMatchWithProfile.setPERSON_ID(nConcernPersonAndFace.getPersonId());
//				nDetectedFaceAndMatchWithProfile.setNAME(nConcernPersonAndFace.getName());
//				nDetectedFaceAndMatchWithProfile.setGENDER(nConcernPersonAndFace.getGender());
//				nDetectedFaceAndMatchWithProfile.setCONCERN_TYPE(nConcernPersonAndFace.getConcernType());
//				nDetectedFaceAndMatchWithProfile.setCP_IS_VALID(nConcernPersonAndFace.getIsValid());
//				nDetectedFaceAndMatchWithProfile.setCP_REMARKS(nConcernPersonAndFace.getCpRemarks());
//				nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_AT(nConcernPersonAndFace.getLastUpdateAt());
//				nDetectedFaceAndMatchWithProfile.setCP_LAST_UPDATE_BY(nConcernPersonAndFace.getLastUpdateBy());
//				nDetectedFaceAndMatchWithProfile.setBIRTHDAY(nConcernPersonAndFace.getBirthday());
//				nDetectedFaceAndMatchWithProfile.setNATIONALITY(nConcernPersonAndFace.getNationality());
//				nDetectedFaceAndMatchWithProfile.setPASSPORT_NO(nConcernPersonAndFace.getPassportNo());
//				nDetectedFaceAndMatchWithProfile.setFIRST_NAME(nConcernPersonAndFace.getFirstName());
//				nDetectedFaceAndMatchWithProfile.setMIDDLE_NAME(nConcernPersonAndFace.getMiddleName());
//				nDetectedFaceAndMatchWithProfile.setLAST_NAME(nConcernPersonAndFace.getLastName());
//				nDetectedFaceAndMatchWithProfile.setFACE_ID(nConcernPersonAndFace.getfaceId());
//				nDetectedFaceAndMatchWithProfile.setCF_IS_VALID(nConcernPersonAndFace.getIsValidFace());
//				// nDetectedFaceAndMatchWithProfile.setImg(nConcernPersonAndFace.getImg());
//				nDetectedFaceAndMatchWithProfile.setIMG_FORMAT(nConcernPersonAndFace.getImgFormat());
//				if (nConcernPersonAndFace.getImgH() != null) {
//					nDetectedFaceAndMatchWithProfile.setCF_IMG_H(Integer.parseInt(nConcernPersonAndFace.getImgH()));
//				}
//
//				if (nConcernPersonAndFace.getImgW() != null) {
//					nDetectedFaceAndMatchWithProfile.setCF_IMG_W(Integer.parseInt(nConcernPersonAndFace.getImgW()));
//				}
//				// nDetectedFaceAndMatchWithProfile.setCfFeature(nConcernPersonAndFace.getFeature());
//				nDetectedFaceAndMatchWithProfile.setCF_LANDMARKS(nConcernPersonAndFace.getLandmarks());
//				nDetectedFaceAndMatchWithProfile.setREMARKS(nConcernPersonAndFace.getCfRemarks());
//				nDetectedFaceAndMatchWithProfile.setIMG_PATH(nConcernPersonAndFace.getImgPath());
//				//}

				detectedFaceAndLowMatchWithProfileService
				.insertDetectedFaceAndLowMatchWithProfile(nDetectedFaceAndMatchWithProfile, mongoTemplateManager);

				logger.info("insert DetectedFace, Match and profile: {}", nDetectedFaceAndMatchWithProfile);
			}
		}
	}

	public List<NDetectedFaceMatch> addNConcernedFaceMatches(DetectedFace detectedFace,
			@Nonnull List<Pair<String, Integer>> matches, int threshold, MongoTemplateManager mongoTemplateManager) throws Exception {

		List<NDetectedFaceMatch> nDetectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();

		if (CollectionUtils.isEmpty(matches)) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return nDetectedFaceMatchs;
		}

		int rank = 1;
		Pair<String, Integer> match = null;
		for (int i = 0; i < matches.size(); i++) {
			match = matches.get(i);

			NDetectedFaceMatch nDetectedFaceMatchProfile = new NDetectedFaceMatch();
			nDetectedFaceMatchProfile.setDetectedFaceId(String.valueOf(detectedFace.getId()));
			nDetectedFaceMatchProfile.setSystemId(detectedFace.getSystemId());
			nDetectedFaceMatchProfile.setCctvId(detectedFace.getCctvId());
			nDetectedFaceMatchProfile.setSrvcType(detectedFace.getSrvcType());
			nDetectedFaceMatchProfile.setImgFile(detectedFace.getImgFile());
			nDetectedFaceMatchProfile.setImgW(detectedFace.getImgWidth());
			nDetectedFaceMatchProfile.setImgH(detectedFace.getImgHeight());
			nDetectedFaceMatchProfile.setImgX(detectedFace.getImgX());
			nDetectedFaceMatchProfile.setImgY(detectedFace.getImgY());
			nDetectedFaceMatchProfile.setFeature(new Binary(detectedFace.getFeature()));
			nDetectedFaceMatchProfile.setFrmFile(detectedFace.getFrmFile());
			nDetectedFaceMatchProfile.setFrmW(detectedFace.getFrmWidth());
			nDetectedFaceMatchProfile.setFrmH(detectedFace.getFrmHeight());
			nDetectedFaceMatchProfile.setFrmTime(detectedFace.getFrmTime());
			nDetectedFaceMatchProfile.setLastUpdateAt(detectedFace.getLastUpdateAt());
			nDetectedFaceMatchProfile.setDetectedDate(BaseUtils.formatToYear2DayString(new java.util.Date()));
			nDetectedFaceMatchProfile.setCncrnFaceId(match.getLeft());
			nDetectedFaceMatchProfile.setScore(match.getRight());
			nDetectedFaceMatchProfile.setRank(i + 1);
			nDetectedFaceMatchProfile.setLastUpdateMatchBy(null);
			nDetectedFaceMatchProfile.setLastUpdateMatchAt(BaseUtils.getNowString());
			if (match.getRight() >= threshold) {
				detectedFaceMatchService.insertConcernedFaceMatch(nDetectedFaceMatchProfile, mongoTemplateManager);
			}
			nDetectedFaceMatchs.add(nDetectedFaceMatchProfile);
		}
		this.logger.debug("[NoSQL] Successfully saved {} Concerned face matches", matches.size());

		return nDetectedFaceMatchs;
	}

	public List<NDetectedFaceMatch> addNConcernedFaceMatches(DetectedFace detectedFace,
			@Nonnull List<Pair<String, Integer>> matches, int threshold) throws Exception {

		List<NDetectedFaceMatch> nDetectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();

		if (CollectionUtils.isEmpty(matches)) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return nDetectedFaceMatchs;
		}

		int rank = 1;
		Pair<String, Integer> match = null;
		for (int i = 0; i < matches.size(); i++) {
			match = matches.get(i);

			NDetectedFaceMatch nDetectedFaceMatchProfile = new NDetectedFaceMatch();
			nDetectedFaceMatchProfile.setDetectedFaceId(String.valueOf(detectedFace.getId()));
			nDetectedFaceMatchProfile.setSystemId(detectedFace.getSystemId());
			nDetectedFaceMatchProfile.setCctvId(detectedFace.getCctvId());
			nDetectedFaceMatchProfile.setSrvcType(detectedFace.getSrvcType());
			nDetectedFaceMatchProfile.setImgFile(detectedFace.getImgFile());
			nDetectedFaceMatchProfile.setImgW(detectedFace.getImgWidth());
			nDetectedFaceMatchProfile.setImgH(detectedFace.getImgHeight());
			nDetectedFaceMatchProfile.setImgX(detectedFace.getImgX());
			nDetectedFaceMatchProfile.setImgY(detectedFace.getImgY());
			nDetectedFaceMatchProfile.setFeature(new Binary(detectedFace.getFeature()));
			nDetectedFaceMatchProfile.setFrmFile(detectedFace.getFrmFile());
			nDetectedFaceMatchProfile.setFrmW(detectedFace.getFrmWidth());
			nDetectedFaceMatchProfile.setFrmH(detectedFace.getFrmHeight());
			nDetectedFaceMatchProfile.setFrmTime(detectedFace.getFrmTime());
			nDetectedFaceMatchProfile.setLastUpdateAt(detectedFace.getLastUpdateAt());
			nDetectedFaceMatchProfile.setDetectedDate(BaseUtils.formatToYear2DayString(new java.util.Date()));
			nDetectedFaceMatchProfile.setCncrnFaceId(match.getLeft());
			nDetectedFaceMatchProfile.setScore(match.getRight());
			nDetectedFaceMatchProfile.setRank(i + 1);
			nDetectedFaceMatchProfile.setLastUpdateMatchBy(null);
			nDetectedFaceMatchProfile.setLastUpdateMatchAt(BaseUtils.getNowString());
			if (match.getRight() >= threshold) {
				detectedFaceMatchService.insertConcernedFaceMatch(nDetectedFaceMatchProfile);
			}
			nDetectedFaceMatchs.add(nDetectedFaceMatchProfile);
		}
		this.logger.debug("[NoSQL] Successfully saved {} Concerned face matches", matches.size());

		return nDetectedFaceMatchs;
	}

	public List<NDetectedFaceMatch> addNConcernedFaceMatches(DetectedFace detectedFace,
			@Nonnull List<Pair<String, Integer>> matches) throws Exception {

		List<NDetectedFaceMatch> nDetectedFaceMatchs = new ArrayList<NDetectedFaceMatch>();

		if (CollectionUtils.isEmpty(matches)) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return nDetectedFaceMatchs;
		}

		int rank = 1;
		Pair<String, Integer> match = null;
		for (int i = 0; i < matches.size(); i++) {
			match = matches.get(i);

			NDetectedFaceMatch nDetectedFaceMatchProfile = new NDetectedFaceMatch();
			nDetectedFaceMatchProfile.setDetectedFaceId(String.valueOf(detectedFace.getId()));
			nDetectedFaceMatchProfile.setSystemId(detectedFace.getSystemId());
			nDetectedFaceMatchProfile.setCctvId(detectedFace.getCctvId());
			nDetectedFaceMatchProfile.setSrvcType(detectedFace.getSrvcType());
			nDetectedFaceMatchProfile.setImgFile(detectedFace.getImgFile());
			nDetectedFaceMatchProfile.setImgW(detectedFace.getImgWidth());
			nDetectedFaceMatchProfile.setImgH(detectedFace.getImgHeight());
			nDetectedFaceMatchProfile.setImgX(detectedFace.getImgX());
			nDetectedFaceMatchProfile.setImgY(detectedFace.getImgY());
			nDetectedFaceMatchProfile.setFeature(new Binary(detectedFace.getFeature()));
			nDetectedFaceMatchProfile.setFrmFile(detectedFace.getFrmFile());
			nDetectedFaceMatchProfile.setFrmW(detectedFace.getFrmWidth());
			nDetectedFaceMatchProfile.setFrmH(detectedFace.getFrmHeight());
			nDetectedFaceMatchProfile.setFrmTime(detectedFace.getFrmTime());
			nDetectedFaceMatchProfile.setLastUpdateAt(detectedFace.getLastUpdateAt());
			nDetectedFaceMatchProfile.setDetectedDate(BaseUtils.formatToYear2DayString(new java.util.Date()));
			nDetectedFaceMatchProfile.setCncrnFaceId(match.getLeft());
			nDetectedFaceMatchProfile.setScore(match.getRight());
			nDetectedFaceMatchProfile.setRank(i + 1);
			nDetectedFaceMatchProfile.setLastUpdateMatchBy(null);
			nDetectedFaceMatchProfile.setLastUpdateMatchAt(BaseUtils.getNowString());
			detectedFaceMatchService.insertConcernedFaceMatch(nDetectedFaceMatchProfile);
			nDetectedFaceMatchs.add(nDetectedFaceMatchProfile);
		}
		this.logger.debug("[NoSQL] Successfully saved {} Concerned face matches", matches.size());

		return nDetectedFaceMatchs;
	}

	// @TODO(Done) Rename to addDetectedFace later
	/**
	 * @param result
	 * @return the ID of added face result
	 */
	@Transactional
	public int addDetectedFace(@Nonnull DetectedFace face) {
		return this.detectedFaceMapper.insertDetectedFace(face);
	}

	public NDetectedFace addNDetectedFace(@Nonnull DetectedFace face) throws Exception {
		NDetectedFace nDetectedFace = null;
		nDetectedFace = new NDetectedFace();
		nDetectedFace.setDetectedFaceId(new ObjectId().toString());
		nDetectedFace.setSystemId(face.getSystemId());
		nDetectedFace.setCctvId(face.getCctvId());
		nDetectedFace.setSrvcType(face.getSrvcType());
		nDetectedFace.setImgFile(face.getImgFile());
		nDetectedFace.setImgW(face.getImgWidth());
		nDetectedFace.setImgH(face.getImgHeight());
		nDetectedFace.setImgX(face.getImgX());
		nDetectedFace.setImgY(face.getImgY());
		// nDetectedFace.setFeature(BaseUtils.getHexString(face.getFeature()));
		// //이부분 핵사로 변경 필요
		nDetectedFace.setFeature(new Binary(face.getFeature()));
		nDetectedFace.setFrmFile(face.getFrmFile());
		nDetectedFace.setFrmW(face.getFrmWidth());
		nDetectedFace.setFrmH(face.getFrmHeight());
		nDetectedFace.setFrmTime(face.getFrmTime());
		nDetectedFace.setDetectedDate(BaseUtils.formatToYear2DayString(new java.util.Date()));
		nDetectedFace.setLastUpdateAt(BaseUtils.getNowString());
		this.detectedFaceService.insertDetectedFace(nDetectedFace);
		return nDetectedFace;
	}

	// @TODO(Done) Rename to setBestMatchOfDetectedFace later
	// @TODO Remove setBestMatchOfDetectedFace later
	/**
	 * @param detectedFaceId
	 * @param concernedFaceId
	 * @param confidence
	 */
	// @Transactional
	// public void setBestMatchOfDetectedFace(@Nonnull int detectedFaceId,
	// @Nonnull int concernedFaceId, @Nonnull int confidence){
	// this.resultMapper.updateReusltConcernedPerson(detectedFaceId,concernedFaceId,confidence);
	// }

	@Transactional
	@Nullable
	public Visitor findVisitorById(@NotEmpty String visitorId) {
		Validate.isTrue(StringUtils.isNotEmpty(visitorId), "The ID of visitor to find should be specified.");

		Visitor visitor = this.visitorMapper.selectVisitorById(visitorId);
		List<VisitorFace> faces = this.visitorFaceMapper.selectVisitorFacesByVisitor(visitorId);

		for (VisitorFace face : faces) {
			visitor.addFace(face);
		}
		return visitor;
	}

	@Transactional
	@Nullable
	public Personnel findPersonnelById(@NotEmpty String id) {
		Validate.isTrue(StringUtils.isNotEmpty(id), "The ID of personnel to find should be specified.");

		Personnel personnel = this.personnelMapper.selectPersonnelById(id);
		List<PersonnelFace> faces = this.personnelFaceMapper.selectPersonnelFacesByPersonnel(id);

		// TODO feature 값이 없을 시, 생성해서 VAS_PRSNNL_FACE 테이블에 feature 값을 넣어주어야 한다.
		if (faces == null) {

		}

		for (PersonnelFace face : faces) {
			personnel.addFace(face);
		}
		return personnel;
	}

	@Transactional
	@Nullable
	public List<PersonnelFace> findPersonnelFacesByPersonnel(@NotEmpty String personnelId) {
		Validate.isTrue(StringUtils.isNotEmpty(personnelId), "The ID of personnel to find should be specified.");

		List<PersonnelFace> faces = this.personnelFaceMapper.selectPersonnelFacesByPersonnel(personnelId);

		return faces;
	}

	@Transactional
	public void addPersonnelFace(PersonnelFace personnelFace) {

		int cnt = this.personnelFaceMapper.insertPersonnelFace(personnelFace);
	}

	/**
	 * @param id
	 *            the ID of visitor face to set
	 * @param feature
	 * @param landmarks
	 */
	@Transactional
	public void setFeatureAndLandmarksOfVisitorFace(@NotEmpty String id, @Nullable byte[] feature,
			@Nullable String landmarks) {
		Validate.isTrue(StringUtils.isNotEmpty(id), "The ID of visitor face to update should be specified.");

		int cnt = this.visitorFaceMapper.setFeatureAndLandmarks(id, feature, landmarks);
	}

	@Transactional
	public void addJobFaceMatch(@Nonnull List<Pair<String, Integer>> matches, String detectedFaceId) {

		if (CollectionUtils.isEmpty(matches)) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return;
		}

		DetectedFace detectedFace = new DetectedFace();

		for (int i = 0; i < matches.size(); i++) {

			detectedFace.setDetectedFaceId(detectedFaceId);
			detectedFace.setJobCncrnFaceId(Integer.parseInt(matches.get(i).getLeft()));
			detectedFace.setScore(matches.get(i).getRight());

			this.detectedFaceMapper.insertJobFaceMatch(detectedFace);
		}

		this.logger.debug("Successfully saved {} Concerned Face matches (In On-demand)", matches.size());
	}

	@Deprecated
	@Transactional
	public void addAccessEvent(AccessEvent ev, Visitor visitor, String userId) {
		ev.setVisitorId(visitor.getId());
		this.accessEventMapper.insertAccessEvent(ev);
		// this.logger.debug("Successfully saved {} visitor matches",
		// matches.size());
	}

	/**
	 * The tree elements in triples are expected to be personnel's face ID,
	 * detected face ID, and the match score between the personnel's face and
	 * the detected face.
	 *
	 * @param matches
	 * @param userId
	 */
	@Transactional
	public void addPersonnelMatches(@Nonnull List<Triple<String, String, Integer>> matches, String passNo,
			String accessAt, String userId) {
		Validate.isTrue(matches != null, "The specified matches shouln't be null.");

		if (matches.isEmpty()) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return;
		}

		int rank = 1;
		for (Triple<String, String, Integer> match : matches) {
			this.personnelMatchMapper.insertPersonnelMatch(match.getLeft(), match.getMiddle(), match.getRight(),
					passNo, accessAt, userId, rank++);
		}
		this.logger.debug("Successfully saved {} personnel matches", matches.size());
	}

	/**
	 * The tree elements in triples are expected to be visitor's face ID,
	 * detected face ID, and the match score between the visitor's face and the
	 * detected face.
	 *
	 * @param matches
	 * @param userId
	 */
	@Transactional
	public void addVisitorMatches(@Nonnull List<Triple<String, String, Integer>> matches, String passNo,
			String accessAt, String userId) {
		Validate.isTrue(matches != null, "The specified matches shouln't be null.");

		if (matches.isEmpty()) {
			this.logger.warn("The specified matches are empty. There's nothing to save.");
			return;
		}

		int rank = 1;
		for (Triple<String, String, Integer> match : matches) {
			this.visitorMatchMapper.insertVisitorMatch(match.getLeft(), match.getMiddle(), match.getRight(), passNo,
					accessAt, userId, rank++);
		}
		this.logger.debug("Successfully saved {} visitor matches", matches.size());
	}

	/**
	 *
	 * @param ConcernedFace
	 */
	@Transactional
	public void registerConcernedFace(ConcernedFace face) {

		int cnt = this.concernedFaceMapper.insertConcernedFace(face);

		if (cnt != 0) {
			this.logger.debug("Fail to save concerned faces. filename : {}, filePath : {}" + face.getImgName()
					+ face.getImgPath());
		} else {
			this.logger.debug("Successfully saved concerned faces. filename : {}, filePath : {}" + face.getImgName()
					+ face.getImgPath());
		}

	}

	// @Transactional @Nullable
	// public List<Pair<String,String>> selectFRSAllCctvsForStart(){
	//
	// List<Pair<String,String>> cctvs =
	// this.deviceMapper.selectFRSAllCctvsForStart();
	//
	// return cctvs;
	// }
	// get roi list
	@Transactional
	@Nullable
	public List<DetectedRoi> findCctvIdByRoiList(@Param("cctvId") String cctvId) {
		List<DetectedRoi> detectedRoi = this.cctvServiceMapper.selectDetectedRoiList(cctvId);

		return detectedRoi;
	}

	@Transactional
	@Nullable
	public int insertCctvServiceStart(@Param("systemId") String systemId, @Param("cctvId") String cctvId,
			@Param("srvcType") String srvcType) {
		int cnt = this.cctvServiceMapper.insertCctvServiceStart(systemId, cctvId, srvcType);
		return cnt;
	}

	@Transactional
	@Nullable
	public int updateCctvServiceEnd(@Param("cctvId") String cctvId) {

		return this.cctvServiceMapper.updateCctvServiceEnd(cctvId);
	}

	// used AKKA node management
	@Transactional
	public Node getNodeInfo(String nodeAddress, String nodePort) {
		return nodeMapper.selectNode(nodeAddress, nodePort);
	}

	// used AKKA node management
	@Transactional
	public HashMap<Integer, Integer> getConcernMatchingVolumeInfo(String nodeAddress, String nodePort) {
		return nodeMapper.selectConcernMatchingVolumn(nodeAddress, nodePort);
	}

	// used AKKA node management
	@Transactional
	public HashMap<Integer, Integer> getConcernMatchingVolumeInfo(int nodeId) {
		return nodeMapper.selectConcernMatchingVolumnByNodeId(nodeId);
	}

	// used AKKA node management
	@Transactional
	public Node getNodeInfoById(int nodeId) {
		return nodeMapper.selectNodeById(nodeId);
	}

	// used MQ Publisher
	@Transactional
	public String[] getNodeByCncrnFaceIdx(int idx) {
		return nodeMapper.selectNodeByCncrnFaceIdx(idx);
	}

	// used MQ Publisher
	@Transactional
	public String[] getNodeOfLastCncrnFaceId() {
		return nodeMapper.selectNodeOfLastCncrnFaceId();
	}

	@Transactional
	public String[] getNodesByFromIdx(List<Integer> fromIdxList) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("from_list", fromIdxList);
		return nodeMapper.selectNodesByFromIdx(param);
	}

	// used AKKA node management
	@Transactional
	public boolean makeNewNode(Node node) {
		try {

			// first, get nodeId from VAS_NODE table
			Integer nodeId = nodeMapper.selectNodeId(node.getIpAddress(), node.getPort());
			if (nodeId == null) {
				this.logger.error(
						"++ Because nodeId is null, there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
						node.getIpAddress(), node.getPort());
				return false;
			} else {
				if (nodeId.intValue() <= 0) {
					this.logger.error("++ there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
							node.getIpAddress(), node.getPort());
					return false;
				}
			}

			node.setNodeId(nodeId);
			int cnt = nodeMapper.insertNewNode(node);
			if (cnt != 0) {
				this.logger.debug("Successfully inserted new AKKA worker node : {}", node);
				return true;
			} else {
				this.logger.debug("Fail to insert new AKKA worker node : {}", node);
				return false;
			}
		} catch (DataAccessException ex) {
			this.logger
			.error("++ Insert new Node[{}]in DB is failed. because another master node already inserted this node !!!",
					node);
			return false;

		}
	}

	// used AKKA node management
	@Transactional
	public boolean resetNode(Node node) {
		Node existingNode = nodeMapper.selectNode(node.getIpAddress(), node.getPort());

		if (existingNode == null) {
			this.logger.debug("++ Fail to select existing AKKA worker node in DB : {}", node);
			return false;
		}

		node.setNodeId(existingNode.getNodeId());
		int cnt = nodeMapper.updateExistingNode(node);
		if (cnt != 0) {
			this.logger.debug("++ Successfully updated node info in DB : {}", node);
			return true;
		} else {
			this.logger.debug("++ Fail to update node info in DB : {}", node);
			return false;
		}

	}

	// used AKKA node management
	@Transactional
	public boolean clearCctv(int nodeId) {
		int cnt = nodeMapper.deleteCctv(nodeId);
		return true;
	}

	// used AKKA node management
	@Transactional
	public boolean clearCctv(int nodeId, String cctvId) {
		int cnt = nodeMapper.deleteOneCctv(nodeId, cctvId);
		return true;
	}

	// used AKKA node management
	@Transactional
	@Nullable
	public List<Cctv> getCctvList(int nodeId) {
		List<Cctv> cctvList = this.nodeMapper.selectCctvList(nodeId);

		return cctvList;
	}

	// used AKKA node management
	@Transactional
	@Nullable
	public boolean updateNode(Node node) {
		int cnt = this.nodeMapper.updateExistingNode(node);
		if (cnt == 0) {
			this.logger.warn("Faile to update node in VAS_NODE_SRVC table! node = {} ", node);
			return false;
		}

		return true;
	}

	// used AKKA node management
	@Transactional
	@Nullable
	public boolean setCctvList(List<Cctv> cctvList) {

		for (Cctv cctv : cctvList) {
			try {
				this.nodeMapper.insertCctv(cctv);
			} catch (DataAccessException ex) {
				logger.error(
						"++ Insert cctv[{}]in DB is failed. because another master node already inserted this cctv !!!",
						cctv);
			}
		}

		// Map<String, Object> map = new HashMap<String, Object>();
		// map.put("list", cctvList);
		// this.nodeMapper.insertCctvList(map);

		return true;
	}
	// used AKKA node management
	@Transactional
	@Nullable
	public List<Node> getNodeList() {
		List<Node> nodeList = this.nodeMapper.selectNodeList();
		return nodeList;
	}

	// used AKKA node management
	@Transactional
	@Nullable
	public Cctv findCctvByCctvId(String cctvId, String systemId) {
		Cctv cctv = this.nodeMapper.selectCctvByCctvId(cctvId, systemId);
		return cctv;
	}

	// used AKKA node management
	@Transactional
	@Nullable
	public Node getNodeInfoIfNotExistMakeNewNode(String nodeAddress, String nodePort) {

		Node node = nodeMapper.selectNode(nodeAddress, nodePort);
		if (node == null) {
			Node newNode = new Node();
			newNode.setDefault(nodeAddress, nodePort);

			// first, get nodeId from VAS_NODE table
			Integer nodeId = nodeMapper.selectNodeId(nodeAddress, nodePort);
			if (nodeId == null) {
				this.logger.error("++ there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
						node.getIpAddress(), node.getPort());
				return null;
			} else {
				if (nodeId.intValue() <= 0) {
					this.logger.error("++ there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
							node.getIpAddress(), node.getPort());
					return null;
				}
			}
			newNode.setNodeId(nodeId);

			// insert VAS_FR_NODE table
			int cnt = nodeMapper.insertNewNode(newNode);
			if (cnt != 0) {
				this.logger.debug("Successfully inserted new AKKA worker node : {}", node);
				return newNode;
			} else {
				this.logger.debug("Fail to insert new AKKA worker node : {}", node);
				return null;
			}
		} else {
			return node;
		}

	}

	// used AKKA node management
	@Transactional
	@Nullable
	public boolean updateCctvStatus(String systemId, String cctvId, String status) {
		int cnt = this.nodeMapper.updateCctvStatus(systemId, cctvId, status);
		if (cnt == 0)
			this.logger.warn("Faile to update CCTV status in VAS_FR_NODE_CCTV table! cctvId = {}", cctvId);
		return false;

	}

	// used Config management
	@Transactional
	@Nullable
	public FRConfig getConfigInfo() {
		FRConfig frConfig = this.nodeMapper.selectConfigInfo();
		return frConfig;
	}

	@Transactional
	@Nullable
	public FRConfig getConfigInfoByCctvId(String cctvId) {
		FRConfig frConfig = this.nodeMapper.selectConfigInfoByCctvId(cctvId);
		return frConfig;
	}

	// used AKKA ondemand management
	@Transactional
	public List<Node> getStandbyOndemandNodeList() {
		List<Node> nodes = this.nodeMapper.selectStandbyOndemandNodeList();
		return nodes;
	}

	// used AKKA ondemand management
	@Transactional
	public List<Integer> getOngoingOndemandDBNodeList(String jobId) {
		List<Integer> nodeIds = this.nodeMapper.selectOngoingOndemandDBNodeList(jobId);
		return nodeIds;
	}

	// used AKKA ondemand management
	@Transactional
	public List<Integer> getOngoingOndemandVMSNodeList(String jobId) {
		List<Integer> nodeIds = this.nodeMapper.selectOngoingOndemandVMSNodeList(jobId);
		return nodeIds;
	}

	// used AKKA ondemand management
	@Transactional
	public List<Integer> getOngoingOndemandVideoNodeList(String jobId) {
		List<Integer> nodeIds = this.nodeMapper.selectOngoingOndemandVideoNodeList(jobId);
		return nodeIds;
	}

	// used AKKA ondemand management
	@Transactional
	public void storeOndemandDBSubJob(OndemandDBSubJobVO ondemandDBSubJobVO) {
		this.nodeMapper.insertOndemandDBSubJob(ondemandDBSubJobVO);
	}

	// used AKKA ondemand management
	@Transactional
	public void storeOndemandVMSSubJob(OndemandVMSSubJobVO ondemandVMSSubJobVO) {
		this.nodeMapper.insertOndemandVMSSubJob(ondemandVMSSubJobVO);
	}

	// used AKKA ondemand management
	@Transactional
	public void storeOndemandVideoSubJob(OndemandVideoSubJobVO ondemandVideoSubJobVO) {
		this.nodeMapper.insertOndemandVideoSubJob(ondemandVideoSubJobVO);
	}

	// used AKKA ondemand management
	@Transactional
	public OndemandDBSubJobVO getOngoingDBSubJob(int nodeId) {
		return this.nodeMapper.selectOngoingDBSubJob(nodeId);
	}

	// used AKKA ondemand management
	@Transactional
	public OndemandVMSSubJobVO getOngoingVMSSubJob(int nodeId) {
		return this.nodeMapper.selectOngoingVMSSubJob(nodeId);
	}

	// used AKKA ondemand management
	@Transactional
	public OndemandVideoSubJobVO getOngoingVideoSubJob(int nodeId) {
		return this.nodeMapper.selectOngoingVideoSubJob(nodeId);
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandDBJobofAllNodeCompleted(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandDBAllCount(jobId);
		int finishedNodeCount = this.nodeMapper.selectOndemandDBFinishedCount(jobId);
		if (allNodeCount == finishedNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandVMSJobofAllNodeCompleted(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandVMSAllCount(jobId);
		int finishedNodeCount = this.nodeMapper.selectOndemandVMSFinishedCount(jobId);
		if (allNodeCount == finishedNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandVideoJobofAllNodeCompleted(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandVideoAllCount(jobId);
		int finishedNodeCount = this.nodeMapper.selectOndemandVideoFinishedCount(jobId);
		if (allNodeCount == finishedNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandDBJobSuccessful(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandDBAllCount(jobId);
		int sucessfulNodeCount = this.nodeMapper.selectOndemandDBSuccessfulCount(jobId);
		if (allNodeCount == sucessfulNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandVMSJobSuccessful(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandVMSAllCount(jobId);
		int sucessfulNodeCount = this.nodeMapper.selectOndemandVMSSuccessfulCount(jobId);
		if (allNodeCount == sucessfulNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public boolean isOndemandVideoJobSuccessful(String jobId) {
		int allNodeCount = this.nodeMapper.selectOndemandVideoAllCount(jobId);
		int sucessfulNodeCount = this.nodeMapper.selectOndemandVideoSuccessfulCount(jobId);
		if (allNodeCount == sucessfulNodeCount)
			return true;
		else
			return false;
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandDBStatus(int nodeId, String jobId, String status) {
		String time = BaseUtils.formatToYear2SecString(new Date());
		this.nodeMapper.updateOndemandDBStatus(nodeId, jobId, status, time);
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandVMSStatus(int nodeId, String jobId, String status) {
		String time = BaseUtils.formatToYear2SecString(new Date());
		this.nodeMapper.updateOndemandVMSStatus(nodeId, jobId, status, time);
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandVideoStatus(int nodeId, String jobId, String status) {
		String time = BaseUtils.formatToYear2SecString(new Date());
		this.nodeMapper.updateOndemandVideoStatus(nodeId, jobId, status, time);
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandDBStatusWithThread(OndemandDBSubJobVO subJobVO) {
		this.nodeMapper.updateOndemandDBStatusWithThread(subJobVO.getNodeId(), subJobVO.getJobId(),
				subJobVO.getJobStatus(), subJobVO.getStartTime(), subJobVO.getTotalStartThread());
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandVMSStatusWithThread(OndemandVMSSubJobVO subJobVO) {
		this.nodeMapper.updateOndemandVMSStatusWithThread(subJobVO.getNodeId(), subJobVO.getJobId(),
				subJobVO.getJobStatus(), subJobVO.getStartTime(), subJobVO.getTotalStartThread());
	}

	// used AKKA ondemand management
	@Transactional
	public void updateOndemandVideoStatusWithThread(OndemandVideoSubJobVO subJobVO) {
		this.nodeMapper.updateOndemandVideoStatusWithThread(subJobVO.getNodeId(), subJobVO.getJobId(),
				subJobVO.getJobStatus(), subJobVO.getStartTime(), subJobVO.getTotalStartThread());
	}

	// used AKKA ondemand management
	@Transactional
	public HashMap<String, Integer> selectOndemandDBThread(int nodeId, String jobId) {
		return this.nodeMapper.selectOndemandDBThread(nodeId, jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public HashMap<String, Integer> selectOndemandVMSThread(int nodeId, String jobId) {
		return this.nodeMapper.selectOndemandVMSThread(nodeId, jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public HashMap<String, Integer> selectOndemandVideoThread(int nodeId, String jobId) {
		return this.nodeMapper.selectOndemandVideoThread(nodeId, jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public int updateOndemandDBCompletedThread(int nodeId, String jobId, int completedTotalThread) {
		return this.nodeMapper.updateOndemandDBCompletedThread(nodeId, jobId, completedTotalThread);
	}

	// used AKKA ondemand management
	@Transactional
	public int updateOndemandVMSCompletedThread(int nodeId, String jobId, int completedTotalThread) {
		return this.nodeMapper.updateOndemandVMSCompletedThread(nodeId, jobId, completedTotalThread);
	}

	// used AKKA ondemand management
	@Transactional
	public int updateOndemandVideoCompletedThread(int nodeId, String jobId, int completedTotalThread) {
		return this.nodeMapper.updateOndemandVideoCompletedThread(nodeId, jobId, completedTotalThread);
	}

	// used AKKA ondemand management
	@Transactional
	public List<OndemandDBSubJobVO> selectOndemandDBNode(String jobId) {
		return this.nodeMapper.selectOndemandDBNode(jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public List<OndemandVMSSubJobVO> selectOndemandVMSNode(String jobId) {
		return this.nodeMapper.selectOndemandVMSNode(jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public List<OndemandVideoSubJobVO> selectOndemandVideoNode(String jobId) {
		return this.nodeMapper.selectOndemandVideoNode(jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public void updateJobMaster(String jobId, float progress, String resultStatus) {
		this.nodeMapper.updateJobMaster(jobId, progress, resultStatus);
	}

	// used AKKA ondemand management
	@Transactional
	public void deleteDBSubJob(int nodeId, String jobId) {
		this.nodeMapper.deleteDBSubJob(nodeId, jobId);
	}
	// used AKKA ondemand management
	@Transactional
	public void deleteVMSSubJob(int nodeId, String jobId) {
		this.nodeMapper.deleteVMSSubJob(nodeId, jobId);
	}
	// used AKKA ondemand management
	@Transactional
	public void deleteVideoSubJob(int nodeId, String jobId) {
		this.nodeMapper.deleteVideoSubJob(nodeId, jobId);
	}

	// used AKKA ondemand management
	@Transactional
	public List<String> selectOngoingDBJob(int nodeId) {
		return this.nodeMapper.selectOngoingDBJob(nodeId);
	}

	// used AKKA ondemand management
	@Transactional
	public List<String> selectOngoingVMSJob(int nodeId) {
		return this.nodeMapper.selectOngoingVMSJob(nodeId);
	}
	// used AKKA ondemand management
	@Transactional
	public List<String> selectOngoingVideoJob(int nodeId) {
		return this.nodeMapper.selectOngoingVideoJob(nodeId);
	}

	// used AKKA ondemand management
	@Transactional
	public FileAnalysisRequest.AnalysisResource selectAnalysisResource(int rscId) {
		return this.nodeMapper.selectAnalysisResource(rscId);
	}

	@Transactional
	public void deleteMatchingNodeCncrnIndex(int nodeId) {
		this.concernedFaceMapper.deleteMatchingNodeCncrnIndex(nodeId);
	}

	@Transactional
	public void updateMatchingNodeCncrnIndex(int nodeId, int fromIdx, int toIdx) {
		this.concernedFaceMapper.updateMatchingNodeCncrnIndex(nodeId, fromIdx, toIdx);
	}

	@Transactional
	public void insertMatchingNodeCncrnIndex(int nodeId, int fromIdx, int toIdx) {
		this.concernedFaceMapper.insertMatchingNodeCncrnIndex(nodeId, fromIdx, toIdx);
	}

	@Transactional
	public List<Node> getMatchingNodeListOfGroup(int nodeId) {
		// return this.nodeMapper.selectNodeListOfGroupe(nodeId);
		Integer groupId = this.nodeMapper.selectGroupId(nodeId);
		if (groupId == null || groupId.intValue() <= 0) {
			this.logger.error("++ can not find matching node group id of this node id = [{}]", nodeId);
			return null;
		} else {
			List<Node> nodeList = this.nodeMapper.selectStandbyMatchingNodeWithSameGroup(groupId.intValue());
			if (nodeList == null) {
				this.logger.info("++ there in no [standby] matching node in matching group id = [{}]",
						groupId.intValue());
				return null;
			} else {
				return nodeList;
			}
		}

	}

	@Transactional
	public List<Node> getDetectionNodeListOfGroup(String nodeClass, int nodeId) {
		// return this.nodeMapper.selectNodeListOfGroupe(nodeId);
		Integer groupId = this.nodeMapper.selectGroupId(nodeId);
		if (groupId == null || groupId.intValue() <= 0) {
			this.logger.error("++ can not find matching node group id of this node id = [{}]", nodeId);
			return null;
		} else {
			List<Node> nodeList = this.nodeMapper.selectStandbyDetectionNodeWithSameGroup(nodeClass, groupId.intValue());
			if (nodeList == null) {
				this.logger.info("++ there in no [standby] matching node in matching group id = [{}]",
						groupId.intValue());
				return null;
			} else {
				return nodeList;
			}
		}

	}

	// used AKKA node management
	@Transactional
	public boolean makeNewMatchingNode(Node node) {
		try {

			// first, get nodeId from VAS_NODE table
			Integer nodeId = nodeMapper.selectNodeId(node.getIpAddress(), node.getPort());
			if (nodeId == null) {
				this.logger.error(
						"++ Because nodeId is null, there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
						node.getIpAddress(), node.getPort());
				return false;
			} else {
				if (nodeId.intValue() <= 0) {
					this.logger.error("++ there is no node info in VAS_NODE, where IP = [{}], Port = [{}]",
							node.getIpAddress(), node.getPort());
					return false;
				}
			}

			node.setNodeId(nodeId);
			int cnt = nodeMapper.insertNewNode(node);
			if (cnt != 0) {
				this.logger.debug("Successfully inserted new worker node : {}", node);
				return true;
			} else {
				this.logger.debug("Fail to insert new worker node : {}", node);
				return false;
			}
		} catch (DataAccessException ex) {
			this.logger
			.error("++ Insert new Node[{}]in DB is failed. because another master node already inserted this node !!!",
					node);
			return false;

		}
	}

	@Transactional
	public int getGroupId(int nodeId) {

		int noGroup = -1;

		try {
			Integer groupId = this.nodeMapper.selectGroupId(nodeId);
			if (groupId == null || groupId.intValue() <= 0) {
				this.logger.debug("++ Node id = [{}] doesn't have any group Id. "
						+ "It means this node is one of the FRS 2.0 node !!!", nodeId);
				return noGroup;
			} else {
				return groupId.intValue();
			}
		} catch (DataAccessException ex) {
			this.logger.debug("++ Node id = [{}] doesn't have any group Id. "
					+ "It means this node is one of the FRS 2.0 node !!!", nodeId);
			return noGroup;

		}

	}

}
