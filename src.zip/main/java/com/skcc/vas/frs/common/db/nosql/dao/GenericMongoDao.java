package com.skcc.vas.frs.common.db.nosql.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.mongodb.DBObject;
import com.skcc.vas.frs.akka.cluster.Server;
import com.skcc.vas.frs.common.util.base.SpringApplicationContext;
import com.skcc.vas.frs.common.util.spring.SpringContainerLocator;

@Async
@Repository
public class GenericMongoDao {

	protected String collectionName = null;
	protected Class cls = null;
	
	private int MAX_MONGO_TEMPLATE_NUM = 20;
	
	private int mongoTemplateIndex = 0;

	protected MongoTemplate[] mongoTemplates = new MongoTemplate[MAX_MONGO_TEMPLATE_NUM];
	
	public MongoTemplate getMongoTemplate(){
		
		if(mongoTemplateIndex < 0) mongoTemplateIndex = 0;
		int index = (mongoTemplateIndex++ % MAX_MONGO_TEMPLATE_NUM);
		
		return mongoTemplates[index];
	}
	
	public GenericMongoDao(){
		for(int i = 0; i < MAX_MONGO_TEMPLATE_NUM; i++){
			mongoTemplates[i] = (MongoTemplate) SpringApplicationContext.getBean("mongoTemplate");
		}
	}
	
	
	/**
	 * upsert
	 * 
	 * @param obj
	 * @throws Exception
	 */
	public void upsert(Object obj) throws Exception {
		getMongoTemplate().save(obj, this.collectionName);
	}

	/**
	 * insert
	 * 
	 * @param obj
	 * @throws Exception
	 */
	public void insert(Object obj) throws Exception {
		getMongoTemplate().insert(obj, this.collectionName);
	}

	/**
	 * find
	 * 
	 * @param query
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<?> find(Query query) throws Exception {
		return getMongoTemplate().find(query, this.cls, this.collectionName);
	}

	/**
	 * findOne
	 * 
	 * @param query
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Object findOne(Query query) throws Exception {
		return getMongoTemplate().findOne(query, this.cls, this.collectionName);
	}

	/**
	 * findAll
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<?> findAll() throws Exception {
		return getMongoTemplate().findAll(this.cls, this.collectionName);
	}

	/**
	 * count
	 * 
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public long count(Query query) throws Exception {
		return getMongoTemplate().count(query, this.collectionName);
	}

	/**
	 * update
	 * 
	 * @param query
	 * @param update
	 * @throws Exception
	 */
	public void update(Query query, Update update) throws Exception {
		getMongoTemplate().upsert(query, update, collectionName);
	}

	/**
	 * remove
	 * 
	 * @param query
	 * @throws Exception
	 */
	public void remove(Query query) throws Exception {
		getMongoTemplate().remove(query, this.collectionName);
	}

	/**
	 * remove
	 * 
	 * @param obj
	 * @throws Exception
	 */
	public void remove(Object obj) throws Exception {
		getMongoTemplate().remove(obj, this.collectionName);
	}

	/**
	 * findAndModify
	 * 
	 * @param query
	 * @param update
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void findAndModify(Query query, Update update) throws Exception {
		getMongoTemplate().findAndModify(query, update, this.cls, this.collectionName);
	}

	// /**
	// * findContainerOnlyID
	// * @param query
	// * @return
	// * @throws Exception
	// */
	// public List<?> findContainerOnlyID(Query query) throws Exception {
	//// return mongoTemplate.find(query, ContainerOnlyId.class,
	// this.collectionName);
	// }

	// /**
	// * findMgmtCmdOnlyID
	// * @param query
	// * @return
	// * @throws Exception
	// */
	// public List<?> findMgmtCmdOnlyID(Query query) throws Exception {
	//// return mongoTemplate.find(query, MgmtCmdOnlyId.class,
	// this.collectionName);
	// }

	/**
	 * getConverter
	 * 
	 * @param clazz
	 * @param dbObject
	 * @return
	 * @throws Exception
	 */
	public Object getConverter(Class<?> clazz, DBObject dbObject) throws Exception {
		return getMongoTemplate().getConverter().read(clazz, dbObject);
	}

	@SuppressWarnings("unchecked")
	public AggregationResults<?> aggregate(AggregationOperation... operations) {
		Aggregation aggregation = Aggregation.newAggregation(operations);

		return getMongoTemplate().aggregate(aggregation, this.cls, this.cls);
	}
}
