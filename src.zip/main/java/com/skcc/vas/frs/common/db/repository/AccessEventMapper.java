package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.biz.event.AccessEvent;

/**
 * @author
 * @since 2016-01-25
 */
@Repository("face.AccessEventMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface AccessEventMapper {

	/**
	 * The {@code id} of given {@code visitor} object would be ignored and the
	 * ID will be generated and assigned for the {@code visitor} object. The
	 * face objects assigned to the given {@code visitor} objects (which can be
	 * accessed using {@code visitor.getFaces()} would be ignored.
	 *
	 * @param
	 * @return
	 */

	int insertAccessEvent(@Param("event") AccessEvent event);

}
