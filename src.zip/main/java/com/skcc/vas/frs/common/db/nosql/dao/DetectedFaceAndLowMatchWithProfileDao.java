package com.skcc.vas.frs.common.db.nosql.dao;

import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceAndMatchWithProfile;

@Repository
public class DetectedFaceAndLowMatchWithProfileDao extends GenericMongoDao {

	public DetectedFaceAndLowMatchWithProfileDao() {
		collectionName = "VAS_DETECTED_FACE_N_LOW_MATCH_WITH_PROFILE_NOSQL";
		cls = NDetectedFaceAndMatchWithProfile.class;
	}

}
