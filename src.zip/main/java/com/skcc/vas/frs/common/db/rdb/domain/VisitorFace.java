package com.skcc.vas.frs.common.db.rdb.domain;

import com.skcc.vas.frs.common.biz.model.AbstractFace;

/**
 * @author
 * @since 2016-01-25
 *
 */
public class VisitorFace extends AbstractFace {

	/**
	 * the identifier for the visitor who has this face
	 */
	private String visitorId;

	/**
	 * @return the identifier for the visitor who has this face
	 */
	public String getVisitorId() {
		return this.visitorId;
	}

	public VisitorFace setVisitorId(String id) {
		this.visitorId = id;
		return this;
	}

	public VisitorFace() {
	}

}
