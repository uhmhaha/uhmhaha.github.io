package com.skcc.vas.frs.common.db.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.biz.model.AnalyticFace;
import com.skcc.vas.frs.common.db.nosql.domain.NConcernPersonAndFace;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;

@Repository("face.ConcernedFaceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface ConcernedFaceMapper {

	NConcernPersonAndFace seleectConcernedFaceAndPerson(@Param("id") String faceId);

	ConcernedFace selectConcernedFaceById(@Param("id") String id);

	Map<String, Object> selectACncrnImageBinary(@Param("id") String id);

	List<ConcernedFace> selectValidConcernedFaces();

	Map<String, String> selectConcernedFaceVolume(@Param("nodeId") String nodeId);

	List<ConcernedFace> selectValidScopeConcernedFaces(@Param("param") HashMap<String, String> param);

	String selectAllValidConcernedFacesCount();

	List<AnalyticFace> selectValidConcernedFeatures();

	/**
	 * @param personId
	 * @param activeOnly
	 *            when {@code false} the selection include faces that are
	 *            inactive state
	 * @return
	 */
	List<ConcernedFace> selectConcernedFacesWithoutMetaByPerson(@Param("personId") String personId,
			@Param("activeOnly") boolean activeOnly);

	/**
	 * Insert a row for a new concerned face.
	 *
	 * This method would assign {@code face.id} with the key value which is auto
	 * generated at database.
	 *
	 * @param face
	 * @return
	 */
	int insertConcernedFace(@Param("face") ConcernedFace face);

	@Deprecated
	int insertConcernedFaceImage(@Param("face") ConcernedFace face);

	int updateConcernedFace(@Param("face") ConcernedFace face);

	@Deprecated
	int updateConcernedFaceImage(@Param("face") ConcernedFace face);

	@Deprecated
	int updateFeatureExtracted(@Param("id") int id, @Param("feature") byte[] feature);

	@Deprecated
	int updateFaceFeatureInfo(@Param("personId") int personId, @Param("faceId") int faceId,
			@Param("feature") byte[] feature);

	/**
	 * Set the validity of the specified concerned face
	 *
	 * @param id
	 *            the ID of concerned face
	 * @param isValid
	 *            the validity to set
	 * @return
	 */
	int setValidity(@Param("id") String id, @Param("isValid") boolean isValid);

	/**
	 * Set the validity for all the faces of the specified concerned person
	 *
	 * @param personId
	 *            the ID of concerned person
	 * @param isValid
	 *            the validity to set
	 * @return
	 */
	int setValidityByPerson(@Param("personId") String personId, @Param("isValid") boolean isValid);

	/**
	 * Set the feature and landmarks of the specified concerned face
	 *
	 * @param faceId
	 * @param feature
	 * @param landmarks
	 * @return
	 */
	int setMetaOfConcernedFace(@Param("personId") String id, @Param("feature") byte[] feature,
			@Param("landmarks") String landmarks);

	List<ConcernedFace> selectOnlyValidConcernedFaces();

	/**
	 * @param
	 * @param
	 * @return
	 */
	List<ConcernedFace> selectConcernedFacesByJobId(@Param("jobId") String jobId);

	List<ConcernedFace> selectConcernedFaceIdsByPersonId(@Param("personId") String personId);
   
   int deleteMatchingNodeCncrnIndex(@Param("nodeId") int nodeId);
   
   int updateMatchingNodeCncrnIndex(@Param("nodeId") int nodeId, @Param("fromIdx") int fromIdx, @Param("toIdx") int toIdx);
   
   int insertMatchingNodeCncrnIndex(@Param("nodeId") int nodeId, @Param("fromIdx") int fromIdx, @Param("toIdx") int toIdx);

}
