package com.skcc.vas.frs.common.db.rdb.domain;

import com.skcc.vas.frs.common.biz.model.AbstractFace;

/**
 * @author
 * @since 2016-01-22
 *
 */
public class PersonnelFace extends AbstractFace {

	private String personnelId;

	public PersonnelFace() {
	}

	/**
	 * Gets the identifier for the personnel who has this face
	 *
	 * @return
	 */
	public String getPersonnelId() {
		return this.personnelId;
	}

	/**
	 * @param id
	 *            the identifier for the personnel who has this face
	 * @return
	 */
	public PersonnelFace setPersonnelId(String id) {
		this.personnelId = id;
		return this;
	}

}
