package com.skcc.vas.frs.common.db.nosql.domain;

import org.bson.types.Binary;

public class NDetectedFaceAndMatchWithProfile {

	private String DETECTED_FACE_ID;

	private String SYSTEM_ID;

	private String CCTV_ID;

	private String SRVC_TYPE;

	private String IMG_FILE;

	private int IMG_W;

	private int IMG_H;

	private int IMG_X;

	private int IMG_Y;

	private Binary DF_FEATURE;

	private String DF_LANDMARKS;

	private String FRM_FILE;

	private int FRM_W;

	private int FRM_H;

	private String FRM_TIME;

	private String LAST_UPDATE_BY;

	private String LAST_UPDATE_AT;

	private String DETECTED_DATE;

	private String CNCRN_FACE_ID;

	private int SCORE;

	private int RANK;

	private String LAST_UPDATE_MATCH_BY;

	private String LAST_UPDATE_MATCH_AT;

	private String RESULT_TYPE;

	private String PERSON_ID;

	private String NAME;

	private String GENDER;

	private String CONCERN_TYPE;

	private String CP_IS_VALID;

	private String CP_REMARKS;

	private String CP_LAST_UPDATE_BY;

	private String CP_LAST_UPDATE_AT;

	private String BIRTHDAY;

	private String NATIONALITY;

	private String PASSPORT_NO;

	private String FIRST_NAME;

	private String MIDDLE_NAME;

	private String LAST_NAME;

	private String FACE_ID;

	private String CF_IS_VALID;

	private Binary IMG;

	private String IMG_FORMAT;

	private int CF_IMG_W;

	private int CF_IMG_H;

	private Binary CF_FEATURE;

	private String CF_LANDMARKS;

	private String REMARKS;

	private String IMG_PATH;

	// public String getDetectedFaceId() {
	// return detectedFaceId;
	// }
	//
	// public void setDetectedFaceId(String detectedFaceId) {
	// this.detectedFaceId = detectedFaceId;
	// }
	//
	// public String getSystemId() {
	// return systemId;
	// }
	//
	// public void setSystemId(String systemId) {
	// this.systemId = systemId;
	// }
	//
	// public String getCctvId() {
	// return cctvId;
	// }
	//
	// public void setCctvId(String cctvId) {
	// this.cctvId = cctvId;
	// }
	//
	// public String getSrvcType() {
	// return srvcType;
	// }
	//
	// public void setSrvcType(String srvcType) {
	// this.srvcType = srvcType;
	// }
	//
	// public String getImgFile() {
	// return imgFile;
	// }
	//
	// public void setImgFile(String imgFile) {
	// this.imgFile = imgFile;
	// }
	//
	// public int getImgW() {
	// return imgW;
	// }
	//
	// public void setImgW(int imgW) {
	// this.imgW = imgW;
	// }
	//
	// public int getImgH() {
	// return imgH;
	// }
	//
	// public void setImgH(int imgH) {
	// this.imgH = imgH;
	// }
	//
	// public int getImgX() {
	// return imgX;
	// }
	//
	// public void setImgX(int imgX) {
	// this.imgX = imgX;
	// }
	//
	// public int getImgY() {
	// return imgY;
	// }
	//
	// public void setImgY(int imgY) {
	// this.imgY = imgY;
	// }
	//
	// public Binary getFeature() {
	// return feature;
	// }
	//
	// public void setFeature(Binary feature) {
	// this.feature = feature;
	// }
	//
	// public String getLandmarks() {
	// return landmarks;
	// }
	//
	// public void setLandmarks(String landmarks) {
	// this.landmarks = landmarks;
	// }
	//
	// public String getFrmFile() {
	// return frmFile;
	// }
	//
	// public void setFrmFile(String frmFile) {
	// this.frmFile = frmFile;
	// }
	//
	// public int getFrmW() {
	// return frmW;
	// }
	//
	// public void setFrmW(int frmW) {
	// this.frmW = frmW;
	// }
	//
	// public int getFrmH() {
	// return frmH;
	// }
	//
	// public void setFrmH(int frmH) {
	// this.frmH = frmH;
	// }
	//
	// public String getFrmTime() {
	// return frmTime;
	// }
	//
	// public void setFrmTime(String frmTime) {
	// this.frmTime = frmTime;
	// }
	//
	// public String getLastUpdateBy() {
	// return lastUpdateBy;
	// }
	//
	// public void setLastUpdateBy(String lastUpdateBy) {
	// this.lastUpdateBy = lastUpdateBy;
	// }
	//
	// public String getLastUpdateAt() {
	// return lastUpdateAt;
	// }
	//
	// public void setLastUpdateAt(String lastUpdateAt) {
	// this.lastUpdateAt = lastUpdateAt;
	// }
	//
	// public String getDetectedDate() {
	// return detectedDate;
	// }
	//
	// public void setDetectedDate(String detectedDate) {
	// this.detectedDate = detectedDate;
	// }
	//
	// public String getCncrnFaceId() {
	// return cncrnFaceId;
	// }
	//
	// public void setCncrnFaceId(String cncrnFaceId) {
	// this.cncrnFaceId = cncrnFaceId;
	// }
	//
	// public int getScore() {
	// return score;
	// }
	//
	// public void setScore(int score) {
	// this.score = score;
	// }
	//
	// public int getRank() {
	// return rank;
	// }
	//
	// public void setRank(int rank) {
	// this.rank = rank;
	// }
	//
	// public String getLastUpdateMatchBy() {
	// return lastUpdateMatchBy;
	// }
	//
	// public void setLastUpdateMatchBy(String lastUpdateMatchBy) {
	// this.lastUpdateMatchBy = lastUpdateMatchBy;
	// }
	//
	// public String getLastUpdateMatchAt() {
	// return lastUpdateMatchAt;
	// }
	//
	// public void setLastUpdateMatchAt(String lastUpdateMatchAt) {
	// this.lastUpdateMatchAt = lastUpdateMatchAt;
	// }
	//
	// public String getResultType() {
	// return resultType;
	// }
	//
	// public void setResultType(String resultType) {
	// this.resultType = resultType;
	// }
	//
	// public String getPersonId() {
	// return personId;
	// }
	//
	// public void setPersonId(String personId) {
	// this.personId = personId;
	// }
	//
	// public String getName() {
	// return name;
	// }
	//
	// public void setName(String name) {
	// this.name = name;
	// }
	//
	// public String getGender() {
	// return gender;
	// }
	//
	// public void setGender(String gender) {
	// this.gender = gender;
	// }
	//
	// public String getConcernType() {
	// return concernType;
	// }
	//
	// public void setConcernType(String concernType) {
	// this.concernType = concernType;
	// }
	//
	// public String getIsValid() {
	// return isValid;
	// }
	//
	// public void setIsValid(String isValid) {
	// this.isValid = isValid;
	// }
	//
	// public String getCpRemarks() {
	// return cpRemarks;
	// }
	//
	// public void setCpRemarks(String cpRemarks) {
	// this.cpRemarks = cpRemarks;
	// }
	//
	// public String getCpLastUpdateBy() {
	// return cpLastUpdateBy;
	// }
	//
	// public void setCpLastUpdateBy(String cpLastUpdateBy) {
	// this.cpLastUpdateBy = cpLastUpdateBy;
	// }
	//
	// public String getCpLastUpdateAt() {
	// return cpLastUpdateAt;
	// }
	//
	// public void setCpLastUpdateAt(String cpLastUpdateAt) {
	// this.cpLastUpdateAt = cpLastUpdateAt;
	// }
	//
	// public String getBirthday() {
	// return birthday;
	// }
	//
	// public void setBirthday(String birthday) {
	// this.birthday = birthday;
	// }
	//
	// public String getNationality() {
	// return nationality;
	// }
	//
	// public void setNationality(String nationality) {
	// this.nationality = nationality;
	// }
	//
	// public String getPassportNo() {
	// return passportNo;
	// }
	//
	// public void setPassportNo(String passportNo) {
	// this.passportNo = passportNo;
	// }
	//
	// public String getFirstName() {
	// return firstName;
	// }
	//
	// public void setFirstName(String firstName) {
	// this.firstName = firstName;
	// }
	//
	// public String getMiddleName() {
	// return middleName;
	// }
	//
	// public void setMiddleName(String middleName) {
	// this.middleName = middleName;
	// }
	//
	// public String getLastName() {
	// return lastName;
	// }
	//
	// public void setLastName(String lastName) {
	// this.lastName = lastName;
	// }
	//
	// public String getFaceId() {
	// return faceId;
	// }
	//
	// public void setFaceId(String faceId) {
	// this.faceId = faceId;
	// }
	//
	// public String getIsValidFace() {
	// return isValidFace;
	// }
	//
	// public void setIsValidFace(String isValidFace) {
	// this.isValidFace = isValidFace;
	// }
	//
	// public Binary getImg() {
	// return img;
	// }
	//
	// public void setImg(Binary img) {
	// this.img = img;
	// }
	//
	// public String getImgFormat() {
	// return imgFormat;
	// }
	//
	// public void setImgFormat(String imgFormat) {
	// this.imgFormat = imgFormat;
	// }
	//
	// public int getCfImgW() {
	// return cfImgW;
	// }
	//
	// public void setCfImgW(int cfImgW) {
	// this.cfImgW = cfImgW;
	// }
	//
	// public int getCfImgH() {
	// return cfImgH;
	// }
	//
	// public void setCfImgH(int cfImgH) {
	// this.cfImgH = cfImgH;
	// }
	//
	// public Binary getCfFeature() {
	// return cfFeature;
	// }
	//
	// public void setCfFeature(Binary cfFeature) {
	// this.cfFeature = cfFeature;
	// }
	//
	// public String getCfLandmarks() {
	// return cfLandmarks;
	// }
	//
	// public void setCfLandmarks(String cfLandmarks) {
	// this.cfLandmarks = cfLandmarks;
	// }
	//
	// public String getCfRemarks() {
	// return cfRemarks;
	// }
	//
	// public void setCfRemarks(String cfRemarks) {
	// this.cfRemarks = cfRemarks;
	// }

	////////////////////////////////////////////////////////////////////////////////////////////////

	public String getDETECTED_FACE_ID() {
		return DETECTED_FACE_ID;
	}

	public void setDETECTED_FACE_ID(String dETECTED_FACE_ID) {
		DETECTED_FACE_ID = dETECTED_FACE_ID;
	}

	public String getSYSTEM_ID() {
		return SYSTEM_ID;
	}

	public void setSYSTEM_ID(String sYSTEM_ID) {
		SYSTEM_ID = sYSTEM_ID;
	}

	public String getCCTV_ID() {
		return CCTV_ID;
	}

	public void setCCTV_ID(String cCTV_ID) {
		CCTV_ID = cCTV_ID;
	}

	public String getSRVC_TYPE() {
		return SRVC_TYPE;
	}

	public void setSRVC_TYPE(String sRVC_TYPE) {
		SRVC_TYPE = sRVC_TYPE;
	}

	public String getIMG_FILE() {
		return IMG_FILE;
	}

	public void setIMG_FILE(String iMG_FILE) {
		IMG_FILE = iMG_FILE;
	}

	public int getIMG_W() {
		return IMG_W;
	}

	public void setIMG_W(int iMG_W) {
		IMG_W = iMG_W;
	}

	public int getIMG_H() {
		return IMG_H;
	}

	public void setIMG_H(int iMG_H) {
		IMG_H = iMG_H;
	}

	public int getIMG_X() {
		return IMG_X;
	}

	public void setIMG_X(int iMG_X) {
		IMG_X = iMG_X;
	}

	public int getIMG_Y() {
		return IMG_Y;
	}

	public void setIMG_Y(int iMG_Y) {
		IMG_Y = iMG_Y;
	}

	public Binary getDF_FEATURE() {
		return DF_FEATURE;
	}

	public void setDF_FEATURE(Binary dF_FEATURE) {
		DF_FEATURE = dF_FEATURE;
	}

	public String getDF_LANDMARKS() {
		return DF_LANDMARKS;
	}

	public void setDF_LANDMARKS(String dF_LANDMARKS) {
		DF_LANDMARKS = dF_LANDMARKS;
	}

	public String getFRM_FILE() {
		return FRM_FILE;
	}

	public void setFRM_FILE(String fRM_FILE) {
		FRM_FILE = fRM_FILE;
	}

	public int getFRM_W() {
		return FRM_W;
	}

	public void setFRM_W(int fRM_W) {
		FRM_W = fRM_W;
	}

	public int getFRM_H() {
		return FRM_H;
	}

	public void setFRM_H(int fRM_H) {
		FRM_H = fRM_H;
	}

	public String getFRM_TIME() {
		return FRM_TIME;
	}

	public void setFRM_TIME(String fRM_TIME) {
		FRM_TIME = fRM_TIME;
	}

	public String getLAST_UPDATE_BY() {
		return LAST_UPDATE_BY;
	}

	public void setLAST_UPDATE_BY(String lAST_UPDATE_BY) {
		LAST_UPDATE_BY = lAST_UPDATE_BY;
	}

	public String getLAST_UPDATE_AT() {
		return LAST_UPDATE_AT;
	}

	public void setLAST_UPDATE_AT(String lAST_UPDATE_AT) {
		LAST_UPDATE_AT = lAST_UPDATE_AT;
	}

	public String getDETECTED_DATE() {
		return DETECTED_DATE;
	}

	public void setDETECTED_DATE(String dETECTED_DATE) {
		DETECTED_DATE = dETECTED_DATE;
	}

	public String getCNCRN_FACE_ID() {
		return CNCRN_FACE_ID;
	}

	public void setCNCRN_FACE_ID(String cNCRN_FACE_ID) {
		CNCRN_FACE_ID = cNCRN_FACE_ID;
	}

	public int getSCORE() {
		return SCORE;
	}

	public void setSCORE(int sCORE) {
		SCORE = sCORE;
	}

	public int getRANK() {
		return RANK;
	}

	public void setRANK(int rANK) {
		RANK = rANK;
	}

	public String getLAST_UPDATE_MATCH_BY() {
		return LAST_UPDATE_MATCH_BY;
	}

	public void setLAST_UPDATE_MATCH_BY(String lAST_UPDATE_MATCH_BY) {
		LAST_UPDATE_MATCH_BY = lAST_UPDATE_MATCH_BY;
	}

	public String getLAST_UPDATE_MATCH_AT() {
		return LAST_UPDATE_MATCH_AT;
	}

	public void setLAST_UPDATE_MATCH_AT(String lAST_UPDATE_MATCH_AT) {
		LAST_UPDATE_MATCH_AT = lAST_UPDATE_MATCH_AT;
	}

	public String getRESULT_TYPE() {
		return RESULT_TYPE;
	}

	public void setRESULT_TYPE(String rESULT_TYPE) {
		RESULT_TYPE = rESULT_TYPE;
	}

	public String getPERSON_ID() {
		return PERSON_ID;
	}

	public void setPERSON_ID(String pERSON_ID) {
		PERSON_ID = pERSON_ID;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getGENDER() {
		return GENDER;
	}

	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}

	public String getCONCERN_TYPE() {
		return CONCERN_TYPE;
	}

	public void setCONCERN_TYPE(String cONCERN_TYPE) {
		CONCERN_TYPE = cONCERN_TYPE;
	}

	public String getCP_IS_VALID() {
		return CP_IS_VALID;
	}

	public void setCP_IS_VALID(String cP_IS_VALID) {
		CP_IS_VALID = cP_IS_VALID;
	}

	public String getCP_REMARKS() {
		return CP_REMARKS;
	}

	public void setCP_REMARKS(String cP_REMARKS) {
		CP_REMARKS = cP_REMARKS;
	}

	public String getCP_LAST_UPDATE_BY() {
		return CP_LAST_UPDATE_BY;
	}

	public void setCP_LAST_UPDATE_BY(String cP_LAST_UPDATE_BY) {
		CP_LAST_UPDATE_BY = cP_LAST_UPDATE_BY;
	}

	public String getCP_LAST_UPDATE_AT() {
		return CP_LAST_UPDATE_AT;
	}

	public void setCP_LAST_UPDATE_AT(String cP_LAST_UPDATE_AT) {
		CP_LAST_UPDATE_AT = cP_LAST_UPDATE_AT;
	}

	public String getBIRTHDAY() {
		return BIRTHDAY;
	}

	public void setBIRTHDAY(String bIRTHDAY) {
		BIRTHDAY = bIRTHDAY;
	}

	public String getNATIONALITY() {
		return NATIONALITY;
	}

	public void setNATIONALITY(String nATIONALITY) {
		NATIONALITY = nATIONALITY;
	}

	public String getPASSPORT_NO() {
		return PASSPORT_NO;
	}

	public void setPASSPORT_NO(String pASSPORT_NO) {
		PASSPORT_NO = pASSPORT_NO;
	}

	public String getFIRST_NAME() {
		return FIRST_NAME;
	}

	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}

	public String getMIDDLE_NAME() {
		return MIDDLE_NAME;
	}

	public void setMIDDLE_NAME(String mIDDLE_NAME) {
		MIDDLE_NAME = mIDDLE_NAME;
	}

	public String getLAST_NAME() {
		return LAST_NAME;
	}

	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}

	public String getFACE_ID() {
		return FACE_ID;
	}

	public void setFACE_ID(String fACE_ID) {
		FACE_ID = fACE_ID;
	}

	public String getCF_IS_VALID() {
		return CF_IS_VALID;
	}

	public void setCF_IS_VALID(String cF_IS_VALID) {
		CF_IS_VALID = cF_IS_VALID;
	}

	public Binary getIMG() {
		return IMG;
	}

	public void setIMG(Binary iMG) {
		IMG = iMG;
	}

	public String getIMG_FORMAT() {
		return IMG_FORMAT;
	}

	public void setIMG_FORMAT(String iMG_FORMAT) {
		IMG_FORMAT = iMG_FORMAT;
	}

	public int getCF_IMG_W() {
		return CF_IMG_W;
	}

	public void setCF_IMG_W(int cF_IMG_W) {
		CF_IMG_W = cF_IMG_W;
	}

	public int getCF_IMG_H() {
		return CF_IMG_H;
	}

	public void setCF_IMG_H(int cF_IMG_H) {
		CF_IMG_H = cF_IMG_H;
	}

	public Binary getCF_FEATURE() {
		return CF_FEATURE;
	}

	public void setCF_FEATURE(Binary cF_FEATURE) {
		CF_FEATURE = cF_FEATURE;
	}

	public String getCF_LANDMARKS() {
		return CF_LANDMARKS;
	}

	public void setCF_LANDMARKS(String cF_LANDMARKS) {
		CF_LANDMARKS = cF_LANDMARKS;
	}

	public String getREMARKS() {
		return REMARKS;
	}

	public void setREMARKS(String rEMARKS) {
		REMARKS = rEMARKS;
	}

	public String getIMG_PATH() {
		return IMG_PATH;
	}

	public void setIMG_PATH(String iMG_PATH) {
		IMG_PATH = iMG_PATH;
	}

}
