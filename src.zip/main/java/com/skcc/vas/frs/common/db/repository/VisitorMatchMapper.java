package com.skcc.vas.frs.common.db.repository;

import javax.annotation.ParametersAreNonnullByDefault;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * @author
 * @since 2016. 2. 2.
 *
 */
@Repository("face.VisitorMatchMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface VisitorMatchMapper {

	int insertVisitorMatch(@Param("visitorFaceId") String visitorFaceId, @Param("detectedFaceId") String detectedFaceId,
			@Param("score") int score, @Param("passNo") String passNo, @Param("accessAt") String accessAt,
			@Param("updateBy") String userId, @Param("rank") int rank);

}
