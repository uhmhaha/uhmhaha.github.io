package com.skcc.vas.frs.common.util.ondemand;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Pattern;

/**
 *
 * Note that the thread-safeness is different between implementations.
 *
 * @author
 * @since 2015-06-11
 */
public interface FilePreparer {

	// @TODO Consider non-void return such as FileInfo[], List<FileInfo>
	/**
	 * @param systemId
	 * @param deviceId
	 *            The ID of device, usually camera
	 * @param from
	 * @param to
	 * @return
	 */
	@Nonnull
	public FileValue[] prepareFiles(String systemId, String deviceId, @Pattern(regexp = "[1-9][0-9]{7}") String from,
			@Pattern(regexp = "[1-9][0-9]{7}") String to);

	/**
	 * @return {@code null} before the status can't be said.
	 */
	@Nullable
	public FilePrepareState getState();

	public static class FileValue implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		public FileValue() {
		} // For serialization

		/**
		 * Set the {@code size} '-1', if the size is unknown or not concerned.
		 *
		 * @param fullName
		 * @param size
		 */
		public FileValue(String fullName, long size) {
			this.fullName = fullName;
			this.size = size;
		}

		public FileValue(String fullName) {
			this(fullName, -1);
		}

		private String fullName;

		/**
		 *
		 * @see java.io.File#length()
		 */
		// @TODO Why are the size necessary?
		private long size;

		public String getFullName() {
			return this.fullName;
		}

		public FileValue setFullName(String name) {
			this.fullName = name;
			return this;
		}

		public long getSize() {
			return this.size;
		}

		public FileValue setSize(long size) {
			this.size = size;
			return this;
		}
	}
}
