package com.skcc.vas.frs.common.biz.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.biz.domain.ConfigProperty;

@Repository("VasConfigMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface VasConfigMapper {
	
	List<ConfigProperty> selectVASConfigProperty(String param);
	List<ConfigProperty> selectVASConfigPropertyIpBased(String param);
	List<ConfigProperty> selectVASConfigPropertyNodeIdBased(String param);
	
	
	List<ConfigProperty> selectVASConfigPropertyMyNode(String param);
	List<ConfigProperty> selectVASConfigPropertyMasterNode(String param);

}
