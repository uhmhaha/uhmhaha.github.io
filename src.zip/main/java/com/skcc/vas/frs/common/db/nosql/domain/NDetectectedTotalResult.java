package com.skcc.vas.frs.common.db.nosql.domain;

public class NDetectectedTotalResult {

	private NDetectedFaceMatch detectedFaceMatch;

	private NConcernPersonAndFace concernPersonAndFace;

	public NDetectectedTotalResult(NDetectedFaceMatch detectedFaceMatch, NConcernPersonAndFace concernPersonAndFace) {
		this.detectedFaceMatch = detectedFaceMatch;
		this.concernPersonAndFace = concernPersonAndFace;
	}

	public NDetectedFaceMatch getDetectedFaceMatch() {
		return detectedFaceMatch;
	}

	public void setDetectedFaceMatch(NDetectedFaceMatch detectedFaceMatch) {
		this.detectedFaceMatch = detectedFaceMatch;
	}

	public NConcernPersonAndFace getConcernPersonAndFace() {
		return concernPersonAndFace;
	}

	public void setConcernPersonAndFace(NConcernPersonAndFace concernPersonAndFace) {
		this.concernPersonAndFace = concernPersonAndFace;
	}

}
