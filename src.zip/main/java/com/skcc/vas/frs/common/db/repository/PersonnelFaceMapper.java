package com.skcc.vas.frs.common.db.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.constraints.NotNull;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.common.db.rdb.domain.PersonnelFace;

@Repository("face.PersonnelFaceMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface PersonnelFaceMapper {

	/**
	 * @param id
	 *            the ID of the personnel whose faces to find
	 * @return
	 */
	@NotNull
	List<PersonnelFace> selectPersonnelFacesByPersonnel(@Param("personnelId") String id);

	/**
	 * Sets the feature and landmarks for the specified personnel face
	 *
	 * @param id
	 *            the ID of personnel face
	 * @param feature
	 * @param landmarks
	 * @return
	 */
	int setFeatureAndLandmarks(@Param("id") String id, @Param("feature") byte[] feature,
			@Param("landmarks") String landmarks);

	int insertPersonnelFace(@Param("personnelFace") PersonnelFace personnelFace);

}
