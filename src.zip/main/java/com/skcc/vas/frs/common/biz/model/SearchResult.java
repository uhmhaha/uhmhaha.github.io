package com.skcc.vas.frs.common.biz.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.tuple.Pair;

import com.skcc.vas.frs.common.biz.event.Event;
import com.skcc.vas.frs.common.biz.event.EventContext;

/**
 * @author
 * @since 2015-06-19
 *
 * @param <E>
 * @param <C>
 */
public class SearchResult<E extends Event, C extends EventContext> {

	private List<Pair<? extends E, C>> items = new ArrayList<Pair<? extends E, C>>();

	@Min(0)
	private int persistedItemsNum = 0;

	public SearchResult() {

	}

	public <T extends E> SearchResult<E, C> addItem(T ev, C cntx) {
		this.items.add(Pair.of(ev, cntx));
		return this;
	}

	@Nonnull
	public List<Pair<? extends E, C>> getItems() {
		return this.items;
	}

	public int getPersistedItemsNum() {
		return persistedItemsNum;
	}

	/**
	 * Gets the number of items that are found but not persisted.
	 * <p>
	 * The reason this value is not zero can be various. It may be that the
	 * items are not yet tried to persisted or it may be that the items are
	 * tried to persisted but there's an exception.
	 *
	 * @return
	 */
	public int getMissedItemsNum() {
		return this.getItems().size() - this.persistedItemsNum;
	}

	public SearchResult<E, C> setPersistedItemsNum(@Min(0) int num) {
		this.persistedItemsNum = num;
		return this;
	}

}
