package com.skcc.vas.frs.common.db.nosql.domain;

public class MetaDataByCctvID {

	private String devTypeId;

	private String vmsId;

	private String devNm;

	private String devId;

	private String siteNm;

	private String bldNm;

	private String flrNm;

	public String getDevTypeId() {
		return devTypeId;
	}

	public void setDevTypeId(String devTypeId) {
		this.devTypeId = devTypeId;
	}

	public String getVmsId() {
		return vmsId;
	}

	public void setVmsId(String vmsId) {
		this.vmsId = vmsId;
	}

	public String getDevNm() {
		return devNm;
	}

	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}

	public String getDevId() {
		return devId;
	}

	public void setDevId(String devId) {
		this.devId = devId;
	}

	public String getSiteNm() {
		return siteNm;
	}

	public void setSiteNm(String siteNm) {
		this.siteNm = siteNm;
	}

	public String getBldNm() {
		return bldNm;
	}

	public void setBldNm(String bldNm) {
		this.bldNm = bldNm;
	}

	public String getFlrNm() {
		return flrNm;
	}

	public void setFlrNm(String flrNm) {
		this.flrNm = flrNm;
	}

}
