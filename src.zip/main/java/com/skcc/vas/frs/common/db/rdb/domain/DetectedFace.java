package com.skcc.vas.frs.common.db.rdb.domain;

//@TODO(Done) Rename to 'DetectedFace' later
/**
 * @author
 * @since 2015-11-23
 */
public class DetectedFace {

	@Deprecated // @TODO Remove this field and related member ASAP after
				// confirmation
	private int cncrnFaceId;

	private String detectedFaceId; // change dataType from int to String

	private String id; // change dataType from int to String

	private String systemId;

	private String cctvId;

	private String srvcType;

	private String imgFile;

	private int imgWidth;

	private int imgHeight;

	private int imgX;

	private int imgY;

	private byte[] feature;

	private String landmarks;

	private String frmFile;

	private int frmWidth;

	private int frmHeight;

	private String frmTime;

	private String lastUpdateBy;

	private String lastUpdateAt;

	private int score;

	private int rank;

	private String absoluteImagePath;

	public String getAbsoluteImagePath() {
		return absoluteImagePath;
	}

	public void setAbsoluteImagePath(String absoluteImagePath) {
		this.absoluteImagePath = absoluteImagePath;
	}

	@Deprecated // @TODO Remove this field and related member ASAP after
				// confirmation
	private int jobCncrnFaceId;

	public int getCncrnFaceId() {
		return cncrnFaceId;
	}

	public DetectedFace setCncrnFaceId(int cncrnFaceId) {
		this.cncrnFaceId = cncrnFaceId;
		return this;
	}

	public String getDetectedFaceId() {
		return detectedFaceId;
	}

	public DetectedFace setDetectedFaceId(String detectedFaceId) {
		this.detectedFaceId = detectedFaceId;
		return this;
	}

	public String getId() {
		return id;
	}

	public DetectedFace setId(String id) {
		this.id = id;
		return this;
	}

	public String getSystemId() {
		return systemId;
	}

	public DetectedFace setSystemId(String systemId) {
		this.systemId = systemId;
		return this;
	}

	public String getCctvId() {
		return cctvId;
	}

	public DetectedFace setCctvId(String cctvId) {
		this.cctvId = cctvId;
		return this;
	}

	public String getSrvcType() {
		return srvcType;
	}

	public DetectedFace setSrvcType(String srvcType) {
		this.srvcType = srvcType;
		return this;
	}

	public String getImgFile() {
		return imgFile;
	}

	public DetectedFace setImgFile(String imgFile) {
		this.imgFile = imgFile;
		return this;
	}

	public int getImgWidth() {
		return imgWidth;
	}

	public DetectedFace setImgWidth(int imgWidth) {
		this.imgWidth = imgWidth;
		return this;
	}

	public int getImgHeight() {
		return imgHeight;
	}

	public DetectedFace setImgHeight(int imgHeight) {
		this.imgHeight = imgHeight;
		return this;
	}

	public int getImgX() {
		return imgX;
	}

	public DetectedFace setImgX(int imgX) {
		this.imgX = imgX;
		return this;
	}

	public int getImgY() {
		return imgY;
	}

	public DetectedFace setImgY(int imgY) {
		this.imgY = imgY;
		return this;
	}

	public byte[] getFeature() {
		return feature;
	}

	public DetectedFace setFeature(byte[] feature) {
		this.feature = feature;
		return this;
	}

	public String getLandmarks() {
		return landmarks;
	}

	public DetectedFace setLandmarks(String landmarks) {
		this.landmarks = landmarks;
		return this;
	}

	public String getFrmFile() {
		return frmFile;
	}

	public DetectedFace setFrmFile(String frmFile) {
		this.frmFile = frmFile;
		return this;
	}

	public int getFrmWidth() {
		return frmWidth;
	}

	public DetectedFace setFrmWidth(int frmWidth) {
		this.frmWidth = frmWidth;
		return this;
	}

	public int getFrmHeight() {
		return frmHeight;
	}

	public DetectedFace setFrmHeight(int frmHeight) {
		this.frmHeight = frmHeight;
		return this;
	}

	public String getFrmTime() {
		return frmTime;
	}

	public DetectedFace setFrmTime(String frmTime) {
		this.frmTime = frmTime;
		return this;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public DetectedFace setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
		return this;
	}

	public String getLastUpdateAt() {
		return lastUpdateAt;
	}

	public DetectedFace setLastUpdateAt(String lastUpdateAt) {
		this.lastUpdateAt = lastUpdateAt;
		return this;
	}

	public int getScore() {
		return score;
	}

	public DetectedFace setScore(int score) {
		this.score = score;
		return this;
	}

	public int getRank() {
		return rank;
	}

	public DetectedFace setRank(int rank) {
		this.rank = rank;
		return this;
	}

	public int getJobCncrnFaceId() {
		return jobCncrnFaceId;
	}

	public void setJobCncrnFaceId(int jobCncrnFaceId) {
		this.jobCncrnFaceId = jobCncrnFaceId;
	}

}
