package com.skcc.vas.frs.common.db.rdb.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skcc.vas.frs.common.db.nosql.dao.DetectedFaceAndMatchWithProfileDao;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceAndMatchWithProfile;
import com.skcc.vas.frs.matching.biz.MongoTemplateManager;

@Service("face.DetectedFaceAndMatchWithProfileService")
public class DetectedFaceAndMatchWithProfileService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private DetectedFaceAndMatchWithProfileDao detectedFaceAndMatchWithProfileDao;

	public NDetectedFaceAndMatchWithProfile insertDetectedFaceAndMatchWithProfile(
			NDetectedFaceAndMatchWithProfile nFaceAndMatchWithProfile) throws Exception {

		NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfileItem = new NDetectedFaceAndMatchWithProfile();

		nDetectedFaceAndMatchWithProfileItem.setDETECTED_FACE_ID(nFaceAndMatchWithProfile.getDETECTED_FACE_ID());
		nDetectedFaceAndMatchWithProfileItem.setSYSTEM_ID(nFaceAndMatchWithProfile.getSYSTEM_ID());
		nDetectedFaceAndMatchWithProfileItem.setCCTV_ID(nFaceAndMatchWithProfile.getCCTV_ID());
		nDetectedFaceAndMatchWithProfileItem.setSRVC_TYPE(nFaceAndMatchWithProfile.getSRVC_TYPE());
		nDetectedFaceAndMatchWithProfileItem.setIMG_FILE(nFaceAndMatchWithProfile.getIMG_FILE());
		nDetectedFaceAndMatchWithProfileItem.setIMG_W(nFaceAndMatchWithProfile.getIMG_W());
		nDetectedFaceAndMatchWithProfileItem.setIMG_H(nFaceAndMatchWithProfile.getIMG_H());
		nDetectedFaceAndMatchWithProfileItem.setIMG_X(nFaceAndMatchWithProfile.getIMG_X());
		nDetectedFaceAndMatchWithProfileItem.setIMG_Y(nFaceAndMatchWithProfile.getIMG_Y());
		nDetectedFaceAndMatchWithProfileItem.setDF_FEATURE(nFaceAndMatchWithProfile.getDF_FEATURE());
		nDetectedFaceAndMatchWithProfileItem.setFRM_FILE(nFaceAndMatchWithProfile.getFRM_FILE());
		nDetectedFaceAndMatchWithProfileItem.setFRM_W(nFaceAndMatchWithProfile.getFRM_W());
		nDetectedFaceAndMatchWithProfileItem.setFRM_H(nFaceAndMatchWithProfile.getFRM_H());
		nDetectedFaceAndMatchWithProfileItem.setFRM_TIME(nFaceAndMatchWithProfile.getFRM_TIME());
		nDetectedFaceAndMatchWithProfileItem.setLAST_UPDATE_AT(nFaceAndMatchWithProfile.getLAST_UPDATE_AT());
		nDetectedFaceAndMatchWithProfileItem.setDETECTED_DATE(nFaceAndMatchWithProfile.getDETECTED_DATE());

		if (nFaceAndMatchWithProfile.getCNCRN_FACE_ID() != null) {
			nDetectedFaceAndMatchWithProfileItem.setCNCRN_FACE_ID(nFaceAndMatchWithProfile.getCNCRN_FACE_ID());
			nDetectedFaceAndMatchWithProfileItem.setSCORE(nFaceAndMatchWithProfile.getSCORE());
			nDetectedFaceAndMatchWithProfileItem.setRANK(nFaceAndMatchWithProfile.getRANK());
			nDetectedFaceAndMatchWithProfileItem
					.setLAST_UPDATE_MATCH_BY(nFaceAndMatchWithProfile.getLAST_UPDATE_MATCH_BY());
			nDetectedFaceAndMatchWithProfileItem
					.setLAST_UPDATE_MATCH_AT(nFaceAndMatchWithProfile.getLAST_UPDATE_MATCH_AT());

			if (nFaceAndMatchWithProfile.getPERSON_ID() != null) {
				nDetectedFaceAndMatchWithProfileItem.setPERSON_ID(nFaceAndMatchWithProfile.getPERSON_ID());
				nDetectedFaceAndMatchWithProfileItem.setNAME(nFaceAndMatchWithProfile.getNAME());
				nDetectedFaceAndMatchWithProfileItem.setGENDER(nFaceAndMatchWithProfile.getGENDER());
				nDetectedFaceAndMatchWithProfileItem.setCONCERN_TYPE(nFaceAndMatchWithProfile.getCONCERN_TYPE());
				nDetectedFaceAndMatchWithProfileItem.setCP_IS_VALID(nFaceAndMatchWithProfile.getCP_IS_VALID());
				nDetectedFaceAndMatchWithProfileItem.setCP_REMARKS(nFaceAndMatchWithProfile.getCP_REMARKS());
				nDetectedFaceAndMatchWithProfileItem
						.setCP_LAST_UPDATE_AT(nFaceAndMatchWithProfile.getCP_LAST_UPDATE_AT());
				nDetectedFaceAndMatchWithProfileItem
						.setCP_LAST_UPDATE_BY(nFaceAndMatchWithProfile.getCP_LAST_UPDATE_BY());
				nDetectedFaceAndMatchWithProfileItem.setBIRTHDAY(nFaceAndMatchWithProfile.getBIRTHDAY());
				nDetectedFaceAndMatchWithProfileItem.setNATIONALITY(nFaceAndMatchWithProfile.getNATIONALITY());
				nDetectedFaceAndMatchWithProfileItem.setPASSPORT_NO(nFaceAndMatchWithProfile.getPASSPORT_NO());
				nDetectedFaceAndMatchWithProfileItem.setFIRST_NAME(nFaceAndMatchWithProfile.getFIRST_NAME());
				nDetectedFaceAndMatchWithProfileItem.setMIDDLE_NAME(nFaceAndMatchWithProfile.getMIDDLE_NAME());
				nDetectedFaceAndMatchWithProfileItem.setLAST_NAME(nFaceAndMatchWithProfile.getLAST_NAME());
				nDetectedFaceAndMatchWithProfileItem.setFACE_ID(nFaceAndMatchWithProfile.getFACE_ID());
				nDetectedFaceAndMatchWithProfileItem.setCF_IS_VALID(nFaceAndMatchWithProfile.getCF_IS_VALID());
				// nDetectedFaceAndMatchWithProfileItem.setImg(nFaceAndMatchWithProfile.getImg());
				nDetectedFaceAndMatchWithProfileItem.setIMG_FORMAT(nFaceAndMatchWithProfile.getIMG_FORMAT());
				nDetectedFaceAndMatchWithProfileItem.setCF_IMG_H(nFaceAndMatchWithProfile.getCF_IMG_H());
				nDetectedFaceAndMatchWithProfileItem.setCF_IMG_W(nFaceAndMatchWithProfile.getCF_IMG_W());
				// nDetectedFaceAndMatchWithProfileItem.setCfFeature(nFaceAndMatchWithProfile.getFeature());
				nDetectedFaceAndMatchWithProfileItem.setCF_LANDMARKS(nFaceAndMatchWithProfile.getCF_LANDMARKS());
				nDetectedFaceAndMatchWithProfileItem.setREMARKS(nFaceAndMatchWithProfile.getREMARKS());
				nDetectedFaceAndMatchWithProfileItem.setIMG_PATH(nFaceAndMatchWithProfile.getIMG_PATH());
			}
		}

		detectedFaceAndMatchWithProfileDao.insert(nDetectedFaceAndMatchWithProfileItem);
		return nDetectedFaceAndMatchWithProfileItem;
	}
	
	
	public NDetectedFaceAndMatchWithProfile insertDetectedFaceAndMatchWithProfile(
			NDetectedFaceAndMatchWithProfile nFaceAndMatchWithProfile, MongoTemplateManager mongoTemplateManager) throws Exception {

		NDetectedFaceAndMatchWithProfile nDetectedFaceAndMatchWithProfileItem = new NDetectedFaceAndMatchWithProfile();

		nDetectedFaceAndMatchWithProfileItem.setDETECTED_FACE_ID(nFaceAndMatchWithProfile.getDETECTED_FACE_ID());
		nDetectedFaceAndMatchWithProfileItem.setSYSTEM_ID(nFaceAndMatchWithProfile.getSYSTEM_ID());
		nDetectedFaceAndMatchWithProfileItem.setCCTV_ID(nFaceAndMatchWithProfile.getCCTV_ID());
		nDetectedFaceAndMatchWithProfileItem.setSRVC_TYPE(nFaceAndMatchWithProfile.getSRVC_TYPE());
		nDetectedFaceAndMatchWithProfileItem.setIMG_FILE(nFaceAndMatchWithProfile.getIMG_FILE());
		nDetectedFaceAndMatchWithProfileItem.setIMG_W(nFaceAndMatchWithProfile.getIMG_W());
		nDetectedFaceAndMatchWithProfileItem.setIMG_H(nFaceAndMatchWithProfile.getIMG_H());
		nDetectedFaceAndMatchWithProfileItem.setIMG_X(nFaceAndMatchWithProfile.getIMG_X());
		nDetectedFaceAndMatchWithProfileItem.setIMG_Y(nFaceAndMatchWithProfile.getIMG_Y());
		nDetectedFaceAndMatchWithProfileItem.setDF_FEATURE(nFaceAndMatchWithProfile.getDF_FEATURE());
		nDetectedFaceAndMatchWithProfileItem.setFRM_FILE(nFaceAndMatchWithProfile.getFRM_FILE());
		nDetectedFaceAndMatchWithProfileItem.setFRM_W(nFaceAndMatchWithProfile.getFRM_W());
		nDetectedFaceAndMatchWithProfileItem.setFRM_H(nFaceAndMatchWithProfile.getFRM_H());
		nDetectedFaceAndMatchWithProfileItem.setFRM_TIME(nFaceAndMatchWithProfile.getFRM_TIME());
		nDetectedFaceAndMatchWithProfileItem.setLAST_UPDATE_AT(nFaceAndMatchWithProfile.getLAST_UPDATE_AT());
		nDetectedFaceAndMatchWithProfileItem.setDETECTED_DATE(nFaceAndMatchWithProfile.getDETECTED_DATE());

		if (nFaceAndMatchWithProfile.getCNCRN_FACE_ID() != null) {
			nDetectedFaceAndMatchWithProfileItem.setCNCRN_FACE_ID(nFaceAndMatchWithProfile.getCNCRN_FACE_ID());
			nDetectedFaceAndMatchWithProfileItem.setSCORE(nFaceAndMatchWithProfile.getSCORE());
			nDetectedFaceAndMatchWithProfileItem.setRANK(nFaceAndMatchWithProfile.getRANK());
			nDetectedFaceAndMatchWithProfileItem
					.setLAST_UPDATE_MATCH_BY(nFaceAndMatchWithProfile.getLAST_UPDATE_MATCH_BY());
			nDetectedFaceAndMatchWithProfileItem
					.setLAST_UPDATE_MATCH_AT(nFaceAndMatchWithProfile.getLAST_UPDATE_MATCH_AT());

			if (nFaceAndMatchWithProfile.getPERSON_ID() != null) {
				nDetectedFaceAndMatchWithProfileItem.setPERSON_ID(nFaceAndMatchWithProfile.getPERSON_ID());
				nDetectedFaceAndMatchWithProfileItem.setNAME(nFaceAndMatchWithProfile.getNAME());
				nDetectedFaceAndMatchWithProfileItem.setGENDER(nFaceAndMatchWithProfile.getGENDER());
				nDetectedFaceAndMatchWithProfileItem.setCONCERN_TYPE(nFaceAndMatchWithProfile.getCONCERN_TYPE());
				nDetectedFaceAndMatchWithProfileItem.setCP_IS_VALID(nFaceAndMatchWithProfile.getCP_IS_VALID());
				nDetectedFaceAndMatchWithProfileItem.setCP_REMARKS(nFaceAndMatchWithProfile.getCP_REMARKS());
				nDetectedFaceAndMatchWithProfileItem
						.setCP_LAST_UPDATE_AT(nFaceAndMatchWithProfile.getCP_LAST_UPDATE_AT());
				nDetectedFaceAndMatchWithProfileItem
						.setCP_LAST_UPDATE_BY(nFaceAndMatchWithProfile.getCP_LAST_UPDATE_BY());
				nDetectedFaceAndMatchWithProfileItem.setBIRTHDAY(nFaceAndMatchWithProfile.getBIRTHDAY());
				nDetectedFaceAndMatchWithProfileItem.setNATIONALITY(nFaceAndMatchWithProfile.getNATIONALITY());
				nDetectedFaceAndMatchWithProfileItem.setPASSPORT_NO(nFaceAndMatchWithProfile.getPASSPORT_NO());
				nDetectedFaceAndMatchWithProfileItem.setFIRST_NAME(nFaceAndMatchWithProfile.getFIRST_NAME());
				nDetectedFaceAndMatchWithProfileItem.setMIDDLE_NAME(nFaceAndMatchWithProfile.getMIDDLE_NAME());
				nDetectedFaceAndMatchWithProfileItem.setLAST_NAME(nFaceAndMatchWithProfile.getLAST_NAME());
				nDetectedFaceAndMatchWithProfileItem.setFACE_ID(nFaceAndMatchWithProfile.getFACE_ID());
				nDetectedFaceAndMatchWithProfileItem.setCF_IS_VALID(nFaceAndMatchWithProfile.getCF_IS_VALID());
				// nDetectedFaceAndMatchWithProfileItem.setImg(nFaceAndMatchWithProfile.getImg());
				nDetectedFaceAndMatchWithProfileItem.setIMG_FORMAT(nFaceAndMatchWithProfile.getIMG_FORMAT());
				nDetectedFaceAndMatchWithProfileItem.setCF_IMG_H(nFaceAndMatchWithProfile.getCF_IMG_H());
				nDetectedFaceAndMatchWithProfileItem.setCF_IMG_W(nFaceAndMatchWithProfile.getCF_IMG_W());
				// nDetectedFaceAndMatchWithProfileItem.setCfFeature(nFaceAndMatchWithProfile.getFeature());
				nDetectedFaceAndMatchWithProfileItem.setCF_LANDMARKS(nFaceAndMatchWithProfile.getCF_LANDMARKS());
				nDetectedFaceAndMatchWithProfileItem.setREMARKS(nFaceAndMatchWithProfile.getREMARKS());
				nDetectedFaceAndMatchWithProfileItem.setIMG_PATH(nFaceAndMatchWithProfile.getIMG_PATH());
			}
		}

		//detectedFaceAndMatchWithProfileDao.insert(nDetectedFaceAndMatchWithProfileItem);
		
		mongoTemplateManager.sendMongoDBJob(nDetectedFaceAndMatchWithProfileItem, "VAS_DETECTED_FACE_N_MATCH_WITH_PROFILE_NOSQL");
		
		return nDetectedFaceAndMatchWithProfileItem;
	}
}
