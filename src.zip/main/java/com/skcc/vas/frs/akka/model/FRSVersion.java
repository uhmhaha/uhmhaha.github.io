package com.skcc.vas.frs.akka.model;

public enum FRSVersion {
	FRS10(1), FRS20(2), FRS30(3);

	private int version;
	private FRSVersion(int version) {
		this.version = version;
	}

	public int getFRSVersion() {
		return this.version;
	}

}
