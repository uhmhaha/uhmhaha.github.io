package com.skcc.vas.frs.akka.routing;

import javax.annotation.concurrent.Immutable;
import org.apache.commons.lang3.StringUtils;

/**
 * The unique identifier for the CCTV in VAS.
 * <p>
 * VAS can integrated with multiple VMSs in a single deployment. In this case,
 * the CCTV ID provided by the its own VMS cann't be identifier in VAS.
 *
 * @author
 * @since 2016. 6. 17.
 *
 */
@Immutable
public class CctvKey implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public final static int CODE_DEFAULT_START_OR_STOP = 0;
	public final static int CODE_CNCRN_FACE_DB_UPDATED = 3;

	/**
    *
    */
	private final String systemId;

	/**
	 * @return the ID for the system (such as VMS) to which this CCTV belongs
	 */
	public String getSystemId() {
		return this.systemId;
	}

	private final String id;

	/**
	 * @return the ID of this CCTV in its own system
	 */
	public String getId() {
		return this.id;
	}

	private int code;

	public int getCode() {
		return code;
	}

	/**
	 * @param systemId
	 *            the ID for the system (such as VMS) to which this CCTV belongs
	 * @param id
	 *            the ID of this CCTV in its own system
	 */
	public CctvKey(String systemId, String id) {
		this.systemId = systemId;
		this.id = id;
		this.code = CODE_DEFAULT_START_OR_STOP;
	}

	public CctvKey(int code) {
		this.systemId = null;
		this.id = null;
		this.code = code;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;

		CctvKey that = (CctvKey) obj;
		if (StringUtils.equals(this.systemId, that.getSystemId()) && StringUtils.equals(this.id, that.getId())) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("CctvKey class = ");
		if (systemId != null) {
			sb.append(" VMS ID [" + systemId + "]");
		}
		if (id != null) {
			sb.append(" CCTV ID [" + id + "]");
		}
		sb.append(" code [" + codeToString(code) + "]");

		return sb.toString();

	}

	private String codeToString(int code) {
		String codeString = "code_not_defined";
		switch (code) {
			case CODE_DEFAULT_START_OR_STOP :
				codeString = "code_default_start_or_stop";
				break;
			case CODE_CNCRN_FACE_DB_UPDATED :
				codeString = "code_cncrn_face_db_updated";
				break;
		}
		return codeString;
	}

}
