package com.skcc.vas.frs.akka.cluster;

import java.util.concurrent.*;
import javax.annotation.*;
import javax.validation.constraints.*;
import org.apache.camel.*;
import org.apache.commons.lang3.*;
import org.hibernate.validator.constraints.*;
import scala.concurrent.duration.*;
import akka.camel.javaapi.*;
import akka.event.*;
import com.fasterxml.jackson.databind.*;

/**
 * @author
 * @since 2016-06-16
 *
 */
public abstract class WebServiceBase extends UntypedConsumerActor {

	/**
	 * default time-out in milli-second for the web services by this class
	 */
	public static final int TIMEOUT_DEFAULT = 60000; // msec

	public static final int TIMEOUT_MIN = 500;

	protected final LoggingAdapter logger = Logging.getLogger(this);

	/**
	 * Camel's end point URI for this web service
	 */
	private final String uri;

	/**
	 * Jackson object mapper to parse or build the JSON string in the request or
	 * response
	 */
	private final ObjectMapper jacksonMapper;

	@Nonnull
	public ObjectMapper getJacksonMapper() {
		return this.jacksonMapper;
	}

	private final FiniteDuration timeout;

	public WebServiceBase(@NotBlank String uri, @Nonnull ObjectMapper jacksonMapper, @Min(TIMEOUT_MIN) int timeout) {
		Validate.isTrue(StringUtils.isNotBlank(uri), "The endpoint for this web service should be specified.");
		Validate.isTrue(jacksonMapper != null,
				"The Jackson mapper to deserialize the JSON string in the request should be provided.");
		Validate.isTrue(timeout >= TIMEOUT_MIN, "Timeout is too small. It should be equal or more than " + TIMEOUT_MIN
				+ " milli-seconds.");

		this.uri = "jetty:" + uri;
		this.jacksonMapper = jacksonMapper;
		this.timeout = Duration.create(timeout, TimeUnit.MILLISECONDS);
	}

	@Override
	@Consume
	public final String getEndpointUri() {
		return this.uri;
	}

	@Override
	public final FiniteDuration replyTimeout() {
		return this.timeout;
	}

}
