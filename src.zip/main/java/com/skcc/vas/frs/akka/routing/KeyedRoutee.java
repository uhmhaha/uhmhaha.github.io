package com.skcc.vas.frs.akka.routing;

import akka.routing.Routee;

/**
 * @author
 * @since 2016-06-07
 *
 * @param <T>
 */
public interface KeyedRoutee<T extends java.io.Serializable> extends Keyed<T>, Routee {

}
