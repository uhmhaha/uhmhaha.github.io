package com.skcc.vas.frs.akka.util;

import java.io.*;
import java.lang.management.*;
import java.lang.reflect.*;
import java.util.*;
import org.slf4j.*;

public class PIDUtil {

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(PIDUtil.class);
	private static final String JVM_PID_FILE_PREFIX = "jvmpid_";

	public static void createJVMPidFile(String currDirectory) {

		// String currDir = System.getProperty("user.dir");

		/*
		 * 현재 존재하는 Java VM pid 파일을 삭제한다
		 */
		removeJavaVMPidFile(currDirectory);

		/*
		 * 현재 jvm의 pid 값을 구한다
		 */
		String jvmPid = getJavaVMPid();
		if (jvmPid == null) {
			logger.error("++Can't make [{}} file because pid is null", JVM_PID_FILE_PREFIX);
			return;
		}

		String jvmPidFilename = JVM_PID_FILE_PREFIX + jvmPid;
		String jvmPidFileFullpath = currDirectory + "/" + jvmPidFilename;

		File pidFile = new File(jvmPidFileFullpath);
		try {
			pidFile.createNewFile();
		} catch (IOException ex) {
			logger.error("++ [{}] file creation error :[{}}", jvmPidFileFullpath);
			return;
		}

		logger.info("++ Java VM PID file has been created: [{}]", jvmPidFileFullpath);

	}

	private static String getJavaVMPid() {

		try {
			RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
			Field jvmField = runtimeMXBean.getClass().getDeclaredField("jvm");
			jvmField.setAccessible(true);

			Object vmManagement = jvmField.get(runtimeMXBean);
			Method getProcessIdMethod = vmManagement.getClass().getDeclaredMethod("getProcessId");

			getProcessIdMethod.setAccessible(true);
			int jvmpid = (Integer) getProcessIdMethod.invoke(vmManagement);

			return Integer.toString(jvmpid);

		} catch (Exception ex) {
			logger.error("++ Getting JAVA VM PID meets an error  [{}]", ex.toString());
			return null;
		}

	}

	public static List<String> getJavaVMPidFromPidFile(String currDirectory) {

		File dir = new File(currDirectory);

		List<String> pidList = new ArrayList<String>();

		/*
		 * jvmpid_xxx file이 이미 존재하는지 확인한다
		 */
		File[] jvmpidFileList = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {

				return name.startsWith(JVM_PID_FILE_PREFIX);
			}
		});

		String pidFile = null;
		if (jvmpidFileList != null) {
			for (int i = 0; i < jvmpidFileList.length; i++) {
				pidFile = jvmpidFileList[i].getName();
				int idx = pidFile.indexOf(JVM_PID_FILE_PREFIX);
				String pid = pidFile.substring(idx + JVM_PID_FILE_PREFIX.length());
				pidList.add(pid);

			}
		}

		return pidList;
	}

	public static void removeJavaVMPidFile(String currDirectory) {

		File dir = new File(currDirectory);

		/*
		 * jvmpid_xxx file이 이미 존재하는지 확인하고 존재하면 삭제한다
		 */
		File[] jvmpidFileList = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {

				return name.startsWith(JVM_PID_FILE_PREFIX);
			}
		});

		if (jvmpidFileList != null) {
			for (int i = 0; i < jvmpidFileList.length; i++) {
				logger.info("++ Java VM PID file [{}] was deleted", jvmpidFileList[i].getAbsoluteFile());
				jvmpidFileList[i].delete();

			}
		}

	}

}
