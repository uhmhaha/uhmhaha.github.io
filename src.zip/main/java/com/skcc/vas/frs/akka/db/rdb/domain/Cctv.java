package com.skcc.vas.frs.akka.db.rdb.domain;

import org.apache.commons.lang3.StringUtils;

/**
 * The Value Object of VAS_FR_CCTV This is used for dynamic node control and
 * routing
 * 
 * @author Na Hoon
 * @since 2016. 9. 8.
 *
 */
public class Cctv implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	final static public String CCTV_STATUS_STARTED = "started";
	final static public String CCTV_STATUS_STOPPED = "stopped";
	final static public String CCTV_STATUS_INITIAL = "initial";
	final static public String CCTV_STATUS_START_FAILED = "start_failed";
	final static public String CCTV_STATUS_STOP_FAILED = "stop_failed";
	final static public String CCTV_STATUS_START_FAILED_WHEN_UPDATE_FEATURE = "start_failed_when_update_feature";
	final static public String CCTV_STATUS_STOP_FAILED_WHEN_UPDATE_FEATURE = "stop_failed_when_update_feature";

	// CCTV Id
	private String cctvId;

	// worker node Id
	private int nodeId;

	// VMS Id
	private String systemId;

	// device sequence number - only used in FRS UI not FRS server
	private int devSeqNum;

	// status
	private String status;

	public int getDevSeqNum() {
		return devSeqNum;
	}

	public void setDevSeqNum(int devSeqNum) {
		this.devSeqNum = devSeqNum;
	}

	public void setDefault(int nodeId, String systemId, String cctvId, int devSeqNum) {
		this.nodeId = nodeId;
		this.systemId = systemId;
		this.cctvId = cctvId;
		this.devSeqNum = devSeqNum;
		this.status = CCTV_STATUS_INITIAL;
	}

	public void setDefault(int nodeId, String systemId, String cctvId, int devSeqNum, String status) {
		this.nodeId = nodeId;
		this.systemId = systemId;
		this.cctvId = cctvId;
		this.devSeqNum = devSeqNum;
		this.status = status;
	}

	// public void setDefault(int nodeId, String systemId, String cctvId, int
	// code) {
	// this.nodeId = nodeId;
	// this.systemId = systemId;
	// this.cctvId = cctvId;
	// }

	public String getCctvId() {
		return cctvId;
	}

	public void setCctvId(String cctvId) {
		this.cctvId = cctvId;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;

		Cctv other = (Cctv) obj;
		if (StringUtils.equals(this.systemId, other.getSystemId())
				&& StringUtils.equals(this.cctvId, other.getCctvId()) && (this.nodeId == other.getNodeId())) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Cctv class = ");
		if (systemId != null) {
			sb.append(" VMS ID [" + systemId + "]");
		}
		if (cctvId != null) {
			sb.append(" CCTV ID [" + cctvId + "]");
		}
		sb.append(" Node ID [" + nodeId + "]");

		sb.append(" DEV SEQ Num [" + devSeqNum + "]");

		if (status == null) {
			sb.append(" status is [null]");
		} else {
			sb.append(" status [" + status + "]");
		}

		return sb.toString();

	}

}
