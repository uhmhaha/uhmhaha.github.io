package com.skcc.vas.frs.akka.routing;

import javax.annotation.Nonnull;
import org.slf4j.LoggerFactory;
import scala.collection.immutable.IndexedSeq;
import akka.routing.Routee;
import akka.routing.RoutingLogic;

/**
 * @author
 * @since 2016-06-08
 *
 * @param <T>
 *            the type of key
 */
public class MappedRoutingLogic<T extends java.io.Serializable> implements RoutingLogic {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public Routee select(@Nonnull Object msg, @Nonnull IndexedSeq<Routee> routees) {
		if (!(msg instanceof Keyed<?>) && msg != null) {
			this.logger.error("++ Keyed type message should be provided. But {} type message is provided.", msg
					.getClass().getSimpleName());

			return akka.routing.NoRoutee$.MODULE$;
		}

		Key<T> key = ((Keyed<T>) msg).getKey();
		if (key == null) {
			this.logger.error("++ The provided key is null.");
			return akka.routing.NoRoutee$.MODULE$;
		}

		int size = ((scala.collection.SeqLike) routees).size();
		Routee routee = null;
		KeyedRoutee<T> keyedRoutee = null;
		for (int i = 0; i < size; i++) {
			if (!((scala.collection.GenSeqLike) routees).isDefinedAt(i)) {
				break;
			}
			routee = (Routee) ((scala.collection.SeqLike) routees).apply(i);
			if (!(routee instanceof KeyedRoutee<?>)) {
				this.logger.warn("++ KeyedRoutee type routee should be provided. But {} type is provided.", routee
						.getClass().getSimpleName());
				continue;
			}

			if (key.equals(((KeyedRoutee<T>) routee).getKey())) {
				this.logger.debug("++ Found routee mapped to the key of {}.", key);
				keyedRoutee = (KeyedRoutee<T>) routee;
				break;
			}
		}

		if (keyedRoutee != null) {
			return keyedRoutee;
		} else {
			this.logger.warn("++ Can't find routee mapped to the key: {}.", key);
			return akka.routing.NoRoutee$.MODULE$;
		}
	}

}
