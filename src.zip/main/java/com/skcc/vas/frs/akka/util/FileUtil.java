package com.skcc.vas.frs.akka.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtil {

	private static String LOGBACK_FLAG_FILE_NAME = "logback_setup_flag";

	public static void replaceText(String filePath, String filename, String orgText, String replaceText) {

		// if(existLogbackFlagFile(filePath)) {
		// // nothing to do
		// return;
		// }

		String sourceFileFullPath = filePath + "/" + filename;
		String tempFileFullPath = filePath + "/" + filename + ".temp";

		String replaceTextNorm = replaceText.replaceAll("\\\\", "/");

		File inputFile = new File(sourceFileFullPath);
		File outputFile = new File(tempFileFullPath);
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {

			FileReader fr = new FileReader(inputFile);
			FileWriter fw = new FileWriter(outputFile);
			br = new BufferedReader(fr);
			bw = new BufferedWriter(fw);

			String line = null;
			while ((line = br.readLine()) != null) {
				boolean isExist = line.contains(orgText);
				if (isExist) {
					// System.out.println(" org text founded " + orgText + "  "
					// + replaceText);
					String modLine = line.replace(orgText, replaceTextNorm);
					bw.write(modLine);
					bw.newLine();
				} else {
					bw.write(line);
					bw.newLine();
				}
			}

			br.close();
			bw.close();

		} catch (IOException ex) {
			throw new RuntimeException("FileUtil  error :" + getPrintStacTraceString(ex));
		}

		// delete original file
		inputFile.delete();

		// rename tempfile into original file
		outputFile.renameTo(new File(sourceFileFullPath));

		// make flag file
		// makeLogbackFlagFile(filePath);

	}

	private static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}

	public static boolean existLogbackFlagFile(String dir) {

		String flagFileFullPath = dir + "/" + LOGBACK_FLAG_FILE_NAME;
		File flagFile = new File(flagFileFullPath);

		if (flagFile.exists())
			return true;
		else
			return false;
	}

	private static boolean makeLogbackFlagFile(String dir) {

		String flagFileFullPath = dir + "/" + LOGBACK_FLAG_FILE_NAME;
		File flagFile = new File(flagFileFullPath);

		if (flagFile.exists())
			return true;

		try {
			flagFile.createNewFile();
		} catch (IOException ex) {
			return false;
		}

		return true;

	}

	public static boolean runOnEclipse(String separator) {
		// get current path
		Path currentPath = Paths.get(System.getProperty("user.dir"));

		// find separator directory (for example, bin )
		boolean isDir = false;
		for (Path pathElement : currentPath) {
			if (pathElement.toString().equalsIgnoreCase(separator)) {
				isDir = true;
				break;
			}
		}

		// if bin dir is founded, this is running on CMD
		if (isDir)
			return false;
		else
			return true;
	}

}
