package com.skcc.vas.frs.akka.db.rdb.domain;

public class VasNode {
	int nodeId;
	String sysId;
	String nodeType;
	String nodeName;
	String ipAddress;
	String port;
	String macAddress;
	String userId;
	String pwd;
	String useYN;
	String editor;
	String updateAt;
	String remark;

	public int getNodeId() {
		return nodeId;
	}
	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}
	public String getSysId() {
		return sysId;
	}
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getUseYN() {
		return useYN;
	}
	public void setUseYN(String useYN) {
		this.useYN = useYN;
	}
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	public String getUpdateAt() {
		return updateAt;
	}
	public void setUpdateAt(String updateAt) {
		this.updateAt = updateAt;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {

		StringBuffer sb = new StringBuffer();

		sb.append("VasNode class = ");
		sb.append(" node id = [" + nodeId + "]");
		if (sysId != null)
			sb.append(" sys id = [" + sysId + "]");
		else
			sb.append(" sys id = [null]");
		if (nodeType != null)
			sb.append(" node type = [" + nodeType + "]");
		else
			sb.append(" node type =[null]");
		if (nodeName != null)
			sb.append(" node name = [" + nodeName + "]");
		else
			sb.append(" node name = [null]");
		if (ipAddress != null)
			sb.append(" ip address = [" + ipAddress + "]");
		else
			sb.append(" ip address = [null]");
		if (port != null)
			sb.append(" port = [" + port + "]");
		else
			sb.append(" port = [null]");
		if (useYN != null)
			sb.append(" useYN = [" + useYN + "]");
		else
			sb.append(" useYN = [null]");

		return sb.toString();
	}

}
