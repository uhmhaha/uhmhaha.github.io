package com.skcc.vas.frs.akka.model;

import com.skcc.vas.frs.akka.model.OndemandDBSubJob;
import com.skcc.vas.frs.akka.model.OndemandJobConstant;
import com.skcc.vas.frs.akka.model.OndemandVMSSubJob;
import com.skcc.vas.frs.akka.model.OndemandVideoSubJob;

public class MasterToMatchingWorkerMessage implements java.io.Serializable {

	private static final long serialVersionUID = 2L;

	public final static int CODE_UPLOAD_CNCRN_DATA_FROM_DB = 100;

	private int messageCode;

	private int nodeId;

	private String masterURL;

	public MasterToMatchingWorkerMessage(int messageCode, int nodeId) {
		this.messageCode = messageCode;
		this.nodeId = nodeId;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getMasterURL() {
		return masterURL;
	}

	public void setMasterURL(String masterURL) {
		this.masterURL = masterURL;
	}


	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("MasterToMatchingWorkerMessage class =");

		sb.append(" messageCode [" + messageCodeToString(messageCode) + "]");
		sb.append(" node Id [" + nodeId + "]");	
		if(masterURL != null) {
			sb.append(" master URL [" + masterURL + "]");
		}

		return sb.toString();

	}

	private String messageCodeToString(int messageCode) {

		String messageCodeString = "not defined";

		switch (messageCode) {
			case CODE_UPLOAD_CNCRN_DATA_FROM_DB :
				messageCodeString = "upload concerned face data again from DB";
				break;
		}

		return messageCodeString;

	}

}
