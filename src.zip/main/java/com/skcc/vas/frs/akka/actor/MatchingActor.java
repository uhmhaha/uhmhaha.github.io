package com.skcc.vas.frs.akka.actor;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import com.skcc.vas.frs.akka.model.MasterToMatchingWorkerMessage;
import com.skcc.vas.frs.akka.model.MasterToWorkerMessage;
import com.skcc.vas.frs.matching.biz.CncrnFaceManager;

import akka.actor.*;
import akka.cluster.Cluster;
import akka.event.*;

public class MatchingActor extends UntypedActor {
	private final LoggingAdapter logger = Logging.getLogger(getContext().system(), this);
	
	CncrnFaceManager cncrnFaceManager;

	@Override
	public void preStart() {
		Cluster cluster = Cluster.get(getContext().system());
		Address myAddress = cluster.selfAddress();
		logger.info("++ I am matching worker actor --> [{}]. ", myAddress.toString());
	}

	public MatchingActor(CncrnFaceManager cncrnFaceManager) {
		this.cncrnFaceManager = cncrnFaceManager;
	}

	@Override
	public void onReceive(Object msg) throws Exception {
		
		if (msg instanceof MasterToMatchingWorkerMessage) {
			
			try {
				
				MasterToMatchingWorkerMessage masterMessage = (MasterToMatchingWorkerMessage) msg;
				
				logger.info("++ MasterToMatcingWorkerMessage arrived. message = {}", masterMessage);
				logger.info("++ Call updateCncrnFace() of CncrnFaceManger");
			
		
				this.cncrnFaceManager.updateCncrnFace(null, masterMessage.getNodeId());
				
			} catch (Exception ex) {
				logger.error("++ [Exception] Fail to handle [MasterToMatchingWorkerMessage]. Exception : [{}]",
					getPrintStacTraceString(ex));
			}
		}		

	}
	
	
	public static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}

}
