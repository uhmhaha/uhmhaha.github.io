package com.skcc.vas.frs.akka.model;

public class OndemandJobConstant {

	public static class JobType {

		public final static int NOT_DEFINED = 0;
		public final static int DBJOB = 2;
		public final static int VMSJOB = 4;
		public final static int VIDEOJOB = 8;

		public static String getJobName(int jobType) {

			int dbJobType = (jobType & DBJOB);
			int vmsJobType = (jobType & VMSJOB);
			int videoJobType = (jobType & VIDEOJOB);

			String jobTypeName = "Ondemand ";
			if (dbJobType != 0)
				jobTypeName += "[DB] Job ";
			if (vmsJobType != 0)
				jobTypeName += "[VMS] Job ";
			if (videoJobType != 0)
				jobTypeName += "[Video] Job ";
			if (jobType == NOT_DEFINED)
				jobTypeName += "no defined job";

			return jobTypeName;

		}

		public static boolean isDBJob(int jobType) {
			int dbJobType = (jobType & DBJOB);
			if (dbJobType != 0)
				return true;
			else
				return false;
		}

		public static boolean isVMSJob(int jobType) {
			int vmsJobType = (jobType & VMSJOB);
			if (vmsJobType != 0)
				return true;
			else
				return false;
		}

		public static boolean isVideoJob(int jobType) {
			int videoJobType = (jobType & VIDEOJOB);
			if (videoJobType != 0)
				return true;
			else
				return false;
		}

	}

	public static class JobStatus {
		public final static String INITIAL = "initial";
		public final static String ALLOCATED = "allocated";
		public final static String STARTED = "started";
		public final static String START_FAILED = "start_failed";
		public final static String ABROTED = "aborted";
		public final static String ABROT_FAILED = "abort_failed";
		public final static String COMPLETED = "completed";
		public final static String COMPLETED_WITH_ERROR = "completed_with_error";
		public final static String ABORT_COMPLETED = "abort_completed";
		public final static String ABORT_COMPLETED_WITH_ERROR = "abort_completed_with_error";
	}

	public static class JobMasterStatus {
		public final static String COMPLETED = "COMPLETED";
		public final static String ABORT_COMPLETED = "ABORTED";
		public final static String COMPLETED_WITH_ERROR = "FAIL";
		public final static String ABORT_COMPLETED_WITH_ERROR = "FAIL";
	}

	public static class JobCode {
		public final static int ONDEMNAD_JOB_START = 1;
		public final static int ONDEMAND_JOB_ABORT = 2;

		public static String getJobCodeName(int jobCode) {
			if (jobCode == ONDEMNAD_JOB_START)
				return "Job_start";
			else if (jobCode == ONDEMAND_JOB_ABORT)
				return "Job_abort";
			else
				return "unknown job code";
		}
	}
}
