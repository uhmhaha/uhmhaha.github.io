package com.skcc.vas.frs.akka.db.rdb.domain;

public class OndemandVMSSubJobVO {

	private int nodeId;

	private String jobId;

	private String jobStatus;

	private String startTime;

	private String endTime;

	private float portionOfProgress;

	private String baseDir;

	private String cctvIds;

	private String vmsIds;

	private int matchingThreshold;

	private String analysisTimeFrom;

	private String analysisTimeTo;

	private String timeType;

	private int totalStartThread;

	private int totalCompletedThread;

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}

	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}

	public String getBaseDir() {
		return baseDir;
	}

	public void setBaseDir(String baseDir) {
		this.baseDir = baseDir;
	}

	public String getCctvIds() {
		return cctvIds;
	}

	public void setCctvIds(String cctvIds) {
		this.cctvIds = cctvIds;
	}

	public String getVmsIds() {
		return vmsIds;
	}

	public void setVmsIds(String vmsIds) {
		this.vmsIds = vmsIds;
	}

	public int getMatchingThreshold() {
		return matchingThreshold;
	}

	public void setMatchingThreshold(int matchingThreshold) {
		this.matchingThreshold = matchingThreshold;
	}

	public String getAnalysisTimeFrom() {
		return analysisTimeFrom;
	}

	public void setAnalysisTimeFrom(String analysisTimeFrom) {
		this.analysisTimeFrom = analysisTimeFrom;
	}

	public String getAnalysisTimeTo() {
		return analysisTimeTo;
	}

	public void setAnalysisTimeTo(String analysisTimeTo) {
		this.analysisTimeTo = analysisTimeTo;
	}

	public String getTimeType() {
		return timeType;
	}

	public void setTimeType(String timeType) {
		this.timeType = timeType;
	}

	public int getTotalStartThread() {
		return totalStartThread;
	}
	public void setTotalStartThread(int totalStartThread) {
		this.totalStartThread = totalStartThread;
	}
	public int getTotalCompletedThread() {
		return totalCompletedThread;
	}
	public void setTotalCompletedThread(int totalCompletedThread) {
		this.totalCompletedThread = totalCompletedThread;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Node Id = [" + nodeId + "]");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" start time = [" + startTime + "]");
		sb.append(" end time = [" + endTime + "]");
		sb.append(" job status = [" + jobStatus + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" base dir = [" + baseDir + "]");
		sb.append(" cctv Ids = [" + cctvIds + "]");
		sb.append(" vms Ids = [" + vmsIds + "]");
		sb.append(" matching threshold = [" + matchingThreshold + "]");
		sb.append(" analysisTimeFrom = [" + analysisTimeFrom + "]");
		sb.append(" analysisTimeTo = [" + analysisTimeTo + "]");
		sb.append(" timeType = [" + timeType + "]");
		sb.append(" total start thread = [" + totalStartThread + "]");
		sb.append(" total completed thread = [" + totalCompletedThread + "]");

		return sb.toString();
	}

}
