package com.skcc.vas.frs.akka.launcher;

import java.io.*;

import org.apache.commons.lang3.*;
import org.slf4j.*;

import com.skcc.vas.frs.akka.cluster.Server;
import com.skcc.vas.frs.akka.cluster.StandaloneServerDynamicRouting;

/**
 * @author
 * @since 2016-06-21
 *
 */
public class StandaloneServerLauncher {

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(StandaloneServerLauncher.class);

	public static void main(String[] args) {

		final int httpPort;

		switch (args.length) {
			case 0 :
				httpPort = Server.HTTP_PORT_DEFAULT;
				break;
			case 1 :
				httpPort = Integer.valueOf(args[0]);
				break;
			default :
				printUsage("Wrong number of arguments are specifed.");
				return;
		}

		final String systemName = "WatzEyeVAS";
		final String applName = "vas";

		Server server = null;
		try {
			// server = new StandaloneServer(systemName, applName, httpPort,
			// null);
			server = new StandaloneServerDynamicRouting(systemName, applName, httpPort, null);
			server.start();

			StandaloneServerDynamicRouting ss = (StandaloneServerDynamicRouting) server;
			logger.info("The standalone server has started with [HTTP URL: {}.", ss.getBaseUrl() + "/face");
		} catch (Exception ex) {
			logger.error("Fail to start standalone server with HTTP port at {},{}", httpPort, ex);

			if (server != null) {
				try {
					server.stop();
				} catch (Throwable ex2) {
					logger.error("Fail to stop cluster main server after startup failure.", ex2);
				}
			}
			System.exit(-1);

		} finally {

		}

	}

	private static void printUsage(String headline) {

		Console con = System.console();

		if (StringUtils.isNotBlank(headline)) {
			con.printf("\n");
			con.printf(headline);
			con.printf("\n");
		}

		con.printf("\n");
		con.printf("Syntax : > java watzeye.vas.akka.StandaloneServerLauncher [http-port]\n");
		con.printf("\n");

		String str = "  http-port : HTTP port for the server to communicate with client, optional and default is ["
				+ Server.HTTP_PORT_DEFAULT + "]";
		con.printf(str);
	}

}
