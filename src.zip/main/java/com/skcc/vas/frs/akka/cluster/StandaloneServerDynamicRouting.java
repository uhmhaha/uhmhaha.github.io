package com.skcc.vas.frs.akka.cluster;

import static com.skcc.vas.frs.akka.model.ActorProfile.*;

import java.net.*;
import java.util.concurrent.*;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;

import scala.concurrent.Future;
import scala.concurrent.duration.*;
import akka.actor.*;
import akka.camel.*;
import akka.util.*;

import com.fasterxml.jackson.databind.*;
import com.typesafe.config.*;
import com.skcc.vas.frs.akka.actor.DetectionActorDynamicRouting;
import com.skcc.vas.frs.akka.actor.FaceWebServiceCluster;
import com.skcc.vas.frs.akka.cluster.*;
import com.skcc.vas.frs.akka.db.rdb.domain.*;
import com.skcc.vas.frs.akka.model.*;
import com.skcc.vas.frs.akka.db.repository.*;
import com.skcc.vas.frs.akka.routing.*;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.live.biz.ConcernedPersonProcessor;
import com.skcc.vas.frs.live.biz.DetectionProcessorFactory;
import com.skcc.vas.frs.ondemand.db.biz.DBSearchProcessor;
import com.skcc.vas.frs.ondemand.vms.biz.SearchProcessor;

/**
 * @author
 * @since 2016-06-16
 *
 */
public class StandaloneServerDynamicRouting extends ServerBase {

	private final int httpPort;

	public int getHttpPort() {
		return this.httpPort;
	}

	private final String baseUrl;

	public String getBaseUrl() {
		return this.baseUrl;
	}

	/**
	 * @param systemName
	 * @param applName
	 * @param httpPort
	 * @param configSubtree
	 * @throws Exception
	 */
	public StandaloneServerDynamicRouting(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, int httpPort, @Nullable String configSubtree)
			throws Exception {

		super(systemName, applName, configSubtree);

		// http port를 appliation.conf에서 읽어 온다
		// this.httpPort = this.getConfig().getInt("nodes.master.httpport");
		this.httpPort = httpPort;

		// build base URL
		InetAddress addr = InetAddress.getLocalHost();
		this.baseUrl = new StringBuilder().append("http://").append(addr.getHostAddress()).append(":")
				.append(this.getHttpPort()).append("/").append(applName).toString();
	}

	@Override
	public Config buildConfig(@Nullable String configSubtree) {

		Config config = ConfigFactory.load();

		if (configSubtree != null) {
			config = config.getConfig(this.getConfigSubtree()).withFallback(config);
		}

		config = config.withoutPath("akka.cluster").withoutPath("akka.remote");
		config = ConfigFactory.parseString("akka.actor.provider = \"akka.actor.LocalActorRefProvider\"").withFallback(
				config);

		return config;
	}

	@Override
	public ActorSystem buildActorSystem(@Nonnull Config config) throws Exception {
		Validate.isTrue(config != null, "The configuration for actor system should be provided.");

		ObjectMapper jacksonMapper = this.getSpringContainer().getBean("jacksonObjectMapper", ObjectMapper.class);

		ConcernedPersonProcessor cpProcessor = this.getSpringContainer().getBean("hbInnoConcernedPersonProcessor",
				ConcernedPersonProcessor.class);

		DetectionProcessorFactory fdpFactory = this.getSpringContainer().getBean("detectionProcessorFactory",
				DetectionProcessorFactory.class);

		SearchProcessor fsProcessor = this.getSpringContainer().getBean("triumiHbInnoSearchLocalProcessor",
				SearchProcessor.class);

		DBSearchProcessor dbProcessor = this.getSpringContainer().getBean("triumiHbInnoDBSearchProcessor",
				DBSearchProcessor.class);

		SearchProcessor faProcessor = this.getSpringContainer().getBean("sParserHbInnoSearchVideoProcessor",
				SearchProcessor.class);

		FaceMatchJobService faceMatchJobService = this.getSpringContainer().getBean("faceMatchJobService",
				FaceMatchJobService.class);

		Validate.validState(fdpFactory != null,
				"DetectionProcessorFacotry bean can't be found in the Spring container.");
		Validate.validState(jacksonMapper != null, "Jackson ObjectMapper bean can't be found in the Spring container.");

		// build actor system
		ActorSystem system = ActorSystem.create(this.getSystemName(), config);
		Camel camel = CamelExtension.get(system);

		ActorRef detectionService = system.actorOf(Props.create(DetectionActorDynamicRouting.class, fdpFactory),
				FACE_DETECTION_ACTOR.getActorName());

		ActorRef webService = system.actorOf(Props.create(FaceWebServiceCluster.class, this.baseUrl + "/face",
				jacksonMapper, WebServiceBase.TIMEOUT_DEFAULT, detectionService, cpProcessor, dbProcessor, fsProcessor,
				faProcessor, faceMatchJobService), FACE_WEB_ACTOR.getActorName());

		Future<ActorRef> activationFuture = camel.activationFutureFor(webService,
				new Timeout(Duration.create(10, TimeUnit.SECONDS)), system.dispatcher());

		return system;
	}

	@Override
	protected void beforeStop() {
		// nothing to do
	}

}
