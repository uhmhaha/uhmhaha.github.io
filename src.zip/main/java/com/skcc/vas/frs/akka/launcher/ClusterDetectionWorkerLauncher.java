package com.skcc.vas.frs.akka.launcher;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.*;

import com.skcc.vas.frs.akka.cluster.ClusterDetectionWorker;
import com.skcc.vas.frs.akka.cluster.ClusterMatchingWorker;
import com.skcc.vas.frs.akka.cluster.Server;
import com.skcc.vas.frs.akka.model.ClusterConfig;
import com.skcc.vas.frs.akka.service.VasNodeServiceWithoutSpring;
import com.skcc.vas.frs.akka.util.ConfigUtil;
import com.skcc.vas.frs.akka.util.FileUtil;
import com.skcc.vas.frs.akka.util.PIDUtil;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

/**
 * @author NAHOON
 * @since 2017-08-28
 *
 */
public class ClusterDetectionWorkerLauncher {

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(ClusterDetectionWorkerLauncher.class);

	public static void main(String[] args) {

		final String systemName = "WatzEyeVAS";
		final String applName = "vas";

		boolean useOldAkkaSetup = false;

		Server server = null;
		try {

			/*
			 * 현재 java VM의 PID 값을 가지는 PID 파일을 생성한다
			 */
			PIDUtil.createJVMPidFile(System.getProperty("user.dir"));

			/*
			 * log4cplus의 설정 정보를 변경한다
			 */
			ConfigUtil.modifyLog4cplusConfigFile();

			/*
			 * find out my node id using application.conf and DB
			 */
			ClusterConfig clusterConfig = ConfigUtil.setupAutomaticAkkaConfigurationAndGetSelfNodeId(useOldAkkaSetup,
					ClusterDetectionWorker.ROLE);
			logger.info("[AKKA setup]-----Notice----------------------------------");
			if (useOldAkkaSetup) {
				logger.info("[AKKA setup] AKKA setup will use applcation.conf file only !!! ");
				logger.info("[AKKA setup] My Cluster config = [{}]", clusterConfig);
			} else {
				logger.info("[AKKA setup] AKKA setup will use VAS_NODE DB table. Applcation.conf file will be updated automatically !!! ");
				logger.info("[AKKA setup] My Cluster config = [{}]", clusterConfig);
			}
			logger.info("[AKKA setup]--------------------------------------------");

			/*
			 * replace node id of activemq.xml, spring.xml files into real self
			 * node id
			 */
			ConfigUtil.updateSetupFile("conf", "activemq.xml", clusterConfig.getNodeIdInt());
			ConfigUtil.updateSetupFile("conf", "spring.xml", clusterConfig.getNodeIdInt());

			/*
			 * worker node port를 입력받지않고 application.conf에 설정된 값을 사용하도록 한다
			 */
			server = new ClusterDetectionWorker(systemName, applName, null, useOldAkkaSetup, clusterConfig);
			server.start();

			ClusterDetectionWorker cw = (ClusterDetectionWorker) server;

			logger.info("The cluster detection worker has started at [AKKA Address = {}, AKKA port = {}]",
					cw.getAddress(), cw.getPort());

		} catch (Throwable ex) {
			logger.error("Fail to start cluster matching worker {} ", ex);

			if (server != null) {
				try {
					server.stop();
				} catch (Throwable ex2) {
					logger.error("Fail to stop cluster matching worker after startup failure.", ex2);
				}
			}
			System.exit(-1);
		} finally {

		}

	}

} // end of main
