package com.skcc.vas.frs.akka.util;

import java.io.File;
import java.net.InetAddress;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.akka.cluster.ClusterMasterDynamicRouting;
import com.skcc.vas.frs.akka.cluster.ClusterMatchingMaster;
import com.skcc.vas.frs.akka.db.rdb.domain.VasNode;
import com.skcc.vas.frs.akka.model.ClusterConfig;
import com.skcc.vas.frs.akka.service.VasNodeService;
import com.skcc.vas.frs.akka.service.VasNodeServiceWithoutSpring;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.typesafe.config.ConfigRenderOptions;
import com.typesafe.config.ConfigValueFactory;

public class ConfigUtil {

	private static final Logger logger = LoggerFactory.getLogger(ConfigUtil.class);

	final static String LOG4CPLUS_CONFIGFILE = "/conf/log4cplus.properties";
	final static String LOG4CPLUS_LOGFILE = "/log/log4cplus.log";
	final static String LOG4CPLUS_LOG_FILE_LOCATION_KEY = "log4cplus.appender.R.File";
	final static String AKKA_CONF_FILENAME = "application.conf";

	static public void modifyLog4cplusConfigFile() {

		// get current bin directory
		File binDirFile = new File(System.getProperty("user.dir"));
		String binDir = binDirFile.getAbsolutePath().replaceAll("\\\\", "/");
		String parentDir = binDirFile.getParent().replaceAll("\\\\", "/");

		String log4cplusConfigFileFullPath;
		String log4cplusLogFileFullPath;

		String confDir = binDir + "/conf";
		File confDirFile = new File(confDir);
		if (confDirFile.exists()) {
			// eclipse mode
			log4cplusConfigFileFullPath = binDir + LOG4CPLUS_CONFIGFILE;
			log4cplusLogFileFullPath = binDir + LOG4CPLUS_LOGFILE;
		} else {
			log4cplusConfigFileFullPath = parentDir + LOG4CPLUS_CONFIGFILE;
			log4cplusLogFileFullPath = parentDir + LOG4CPLUS_LOGFILE;
		}

		try {

			Parameters params = new Parameters();
			FileBasedConfigurationBuilder<FileBasedConfiguration> builder = new FileBasedConfigurationBuilder<FileBasedConfiguration>(
					PropertiesConfiguration.class).configure(params.properties().setFileName(
					log4cplusConfigFileFullPath));

			Configuration config = builder.getConfiguration();
			config.setProperty(LOG4CPLUS_LOG_FILE_LOCATION_KEY, (Object) log4cplusLogFileFullPath);
			builder.save();

		} catch (ConfigurationException cex) {
			logger.error("log4cplus configuration Exception = {}", cex.toString());
			throw new IllegalStateException("log4cplus configuration Exception = " + cex.toString());

		} catch (Exception ex) {
			logger.error("log4cplus configuration Exception =  [{}]", ex.toString());
			throw new IllegalStateException("log4cplus configuration Exception = " + ex.toString());
		}

	}

	public static Config checkIPaddressInConfig(VasNodeService vasNodeService, Config config, String role) {

		// get my AKKA IP address and AKKA port in application.conf
		String ipAddress = config.getString("akka.remote.netty.tcp.hostname");
		int port = config.getInt("akka.remote.netty.tcp.port");

		String localIPAddress = null;

		// compare AKKA IP address and Port with network information
		try {
			InetAddress addr = InetAddress.getLocalHost();
			localIPAddress = addr.getHostAddress();
		} catch (Exception ex) {
			logger.error("++ failed to get local IP address. [{}]", ex.toString());
			throw new RuntimeException("++ failed to get local IP Address. " + ex.toString());
		}

		if (!StringUtils.equals(ipAddress, localIPAddress)) {
			logger.error(
					"++ AKKA IP address [{}] in application.conf and current IP address [{}] doesn't match each other ",
					ipAddress, localIPAddress);
			throw new RuntimeException("AKKA IP address [" + ipAddress + "] in application.conf "
					+ "and current IP address [" + localIPAddress + " doesn't match each other ");
		}

		// check whether ip and port exists in VAS_NODE table
		if (!vasNodeService.existAddressnPort(ipAddress, Integer.toString(port), role)) {
			String nodeType = null;
			if (role.equalsIgnoreCase(ClusterMasterDynamicRouting.ROLE)) {
				nodeType = VasNodeService.NODE_TYPE_MASTER;
			} else {
				nodeType = VasNodeService.NODE_TYPE_WORKER;
			}
			logger.error(
					"++ IP address = [{}], Port = [{}] Node Type = [{}] in application.conf is not in VAS_NODE table"
							+ " Please insert this node info in VAS_NODE table", ipAddress, port, nodeType);
			throw new IllegalStateException("++ IP address = [" + ipAddress + "] Port = [" + port + " ] Node Type = ["
					+ nodeType
					+ "] in application.conf is not in VAS_NODE table. Please insert this node info in VAS_NODE table");

		}

		return config;

	}

	public static Config setIPaddressInConfig(VasNodeService vasNodeService, Config config, String role) {

		String localIPAddress = null;
		String nodeType = null;
		if (role.equalsIgnoreCase(ClusterMasterDynamicRouting.ROLE)) {
			nodeType = VasNodeService.NODE_TYPE_MASTER;
		} else {
			nodeType = VasNodeService.NODE_TYPE_WORKER;
		}

		// get local IP address
		try {
			InetAddress addr = InetAddress.getLocalHost();
			localIPAddress = addr.getHostAddress();
		} catch (Exception ex) {
			logger.error("++ failed to get local IP address. [{}]. Can't proceed anymore!", ex.toString());
			throw new RuntimeException("++ failed to get local IP Address. Can't proceed anymore!" + ex.toString());
		}

		// get port from application.conf
		String akkaIPAddressInConf = config.getString("akka.remote.netty.tcp.hostname");
		int akkaPortInConf = config.getInt("akka.remote.netty.tcp.port");

		// check local ip and akka ip address in application.conf
		if (StringUtils.equals(akkaIPAddressInConf, localIPAddress)) {

			boolean exist = vasNodeService.existAddressnPort(akkaIPAddressInConf, String.valueOf(akkaPortInConf), role);
			if (exist) {
				vasNodeService.setVasNodePortOccupied(akkaIPAddressInConf, String.valueOf(akkaPortInConf));
				logger.info("++ My IP address [{}] and Port [{}] alreay exist in application.conf and VAS_NODE table",
						akkaIPAddressInConf, akkaPortInConf);
				return config;
			}
		}

		// get available AKKA port from DB
		int akkaPortFromDB = vasNodeService.getAvailablePort(localIPAddress, role);
		if (akkaPortFromDB == VasNodeService.PORT_ERROR) {
			StringBuffer sb = new StringBuffer();
			sb.append("++ Important AKKA application.conf error !!!! ---------\n");
			sb.append("++ Local IP address [" + localIPAddress + "]");
			sb.append(" node type [" + nodeType + "]");
			sb.append(" doesn't exist or no available port in VAS_NODE table. --------\n");
			sb.append("++ Please add this IP address or new port in VAS_NODE table ----------\n\n");
			logger.error(sb.toString());
			throw new RuntimeException(sb.toString());
		}

		// set AKKA remote port and hostname in config
		// Config configTemp = config.withValue("akka.remote.netty.tcp.port",
		// ConfigValueFactory.fromAnyRef(akkaPortFromDB));
		// Config newConfig =
		// configTemp.withValue("akka.remote.netty.tcp.hostname",
		// ConfigValueFactory.fromAnyRef(localIPAddress));

		Config newConfig = ConfigFactory.parseString("akka.remote.netty.tcp.hostname=" + localIPAddress)
				.withFallback(ConfigFactory.parseString("akka.remote.netty.tcp.port=" + akkaPortFromDB))
				.withFallback(config);

		// update application.conf file
		String akkaDir;
		if (FileUtil.runOnEclipse("bin")) {
			Path currentPath = Paths.get(System.getProperty("user.dir"));

			akkaDir = currentPath.toAbsolutePath().normalize().toString() + "/conf";
		} else {

			Path currentPath = Paths.get(System.getProperty("user.dir"));
			String parentDir = currentPath.getParent().toAbsolutePath().normalize().toString();

			akkaDir = parentDir + "/conf";
		}
		String akkaFile = AKKA_CONF_FILENAME;

		String originalText = akkaIPAddressInConf;
		String replaceText = localIPAddress;

		// write ip address on application.conf
		FileUtil.replaceText(akkaDir, akkaFile, originalText, replaceText);

		originalText = String.valueOf(akkaPortInConf);
		replaceText = String.valueOf(akkaPortFromDB);

		// write port on application.conf
		FileUtil.replaceText(akkaDir, akkaFile, originalText, replaceText);

		/*
		 * ConfigRenderOptions co =
		 * ConfigRenderOptions.defaults().setOriginComments
		 * (false).setComments(false).setJson(false); String newConfigString =
		 * newConfig.root().render(co); logger.debug(" config = [{}]",
		 * newConfigString);
		 */

		return newConfig;

	}

	public static Config addSeedNodes(VasNodeService vasNodeService, Config config, String role) {

		List<VasNode> vasNodes = vasNodeService.getNodeInfo();
		if (vasNodes.isEmpty()) {
			logger.error("++ Seed Node operation failed. There is no Node in VAS_NODE table !!!");
			throw new RuntimeException("++ Seed Node operation failed. There is no Node in VAS_NODE table");
		}

		// make current seed node info
		List<String> seedNodes = new ArrayList<String>();
		String prefix = "akka.tcp://WatzEyeVAS@";

		List<String> candidateMasterNodes = new ArrayList<String>();
		Map<String, String> candidateSeedWorkerNodes = new HashMap<String, String>();

		for (VasNode vasNode : vasNodes) {
			// master node
			if (vasNode.getNodeType().equalsIgnoreCase(VasNodeService.NODE_TYPE_MASTER)) {
				candidateMasterNodes.add(vasNode.getIpAddress() + ":" + vasNode.getPort());
			}
			// worker node : one seed node each h/w
			else {
				candidateSeedWorkerNodes.put(vasNode.getIpAddress(), vasNode.getIpAddress() + ":" + vasNode.getPort());
			}
		}

		if (candidateMasterNodes.isEmpty()) {
			logger.error("++ Seed Node operation failed. There is no Master Node in VAS_NODE table !!!");
			throw new RuntimeException("++ Seed Node operation failed. There is no Master Node in VAS_NODE table");
		}

		/*
		 * if I am master, re-allocate my address, port into top position in the
		 * candidateMasterNodes list
		 */
		if (StringUtils.equals(role, ClusterMasterDynamicRouting.ROLE)) {
			// get my AKKA IP address and AKKA port in application.conf
			String ipAddress = config.getString("akka.remote.netty.tcp.hostname");
			int port = config.getInt("akka.remote.netty.tcp.port");
			String myIP_Port = ipAddress + ":" + Integer.toString(port);

			// find my index in candidateMasterNodes list
			int myMasterIndex = -1;
			for (int idx = 0; idx < candidateMasterNodes.size(); idx++) {
				String masterIP_Port = candidateMasterNodes.get(idx);
				if (StringUtils.equals(myIP_Port, masterIP_Port)) {
					myMasterIndex = idx;
					break;
				}
			}

			if (myMasterIndex == -1) {
				logger.error("++ I am [master] node IP address =[{}], Port = [{}], Node Type = [MAST-NODE]. "
						+ "but there in no master node in VAS_NODE", ipAddress, port);
				throw new RuntimeException("++ I am [master] node IP address =[" + ipAddress + "], Port = [" + port
						+ "] " + "Node Type = [MAST-NODE]. but there in no master node in VAS_NODE");
			}
			// re-allocate my master ip, port into top in the
			// candidateMasterNodes list
			if (myMasterIndex != 0) {
				Collections.swap(candidateMasterNodes, myMasterIndex, 0);
			}
		}

		/*
		 * make seed nodes
		 */
		// first, add all master nodes
		for (String masterNodeIP_Port : candidateMasterNodes) {
			seedNodes.add(prefix + masterNodeIP_Port);
		}

		// second, add one worker node each h/w
		for (String workerNodeIP : candidateSeedWorkerNodes.keySet()) {
			seedNodes.add(prefix + candidateSeedWorkerNodes.get(workerNodeIP));
		}

		// change seed node in application.conf
		Config newConfig = config.withValue("akka.cluster.seed-nodes", ConfigValueFactory.fromIterable(seedNodes));

		logger.info("== [AKKA seed node list] =============== ");
		logger.info("== total seed nodes = [{}] ==============", seedNodes.size());
		int i = 0;
		for (String seedNode : seedNodes) {
			logger.info("[{}] seed node = [{}]", i++, seedNode);
		}
		logger.info("== [AKKA seed node list] ===================");

		return newConfig;
	}

	public static ClusterConfig checkIPaddressInConfig(VasNodeServiceWithoutSpring vasNodeService, Config config,
			String role) {

		// get my AKKA IP address and AKKA port in application.conf
		String ipAddress = config.getString("akka.remote.netty.tcp.hostname");
		int port = config.getInt("akka.remote.netty.tcp.port");

		String localIPAddress = null;

		// compare AKKA IP address and Port with network information
		try {
			InetAddress addr = InetAddress.getLocalHost();
			localIPAddress = addr.getHostAddress();
		} catch (Exception ex) {
			logger.error("++ failed to get local IP address. [{}]", ex.toString());
			throw new RuntimeException("++ failed to get local IP Address. " + ex.toString());
		}

		if (!StringUtils.equals(ipAddress, localIPAddress)) {
			logger.error(
					"++ AKKA IP address [{}] in application.conf and current IP address [{}] doesn't match each other ",
					ipAddress, localIPAddress);
			throw new RuntimeException("AKKA IP address [" + ipAddress + "] in application.conf "
					+ "and current IP address [" + localIPAddress + " doesn't match each other ");
		}

		// check whether ip and port exists in VAS_NODE table
		String nodeType = null;
		if (!vasNodeService.existAddressnPort(ipAddress, Integer.toString(port), role)) {

			if (role.equalsIgnoreCase(ClusterMatchingMaster.ROLE)) {
				nodeType = VasNodeService.NODE_TYPE_MASTER;
			} else {
				nodeType = VasNodeService.NODE_TYPE_WORKER;
			}
			logger.error(
					"++ IP address = [{}], Port = [{}] Node Type = [{}] in application.conf is not in VAS_NODE table"
							+ " Please insert this node info in VAS_NODE table", ipAddress, port, nodeType);
			throw new IllegalStateException("++ IP address = [" + ipAddress + "] Port = [" + port + " ] Node Type = ["
					+ nodeType + "] in application.conf is not in VAS_NODE table. Please insert this node info"
					+ " in VAS_NODE table");

		}

		// get my node id from VAS_NODE table
		VasNode vasNode = vasNodeService.getNodeId(ipAddress, Integer.toString(port), role);
		if (vasNode == null || vasNode.getNodeId() == VasNodeServiceWithoutSpring.NODEID_ERROR) {
			logger.error("++ Can't find node Id in VAS_NODE table. IP address = [{}], Port = [{}], Node type = [{}]",
					ipAddress, port, role);
			throw new IllegalStateException("++ Can't find node Id in VAS_NODE table. IP address = [" + ipAddress
					+ "] Port = [" + port + " ] Node Type = [" + role + "]");
		}

		// set ClusterConfig
		ClusterConfig cc = new ClusterConfig(localIPAddress, Integer.toString(port), Integer.toString(vasNode
				.getNodeId()), vasNode.getSysId(), nodeType);

		return cc;

	}

	public static ClusterConfig setIPaddressInConfig(VasNodeServiceWithoutSpring vasNodeService, Config config,
			String role) {

		String localIPAddress = null;
		String nodeType = null;
		int selfNodeId = VasNodeServiceWithoutSpring.NODEID_ERROR;

		if (role.equalsIgnoreCase(ClusterMatchingMaster.ROLE)) {
			nodeType = VasNodeService.NODE_TYPE_MASTER;
		} else {
			nodeType = VasNodeService.NODE_TYPE_WORKER;
		}

		// get local IP address
		try {
			InetAddress addr = InetAddress.getLocalHost();
			localIPAddress = addr.getHostAddress();
		} catch (Exception ex) {
			logger.error("++ failed to get local IP address. [{}]. Can't proceed anymore!", ex.toString());
			throw new RuntimeException("++ failed to get local IP Address. Can't proceed anymore!" + ex.toString());
		}

		// get port from application.conf
		String akkaIPAddressInConf = config.getString("akka.remote.netty.tcp.hostname");
		int akkaPortInConf = config.getInt("akka.remote.netty.tcp.port");

		// compare local ip with akka ip address in application.conf
		if (StringUtils.equals(akkaIPAddressInConf, localIPAddress)) {

			boolean exist = vasNodeService.existAddressnPort(akkaIPAddressInConf, String.valueOf(akkaPortInConf), role);
			if (exist) {
				vasNodeService.setVasNodePortOccupied(akkaIPAddressInConf, String.valueOf(akkaPortInConf));
				logger.info("++ My IP address [{}] and Port [{}] alreay exist in application.conf and VAS_NODE table",
						akkaIPAddressInConf, akkaPortInConf);

				// get my node id from VAS_NODE table
				VasNode vasNode = vasNodeService.getNodeId(akkaIPAddressInConf, String.valueOf(akkaPortInConf), role);
				if (vasNode == null || vasNode.getNodeId() == VasNodeServiceWithoutSpring.NODEID_ERROR) {
					logger.error(
							"++ Can't find node Id in VAS_NODE table. IP address = [{}], Port = [{}], Node type = [{}]",
							akkaIPAddressInConf, akkaPortInConf, role);
					throw new IllegalStateException("++ Can't find node Id in VAS_NODE table. IP address = ["
							+ akkaIPAddressInConf + "] Port = [" + akkaPortInConf + " ] Node Type = [" + role + "]");
				}

				ClusterConfig cc = new ClusterConfig(akkaIPAddressInConf, Integer.toString(akkaPortInConf),
						Integer.toString(vasNode.getNodeId()), vasNode.getSysId(), nodeType);

				return cc;
			}
		}

		// get available AKKA port from DB
		int akkaPortFromDB = vasNodeService.getAvailablePort(localIPAddress, role);
		if (akkaPortFromDB == VasNodeService.PORT_ERROR) {
			StringBuffer sb = new StringBuffer();
			sb.append("++ Important AKKA application.conf error !!!! ---------\n");
			sb.append("++ Local IP address [" + localIPAddress + "]");
			sb.append(" node type [" + nodeType + "]");
			sb.append(" doesn't exist or no available port in VAS_NODE table. --------\n");
			sb.append("++ Please add this IP address or new port in VAS_NODE table ----------\n\n");
			logger.error(sb.toString());
			throw new RuntimeException(sb.toString());
		}

		// set AKKA remote port and hostname in config
		// Config configTemp = config.withValue("akka.remote.netty.tcp.port",
		// ConfigValueFactory.fromAnyRef(akkaPortFromDB));
		// Config newConfig =
		// configTemp.withValue("akka.remote.netty.tcp.hostname",
		// ConfigValueFactory.fromAnyRef(localIPAddress));

		Config newConfig = ConfigFactory.parseString("akka.remote.netty.tcp.hostname=" + localIPAddress)
				.withFallback(ConfigFactory.parseString("akka.remote.netty.tcp.port=" + akkaPortFromDB))
				.withFallback(config);

		// get my node id from VAS_NODE table
		VasNode vasNode = vasNodeService.getNodeId(localIPAddress, String.valueOf(akkaPortFromDB), role);
		if (vasNode == null || vasNode.getNodeId() == VasNodeServiceWithoutSpring.NODEID_ERROR) {
			logger.error(
					"++ Successfully getting akka port but Can't find node Id in VAS_NODE table. IP address = [{}], "
							+ "Port = [{}], Node type = [{}]", akkaIPAddressInConf, akkaPortInConf, role);
			throw new IllegalStateException(
					"++ Successfully getting akka port but Can't find node Id in VAS_NODE table." + " IP address = ["
							+ akkaIPAddressInConf + "] Port = [" + akkaPortInConf + " ] Node Type = [" + role + "]");
		}

		// update application.conf file
		String akkaDir;
		if (FileUtil.runOnEclipse("bin")) {
			Path currentPath = Paths.get(System.getProperty("user.dir"));

			akkaDir = currentPath.toAbsolutePath().normalize().toString() + "/conf";
		} else {

			Path currentPath = Paths.get(System.getProperty("user.dir"));
			String parentDir = currentPath.getParent().toAbsolutePath().normalize().toString();

			akkaDir = parentDir + "/conf";
		}
		String akkaFile = AKKA_CONF_FILENAME;

		String originalText = akkaIPAddressInConf;
		String replaceText = localIPAddress;

		// write ip address on application.conf
		FileUtil.replaceText(akkaDir, akkaFile, originalText, replaceText);

		originalText = String.valueOf(akkaPortInConf);
		replaceText = String.valueOf(akkaPortFromDB);

		// write port on application.conf
		FileUtil.replaceText(akkaDir, akkaFile, originalText, replaceText);

		/*
		 * ConfigRenderOptions co =
		 * ConfigRenderOptions.defaults().setOriginComments
		 * (false).setComments(false).setJson(false); String newConfigString =
		 * newConfig.root().render(co); logger.debug(" config = [{}]",
		 * newConfigString);
		 */

		ClusterConfig cc = new ClusterConfig(localIPAddress, Integer.toString(akkaPortFromDB), Integer.toString(vasNode
				.getNodeId()), vasNode.getSysId(), nodeType);

		return cc;

	}

	public static Config addSeedNodes(VasNodeService vasNodeService, Config config, String role, String clusterName,
			String systemId) {

		// get nodes with same system id from VAS_NODE Table
		List<VasNode> vasNodes = vasNodeService.getNodeInfo(systemId);
		if (vasNodes.isEmpty()) {
			logger.error("++ Seed Node operation failed. There is no Node in VAS_NODE table !!!");
			throw new RuntimeException("++ Seed Node operation failed. There is no Node in VAS_NODE table");
		}

		// make current seed node info
		List<String> seedNodes = new ArrayList<String>();
		String prefix = "akka.tcp://" + clusterName + "@";

		List<String> candidateMasterNodes = new ArrayList<String>();
		Map<String, String> candidateSeedWorkerNodes = new HashMap<String, String>();

		for (VasNode vasNode : vasNodes) {
			// master node
			if (vasNode.getNodeType().equalsIgnoreCase(VasNodeService.NODE_TYPE_MASTER)) {
				candidateMasterNodes.add(vasNode.getIpAddress() + ":" + vasNode.getPort());
			}
			// worker node : one seed node each h/w
			else {
				candidateSeedWorkerNodes.put(vasNode.getIpAddress(), vasNode.getIpAddress() + ":" + vasNode.getPort());
			}
		}

		if (candidateMasterNodes.isEmpty()) {
			logger.error("++ Seed Node operation failed. There is no Master Node in VAS_NODE table !!!");
			throw new RuntimeException("++ Seed Node operation failed. There is no Master Node in VAS_NODE table");
		}

		/*
		 * if I am master, re-allocate my address, port into top position in the
		 * candidateMasterNodes list
		 */
		if (StringUtils.equals(role, ClusterMatchingMaster.ROLE)) {
			// get my AKKA IP address and AKKA port in application.conf
			String ipAddress = config.getString("akka.remote.netty.tcp.hostname");
			int port = config.getInt("akka.remote.netty.tcp.port");
			String myIP_Port = ipAddress + ":" + Integer.toString(port);

			// find my index in candidateMasterNodes list
			int myMasterIndex = -1;
			for (int idx = 0; idx < candidateMasterNodes.size(); idx++) {
				String masterIP_Port = candidateMasterNodes.get(idx);
				if (StringUtils.equals(myIP_Port, masterIP_Port)) {
					myMasterIndex = idx;
					break;
				}
			}

			if (myMasterIndex == -1) {
				logger.error("++ I am [master] node IP address =[{}], Port = [{}], Node Type = [MAST-NODE]. "
						+ "but there in no master node in VAS_NODE", ipAddress, port);
				throw new RuntimeException("++ I am [master] node IP address =[" + ipAddress + "], Port = [" + port
						+ "] " + "Node Type = [MAST-NODE]. but there in no master node in VAS_NODE");
			}
			// re-allocate my master ip, port into top in the
			// candidateMasterNodes list
			if (myMasterIndex != 0) {
				Collections.swap(candidateMasterNodes, myMasterIndex, 0);
			}
		}

		/*
		 * make seed nodes
		 */
		// first, add all master nodes
		for (String masterNodeIP_Port : candidateMasterNodes) {
			seedNodes.add(prefix + masterNodeIP_Port);
		}

		// second, add one worker node each h/w
		for (String workerNodeIP : candidateSeedWorkerNodes.keySet()) {
			seedNodes.add(prefix + candidateSeedWorkerNodes.get(workerNodeIP));
		}

		// change seed node in application.conf
		Config newConfig = config.withValue("akka.cluster.seed-nodes", ConfigValueFactory.fromIterable(seedNodes));

		logger.info("== [AKKA seed node list] =============== ");
		logger.info("== total seed nodes = [{}] ==============", seedNodes.size());
		int i = 0;
		for (String seedNode : seedNodes) {
			logger.info("[{}] seed node = [{}]", i++, seedNode);
		}
		logger.info("== [AKKA seed node list] ===================");

		return newConfig;
	}

	public static ClusterConfig setupAutomaticAkkaConfigurationAndGetSelfNodeId(boolean useOldAkkaSetup, String role) {

		int selfNodeId = -1;

		// load application.conf file
		Config config = ConfigFactory.load();
		if (config == null) {
			logger.error("Can not find [application.conf] file !!!");
			throw new IllegalStateException("Can not find [application.conf] file !!!");
		}

		// create Service instance for mybatis
		VasNodeServiceWithoutSpring vasNodeService = new VasNodeServiceWithoutSpring();
		ClusterConfig cc = null;

		if (useOldAkkaSetup) {
			// compare my IP address and port in application.conf with VAS_NODE
			// DB table
			cc = ConfigUtil.checkIPaddressInConfig(vasNodeService, config, role);
		} else {
			// get my IP address and port from VAS_NODE DB table and write the
			// application.conf file
			cc = ConfigUtil.setIPaddressInConfig(vasNodeService, config, role);
		}

		return cc;

	}

	public static void updateSetupFile(String dir, String fileName, int selfNodeId) {

		String fullPathDir = null;
		if (FileUtil.runOnEclipse("bin")) {
			Path currentPath = Paths.get(System.getProperty("user.dir"));

			fullPathDir = currentPath.toAbsolutePath().normalize().toString() + "/" + dir;
		} else {

			Path currentPath = Paths.get(System.getProperty("user.dir"));
			String parentDir = currentPath.getParent().toAbsolutePath().normalize().toString();

			fullPathDir = parentDir + "/" + dir;
		}

		// check whether file exist or not
		File f = new File(fullPathDir + "/" + fileName);
		if (!f.exists()) {
			throw new IllegalStateException("++ Updating node id is failed. because [" + fullPathDir + fileName
					+ "] doesn't exist !!!");
		}

		String originalText = "nodeId";
		String replaceText = Integer.toString(selfNodeId);

		// write ip address on application.conf
		FileUtil.replaceText(fullPathDir, fileName, originalText, replaceText);

	}

}
