package com.skcc.vas.frs.akka.model;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;

public class FaceResponeJSONFilter extends SimpleBeanPropertyFilter {
	@Override
	public void serializeAsField(Object pojo, JsonGenerator jgen, SerializerProvider provider, PropertyWriter writer)
			throws Exception {

		if (pojo instanceof FaceResponse) {
			if (canSerializeAsField((FaceResponse) pojo, writer.getName())) {
				super.serializeAsField(pojo, jgen, provider, writer);
			}
		} else {
			super.serializeAsField(pojo, jgen, provider, writer);
		}
	}

	private boolean canSerializeAsField(FaceResponse faceResponse, String fieldName) {

		if (fieldName.equals("feature") && faceResponse.getFeature() == null) {
			return false;
		}

		return true;
	}

}
