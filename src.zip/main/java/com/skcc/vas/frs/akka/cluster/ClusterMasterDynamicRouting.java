package com.skcc.vas.frs.akka.cluster;

import static com.skcc.vas.frs.akka.model.ActorProfile.*;

import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;

import scala.concurrent.Future;
import scala.concurrent.duration.*;
import akka.actor.*;
import akka.camel.*;
import akka.util.*;

import com.fasterxml.jackson.databind.*;
import com.typesafe.config.*;
import com.skcc.vas.frs.akka.actor.DynamicMappedRoutingActorMultiMaster;
import com.skcc.vas.frs.akka.actor.FaceWebServiceCluster;
import com.skcc.vas.frs.akka.cluster.*;
import com.skcc.vas.frs.akka.model.FRSVersion;
import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.akka.service.VasNodeService;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.live.biz.ConcernedPersonProcessor;
import com.skcc.vas.frs.live.biz.DetectionProcessorFactory;
import com.skcc.vas.frs.ondemand.db.biz.OndemandDBProcessor;
import com.skcc.vas.frs.ondemand.video.biz.OndemandVideoProcessor;
import com.skcc.vas.frs.ondemand.vms.biz.OndemandVMSProcessor;
import com.skcc.vas.frs.akka.util.ConfigUtil;

/**
 * @author
 * @since 2016-06-22
 *
 */
public class ClusterMasterDynamicRouting extends ClusterNodeBase {

	public static final int NODE_PORT_DEFAULT = 2551;

	public static final String ROLE = "master";

	private final int httpPort;

	public int getHttpPort() {
		return this.httpPort;
	}

	private final String baseUrl;

	public String getBaseUrl() {
		return this.baseUrl;
	}

	boolean useConfFile;

	public ClusterMasterDynamicRouting(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, @Nullable String configSubtree, boolean useConfFile)
			throws Exception {

		super(systemName, applName, NO_DEFINED_PORT, configSubtree, useConfFile);

		// http port를 appliation.conf에서 읽어 온다
		this.httpPort = this.getConfig().getInt("nodes.master.httpport");

		// build base URL
		InetAddress addr = InetAddress.getLocalHost();
		this.baseUrl = new StringBuilder().append("http://").append(addr.getHostAddress()).append(":")
				.append(this.getHttpPort()).append("/").append(applName).toString();

		// validate the master
		this.useConfFile = useConfFile;
		if (useConfFile) {
			String addr2 = null;
			int port2 = -1;
			try {
				addr2 = this.getConfig().getString("nodes.master.address");
				port2 = this.getConfig().getInt("nodes.master.port");
			} catch (Exception ex) {
				throw new IllegalStateException("The address or port for the master is not defined at configuration");
			}

			if (!StringUtils.equals(addr2, this.getAddress().getHostAddress()) || port2 != this.getPort()) {
				throw new IllegalStateException(
						"The address or port for this master is not same with thosed defined in configuration.");
			}
		}

	}

	@Override
	@Nonnull
	protected Config buildConfig(@Nullable String configSubtree) throws Exception {

		Config config = ConfigFactory.load();

		if (configSubtree != null) {
			config = config.getConfig(this.getConfigSubtree()).withFallback(config);
		}

		config = ConfigFactory.parseString("akka.actor.provider = \"akka.cluster.ClusterActorRefProvider\"")
				.withFallback(ConfigFactory.parseString("akka.cluster.roles = [" + ROLE + "]")).withFallback(config);

		return config;
	}

	@Override
	@Nonnull
	protected ActorSystem buildActorSystem(@Nonnull Config config) throws Exception {

		// acquire necessary beans from Spring container
		ObjectMapper jacksonMapper = this.getSpringContainer().getBean("jacksonObjectMapper", ObjectMapper.class);

		ConcernedPersonProcessor cpProcessor = this.getSpringContainer().getBean("hbInnoConcernedPersonProcessor",
				ConcernedPersonProcessor.class);

		DynamicNodeRoutingProcessor dynamicNodeProcessor = this.getSpringContainer().getBean(
				"dynamicNodeRoutingProcessor", DynamicNodeRoutingProcessor.class);

		FaceMatchJobService faceMatchJobService = this.getSpringContainer().getBean("faceMatchJobService",
				FaceMatchJobService.class);
		/* 투르크 온디맨드 db 대용량 지원을 위해 원래기능 주석 처리 */
		OndemandDBProcessor clusterDBProcessor = this.getSpringContainer().getBean("OndemandDBClusterProcessor",
				OndemandDBProcessor.class);

		OndemandVMSProcessor clusterVMSProcessor = this.getSpringContainer().getBean(
				"triumiHbInnoClusterSearchJobProcessor", OndemandVMSProcessor.class);

		OndemandVideoProcessor clusterVideoProcessor = this.getSpringContainer().getBean(
				"sParserHbInnoClusterSearchJobProcessor", OndemandVideoProcessor.class);

		Validate.validState(jacksonMapper != null, "Jackson ObjectMapper bean can't be found in the Spring container.");

		VasNodeService vasNodeService = this.getSpringContainer().getBean("vasNodeService", VasNodeService.class);

		Config configNew;
		if (this.useConfFile) {
			// check my IP address and port in DB
			configNew = ConfigUtil.checkIPaddressInConfig(vasNodeService, config, ROLE);
		} else {
			// modify application.conf using DB data
			configNew = ConfigUtil.setIPaddressInConfig(vasNodeService, config, ROLE);
			this.setPort(configNew.getInt("akka.remote.netty.tcp.port"));
		}

		// add Seed Nodes for AKKA
		Config configFinal = ConfigUtil.addSeedNodes(vasNodeService, configNew, ROLE);

		// build Akka cluster member
		// ActorSystem system = ActorSystem.create(this.getSystemName(),
		// config);
		ActorSystem system = ActorSystem.create(this.getSystemName(), configFinal);
		Camel camel = CamelExtension.get(system);

		ActorRef detectionRoutingService = system.actorOf(Props.create(DynamicMappedRoutingActorMultiMaster.class,
				FACE_DETECTION_ACTOR.getActorName(), dynamicNodeProcessor, this.getAddress().getHostAddress(),
				Integer.toString(this.getPort()), httpPort), FACE_DETECTION_ROUTING_ACTOR.getActorName());

		ActorRef webService = system.actorOf(Props.create(FaceWebServiceCluster.class, this.baseUrl + "/face",
				jacksonMapper, WebServiceBase.TIMEOUT_DEFAULT, detectionRoutingService, cpProcessor,
				clusterDBProcessor, clusterVMSProcessor, clusterVideoProcessor, faceMatchJobService, FRSVersion.FRS20),
				FACE_WEB_ACTOR.getActorName());

		Future<ActorRef> activationFuture = camel.activationFutureFor(webService,
				new Timeout(Duration.create(10, TimeUnit.SECONDS)), system.dispatcher());

		return system;
	}

	@Override
	protected void beforeStop() throws Exception {

	}

}
