package com.skcc.vas.frs.akka.cluster;

import static com.skcc.vas.frs.akka.model.ActorProfile.*;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;

import akka.actor.*;

import com.fasterxml.jackson.databind.*;
import com.typesafe.config.*;
import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.akka.actor.DetectionActorDynamicRouting;
import com.skcc.vas.frs.akka.cluster.*;
import com.skcc.vas.frs.akka.model.ClusterConfig;
import com.skcc.vas.frs.akka.service.VasNodeService;
import com.skcc.vas.frs.akka.util.ConfigUtil;
import com.skcc.vas.frs.akka.util.LicenseUtil;
import com.skcc.vas.frs.common.util.spring.Profile;
import com.skcc.vas.frs.live.biz.DetectionProcessorFactory;
import com.skcc.vas.frs.ondemand.db.biz.OndemandDBProcessor;
import com.skcc.vas.frs.ondemand.video.biz.OndemandVideoProcessor;
import com.skcc.vas.frs.ondemand.vms.biz.OndemandVMSProcessor;

/**
 * @author
 * @since 2016-06-24
 *
 */
public class ClusterDetectionWorker extends ClusterNodeBase {

	public static final String ROLE = "worker";

	boolean useConfFile;

	ClusterConfig clusterConfig;

	public ClusterDetectionWorker(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, @Nullable String configSubtree, boolean useConfFile,
			ClusterConfig clusterConfig) {

		super(systemName, applName, NO_DEFINED_PORT, configSubtree, useConfFile);

		this.useConfFile = useConfFile;
		this.clusterConfig = clusterConfig;

	}

	@Override
	@Nonnull
	protected Config buildConfig(@Nullable String configSubtree) throws Exception {

		Config config = ConfigFactory.load();
		if (configSubtree != null) {
			config = config.getConfig(this.getConfigSubtree()).withFallback(config);
		}

		config = ConfigFactory.parseString("akka.actor.provider = \"akka.cluster.ClusterActorRefProvider\"")
				.withFallback(ConfigFactory.parseString("akka.cluster.roles = [" + ROLE + "]")).withFallback(config);

		return config;
	}

	@Override
	@Nonnull
	protected ActorSystem buildActorSystem(@Nonnull Config config) throws Exception {

		// acquire necessary beans from Spring container
		ObjectMapper jacksonMapper = this.getSpringContainer().getBean("jacksonObjectMapper", ObjectMapper.class);

		DetectionProcessorFactory fdpFactory = this.getSpringContainer().getBean("detectionProcessorFactory",
				DetectionProcessorFactory.class);

		DetectionProcessorFactory fdOnlyPFactory = this.getSpringContainer().getBean("detectionOnlyProcessorFactory",
				DetectionProcessorFactory.class);

			//솔루션을 위한 ondemand 서비스
		OndemandDBProcessor clusterDBProcessor = this.getSpringContainer().getBean("OndemandDBClusterProcessor",
				OndemandDBProcessor.class);
		
		OndemandVMSProcessor clusterVMSProcessor = this.getSpringContainer().getBean(
				"triumiHbInnoClusterSearchJobProcessor", OndemandVMSProcessor.class);

		OndemandVideoProcessor clusterVideoProcessor = this.getSpringContainer().getBean(
				"sParserHbInnoClusterSearchJobProcessor", OndemandVideoProcessor.class);

		VasNodeService vasNodeService = this.getSpringContainer().getBean("vasNodeService", VasNodeService.class);

		Profile springProfile = this.getSpringContainer().getBean("spring.Profile", Profile.class);

		String[] profiles = springProfile.getSpringProfiles();
		for (String profile : profiles) {
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			logger.debug("current spring profile : [{}]", profile);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		}
		
		String[] beans =springProfile.getSpringBeans();
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		for(String bean : beans) {
			logger.debug("current spring bean : [{}]", bean);
		}
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		
		LicenseUtil.checkHBinnoLicense(this.getSpringContainer().getBean("hbInnoAdapter", HbInnoAdapter.class));

		Validate.validState(fdpFactory != null,
				"DetectionProcessorFacotry bean can't be found in the Spring container.");
		Validate.validState(fdOnlyPFactory != null,
				"DetectionProcessorFacotry(only Detection )bean can't be found in the Spring container.");
		Validate.validState(jacksonMapper != null, "Jackson ObjectMapper bean can't be found in the Spring container.");
		Validate.validState(clusterDBProcessor != null,
				"Ondemand DB process implement bean can't be found in the Spring container.");
		Validate.validState(clusterVMSProcessor != null,
				"Ondemand VMS process implement bean can't be found in the Spring container.");
		Validate.validState(clusterVideoProcessor != null,
				"Ondemand Video process implement bean can't be found in the Spring container.");
		Validate.validState(vasNodeService != null, "VasNodeService bean can't be found in the Spring container.");

		Config configNew = ConfigFactory
				.parseString("akka.remote.netty.tcp.hostname=" + this.clusterConfig.getIpAddress())
				.withFallback(
						ConfigFactory.parseString("akka.remote.netty.tcp.port=" + this.clusterConfig.getPortInt()))
				.withFallback(config);

		// add Seed Nodes for AKKA
		Config configFinal = ConfigUtil.addSeedNodes(vasNodeService, configNew, ROLE, this.getSystemName(),
				this.clusterConfig.getSystemId());

		// build Akka cluster member
		ActorSystem system = ActorSystem.create(this.getSystemName(), configFinal);

		ActorRef detectionService = system.actorOf(Props.create(DetectionActorDynamicRouting.class, fdOnlyPFactory,
				clusterDBProcessor, clusterVMSProcessor, clusterVideoProcessor), FACE_DETECTION_ACTOR.getActorName());

		return system;
	}

	@Override
	protected void beforeStop() throws Exception {

	}

}
