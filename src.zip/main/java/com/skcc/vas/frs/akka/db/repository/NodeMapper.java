package com.skcc.vas.frs.akka.db.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.akka.db.rdb.domain.Node;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandDBSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVMSSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVideoSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.VasNode;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;

@Repository("face.NodeMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface NodeMapper {

	Node selectNode(@Param("nodeAddress") String nodeAddress, @Param("nodePort") String nodePort);

	Node selectNodeById(@Param("nodeId") int nodeId);

	String[] selectNodesByFromIdx(HashMap<String, Object> param);

	String[] selectNodeByCncrnFaceIdx(@Param("idx") int idx);

	String[] selectNodeOfLastCncrnFaceId();

	int insertNewNode(@Param("node") Node node);

	Integer selectNodeId(@Param("nodeAddress") String nodeAddress, @Param("nodePort") String nodePort);

	int updateExistingNode(@Param("node") Node node);

	int deleteCctv(@Param("nodeId") int nodeId);

	int deleteOneCctv(@Param("nodeId") int nodeId, @Param("cctvId") String cctvId);

	List<Cctv> selectCctvList(@Param("nodeId") int nodeId);

	int insertCctv(@Param("cctv") Cctv cctv);

	int insertCctvList(Map<String, Object> map);

	List<Node> selectNodeList();

	Cctv selectCctvByCctvId(@Param("cctvId") String cctvId, @Param("systemId") String systemId);

	int updateCctvStatus(@Param("systemId") String systemId, @Param("cctvId") String cctvId,
			@Param("status") String status);

	FRConfig selectConfigInfo();

	FRConfig selectConfigInfoByCctvId(@Param("cctvId") String cctvId);

	List<Node> selectStandbyOndemandNodeList();

	List<Integer> selectOngoingOndemandDBNodeList(@Param("jobId") String jobId);
	List<Integer> selectOngoingOndemandVMSNodeList(@Param("jobId") String jobId);
	List<Integer> selectOngoingOndemandVideoNodeList(@Param("jobId") String jobId);

	int insertOndemandDBSubJob(@Param("dbSubJobVO") OndemandDBSubJobVO ondemandDBSubJobVO);
	int insertOndemandVMSSubJob(@Param("vmsSubJobVO") OndemandVMSSubJobVO ondemandVMSSubJobVO);
	int insertOndemandVideoSubJob(@Param("videoSubJobVO") OndemandVideoSubJobVO ondemandVideoSubJobVO);

	OndemandDBSubJobVO selectOngoingDBSubJob(@Param("nodeId") int nodeId);
	OndemandVMSSubJobVO selectOngoingVMSSubJob(@Param("nodeId") int nodeId);
	OndemandVideoSubJobVO selectOngoingVideoSubJob(@Param("nodeId") int nodeId);

	int selectOndemandDBAllCount(@Param("jobId") String jobId);
	int selectOndemandDBFinishedCount(@Param("jobId") String jobId);
	int selectOndemandDBSuccessfulCount(@Param("jobId") String jobId);

	int selectOndemandVMSAllCount(@Param("jobId") String jobId);
	int selectOndemandVMSFinishedCount(@Param("jobId") String jobId);
	int selectOndemandVMSSuccessfulCount(@Param("jobId") String jobId);

	int selectOndemandVideoAllCount(@Param("jobId") String jobId);
	int selectOndemandVideoFinishedCount(@Param("jobId") String jobId);
	int selectOndemandVideoSuccessfulCount(@Param("jobId") String jobId);

	int updateOndemandDBStatus(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("time") String time);
	int updateOndemandVMSStatus(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("time") String time);
	int updateOndemandVideoStatus(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("time") String time);

	int updateOndemandDBStatusWithThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("startTime") String startTime, @Param("totalThread") int totalThread);
	int updateOndemandVMSStatusWithThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("startTime") String startTime, @Param("totalThread") int totalThread);
	int updateOndemandVideoStatusWithThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("status") String status, @Param("startTime") String startTime, @Param("totalThread") int totalThread);

	HashMap<String, Integer> selectOndemandDBThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId);
	HashMap<String, Integer> selectOndemandVMSThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId);
	HashMap<String, Integer> selectOndemandVideoThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId);

	int updateOndemandDBCompletedThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("thread") int completedTotalThread);
	int updateOndemandVMSCompletedThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("thread") int completedTotalThread);
	int updateOndemandVideoCompletedThread(@Param("nodeId") int nodeId, @Param("jobId") String jobId,
			@Param("thread") int completedTotalThread);

	List<OndemandDBSubJobVO> selectOndemandDBNode(@Param("jobId") String jobId);
	List<OndemandVMSSubJobVO> selectOndemandVMSNode(@Param("jobId") String jobId);
	List<OndemandVideoSubJobVO> selectOndemandVideoNode(@Param("jobId") String jobId);

	int deleteDBSubJob(@Param("nodeId") int nodeId, @Param("jobId") String jobId);
	int deleteVMSSubJob(@Param("nodeId") int nodeId, @Param("jobId") String jobId);
	int deleteVideoSubJob(@Param("nodeId") int nodeId, @Param("jobId") String jobId);

	List<String> selectOngoingDBJob(@Param("nodeId") int nodeId);
	List<String> selectOngoingVMSJob(@Param("nodeId") int nodeId);
	List<String> selectOngoingVideoJob(@Param("nodeId") int nodeId);

	int updateJobMaster(@Param("jobId") String jobId, @Param("progress") float progress,
			@Param("resultStatus") String resultStatus);

	FileAnalysisRequest.AnalysisResource selectAnalysisResource(@Param("rscId") int rscId);

	List<VasNode> selectVasNodes();
	List<VasNode> selectVasNodesWithSystemId(@Param("systemId") String systemId);
	VasNode selectVasNode(@Param("nodeAddress") String nodeAddress, @Param("nodePort") String nodePort);
	List<VasNode> selectVasNodesbyAddress(@Param("nodeAddress") String nodeAddress, @Param("nodeType") String nodeType);
	int updateVasNodePortUsed(@Param("nodeAddress") String nodeAddress, @Param("nodePort") String nodePort,
			@Param("allocated") String portUsed);
	
	HashMap<Integer, Integer> selectConcernMatchingVolumn(@Param("nodeAddress") String nodeAddress, @Param("nodePort") String nodePort);
	HashMap<Integer, Integer> selectConcernMatchingVolumnByNodeId(@Param("nodeId") int nodeId);
	
	   
	List<Node> selectNodeListOfGroupe(@Param("nodeId") int nodeId);
	
	Integer selectGroupId(@Param("nodeId") int nodeId);
	List<Node> selectStandbyMatchingNodeWithSameGroup(@Param("groupId") int groupId);
	List<Node> selectStandbyDetectionNodeWithSameGroup(@Param("nodeClass") String nodeClass, @Param("groupId") int groupId);
	
}
