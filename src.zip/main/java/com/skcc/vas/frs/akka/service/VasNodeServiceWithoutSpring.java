package com.skcc.vas.frs.akka.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.skcc.vas.frs.akka.cluster.ClusterMatchingMaster;
import com.skcc.vas.frs.akka.cluster.ClusterMatchingWorker;
import com.skcc.vas.frs.akka.db.rdb.domain.VasNode;

public class VasNodeServiceWithoutSpring {

	public static final int PORT_ERROR = -1;
	public static final String ALLOCATED = "Y";
	public static final String NODE_TYPE_MASTER = "MAST-NODE";
	public static final String NODE_TYPE_WORKER = "WORK-NODE";
	public static final int NODEID_ERROR = -1;

	private SqlSessionFactory sf = null;

	private SqlSessionFactory getSqlSessionFactory() {
		if (sf == null) {
			String resource = "mybatis-java.xml";
			InputStream inputStream;
			try {
				inputStream = Resources.getResourceAsStream(resource);
			} catch (IOException ex) {
				throw new IllegalArgumentException(ex);
			}
			sf = new SqlSessionFactoryBuilder().build(inputStream);
		}

		return sf;

	}

	public List<VasNode> getNodeInfo() {

		SqlSession sqlSession = getSqlSessionFactory().openSession();
		List<VasNode> vasNodes = null;

		try {
			String statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.selectVasNodes";
			vasNodes = sqlSession.selectList(statement);
		} finally {
			sqlSession.close();
		}

		if (vasNodes == null || vasNodes.size() == 0) {
			return Collections.emptyList();
		}

		// remove VasNode with useYN = 'N' or 'n'
		List<VasNode> filteredVasNodes = new ArrayList<VasNode>();
		for (VasNode vasNode : vasNodes) {
			if (vasNode.getUseYN() != null && vasNode.getUseYN().equalsIgnoreCase("n")) {
				continue;
			}
			filteredVasNodes.add(vasNode);
		}
		return filteredVasNodes;

	}

	public boolean existAddressnPort(String ipAddress, String port, String role) {

		SqlSession sqlSession = getSqlSessionFactory().openSession();
		VasNode vasNode = null;

		try {

			String statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.selectVasNodeFromMap";
			Map<String, Object> parameter = new HashMap<String, Object>();
			parameter.put("nodeAddress", ipAddress);
			parameter.put("nodePort", port);

			vasNode = sqlSession.selectOne(statement, parameter);

		} finally {
			sqlSession.close();
		}

		if (vasNode == null) {
			return false;
		}

		String nodeType = vasNode.getNodeType();

		// master node
		if (role.equalsIgnoreCase(ClusterMatchingMaster.ROLE)) {
			if (nodeType.equalsIgnoreCase(NODE_TYPE_MASTER))
				return true;
			else
				return false;
		} else if (role.equalsIgnoreCase(ClusterMatchingWorker.ROLE)) {
			if (nodeType.equalsIgnoreCase(NODE_TYPE_WORKER))
				return true;
			else
				return false;
		} else {
			return false;
		}
	}

	public VasNode getNodeId(String ipAddress, String port, String role) {

		SqlSession sqlSession = getSqlSessionFactory().openSession();
		VasNode vasNode = null;
		try {

			String statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.selectVasNodeFromMap";
			Map<String, Object> parameter = new HashMap<String, Object>();
			parameter.put("nodeAddress", ipAddress);
			parameter.put("nodePort", port);

			vasNode = sqlSession.selectOne(statement, parameter);

		} finally {
			sqlSession.close();
		}

		if (vasNode == null)
			return null;

		String nodeType = vasNode.getNodeType();

		// master node
		if (role.equalsIgnoreCase(ClusterMatchingMaster.ROLE)) {
			if (!nodeType.equalsIgnoreCase(NODE_TYPE_MASTER))
				vasNode.setNodeId(NODEID_ERROR);
		} else if (role.equalsIgnoreCase(ClusterMatchingWorker.ROLE)) {
			if (!nodeType.equalsIgnoreCase(NODE_TYPE_WORKER))
				vasNode.setNodeId(NODEID_ERROR);
		} else {
			vasNode.setNodeId(NODEID_ERROR);
		}

		return vasNode;
	}

	public int getAvailablePort(String ipAddress, String role) {

		SqlSession sqlSession = getSqlSessionFactory().openSession(true);

		String nodeType;
		List<VasNode> vasNodes = null;
		String akkaPort = null;

		// master node
		if (role.equalsIgnoreCase(ClusterMatchingMaster.ROLE)) {
			nodeType = NODE_TYPE_MASTER;

		} else {// worker node
			nodeType = NODE_TYPE_WORKER;
		}

		try {

			String statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.selectVasNodesbyAddressFromMap";
			Map<String, Object> parameter = new HashMap<String, Object>();
			parameter.put("nodeAddress", ipAddress);
			parameter.put("nodeType", nodeType);

			vasNodes = sqlSession.selectList(statement, parameter);

			if (vasNodes != null && !vasNodes.isEmpty()) {
				// update the port as already occupied
				akkaPort = vasNodes.get(0).getPort();

				statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.updateVasNodePortUsedFromMap";
				Map<String, Object> parameter2 = new HashMap<String, Object>();
				parameter2.put("nodeAddress", ipAddress);
				parameter2.put("nodePort", akkaPort);
				parameter2.put("allocated", ALLOCATED);

				sqlSession.update(statement, parameter2);
			}

		} finally {
			sqlSession.close();
		}

		if (vasNodes == null || vasNodes.isEmpty()) {
			return PORT_ERROR;
		}

		return Integer.parseInt(akkaPort);

	}

	public void setVasNodePortOccupied(String ipAddress, String port) {

		SqlSession sqlSession = getSqlSessionFactory().openSession(true);

		try {
			String statement = "com.skcc.vas.frs.akka.db.repository.NodeMapper.updateVasNodePortUsedFromMap";
			Map<String, Object> parameter = new HashMap<String, Object>();
			parameter.put("nodeAddress", ipAddress);
			parameter.put("nodePort", port);
			parameter.put("allocated", ALLOCATED);

			sqlSession.update(statement, parameter);

		} finally {
			sqlSession.close();
		}

	}

}
