package com.skcc.vas.frs.akka.actor;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;







import akka.actor.ActorSystem;
import akka.actor.Address;
import akka.actor.UntypedActor;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent;
import akka.cluster.ClusterEvent.MemberEvent;
import akka.cluster.ClusterEvent.MemberRemoved;
import akka.cluster.ClusterEvent.MemberUp;
import akka.cluster.ClusterEvent.ReachableMember;
import akka.cluster.ClusterEvent.UnreachableMember;
import akka.cluster.Member;
import akka.cluster.MemberStatus;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import akka.routing.Router;

import com.skcc.vas.frs.akka.db.rdb.domain.*;
import com.skcc.vas.frs.akka.model.*;
import com.skcc.vas.frs.akka.routing.*;
import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.akka.util.*;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.interfaces.activemq.model.ConcernedFaceUpdateMessage;
import com.skcc.vas.frs.interfaces.activemq.publisher.ConcernedFaceUpdatePulisher;

public class DynamicMappedRoutingActorMultiMaster<T extends java.io.Serializable> extends UntypedActor {

	private final static String MASTER_ROLE = "master";

	private final LoggingAdapter logger = Logging.getLogger(getContext().system(), this);

	private final Cluster cluster;

	private final String routeeName;

	DynamicNodeRoutingProcessor routingProcessor;

	private ConcernedFaceUpdatePulisher concernedFaceUpdatePulisher;
	
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	private final Lock routeesLock = new ReentrantLock();

	private volatile Router router = null;

	// this should be removed later
	private final List<KeyedRoutee<T>> routees = new ArrayList<KeyedRoutee<T>>();

	private String masterAddress;
	private String masterPort;
	private String masterURL;

	private final static String AKKAProtocol = "akka.tcp://WatzEyeVAS@";

	private final static int CONCERNED_FACES_COUNT = 30000;

	/*
	 * master가 2개 이상 존재하는 경우 member up, member remove를 처리하기 위한 master를 결정
	 */
	private TreeSet<Long> masterPriority = new TreeSet<Long>();
	private boolean firstMaster = true; // master가 up 되기전에 worker node가 먼저 up되는
	// 경우가 있으므로 반드시 true로 해야 함
	/*
	 * master가 여러 개인 경우 master priority 로직을 사용할지 말지를 결정 supportMasterPriority =
	 * true : the master of master만 member up and member removed 처리를 수행
	 * supportMasterPriority = false : 모든 master는 동일하게 member up and member
	 * removed 처리를 수행
	 */
	private final boolean supportMasterPriority = true;

	/*
	 * cctv가 할당되고 detection을 수행 중인 node가 죽게되는 경우, failover를 하지 못하게 되면 node의 상태는
	 * removed로 됨 운영자가 재 기동시 자동으로 node role을 standby가 아닌 active로 변경하고, 자동으로 cctv
	 * detection 수행 할지 말지를 결정
	 */
	private final boolean supportAutoActive = true;

	/*
	 * ondemand에서 node가 죽게되는 경우, failover를 위해서 standby node가 없는 경우에도 기존 ondemand
	 * node에 job 단위로 failover를 수행할지를 결정
	 */
	private final boolean supportJobFailover = false;

	@Nullable
	protected Router getRouter() {
		return this.router;
	}

	public DynamicMappedRoutingActorMultiMaster(@NotBlank String routeeName,
			@Nonnull DynamicNodeRoutingProcessor routingProcessor, String masterAddress, String masterPort, int httpPort) {

		Validate.isTrue(StringUtils.isNotBlank(routeeName), "Actor name for the routee should be specified");
		Validate.isTrue(routingProcessor != null, "The dynamic routing processor should be provided.");

		this.routeeName = routeeName;
		this.routingProcessor = routingProcessor;

		this.masterAddress = masterAddress;
		this.masterPort = masterPort;

		this.cluster = Cluster.get(this.getContext().system());
		this.cluster.subscribe(getSelf(), ClusterEvent.initialStateAsEvents(),
				// MemberEvent.class, UnreachableMember.class, ReachableMember.class,
				// MemberRemoved.class, SeenChanged.class, AssociatedEvent.class);
				MemberEvent.class, UnreachableMember.class, ReachableMember.class, MemberRemoved.class);

		/*
		 * master node가 여러 개인 경우에 대비해 Priority TreeSet에 자기 자신을 등록한다
		 */
		long masterValue = getUniqueNodeValueFromAddress(this.masterAddress, this.masterPort);
		this.masterPriority.add(masterValue);
		this.firstMaster = true;

		/*
		 * master http 주소를 만든다
		 */
		this.masterURL = "http://" + this.masterAddress + ":" + String.valueOf(httpPort) + "/vas/face";

		logger.debug("++ DynamicMappedRoutingActor constructor called, akka address: [{}] ", cluster.selfAddress().toString());

	}

	public DynamicMappedRoutingActorMultiMaster(@NotBlank String routeeName,
			@Nonnull DynamicNodeRoutingProcessor routingProcessor,
			@Nonnull ConcernedFaceUpdatePulisher concernedFaceUpdatePulisher, @Nonnull FaceDataManager faceDataManager,
			String masterAddress, String masterPort, int httpPort) {

		Validate.isTrue(StringUtils.isNotBlank(routeeName), "Actor name for the routee should be specified");
		Validate.isTrue(routingProcessor != null, "The dynamic routing processor should be provided.");

		this.routeeName = routeeName;
		this.routingProcessor = routingProcessor;

		this.concernedFaceUpdatePulisher = concernedFaceUpdatePulisher;
		this.faceDataManager = faceDataManager;

		this.masterAddress = masterAddress;
		this.masterPort = masterPort;

		this.cluster = Cluster.get(this.getContext().system());
		this.cluster.subscribe(getSelf(), ClusterEvent.initialStateAsEvents(),
				// MemberEvent.class, UnreachableMember.class, ReachableMember.class,
				// MemberRemoved.class, SeenChanged.class, AssociatedEvent.class);
				MemberEvent.class, UnreachableMember.class, ReachableMember.class, MemberRemoved.class);

		/*
		 * master node가 여러 개인 경우에 대비해 Priority TreeSet에 자기 자신을 등록한다
		 */
		long masterValue = getUniqueNodeValueFromAddress(this.masterAddress, this.masterPort);
		this.masterPriority.add(masterValue);
		this.firstMaster = true;

		/*
		 * master http 주소를 만든다
		 */
		this.masterURL = "http://" + this.masterAddress + ":" + String.valueOf(httpPort) + "/vas/face";

		logger.debug("++ DynamicMappedRoutingActor constructor called, akka address: [{}] ", cluster.selfAddress().toString());

	}

	@Override
	public void onReceive(Object msg) throws Exception {

		logger.debug("++ DynamicMappedRoutingActor - onReceived called");

		/*
		 * From: FaceWebService
		 */
		if (msg instanceof Keyed<?>) {

			try {
				KeyedMessage<CctvKey, Boolean> keyedMessage = (KeyedMessage<CctvKey, Boolean>) msg;
				Key<CctvKey> key = (Key<CctvKey>) keyedMessage.getKey();
				CctvKey cctvKey = key.get();
				boolean startstopFlag = keyedMessage.getMessage();

				String cctvId = cctvKey.getId();
				String systemId = cctvKey.getSystemId();
				int code = cctvKey.getCode(); // for CNCRN_FACE_DB_UPDATE

				this.logger.debug("++ Keyed Message arrived: {} flag = {}", cctvKey, startstopFlag);
				logger.debug("++ Keyed message print routee list");
				printRouteeList();

				if (code == CctvKey.CODE_DEFAULT_START_OR_STOP) {

					int nodeId = findNodeId(cctvId, systemId);
					if (nodeId < 0) {
						this.logger.warning("++ There is no worker node which has cctv Id = {}, system id = {}",
								cctvId, systemId);
						return;
					}

					/*
					 * node의 role이 active이고 status = initial, start, stop인지 확인
					 */
					boolean ret = checkNodeAvailable(nodeId);
					if (!ret) {
						this.logger.warning("++ There is worker node which has cctv Id = {}, but worker node state is "
								+ "not available", cctvId);
						return;
					}

					logger.debug("++ system id: {}, cctv id: {}, action: {} message route to Node id = {}", systemId,
							cctvId, startstopFlag, nodeId);

					ret = addRouteesForMember(nodeId);
					if (ret == false) {
						logger.warning("++ addRoutessForMember() is failed. so node id = {} start message can't go !!");
						return;
					}

					// make KeyedMessage
					KeyedMessage<Cctv, Boolean> km = createSingleKeyedMessage(nodeId, cctvId, systemId, startstopFlag);
					if (km == null) {
						logger.debug("++ CCTV[Id={}] [start/stop] command doesn't go to Node Id={}", cctvId, nodeId);
						return;
					}

					this.router.route(km, this.getSender());

					if (startstopFlag)
						logger.debug("++ CCTV[Id={}][start] command goes to Node Id={}", cctvId, nodeId);
					else
						logger.debug("++ CCTV[Id={}][stop] command goes to Node Id={}", cctvId, nodeId);

				}
				if (code == CctvKey.CODE_CNCRN_FACE_DB_UPDATED) {

					/*
					 * VMS id는 값을 설정하지 않고(UI에서 VMS id 값을 넘겨주지 않기 때문에), code만
					 * 전송한다
					 */
					MasterToWorkerMessage nodeMsg = new MasterToWorkerMessage(
							MasterToWorkerMessage.CODE_CNCRN_FACE_DB_UPDATED);
					SendWorkerMessageWithoutRouter(nodeMsg);
				}
			} catch (Exception ex) {
				logger.error("++ [Exception] Fail to handle [KeyedMessage]. Exception : [{}]",
						getPrintStacTraceString(ex));
			}
		}
		/*
		 * From FaceWebSerice
		 */
		else if (msg instanceof NodeMessage) {

			try {

				NodeMessage nm = (NodeMessage) msg;

				this.logger.info("++ NodeMessage arrived {}", nm);

				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_START) {

					boolean ret = checkNodeStatus(nm.getSystemId(), nm.getNodeId());
					if (!ret)
						return;

					ret = addRouteesForMember(nm.getNodeId());
					if (ret == false) {
						logger.warning("++ addRoutessForMember() is failed. so node id = {} start message can't go !!");
						return;
					}

					// Boolean.TRUE means "start worker node"
					List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(nm.getNodeId(),
							Boolean.TRUE);
					for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
						this.router.route(km, this.getSender());
					}

					// update Node of the dynamic routing map
					updateNodeStatus(nm.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START);

					logger.debug("++ Node(Id =[{}]) [Start] command goes to worker node", nm.getNodeId());
				}
				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_STOP) {

					boolean ret = checkNodeStatus(nm.getSystemId(), nm.getNodeId());
					if (!ret)
						return;

					ret = addRouteesForMember(nm.getNodeId());
					if (ret == false) {
						logger.warning("++ addRoutessForMember() is failed. so node id = {} stop message can't go !!");
						return;
					}

					// Boolean.FALSE means "stop worker node"
					List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(nm.getNodeId(),
							Boolean.FALSE);

					for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
						this.router.route(km, this.getSender());
					}

					// update Node of the dynamic routing map
					updateNodeStatus(nm.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_STOP);

					logger.debug("++ Node(Id =[{}]) [Stop] command goes to worker node", nm.getNodeId());
				}
				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_START_ALL) {

					List<Node> nodeList = getAllNodeList();
					if (nodeList == null) {
						logger.warning("++ [Node start all] message, but there is no node list");
						return;
					}

					/*
					 * Node 단위로 start 수행
					 */
					for (Node node : nodeList) {
						boolean ret = checkNodeStatus(nm.getSystemId(), node.getNodeId());
						if (!ret)
							continue; // 다음 node에 대해서 수행

						ret = addRouteesForMember(node.getNodeId());
						if (ret == false) {
							logger.warning("++ addRoutessForMember() is failed. so node id = {} start message can't go !!");
							continue;
						}

						// Boolean.TRUE means "start worker node"
						List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(node.getNodeId(),
								Boolean.TRUE);
						for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
							this.router.route(km, this.getSender());
						}

						// update Node of the dynamic routing map
						updateNodeStatus(node.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START);

						logger.debug("++ Node(Id =[{}]) [Start] command goes to worker node", node.getNodeId());

					}// for() loop

				}
				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_STOP_ALL) {

					List<Node> nodeList = getAllNodeList();
					if (nodeList == null) {
						logger.warning("++ [Node stop all] message, but there is no node list");
						return;
					}

					/*
					 * Node 단위로 stop 수행
					 */
					for (Node node : nodeList) {
						boolean ret = checkNodeStatus(nm.getSystemId(), node.getNodeId());
						if (!ret)
							continue; // 다음 node에 대해서 수행

						ret = addRouteesForMember(node.getNodeId());
						if (ret == false) {
							logger.warning("++ addRoutessForMember() is failed. so node id = {} start message can't go !!");
							continue;
						}

						// Boolean.TRUE means "start worker node"
						List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(node.getNodeId(),
								Boolean.FALSE);
						for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
							this.router.route(km, this.getSender());
						}

						// update Node of the dynamic routing map
						updateNodeStatus(node.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_STOP);

						logger.debug("++ Node(Id =[{}]) [Stop] command goes to worker node", node.getNodeId());

					}// for() loop

				}

				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_ROI_UPDATED_IN_ONE_DEVICE) {
					sendROIUpdateMessage(nm);
				}

				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ONE_DEVICE) {
					sendFREngineUpdateMessage(nm);
				}

				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES) {
					sendFREngineUpdateMessageToAll(nm);
				}

				if (nm.getMessageCode() == NodeMessage.NodeMessageCode.NM_CNCRN_FACE_DB_UPDATED) {

					ArrayList<String> matchNodeIdList = new ArrayList<String>();

					// FaceRequest Type : REMOVE_PERSON
					if (nm.getPersonId() != null) {
						List<String> faceIds = this.getFaceDataManager().findConcernedFaceIdsByPersonId(
								nm.getPersonId());
						String[] matchNodeIdArr = getNodesByFaceIds(faceIds);

						publishCncrnFaceUpdate(ConcernedFaceUpdateMessage.UPDATE_FEATURE_COMMAND, matchNodeIdArr,
								ConcernedFaceUpdateMessage.UPDATE_FEATURES);
					}
					// FaceRequest Type : REMOVE_FACES
					else if(nm.getFaceIds() != null && nm.getFaceIds().size() != 0){						
						String[] matchNodeIdArr = getNodesByFaceIds(nm.getFaceIds());

						publishCncrnFaceUpdate(ConcernedFaceUpdateMessage.UPDATE_FEATURE_COMMAND, matchNodeIdArr,
								ConcernedFaceUpdateMessage.UPDATE_FEATURES);
					}
					// FaceRequest Type : REGISTER_CONCERNED_FACE_DONE
					else {

						int fromFaceId = nm.getFaceIdFrom();
						int toFaceId = nm.getFaceIdTo();						

						this.logger.debug("FromFace Id : {},   To Face Id : {}", fromFaceId, toFaceId);

						// Concerned Face 1건 추가
						if(fromFaceId == toFaceId){
							String[] matchNodeIdArr = this.getFaceDataManager().getNodeOfLastCncrnFaceId();

							publishCncrnFaceUpdate(ConcernedFaceUpdateMessage.UPDATE_FEATURE_COMMAND, matchNodeIdArr,
									ConcernedFaceUpdateMessage.INSERT_FEATURES);
						}

						// Concerned Face 1건 이상 추가
						else if(toFaceId > fromFaceId){
							List<String> faceIdList = new ArrayList<String>();
							for(int i = toFaceId; fromFaceId == i; i--){
								faceIdList.add(String.valueOf(i));
							}
							
							String[] matchNodeIdArr = getNodesByFaceIds(faceIdList);
							
							publishCncrnFaceUpdate(ConcernedFaceUpdateMessage.UPDATE_FEATURE_COMMAND, matchNodeIdArr,
									ConcernedFaceUpdateMessage.INSERT_FEATURES);
						}

						else{
							this.logger.error("[fromFaceId:{}] must be greater than [toFaceId:{}]. ", fromFaceId, toFaceId);
						}
						

						//						int fromValueOfFirstNode = (((fromFaceId-1)/CONCERNED_FACES_COUNT)*CONCERNED_FACES_COUNT) + 1;
						//						int fromValueOfLastNode = (((toFaceIdId-1)/CONCERNED_FACES_COUNT)*CONCERNED_FACES_COUNT) + 1;

						

						//						// Concerned Face 1건 이상 추가
						//						else{
						//							int i = fromValueOfLastNode;
						//							List<Integer> fromValueList = new ArrayList<Integer>();
						//							while(true){			
						//								fromValueList.add(i);
						//								if(fromValueOfFirstNode == fromValueOfLastNode){
						//									break;
						//								}
						//								
						//								i = i - CONCERNED_FACES_COUNT;
						//								if(i == fromValueOfFirstNode){
						//									fromValueList.add(i);
						//									break;
						//								}
						//							}
						//
						//							this.logger.debug("fromValueList {} ", fromValueList.toString());
						//
						//							String[] matchNodeIdArr = this.getFaceDataManager().getNodesByFromIdx(fromValueList);		
						//							
						//							publishCncrnFaceUpdate(ConcernedFaceUpdateMessage.UPDATE_FEATURE_COMMAND, matchNodeIdArr,
						//									ConcernedFaceUpdateMessage.INSERT_FEATURES);
						//						}
					}

				}
			} catch (Exception ex1) {
				logger.error("++ [Exception] Fail to handle [NodeMessage]. Exception : [{}]",
						getPrintStacTraceString(ex1));
			}
		}
		/*
		 * from: DectionActorDymaicRouting
		 */
		else if (msg instanceof ActorStatusMessage) {

			try {

				ActorStatusMessage asm = (ActorStatusMessage) msg;

				this.logger.info("++ [ActorStatus process] ActorStatusMessage arrived, message = {}", asm);

				Node node = getNodeFromAddress(asm.getWorkerAddress(), "++ [AcstorStatus process]");
				if (node == null) {
					this.logger.warning(
							"++ [ActorStatus process] There is no Node info in DB " + "node address = [{}]",
							asm.getWorkerAddress());
					return;
				}

				this.logger.info("++ [ActorStatus process] Sender Node Id =[{}] in DB = [{}]", node.getNodeId(), node);

				if (asm.isOndemandMessage()) {
					processOndemandResponse(asm, node.getNodeId());
				}

				// if(asm.getMessageCode() ==
				// ActorStatusMessage.WORKER_NODE_START_DETECTION_FAILED) {
				// Node node = getNodeFromAddress(asm.getWorkerAddress());
				// if(node == null) {
				// logger.error("++ [ActorStatus process] Node[{}] doesn't exist in VAS_FR_NODE DB",
				// asm);
				// return;
				// }
				//
				// /*
				// * Node의 상태를 na, removed로 변경한다 --> 이후 node checker에게 node 재
				// 기동을 맡긴다
				// */
				// updateNodeStatus(node.getNodeId(),
				// NodeMessage.NodeMessageCode.NM_NODE_REMOVED);
				// logger.info("++ [ActorStatus process] Node Id=[{}} failed to start cctv[{}]."
				// +
				// "So Node role is changed into [NA] and [REMOVED]. Node checker will re-start this node",
				// node.getNodeId(), asm.getDeviceId());
				// }
			} catch (Exception ex2) {
				logger.error("++ [Exception] Fail to handle [ActorStatusMessage]. Exception : [{}]",
						getPrintStacTraceString(ex2));
			}

		}
		/*
		 * from Facewebservice
		 */
		else if (msg instanceof OndemandJob) {
			try {

				OndemandJob ondemandJob = (OndemandJob) msg;

				this.logger.info("++ [OndemandJob] Message arrived {}", ondemandJob);
				List<Integer> transmittedNodeIds = sendOndemandJob(ondemandJob);
				if (transmittedNodeIds == null)
					return;

				// update Node of the dynamic routing map
				for (Integer nodeId : transmittedNodeIds) {
					updateNodeStatusWithNodeClass(nodeId, NodeMessage.NodeMessageCode.NM_NODE_START,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
				}
			} catch (Exception ex3) {
				logger.error("++ [Exception] Fail to handle [OndemandJob]. Exception : [{}]",
						getPrintStacTraceString(ex3));
			}
		}

		/*
		 * from Facewebservice
		 */
		else if (msg instanceof OndemandJobResponse) {
			try {

				OndemandJobResponse ondemandJobResponse = (OndemandJobResponse) msg;

				this.logger.info("++ [Ondemand response] Message arrived {}", ondemandJobResponse);
				boolean isNodeJobCompleted = compareNumOfHttpResponseWithNumOfSubJobThread(ondemandJobResponse);
				if (isNodeJobCompleted) {

					logger.info("++ [Ondemand response] Job Id =[{}] of the current Node Id=[{}] is done."
							+ "Now check whether another nodes finished the Job or not",
							ondemandJobResponse.getJobId(), ondemandJobResponse.getNodeId());

					checkAllNodeSubJobThreadFinishedAndUpdateJobMaster(ondemandJobResponse);

					if (isRemainedAnotherJobinNode(ondemandJobResponse.getNodeId())) {
						logger.info(
								"++ [Ondemand response] Node Id=[{}] has some ongoing jobs. So Node status remains 'started'",
								ondemandJobResponse.getNodeId());

					} else {
						logger.info("++ [Ondemand response] Node Id=[{}] doesn't any ongoing job. "
								+ "So Node status will be 'initial'", ondemandJobResponse.getNodeId());
						updateNodeStatusWithNodeClass(ondemandJobResponse.getNodeId(),
								NodeMessage.NodeMessageCode.NM_NODE_INITIAL, Node.NodeClass.NODE_CLASS_ONDEMAND);
					}

				}
			} catch (Exception ex4) {
				logger.error("++ [Exception] Fail to handle [OndemandJobResponse]. Exception : [{}]",
						getPrintStacTraceString(ex4));
			}
		}

		/*
		 * From: AKKA cluster
		 */
		else if (msg instanceof MemberUp) {
			try {
				MemberEvent ev = (MemberEvent) msg;
				Member member = ev.member();

				if (isMasterNode(member)) {

					this.logger.info("++ Master node = {} is up", member.address());

					/*
					 * master priority에 등록
					 */
					long masterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.add(masterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ I[master] am the master of master. So Now I control member up and member removed");
					} else {
						logger.info("++ I[master] am not the master of master. So Another master "
								+ "contols member up and member removed");
					}

					/*
					 * Node role이 active, standby인 모든 worker node에게 master node가
					 * member up이 되었다는 것을 알린다
					 */
					// SendMasterUpNotification(member);

					return;
				} else if (isAnotherMasterNode(member)) {
					this.logger.info("++ Another Master node = {} is up", member.address());
					/*
					 * master priority에 등록
					 */
					long anotherMasterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.add(anotherMasterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ I[master] am the master of master. So Now I control member up and member removed");
					} else {
						logger.info("++ I[master] am not the master of master. So Another master[{}] contols "
								+ "member up and member removed", member.address());
					}

					return;
				}

				this.logger.info("++ Worker node(address:{}) is up", member.address());

				/*
				 * master node가 여러개 있는 경우 the master of master가 아닌 경우 아무런 처리를 하지
				 * 않는다
				 */
				if (this.supportMasterPriority == true && this.firstMaster == false) {
					this.logger.info("++ I am not the master of master. So I don't control worker node member up");
					return;
				}

				registerWorkerNode(member.address());

			} catch (Exception ex5) {
				logger.error("++ [Exception] Fail to handle [Member up]. Exception : [{}]",
						getPrintStacTraceString(ex5));
			}

		}
		/*
		 * AKKA cluster
		 */
		else if (msg instanceof UnreachableMember) {

			try {
				UnreachableMember ev = (UnreachableMember) msg;
				Member member = ev.member();
				Node node = getNodeFromAddress(member.address(), "++ [Unreachable]");
				if (node != null) {
					logger.info("++ [Unreachable]Memeber(address:{}) Node Id =[{}] has unreachable", member.address(),
							node.getNodeId());
				} else {
					logger.info("++ [Unreachable]Memeber(address:{}) has unreachable but there is no Node info in DB",
							member.address());
				}
			} catch (Exception ex6) {
				logger.error("++ [Exception] Fail to handle [UnreachableMember]. Exception : [{}]",
						getPrintStacTraceString(ex6));
			}

		}
		/*
		 * from AKKA cluster
		 */
		else if (msg instanceof MemberRemoved) {
			try {
				MemberRemoved ev = (MemberRemoved) msg;
				Member member = ev.member();
				Node node = getNodeFromAddress(member.address(), "++ [Removed process]");
				if (node != null) {
					logger.info("++ [Removed process]Member(address: {}) Node Id =[{}] removed ", member.address(),
							node.getNodeId());
				} else {
					logger.info("++ [Removed process]Member(address: {}) removed. but there is no Node info in DB"
							+ "Maybe this node is another master node. ", member.address());
				}

				if (isAnotherMasterNode(member)) {
					this.logger.info("++ [Removed process]Another Master node = {} is removed " + "but nothing to do",
							member.address());

					/*
					 * master priority에서 삭제
					 */
					long anotherMasterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.remove(anotherMasterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ [Removed process]total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ [Removed process]I[master] am the master of master. "
								+ "So Now I control member up and member removed");
					} else {
						logger.info("++ [Removed process]I[master] am not the master of master."
								+ " So Another master[{}] contols member up and member removed", member.address());
					}

					return;
				}

				/*
				 * master node가 여러개 있는 경우 the master of master가 아닌 경우 아무런 처리를 하지
				 * 않는다
				 */
				if (this.supportMasterPriority == true && this.firstMaster == false) {
					this.logger.info("++ [Removed process]I am not the master of master. So I don't control "
							+ "worker node removed and failover");
					return;
				}

				/*
				 * down된 node의 상태를 VAS_FR_NODE table에서 removed로 변경하고 변경전 node
				 * 정보를 가져온다
				 */
				Node deletedNode = changeNodeStatusAndgetOldStatus(member);
				if (deletedNode == null) {
					logger.info("++ [Removed process]Failed fail-over this Member[address:{}] "
							+ "because of already failover by another master node or DB error", member.address());
					return;
				}

				logger.info("++ [Removed process]Node(Id=[{}])removed and VAS_FR_NODE table is changed in [removed]",
						deletedNode.getNodeId());

				/*
				 * down된 node가 standby 상태였다면 failover를 진행하지 않는다
				 */
				if (deletedNode.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)) {
					logger.info("++ [Removed process]Don't failover because this node[{}] role is [Standby]",
							deletedNode);
					// VAS_FR_NODE_CCTV에서 할당된 CCTV list를 삭제한다
					routingProcessor.clearCctvList(deletedNode.getNodeId());
					return;
				}

				/*
				 * down된 node가 na 상태였다면 failover를 진행하지 않는다
				 */
				if (deletedNode.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_NA)) {
					logger.info("++ [Removed process]Don't failover because this node[{}] role is [NA]", deletedNode);
					// VAS_FR_NODE_CCTV에서 할당된 CCTV list를 삭제한다
					routingProcessor.clearCctvList(deletedNode.getNodeId());
					return;
				}

				removeRouteesOfMember(deletedNode.getNodeId());

				/*
				 * failover를 위한 standby node가 있는지 찾는다
				 */
				int groupId = routingProcessor.getGroupId(deletedNode.getNodeId());
				int failoverNodeId = -1;
				if (groupId < 0) { // FRS 2.0
					this.logger.debug("++ [Removed process] Member(address:{}, Node Id=[{}] is FRS 20 version",
							member.address(), deletedNode.getNodeId());
					failoverNodeId = findFailoverNode(deletedNode.getNodeClass());
				} else { // FRS 3.0
					this.logger.debug("++ [Removed process] Member(address:{}, Node Id=[{}] is FRS 30 version. "
							+ "group id = [{}]",
							member.address(), deletedNode.getNodeId(), groupId);
					failoverNodeId = findFailoverNodeOfGroup(deletedNode.getNodeClass(), deletedNode.getNodeId());
				}
				
				if (failoverNodeId < 0 && deletedNode.getNodeClass().equals(Node.NodeClass.NODE_CLASS_LIVE)) {
					this.logger.info("++ [Removed process : Live] Member(address:{}, Node Id=[{}])"
							+ " becomes [removed] but there are no standby node !!!. " + "removed process ends",
							member.address(), deletedNode.getNodeId());
					if (supportAutoActive) {
						// VAS_FR_NODE_CCTV에 할당된 CCTV list를 삭제하지 않는다
						// 재 기동에 대비해서 그대로 둔다

					} else {
						// Live FRS인 경우 VAS_FR_NODE_CCTV에서 할당된 CCTV list를 삭제한다
						routingProcessor.clearCctvList(deletedNode.getNodeId());
					}
					return;
				}

				if (failoverNodeId < 0 && deletedNode.getNodeClass().equals(Node.NodeClass.NODE_CLASS_ONDEMAND)) {
					if (supportJobFailover) {
						this.logger.info("++ [Removed process : Live] Member(address:{}, Node Id=[{}])"
								+ " becomes [removed] but there are no standby node !!!. "
								+ "Even though no Standby node, removed process continue.", member.address(),
								deletedNode.getNodeId());

					} else {
						this.logger.info("++ [Removed process : Ondemand] Member(address:{}, Node Id=[{}])"
								+ " becomes [removed] but there are no standby node !!!. " + "removed process ends",
								member.address(), deletedNode.getNodeId());

						updateJobStatus(deletedNode.getNodeId());
						return;
					}
				}

				logger.info("++ [Removed process]Removed node(Node Id=[{}]) find fail-over node Id=[{}]",
						deletedNode.getNodeId(), failoverNodeId);

				// Live FRS인 경우 failover node에 CCTV 정보를 설정한다
				if (deletedNode.getNodeClass().equalsIgnoreCase(Node.NodeClass.NODE_CLASS_LIVE)) {
					setFailoverNodeCctvList(deletedNode.getNodeId(), failoverNodeId);
					boolean ret = addRouteesForMember(failoverNodeId);
					if (ret == false)
						return;
				}

				if (deletedNode.getNodeClass().equalsIgnoreCase(Node.NodeClass.NODE_CLASS_LIVE)) {
					startFailoverNodeAndUpdateForLive(deletedNode, failoverNodeId);
				}

				if (deletedNode.getNodeClass().equalsIgnoreCase(Node.NodeClass.NODE_CLASS_ONDEMAND)) {
					startFailoverNodeAndUpdateForOndemand(deletedNode, failoverNodeId);
				}
			} catch (Exception ex7) {
				logger.error("++ [Exception] Fail to handle [Member removed]. Exception : [{}]",
						getPrintStacTraceString(ex7));
			}

		}

		/*
		 * from: AKKA cluster
		 */
		else if (msg instanceof ReachableMember) {
			try {

				ReachableMember ev = (ReachableMember) msg;
				Member member = ev.member();
				this.logger.info("++ Member(address:{}) becomes reachable.", member.address());

				if (isAnotherMasterNode(member)) {
					this.logger
					.info("++ Another Master node = {} becomes rechable but nothing to do", member.address());

					return;
				}

				// reachable, unreachable상태 모두 아무런 처리를 하지 않는다. 그래서 주석처리
				// registerWorkerNode(ev.member().address());
			} catch (Exception ex8) {
				logger.error("++ [Exception] Fail to handle [ReachableMember]. Exception : [{}]",
						getPrintStacTraceString(ex8));
			}

		}
		/*
		 * from AKKA cluster
		 */
		else if (msg instanceof MemberEvent) {
			MemberEvent ev = (MemberEvent) msg;
			MemberStatus ms = ev.member().status();
			if (ms == MemberStatus.joining()) {
				logger.info("++ MeberEvent called member{} is joining", ev.member());
			}
			if (ms == MemberStatus.up()) {
				logger.info("++ MeberEvent called member{} is up", ev.member());
			}
			if (ms == MemberStatus.down()) {
				logger.info("++ MeberEvent called member{} is down", ev.member());
			}
			if (ms == MemberStatus.removed()) {
				logger.info("++ MeberEvent called member{} is removed", ev.member());
			}
			if (ms == MemberStatus.leaving()) {
				logger.info("++ MeberEvent called member{} is leaving", ev.member());
			}
			if (ms == MemberStatus.exiting()) {
				logger.info("++ MemberEvent called member{}; is exiting", ev.member());
			}
		}
		// else if(msg instanceof AssociatedEvent) {
		// AssociatedEvent ev = (AssociatedEvent)msg;
		// String event = ev.eventName();
		// Address localAddr = ev.getLocalAddress();
		// Address remoteAddr = ev.getRemoteAddress();
		//
		// logger.info("++ AssociatedEvent called event = {}, local address {}, remote address {}",
		// event, localAddr, remoteAddr);
		//
		// }
		else {
			this.unhandled(msg);
		}
	}

	private void registerWorkerNode(Address workerAddress) {

		this.logger.debug("+++ createNode() called");

		/*
		 * 새롭게 AKKA에 등록된 Member의 Ip address, port 정보 획득
		 */
		// Address = akka.tcp://WatzEyeVAS@10.250.46.50:1111, ==>
		// user/faceDetectionService는 없음에 주의
		Address addr = workerAddress;
		// addrnport = WatzEyeVAS@10.250.46.50:1111
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_FR_NODE table의 node 상태 정보를 이전 상태에 관계 없이 초기화
		 */
		// 해당 node의 현재 정보를 읽어 온다
		Node nodeFromDB = routingProcessor.getNodeInfo(address, port);
		if (nodeFromDB == null) {
			logger.debug("++ [MemberUP process]current node[{}:{}] is new one and No data in DB", address, port);

		} else {
			logger.debug("++ [MemberUP process]current node[{}] already exists in DB", nodeFromDB);
		}

		if (nodeFromDB == null) {

			// VAS_FR_NODE table에 해당 node가 없으면 새로운 node를 만들고 초기화한다
			logger.debug("++ [MemberUP process]make new node in DB ");
			boolean ret = routingProcessor.makeNewNode(address, port);
			if (ret == false) {
				logger.error("++ [MemberUP process] fail to insert node data in VAS_FR_NODE, "
						+ "because there is no related-Node info in VAS_NODE where IP = [{}], Port = [{}] !!!"
						+ "Please, check VAS_NODE table", address, port);
				return;
			}

			// 해당 node 정보를 VAS_FR_NODE에서 가져온다
			nodeFromDB = routingProcessor.getNodeInfo(address, port);

			/*
			 * VAS_FR_CCTV table에서 해당 Node id에 할당된 cctv id를 clear
			 */
			logger.debug("++ [MemberUP process]Making new node is done. And clear CctvList : node id = {} from DB",
					nodeFromDB.getNodeId());
			routingProcessor.clearCctvList(nodeFromDB.getNodeId());

			return;

		}

		String role = nodeFromDB.getRole();
		String nodeStatus = nodeFromDB.getNodeStatus();
		String nodeClass = nodeFromDB.getNodeClass();

		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_ACTIVE)) {
			/*
			 * Active 상태이면, 아무것도 하지 않는다 worker node는 정상이지만 master node만 down되었다가
			 * 재 기동되었기 때문임
			 */
			logger.debug("++ [MemberUP process]Member is up but node's role is [active]."
					+ " So remain cctv list from DB : node id = [{}] ", nodeFromDB.getNodeId());

		}

		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)) {
			/*
			 * Standby 상태이면, VAS_FR_NODE_CCTV table에서 해당 Node id에 할당된 cctv id를
			 * clear
			 */
			logger.debug("++ [MemberUP process]Member is up but node's role is [standby]. "
					+ "So clear CctvList from DB : node id = [{}]", nodeFromDB.getNodeId());
			routingProcessor.clearCctvList(nodeFromDB.getNodeId());
		}

		// VAS_FR_NODE에 해당 node가 기 존재하고 node.role이 "na"이면 node 정보를 초기화한다
		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_NA)) {

			logger.debug("++ [MemberUP process]Node role = 'na'. So reset current node in DB = {} ", nodeFromDB);

			if (nodeStatus.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED)) {
				// 죽기 전의 node class를 유지
				routingProcessor.resetNode(address, port, nodeClass);
			} else {
				// 이미 failover 되었으나 class를 initial로 초기화하지 않고 자신의 class를 유지한다. 초기
				// 설정된 live와 ondemand group을 유지하기 위함
				routingProcessor.resetNode(address, port, nodeClass);
			}

			/*
			 * Fail-over가 안 된 node이면 cctv clear하지 않는다
			 */
			if (supportAutoActive && nodeStatus.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED)) {

				List<Cctv> cctvList = routingProcessor.getCctvList(nodeFromDB.getNodeId());
				if (cctvList == null) {
					logger.info("++ [MemberUP process]supportAutoActive is true but cctv list[Node id =[{}]] is null",
							nodeFromDB.getNodeId());
					return;
				}

				if (cctvList.size() == 0) {
					logger.info("++ [MemberUP process]supportAutoActive is true but cctv list[Node id =[{}]] is 0",
							nodeFromDB.getNodeId());
					return;
				}

				// cctv의 status 컬럼 상태를 본 후 죽기전의 cctv 상태가 started or stop이면
				// worker node에 메시지 전송
				String cctvStatus = cctvList.get(0).getStatus();

				if (cctvStatus == null) {
					/*
					 * VAS_FR_NODE_CCTV table에서 해당 Node id에 할당된 cctv id를 clear
					 */
					logger.debug("++ [MemberUP process]Node's rols is changed [NA] into [Standby]."
							+ " And clear CctvList : node id = [{}] from DB", nodeFromDB.getNodeId());
					routingProcessor.clearCctvList(nodeFromDB.getNodeId());
					return;
				}

				if (cctvStatus.equalsIgnoreCase(Cctv.CCTV_STATUS_STARTED)
						|| cctvStatus.equalsIgnoreCase(Cctv.CCTV_STATUS_STOPPED)
						|| cctvStatus.equalsIgnoreCase(Cctv.CCTV_STATUS_START_FAILED)) {

					boolean ret = addRouteesForMember(nodeFromDB.getNodeId());
					if (ret == false) {
						logger.warning("++ [MemberUP process]addRoutessForMember() is failed."
								+ " so node id = [{}] start message can't go !!", nodeFromDB.getNodeId());
						return;
					}

					if (cctvStatus.equalsIgnoreCase(Cctv.CCTV_STATUS_STARTED)
							|| cctvStatus.equalsIgnoreCase(Cctv.CCTV_STATUS_START_FAILED)) {
						// Boolean.TRUE means "start worker node"
						List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(nodeFromDB.getNodeId(),
								Boolean.TRUE);
						for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
							this.router.route(km, this.getSender());
						}
						// update Node of VAS_FR_NODE table
						updateNodeStatus(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START);
						logger.debug("++ [MemberUP process]supportAutoActive is true. So [removed] node chagned into"
								+ " [active] Node(Id =[{}]) [Start] command goes to worker node",
								nodeFromDB.getNodeId());
					} else {
						// Boolean.FALSE means "stop worker node"
						// List<KeyedMessage<Cctv, Boolean>> keyedMessageList =
						// createKeyedMessage(nodeFromDB.getNodeId(),
						// Boolean.FALSE);
						/*
						 * INCON SDK 버그로 인한 임시 코드 INCON SDK가 관심인물 추가시 stopLive
						 * 시도할 때 죽으므로, cctv 상태가 stop이어도 강제로 start 해 주자
						 */
						List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(nodeFromDB.getNodeId(),
								Boolean.TRUE);

						for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
							this.router.route(km, this.getSender());
						}
						// update Node of VAS_FR_NODE table
						// updateNodeStatus(nodeFromDB.getNodeId(),
						// NodeMessage.NodeMessageCode.NM_NODE_STOP);
						// logger.debug("++ supportAutoActive is true. So removed node chagned into active Node(Id =[{}])."
						// +
						// " [Stop] command goes to worker node",nodeFromDB.getNodeId());

						/*
						 * INCON SDK 버그로 인한 임시 코드 INCON SDK가 관심인물 추가시 stopLive
						 * 시도할 때 죽으므로, cctv 상태가 stop이어도 강제로 start 해 주자
						 */
						updateNodeStatus(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START);
						logger.debug(
								"++ [MemberUP process]supportAutoActive is true. So [removed] node chagned into [active]"
										+ " Node(Id =[{}])."
										+ "[Start] command(even if CCTV status is [stop]) goes to worker node",
										nodeFromDB.getNodeId());

					}

				} else {
					// cctv status가 initial이므로 node 상태만 active로 변경한다
					// update Node of VAS_FR_NODE table
					updateNodeStatus(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_STOP);
					logger.debug(
							"++ [MemberUP process]supportAutoActive is true but cctv status is [stopped] or [initial]. "
									+ "So chagned into active Node(Id =[{}])."
									+ " Any command doesn't go to worker node", nodeFromDB.getNodeId());
				}

			} else {
				/*
				 * VAS_FR_NODE_CCTV table에서 해당 Node id에 할당된 cctv id를 clear
				 */
				logger.debug("++ [MemberUP process]Node's rols is changed [NA] into [Standby]. And clear CctvList :"
						+ " node id = {} from DB", nodeFromDB.getNodeId());
				routingProcessor.clearCctvList(nodeFromDB.getNodeId());
			}

		}

		logger.debug("++ end of createNode ");

	}

	private void startFailoverNodeAndUpdateForLive(Node deletedNode, int failoverNodeId) {
		/*
		 * down된 node가 start 상태인 경우 start 상태로 전송
		 */
		if (deletedNode.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {
			logger.debug("++ [Removed process]Node [start] command goes to failover node Id[{}]. Removed process ends",
					failoverNodeId);
			// Boolean.TRUE means "start worker node"
			List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(failoverNodeId, Boolean.TRUE);
			for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
				this.router.route(km, this.getSender());
			}

			// update Node in VAS_FR_NODE table
			updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_START,
					Node.NodeClass.NODE_CLASS_LIVE);
			updateNodeStatusWithNodeClass(deletedNode.getNodeId(),
					NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER, Node.NodeClass.NODE_CLASS_LIVE);

		}
		/*
		 * down된 node가 stop 상태인 경우 stop 상태로 전송
		 */
		if (deletedNode.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STOPPED)) {
			logger.debug("++ [Removed process]Node [stop] command goes to failover node Id[{}]. Removed process ends",
					failoverNodeId);
			// Boolean.TRUE means "stop worker node"
			List<KeyedMessage<Cctv, Boolean>> keyedMessageList = createKeyedMessage(failoverNodeId, Boolean.FALSE);
			for (KeyedMessage<Cctv, Boolean> km : keyedMessageList) {
				this.router.route(km, this.getSender());
			}

			// update Node in VAS_FR_NODE table
			updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_STOP,
					Node.NodeClass.NODE_CLASS_LIVE);
			updateNodeStatusWithNodeClass(deletedNode.getNodeId(),
					NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER, Node.NodeClass.NODE_CLASS_LIVE);

		}

	}

	private void updateJobStatus(int deletedNodeId) {

		/*
		 * VAS_FR_NODE_ONDEMAND_DB, _VMS, _VIDEO table에서 deletedNode id에 해당되는
		 * ondemand job이 있는지 확인
		 */
		OndemandDBSubJobVO dbSubJobVO = null;
		OndemandVMSSubJobVO vmsSubJobVO = null;
		OndemandVideoSubJobVO videoSubJobVO = null;

		dbSubJobVO = routingProcessor.getOngoingDBSubJob(deletedNodeId);
		vmsSubJobVO = routingProcessor.getOngoingVMSSubJob(deletedNodeId);
		videoSubJobVO = routingProcessor.getOngoingVideoSubJob(deletedNodeId);
		if (dbSubJobVO != null) {
			// deleted node의 VAS_FR_ONDEMAND_DB table에 job 실패를 기록한다
			storeDBSubJobFailedState(deletedNodeId, dbSubJobVO.getJobId());

			boolean allNodeCompleted = isOndemandJobofAllNodeCompleted(dbSubJobVO.getJobId(),
					OndemandJobConstant.JobType.DBJOB);
			if (allNodeCompleted) {
				// update VAS_JOB_MASTER table에 job 실패를 기록한다
				updateJobMaster(dbSubJobVO.getJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
			}
		}
		if (vmsSubJobVO != null) {
			// deleted node의 VAS_FR_ONDEMAND_VMS table에 job 실패를 기록한다
			storeVMSSubJobFailedState(deletedNodeId, vmsSubJobVO.getJobId());

			boolean allNodeCompleted = isOndemandJobofAllNodeCompleted(vmsSubJobVO.getJobId(),
					OndemandJobConstant.JobType.VMSJOB);
			if (allNodeCompleted) {
				// update VAS_JOB_MASTER table에 job 실패를 기록한다
				updateJobMaster(vmsSubJobVO.getJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
			}

		}
		if (videoSubJobVO != null) {
			// deleted node의 VAS_FR_ONDEMAND_VIDEO table에 job 실패를 기록한다
			storeVideoSubJobFailedState(deletedNodeId, videoSubJobVO.getJobId());

			boolean allNodeCompleted = isOndemandJobofAllNodeCompleted(videoSubJobVO.getJobId(),
					OndemandJobConstant.JobType.VIDEOJOB);
			if (allNodeCompleted) {
				// update VAS_JOB_MASTER table에 job 실패를 기록한다
				updateJobMaster(vmsSubJobVO.getJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
			}
		}

	}

	private void startFailoverNodeAndUpdateForOndemand(Node deletedNode, int failoverNodeId) {

		boolean existStanbyNode = false;
		Node failoverNode = null;
		if (failoverNodeId > 0) {
			existStanbyNode = true;
			failoverNode = routingProcessor.getNodeInfoById(failoverNodeId);
		}

		// Interger ==> DBJOB, VMSJOB, VIDEOJOB
		// Node ==> null or available node
		HashMap<Integer, Node> avaliableNodes = new HashMap<Integer, Node>();

		/*
		 * VAS_FR_NODE_ONDEMAND_DB, _VMS, _VIDEO table에서 deletedNode id에 해당되는
		 * ondemand job이 있는지 확인
		 */
		OndemandDBSubJobVO dbSubJobVO = null;
		OndemandVMSSubJobVO vmsSubJobVO = null;
		OndemandVideoSubJobVO videoSubJobVO = null;

		dbSubJobVO = routingProcessor.getOngoingDBSubJob(deletedNode.getNodeId());
		vmsSubJobVO = routingProcessor.getOngoingVMSSubJob(deletedNode.getNodeId());
		videoSubJobVO = routingProcessor.getOngoingVideoSubJob(deletedNode.getNodeId());

		int ondemandJobType = OndemandJobConstant.JobType.NOT_DEFINED;

		if (dbSubJobVO != null) {
			ondemandJobType |= OndemandJobConstant.JobType.DBJOB;
			if (existStanbyNode) {
				avaliableNodes.put(OndemandJobConstant.JobType.DBJOB, failoverNode);
			} else {
				List<Integer> numOfStandbyNodeIds = routingProcessor.selectNumOfOndemandDBStanbyNode();
				if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
					avaliableNodes.put(OndemandJobConstant.JobType.DBJOB, null);
				} else {
					Node availableNode = routingProcessor.getNodeInfoById(numOfStandbyNodeIds.get(0));
					avaliableNodes.put(OndemandJobConstant.JobType.DBJOB, availableNode);
				}
			}
		}
		if (vmsSubJobVO != null) {
			ondemandJobType |= OndemandJobConstant.JobType.VMSJOB;
			if (existStanbyNode) {
				avaliableNodes.put(OndemandJobConstant.JobType.VMSJOB, failoverNode);
			} else {
				List<Integer> numOfStandbyNodeIds = routingProcessor.selectNumOfOndemandVMSStanbyNode();
				if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
					avaliableNodes.put(OndemandJobConstant.JobType.VMSJOB, null);
				} else {
					Node availableNode = routingProcessor.getNodeInfoById(numOfStandbyNodeIds.get(0));
					avaliableNodes.put(OndemandJobConstant.JobType.VMSJOB, availableNode);
				}

			}
		}
		if (videoSubJobVO != null) {
			ondemandJobType |= OndemandJobConstant.JobType.VIDEOJOB;
			if (existStanbyNode) {
				avaliableNodes.put(OndemandJobConstant.JobType.VIDEOJOB, failoverNode);
			} else {
				List<Integer> numOfStandbyNodeIds = routingProcessor.selectNumOfOndemandVideoStanbyNode();
				if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
					avaliableNodes.put(OndemandJobConstant.JobType.VIDEOJOB, null);
				} else {
					Node availableNode = routingProcessor.getNodeInfoById(numOfStandbyNodeIds.get(0));
					avaliableNodes.put(OndemandJobConstant.JobType.VIDEOJOB, availableNode);
				}

			}
		}

		logger.info("++ [Removed process: ondemand] deleted node[Node Id = {}] ongoing job type = [{}]",
				deletedNode.getNodeId(), OndemandJobConstant.JobType.getJobName(ondemandJobType));
		String log = "++ [Removed process: ondemand] failover node info: ";
		if (OndemandJobConstant.JobType.isDBJob(ondemandJobType)) {
			Node dbNode = avaliableNodes.get(OndemandJobConstant.JobType.DBJOB);
			if (dbNode == null) {
				log += "(DB Job, Node[no available node]) ";
			} else {
				log += "(DB Job, Node[ " + dbNode.getNodeId() + "]) ";
			}
		}
		if (OndemandJobConstant.JobType.isVMSJob(ondemandJobType)) {
			Node vmsNode = avaliableNodes.get(OndemandJobConstant.JobType.VMSJOB);
			if (vmsNode == null) {
				log += "(VMS Job, Node[no available node]) ";
			} else {
				log += "(VMS Job, Node[ " + vmsNode.getNodeId() + "]) ";
			}
		}
		if (OndemandJobConstant.JobType.isVideoJob(ondemandJobType)) {
			Node videoNode = avaliableNodes.get(OndemandJobConstant.JobType.VIDEOJOB);
			if (videoNode == null) {
				log += "(Video Job, Node[no available node]) ";
			} else {
				log += "(Video Job, Node[ " + videoNode.getNodeId() + "]) ";
			}
		}
		logger.info("{}", log);

		/*
		 * OndemandDBSubJob
		 */
		if (OndemandJobConstant.JobType.isDBJob(ondemandJobType)) {

			// OndemandDBSubJob을 생성한다
			Map<String, byte[]> concernFaces = routingProcessor.getFeatures(dbSubJobVO.getJobId());
			OndemandDBSubJob dbSubJob = ConversionBetweenSubJobAndVO.convert(dbSubJobVO, concernFaces);

			// MasterToWorkerMessage를 생성한다
			Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.DBJOB);
			if (availableNode != null) {
				MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(dbSubJob, availableNode.getNodeId());

				// failover node에 메시지 전송한다
				sendWorkerMessageWithoutRouterOndemand(mtw, availableNode);

				// failover node에 해당되는 VAS_FR_ONDEMAND_DB table subjob 정보를 기록한다
				storeSubJob(mtw, availableNode, dbSubJobVO.getJobId());

				// deleted node의 VAS_FR_ONDEMAND_DB table subjob 정보를 삭제한다
				routingProcessor.deleteDBSubJob(deletedNode.getNodeId(), dbSubJobVO.getJobId());
			} else {
				// deleted node의 VAS_FR_ONDEMAND_DB table에 job 실패를 기록한다
				storeDBSubJobFailedState(deletedNode.getNodeId(), dbSubJobVO.getJobId());
			}

		}

		/*
		 * OndemandVMSSubJob
		 */
		if (OndemandJobConstant.JobType.isVMSJob(ondemandJobType)) {

			// OndemandVMSSubJob을 생성한다
			HashMap<String, byte[]> concernFaces = routingProcessor.getFeatures(vmsSubJobVO.getJobId());
			OndemandVMSSubJob vmsSubJob = ConversionBetweenSubJobAndVO.convert(vmsSubJobVO, concernFaces);

			// MasterToWorkerMessage를 생성한다
			Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.VMSJOB);
			if (availableNode != null) {
				MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(vmsSubJob, availableNode.getNodeId());

				// failover node에 메시지 전송한다
				sendWorkerMessageWithoutRouterOndemand(mtw, availableNode);

				// failover node에 해당되는 VAS_FR_ONDEMAND_VMS table subjob 정보를 기록한다
				storeSubJob(mtw, availableNode, vmsSubJobVO.getJobId());

				// deleted node의 VAS_FR_ONDEMAND_DB table subjob 정보를 삭제한다
				routingProcessor.deleteVMSSubJob(deletedNode.getNodeId(), vmsSubJobVO.getJobId());
			} else {
				// deleted node의 VAS_FR_ONDEMAND_VMS table에 job 실패를 기록한다
				storeVMSSubJobFailedState(deletedNode.getNodeId(), vmsSubJobVO.getJobId());
			}

		}

		/*
		 * OndemandVideoSubJob
		 */
		if (OndemandJobConstant.JobType.isVideoJob(ondemandJobType)) {
			// OndemandVideoSubJob을 생성한다
			HashMap<String, byte[]> concernFaces = routingProcessor.getFeatures(videoSubJobVO.getJobId());
			OndemandVideoSubJob videoSubJob = ConversionBetweenSubJobAndVO.convert(videoSubJobVO, concernFaces,
					routingProcessor);

			// MasterToWorkerMessage를 생성한다
			Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.VIDEOJOB);
			if (availableNode != null) {
				MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(videoSubJob, availableNode.getNodeId());

				// failover node에 메시지 전송한다
				sendWorkerMessageWithoutRouterOndemand(mtw, availableNode);

				// failover node에 해당되는 VAS_FR_ONDEMAND_DB table subjob 정보를 기록한다
				storeSubJob(mtw, availableNode, videoSubJobVO.getJobId());

				// deleted node의 VAS_FR_ONDEMAND_DB table subjob 정보를 삭제한다
				routingProcessor.deleteVideoSubJob(deletedNode.getNodeId(), videoSubJobVO.getJobId());
			} else {
				// deleted node의 VAS_FR_ONDEMAND_Video table에 job 실패를 기록한다
				storeVideoSubJobFailedState(deletedNode.getNodeId(), videoSubJobVO.getJobId());
			}

		}

		/*
		 * deleted node 상태를 변경한다
		 */
		boolean noAvaiableNode = true;
		for (int jobType : avaliableNodes.keySet()) {
			Node node = avaliableNodes.get(jobType);
			if (node != null) {
				noAvaiableNode = false;
				break;
			}
		}

		if (noAvaiableNode) {
			updateNodeStatus(deletedNode.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_REMOVED);
			logger.info("++ [Removed process: ondemand] deleted node[{}] updated into [REMOVED] in " + "VAS_FR_NODE",
					deletedNode.getNodeId());
		} else {
			updateNodeStatus(deletedNode.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER);
			logger.info("++ [Removed process: ondemand] deleted node[{}] updated into [REMOVED_FAILOVER] in "
					+ "VAS_FR_NODE", deletedNode.getNodeId());
		}

		/*
		 * fail-over node 상태를 변경한다
		 */
		if (ondemandJobType != OndemandJobConstant.JobType.NOT_DEFINED) {
			if (existStanbyNode) {
				updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_START,
						Node.NodeClass.NODE_CLASS_ONDEMAND);
			} else {
				if (OndemandJobConstant.JobType.isDBJob(ondemandJobType)) {
					Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.DBJOB);
					if (availableNode != null) {
						updateNodeStatusWithNodeClass(availableNode.getNodeId(),
								NodeMessage.NodeMessageCode.NM_NODE_START, Node.NodeClass.NODE_CLASS_ONDEMAND);
					}
				}
				if (OndemandJobConstant.JobType.isVMSJob(ondemandJobType)) {
					Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.VMSJOB);
					if (availableNode != null) {
						updateNodeStatusWithNodeClass(availableNode.getNodeId(),
								NodeMessage.NodeMessageCode.NM_NODE_START, Node.NodeClass.NODE_CLASS_ONDEMAND);
					}

				}
				if (OndemandJobConstant.JobType.isVideoJob(ondemandJobType)) {
					Node availableNode = avaliableNodes.get(OndemandJobConstant.JobType.VIDEOJOB);
					if (availableNode != null) {
						updateNodeStatusWithNodeClass(availableNode.getNodeId(),
								NodeMessage.NodeMessageCode.NM_NODE_START, Node.NodeClass.NODE_CLASS_ONDEMAND);
					}
				}
			}
		}

	}

	private void storeDBSubJobFailedState(int nodeId, String jobId) {

		List<Integer> totalThreads = routingProcessor.checkDBSubJobThread(nodeId, jobId);
		if (totalThreads == null) {
			logger.warning("++ [Removed process: DB Job] Job Id = [{}], Node Id = [{}] "
					+ "There is no node info in VAS_FR_NODE_ONDEMNAD_DB table", jobId, nodeId);
			return;
		}
		int totalStartThread = totalThreads.get(0);

		// totalCompletedThread 수를 start 수와 동일하게 맞춘다
		routingProcessor.updateOndemandDBCompletedThread(nodeId, jobId, totalStartThread);

		// job 결과를 error로 기록한다
		routingProcessor
		.updateOndemandDBSubJobUpdate(nodeId, jobId, OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);

	}

	private void storeVMSSubJobFailedState(int nodeId, String jobId) {

		List<Integer> totalThreads = routingProcessor.checkVMSSubJobThread(nodeId, jobId);
		if (totalThreads == null) {
			logger.warning("++ [Removed process: VMS Job] Job Id = [{}], Node Id = [{}] "
					+ "There is no node info in VAS_FR_NODE_ONDEMNAD_VMS table", jobId, nodeId);
			return;
		}
		int totalStartThread = totalThreads.get(0);

		// totalCompletedThread 수를 start 수와 동일하게 맞춘다
		routingProcessor.updateOndemandVMSCompletedThread(nodeId, jobId, totalStartThread);

		// job 결과를 error로 기록한다
		routingProcessor.updateOndemandVMSSubJobUpdate(nodeId, jobId,
				OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);

	}

	private void storeVideoSubJobFailedState(int nodeId, String jobId) {

		List<Integer> totalThreads = routingProcessor.checkVideoSubJobThread(nodeId, jobId);
		if (totalThreads == null) {
			logger.warning("++ [Removed process: Video Job] Job Id = [{}], Node Id = [{}] "
					+ "There is no node info in VAS_FR_NODE_ONDEMNAD_VIDEO table", jobId, nodeId);
			return;
		}
		int totalStartThread = totalThreads.get(0);

		// totalCompletedThread 수를 start 수와 동일하게 맞춘다
		routingProcessor.updateOndemandVideoCompletedThread(nodeId, jobId, totalStartThread);

		// job 결과를 error로 기록한다
		routingProcessor.updateOndemandVideoSubJobUpdate(nodeId, jobId,
				OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);

	}

	private void processOndemandResponse(ActorStatusMessage asm, Node responseNode) {

		if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS
				|| asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED) {

			boolean ret = isOndemandJobofAllNodeCompleted(asm.getOndemandJobId(), asm.getOndemandJobType());
			if (ret) {
				logger.info("++ [Ondemand process] all nodes finished the job, Job Id = [{}], Job type = [{}]",
						asm.getOndemandJobId(), OndemandJobConstant.JobType.getJobName(asm.getOndemandJobType()));
				// update Node of the dynamic routing map
				updateNodeStatusWithNodeClass(responseNode.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
						Node.NodeClass.NODE_CLASS_ONDEMAND);

				// update job master
				boolean isOndemandJobSuccessful = getOndemandJobStatusFromAllNodes(asm.getOndemandJobId(),
						asm.getOndemandJobType());
				if (isOndemandJobSuccessful)
					updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED);
				else
					updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
			} else {
				logger.info("++ [Ondemand process] Job Id = [{}] Job Type = [{}], all nodes don't finish the job."
						+ " Nothing to do", asm.getOndemandJobId(),
						OndemandJobConstant.JobType.getJobName(asm.getOndemandJobType()));
			}
		}

		if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS) {

			boolean ret = isOndemandJobofAllNodeCompleted(asm.getOndemandJobId(), asm.getOndemandJobType());
			if (ret) {
				logger.info("++ [Ondemand process] all nodes aborted the job, Job Id = [{}], Job type = [{}]",
						asm.getOndemandJobId(), OndemandJobConstant.JobType.getJobName(asm.getOndemandJobType()));

				// update Node of the dynamic routing map
				updateNodeStatusWithNodeClass(responseNode.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
						Node.NodeClass.NODE_CLASS_ONDEMAND);

				// update job master
				updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED);
			} else {
				logger.info("++ [Ondemand process] Job Id = [{}] Job Type = [{}], all nodes don't abort the job."
						+ " Nothing to do", asm.getOndemandJobId(),
						OndemandJobConstant.JobType.getJobName(asm.getOndemandJobType()));
			}
		}

	}

	private void processOndemandResponse(ActorStatusMessage asm, int responseNodeId) {

		if (asm.getOndemandJobType() == OndemandJobConstant.JobType.DBJOB) {
			OndemandDBSubJobVO dbSubJobVO = null;
			if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS) {
				dbSubJobVO = ConversionBetweenSubJobAndVO.updateDBSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.STARTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandDBSubJobUpdateWithThread(dbSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED) {
				dbSubJobVO = ConversionBetweenSubJobAndVO.updateDBSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.START_FAILED,
						asm.getOndemandTotalThread());

				routingProcessor.updateOndemandDBSubJobUpdateWithThread(dbSubJobVO);

				// VAS_FRS_NODE의 상태 변경
				boolean jobRemainded = isRemainedAnotherJobinNode(responseNodeId);
				if (jobRemainded == false) {
					updateNodeStatusWithNodeClass(responseNodeId, NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
					logger.info("++ [ActorStatus process] Ondemand Job [{}] in node [{}] failed to start. and there"
							+ "is no Ondemand Job. So Node role changed into [standby]", asm, responseNodeId);
				}

				boolean allNodeStartFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.DBJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.START_FAILED);
				if (allNodeStartFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
					logger.error("++ [ActorStatus process] Ondemand job [{}] in all nodes failed to start. So"
							+ "VAS_JOB_MASTER updated [completed_with_error]", asm);
				}
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS) {
				dbSubJobVO = ConversionBetweenSubJobAndVO.updateDBSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandDBSubJobUpdateWithThread(dbSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED) {
				dbSubJobVO = ConversionBetweenSubJobAndVO.updateDBSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROT_FAILED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandDBSubJobUpdateWithThread(dbSubJobVO);

				boolean allNodeAbortedFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.DBJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.ABROT_FAILED);

				if (allNodeAbortedFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(),
							OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED_WITH_ERROR);
				}
			}

		}

		if (asm.getOndemandJobType() == OndemandJobConstant.JobType.VMSJOB) {
			OndemandVMSSubJobVO vmsSubJobVO = null;
			if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS) {
				vmsSubJobVO = ConversionBetweenSubJobAndVO.updateVMSSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.STARTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVMSSubJobUpdateWithThread(vmsSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED) {
				vmsSubJobVO = ConversionBetweenSubJobAndVO.updateVMSSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.START_FAILED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVMSSubJobUpdateWithThread(vmsSubJobVO);

				// VAS_FRS_NODE의 상태 변경
				boolean jobRemainded = isRemainedAnotherJobinNode(responseNodeId);
				if (jobRemainded == false) {
					updateNodeStatusWithNodeClass(responseNodeId, NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
					logger.info("++ [ActorStatus process] Ondemand Job [{}] in node [{}] failed to start. and there"
							+ "is no Ondemand Job. So Node role changed into [standby]", asm, responseNodeId);
				}

				boolean allNodeStartFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.VMSJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.START_FAILED);
				if (allNodeStartFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
					logger.error("++ [ActorStatus process] Ondemand job [{}] in all nodes failed to start. So"
							+ "VAS_JOB_MASTER updated [completed_with_error]", asm);
				}
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS) {
				vmsSubJobVO = ConversionBetweenSubJobAndVO.updateVMSSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVMSSubJobUpdateWithThread(vmsSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED) {
				vmsSubJobVO = ConversionBetweenSubJobAndVO.updateVMSSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROT_FAILED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVMSSubJobUpdateWithThread(vmsSubJobVO);

				// VAS_FRS_NODE의 상태 변경
				boolean jobRemainded = isRemainedAnotherJobinNode(responseNodeId);
				if (jobRemainded == false) {
					updateNodeStatusWithNodeClass(responseNodeId, NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
				}

				boolean allNodeAbortedFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.VMSJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.ABROT_FAILED);

				if (allNodeAbortedFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(),
							OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED_WITH_ERROR);
				}
			}

		}

		if (asm.getOndemandJobType() == OndemandJobConstant.JobType.VIDEOJOB) {
			OndemandVideoSubJobVO videoSubJobVO = null;
			if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS) {
				videoSubJobVO = ConversionBetweenSubJobAndVO.updateVideoSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.STARTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVideoSubJobUpdateWithThread(videoSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED) {
				videoSubJobVO = ConversionBetweenSubJobAndVO.updateVideoSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.START_FAILED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVideoSubJobUpdateWithThread(videoSubJobVO);

				// VAS_FRS_NODE의 상태 변경
				boolean jobRemainded = isRemainedAnotherJobinNode(responseNodeId);
				if (jobRemainded == false) {
					updateNodeStatusWithNodeClass(responseNodeId, NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
					logger.info("++ [ActorStatus process] Ondemand Job [{}] in node [{}] failed to start. and there"
							+ "is no Ondemand Job. So Node role changed into [standby]", asm, responseNodeId);
				}

				boolean allNodeStartFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.VIDEOJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.START_FAILED);
				if (allNodeStartFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(), OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
					logger.error("++ [ActorStatus process] Ondemand job [{}] in all nodes failed to start. So"
							+ "VAS_JOB_MASTER updated [completed_with_error]", asm);
				}
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS) {
				videoSubJobVO = ConversionBetweenSubJobAndVO.updateVideoSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROTED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVideoSubJobUpdateWithThread(videoSubJobVO);
			} else if (asm.getMessageCode() == ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED) {
				videoSubJobVO = ConversionBetweenSubJobAndVO.updateVideoSubJob(responseNodeId, asm.getOndemandJobId(),
						BaseUtils.formatToYear2SecString(new Date()), OndemandJobConstant.JobStatus.ABROT_FAILED,
						asm.getOndemandTotalThread());
				routingProcessor.updateOndemandVideoSubJobUpdateWithThread(videoSubJobVO);

				// VAS_FRS_NODE의 상태 변경
				boolean jobRemainded = isRemainedAnotherJobinNode(responseNodeId);
				if (jobRemainded == false) {
					updateNodeStatusWithNodeClass(responseNodeId, NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
							Node.NodeClass.NODE_CLASS_ONDEMAND);
				}

				boolean allNodeAbortedFailed = checkAllNodeStartorAbortFailed(OndemandJobConstant.JobType.VIDEOJOB,
						asm.getOndemandJobId(), OndemandJobConstant.JobStatus.ABROT_FAILED);

				if (allNodeAbortedFailed) {
					// VAS_JOB_MASTER에 failed로 기록한다
					updateJobMaster(asm.getOndemandJobId(),
							OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED_WITH_ERROR);
				}
			}

		}

	}

	private boolean checkAllNodeStartorAbortFailed(int jobType, String jobId, String jobStatus) {

		boolean allNodeFailed = true;

		if (jobType == OndemandJobConstant.JobType.DBJOB) {
			List<OndemandDBSubJobVO> dbSubJobVOs = routingProcessor.getDBAllNodeSubJobThread(jobId);
			for (OndemandDBSubJobVO dbSubJobVO : dbSubJobVOs) {
				if (!dbSubJobVO.getJobStatus().equalsIgnoreCase(jobStatus)) {
					allNodeFailed = false;
					break;
				}
			}
		}

		if (jobType == OndemandJobConstant.JobType.VMSJOB) {
			List<OndemandVMSSubJobVO> vmsSubJobVOs = routingProcessor.getVMSAllNodeSubJobThread(jobId);
			for (OndemandVMSSubJobVO vmsSubJobVO : vmsSubJobVOs) {
				if (!vmsSubJobVO.getJobStatus().equalsIgnoreCase(jobStatus)) {
					allNodeFailed = false;
					break;
				}
			}
		}

		if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {
			List<OndemandVideoSubJobVO> videoSubJobVOs = routingProcessor.getVideoAllNodeSubJobThread(jobId);
			for (OndemandVideoSubJobVO videoSubJobVO : videoSubJobVOs) {
				if (!videoSubJobVO.getJobStatus().equalsIgnoreCase(jobStatus)) {
					allNodeFailed = false;
					break;
				}
			}
		}

		return allNodeFailed;

	}

	private boolean checkNodeStatus(String systemId, int nodeId) {

		logger.debug("++ checkNodeStatus called");

		/*
		 * VAS_FR_NODE table에서 현재 nodeId에 해당되는 정보를 읽어 온다
		 */
		Node node = routingProcessor.getNodeInfoById(nodeId);
		if (node == null) {
			this.logger.warning("++ There is Node data in VAS_FR_NODE table !!! node id = {} ", nodeId);
			return false;
		}

		/*
		 * 현재 VAS_NODE_SRVC에 설정된 node state가 동작 가능한 상태인지 확인
		 */
		if (StringUtils.equals(node.getRole(), Node.Role.NODE_ROLE_NA)) {
			this.logger.warning("++ Current node Role status = [not availiable]. "
					+ "so first restart worker node manually ! node = {}", node);
			return false;
		}
		if (StringUtils.equals(node.getNodeStatus(), Node.NodeStatus.NODE_STATUS_REMOVED)) {
			this.logger.warning("++ Current node status = [removed]. "
					+ "so first restart worker node manually ! node = {}", node);
			return false;
		}

		if (StringUtils.equals(node.getNodeStatus(), Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
			this.logger.warning("++ Current node status = [removed_failover]. "
					+ "so first restart worker node manually ! node = {}", node);
			return false;
		}
		if (StringUtils.equals(node.getRole(), Node.Role.NODE_ROLE_STANDBY)) {
			this.logger.warning("++ Current node Role status = [standby]. "
					+ "so first change worker role into active ! node = {}", node);
			return false;
		}

		if (!StringUtils.equals(node.getNodeClass(), Node.NodeClass.NODE_CLASS_LIVE)) {
			this.logger.warning("++ Current node class = [{}]. "
					+ "so first change worker class into [live] ! node = {}", node.getNodeClass(), node);
			return false;
		}

		/*
		 * 현재 VAS_FR_NODE에 설정된 node state와 UI 요청 state가 동일한지 확인 요청 상태가 동일해도 진행하는
		 * 것으로 바꿈. 따라서 주석 처리
		 */
		// if(nodeMessageCode == NodeMessage.NodeMessageCode.NM_NODE_START) {
		// if(StringUtils.equals(node.getNodeStatus(),Node.NodeStatus.NODE_STATUS_STARTED))
		// {
		// this.logger.warning("++ Node has already [start state]. Nothing to do! node = {}",
		// node);
		// return false;
		// }
		// }
		//
		// if(nodeMessageCode == NodeMessage.NodeMessageCode.NM_NODE_STOP) {
		// if(StringUtils.equals(node.getNodeStatus(),Node.NodeStatus.NODE_STATUS_STOPPED
		// )) {
		// this.logger.warning("++ Node has already [stop state]. Nothing to do! node = {}",
		// node);
		// return false;
		// }
		// }

		/*
		 * VAS_FR_NODE_CCTV table에서 현재 nodeId에 해당되는 CCTV list를 읽어 온다
		 */
		// logger.debug("++ checkNodeStatus: Get ccvt list from VAS_FR_NODE_CCTV table ");
		// List<Cctv> cctvList = routingProcessor.getCctvList(nodeId);
		// if(cctvList.size() == 0) {
		// this.logger.warning("++ There is no CCTV data in VAS_FR_NODE_CCTV table !!! node = {}, [UI] shoud be insert cctv list ",
		// node);
		// return false;
		// }
		//
		// for(Cctv cctv : cctvList) {
		// logger.debug("++ Node Id[{}] - cctv from DB = {}", nodeId,
		// cctv.toString());
		// }

		logger.debug("++ end of checkNodeStatus");

		return true;

	}

	private List<KeyedMessage<Cctv, Boolean>> createKeyedMessage(int nodeId, Boolean flag) {

		List<KeyedMessage<Cctv, Boolean>> kmList = new ArrayList<KeyedMessage<Cctv, Boolean>>();

		List<Cctv> cctvList = routingProcessor.getCctvList(nodeId);
		for (Cctv cctv : cctvList) {
			KeyedMessage<Cctv, Boolean> km = new KeyedMessage<Cctv, Boolean>(cctv, flag);
			kmList.add(km);
		}

		return kmList;
	}

	private KeyedMessage<Cctv, Boolean> createSingleKeyedMessage(int nodeId, String cctvId, String systemId,
			boolean flag) {

		Cctv cctv = routingProcessor.findCctvByCctvId(cctvId, systemId);
		if (cctv == null) {
			logger.error("++ There is no Cctv info in VAS_FR_NODE_CCTV table. Cctv id = [{}]", cctvId);
			return null;
		}

		KeyedMessage<Cctv, Boolean> km = new KeyedMessage<Cctv, Boolean>(cctv, flag);
		return km;
	}

	private void updateNodeStatus(int nodeId, int NodeMessageCode) {

		/*
		 * VAS_FR_NODE에서 node 정보를 읽어온다
		 */
		Node updatedNode = routingProcessor.getNodeInfoById(nodeId);
		if (updatedNode == null) {
			logger.error("++ there is no node to update Node status node id = {}", nodeId);
			return;
		}

		// node의 status를 변경
		switch (NodeMessageCode) {
			case NodeMessage.NodeMessageCode.NM_NODE_START :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STARTED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_STOP :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STOPPED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;
			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_INITIAL :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_INITIAL);
				// node의 role을 변경 --> standby로
				updatedNode.setRole(Node.Role.NODE_ROLE_STANDBY);
				break;
		}

		// node의 update time을 변경
		updatedNode.setUpdateTime(BaseUtils.formatToYear2SecString(new Date()));

		// VAS_FR_NODE_CCTV table은 변경하지 않음

		/*
		 * VAS_FR_NODE table의 node에 해당되는 정보를 update (worker node한테 start or stop
		 * message를 보냈으므로)
		 */
		routingProcessor.updateNode(updatedNode);

	}

	private void updateNodeStatusWithNodeClass(int nodeId, int NodeMessageCode, String nodeClass) {

		/*
		 * VAS_FR_NODE에서 node 정보를 읽어온다
		 */
		Node updatedNode = routingProcessor.getNodeInfoById(nodeId);
		if (updatedNode == null) {
			logger.error("++ there is no node to update Node status node id = {}", nodeId);
			return;
		}

		// node의 status를 변경
		switch (NodeMessageCode) {
			case NodeMessage.NodeMessageCode.NM_NODE_START :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STARTED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_STOP :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STOPPED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;
			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_INITIAL :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_INITIAL);
				// node의 role을 변경 --> standby로
				updatedNode.setRole(Node.Role.NODE_ROLE_STANDBY);
				break;
		}

		// node의 update time을 변경
		updatedNode.setUpdateTime(BaseUtils.formatToYear2SecString(new Date()));

		// node class 를 변경
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_LIVE)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_LIVE);
		}
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_ONDEMAND)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_ONDEMAND);
		}
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_INITAL)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_INITAL);
		}

		// VAS_FR_CCTV table은 변경하지 않음

		/*
		 * VAS_FR_NODE table의 node에 해당되는 정보를 update (worker node한테 start or stop
		 * message를 보냈으므로)
		 */
		routingProcessor.updateNode(updatedNode);

	}

	private void updateRouter() {
		MappedRouterConfig<T> factory = new MappedRouterConfig<T>(this.routees);

		int n1 = (this.router == null) ? 0 : ((scala.collection.SeqLike) this.router.routees()).size();
		this.router = factory.createRouter(this.getContext().system());
		int n2 = ((scala.collection.SeqLike) this.router.routees()).size();

		this.logger.info("++ Updated the router. The number of routee changed {} --> {}.", n1, n2);
		printRouteeList();
	}

	private boolean addRouteesForMember(int nodeId) {

		ActorSystem system = this.getContext().system();
		KeyedRoutee<T> routee = null;

		this.routeesLock.lock();

		/*
		 * VAS_FR_NODE table에서 node 정보를 가져온다
		 */
		Node node = routingProcessor.getNodeInfoById(nodeId);
		if (node == null) {
			logger.warning("++ there in no node in DB. So addRouteeForMember() fails");
			return false;
		}

		/*
		 * akka path를 생성한다
		 */
		// nodePath =
		// akka.tcp://WatzEyeVAS@10.250.46.50:2221/user/faceDetectionService
		String nodePath = new StringBuilder().append(AKKAProtocol).append(node.getIpAddress()).append(":")
				.append(node.getPort()).append("/user/").append(this.routeeName).toString();

		logger.info("++ newly added Worker Node Id[{}], path = {}", node.getNodeId(), nodePath);

		/*
		 * VAS_FR_NODE_CCTV table에서 cctv list를 가져온다
		 */
		List<Cctv> cctvList = routingProcessor.getCctvList(nodeId);
		if (cctvList == null) {
			this.logger.warning("++ cctv list is null. node id = {}", nodeId);
			return false;
		}
		if (cctvList.size() == 0) {
			this.logger.warning("++ There are no cctv list of the node id = {}", nodeId);
			return false;
		}

		/*
		 * 기존 routees에 이미 존재하는 cctv 정보를 삭제한다. 삭제하지 않으면 동일 cctv 정보가 계속해서 routees에
		 * 추가된다
		 */
		deleteExistingRoutees(cctvList);

		/*
		 * node에 할당된 cctv 수 만큼 KeyedActorSelectionRoutee를 생성
		 */
		for (Cctv cctv : cctvList) {
			// KeyedRoutee 하나를 생성
			logger.debug("++ addRouteesForMember: node Id: {}, Cctv = {}", nodeId, cctv);

			routee = new KeyedActorSelectionRoutee(cctv, system.actorSelection(nodePath));

			// List<KeyedRoutee<T>> routees에 KeyedActorSelectionRoutee를 하나 추가
			this.routees.add(routee);
		}

		printRouteeList();

		this.routeesLock.unlock();

		this.updateRouter();

		return true;
	}

	private Node changeNodeStatusAndgetOldStatus(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return null;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address addr = member.address();
		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_NODE_SRVC table의 node 상태 정보를 [removed]로 변경
		 */

		// 해당 node의 현재 정보를 읽어 온다
		Node node = routingProcessor.getNodeInfo(address, port);
		if (node == null) {
			// 해당 node가 없으면 예외상황으로 종료
			this.logger.warning("++ removed node = {} from AKKA doesn't have any information in VAS_FR_NODE table",
					addr.toString());
			return null;
		}

		// 다른 master node가 이미 removed-failover 한 상태인지 확인
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
			return null;
		}

		// 해당 node의 상태 정보를 removed로 변경한다
		updateNodeStatus(node.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_REMOVED);

		return node;

	}

	private void removeRouteesOfMember(int nodeId) {

		this.routeesLock.lock();
		Key<T> key = null;
		Cctv cctv = null;
		for (int i = this.routees.size() - 1; i > -1; i--) {
			key = this.routees.get(i).getKey();
			cctv = (Cctv) key.get();
			if (nodeId == cctv.getNodeId()) {
				this.routees.remove(i);
			}
		}

		this.routeesLock.unlock();

		this.updateRouter();
	}

	private int findFailoverNode(String nodeClass) {

		int error = -1;

		/*
		 * VAS_FR_NODE table에서 standby인 node를 찾는다
		 */
		List<Node> nodeList = routingProcessor.getNodeList();

		if (nodeList == null) {
			return error;
		}

		if (nodeList.size() == 0) {
			return error;
		}

		for (Node node : nodeList) {
			if (node.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)
					&& node.getNodeClass().equalsIgnoreCase(nodeClass)) {
				return node.getNodeId();
			}
		}
		return error;

	}

	private void setFailoverNodeCctvList(int deletedNodeId, int failoverNodeId) {

		/*
		 * VAS_FR_NODE_CCTV table에서 해당되는 node의 cctv list를 가져온다
		 */
		List<Cctv> deletedCctvList = routingProcessor.getCctvList(deletedNodeId);

		if (deletedCctvList == null) {
			logger.error("++ deleted node cctvlist is null, deleted node Id = {}", deletedNodeId);
			return;
		}

		if (deletedCctvList.size() == 0) {
			logger.error("++ deleted node doesn't have any cctv list, deleted node Id = {}", deletedNodeId);
			return;
		}

		/*
		 * fail-over node의 cctvList를 deleted node의 cctv list로 부터 만든다
		 */
		List<Cctv> failoverCctvList = new ArrayList<Cctv>();

		for (Cctv deletedCctv : deletedCctvList) {

			// deleted cctv 정보로 부터 fail-over Cctv 정보를 새롭게 생성한다
			Cctv failoverCctv = new Cctv();
			failoverCctv.setDefault(failoverNodeId, deletedCctv.getSystemId(), deletedCctv.getCctvId(),
					deletedCctv.getDevSeqNum());

			failoverCctvList.add(failoverCctv);
		}

		/*
		 * VAS_FR_CCTV table에서 deleted node의 cctv data를 삭제한다
		 */
		routingProcessor.clearCctvList(deletedNodeId);

		/*
		 * VAS_FR_CCTV table에 fail-over의 node cctv data를 저장한다
		 */
		// 일단 cctv data를 clear 한다
		routingProcessor.clearCctvList(failoverNodeId);

		// cctv data를 insert 한다
		routingProcessor.setCctvList(failoverCctvList);

	}

	private int findNodeId(String cctvId, String systemId) {
		int error = -1;
		Cctv cctv = routingProcessor.findCctvByCctvId(cctvId, systemId);
		if (cctv == null) {
			return error;
		} else {
			return cctv.getNodeId();
		}

	}

	private boolean checkNodeAvailable(int nodeId) {

		Node node = routingProcessor.getNodeInfoById(nodeId);
		String role = node.getRole();
		String status = node.getNodeStatus();

		boolean available = false;

		/*
		 * Node의 role이 active이고 Note의 상태가 initial, started, stopped인 경우에
		 * available 하다고 판단
		 */
		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_ACTIVE)) {
			if (status.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_INITIAL)
					|| status.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)
					|| status.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STOPPED)) {

				available = true;
			}
		}

		return available;
	}

	/*
	 * Member Up이 될 때 Master가 member up이 되는지 확인
	 */
	private boolean isMasterNode(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return true;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address addr = member.address();
		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		if (masterAddress.equals(address) && masterPort.equals(port)) {
			return true;
		}

		return false;
	}

	/*
	 * Member Up이 될 때 다른 쪽에 설치된 Master가 member up이 되는지 확인
	 */
	private boolean isAnotherMasterNode(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return true;
		}

		/*
		 * 다른 master node가 member up 되는 경우를 확인
		 */
		Set<String> roleSet = member.getRoles();
		for (String role : roleSet) {
			if (role.equalsIgnoreCase(MASTER_ROLE))
				return true;
		}

		return false;
	}

	private void deleteExistingRoutees(Cctv cctv) {

		Key<T> key = null;
		Cctv cctvInRoutees = null;
		logger.info("++ [delete existing routees] router size = [{}] ++++++++++++++++++++", this.routees.size());
		for (int i = 0; i < this.routees.size(); i++) {
			key = this.routees.get(i).getKey();
			cctvInRoutees = (Cctv) key.get();

			logger.info("++ routee -- [{}], Cctv = {}", i, cctvInRoutees.toString());

			if (cctvInRoutees.equals(cctv)) {
				logger.debug("++ same cctv is in routees, now this cctv removed from router. cctv = {},"
						+ " cctv from routees = {}", cctv, cctvInRoutees);
				routees.remove(i);
			}
		}

		logger.info("++ [delete existing routees]++  ++++++++++++++++++++");

		printRouteeList();

	}

	private void deleteExistingRoutees(List<Cctv> cctvList) {

		Key<T> key = null;
		Cctv cctvInRoutees = null;

		logger.debug("-- [delete existing routees] current router size = [{}]", this.routees.size());
		for (int i = this.routees.size() - 1; i > -1; i--) {
			key = this.routees.get(i).getKey();
			cctvInRoutees = (Cctv) key.get();

			// logger.debug("-- routee -- [{}], Cctv = {}", i,
			// cctvInRoutees.toString());

			for (Cctv cctv : cctvList) {

				if (cctvInRoutees.equals(cctv)) {
					// logger.debug("-- same cctv is in routees, now this cctv removed from router. cctv = {}, cctv from routees = {}",
					// cctv, cctvInRoutees);
					routees.remove(i);
				}
			}
		}

		// logger.debug("--------------------------");

		printRouteeList();

	}

	private void printRouteeList() {

		// Key<T> key = null;
		// Cctv cctv = null;
		// logger.info("-- [routee list information] router size = [{}] ---------",
		// this.routees.size());
		// for(int i = 0 ; i < this.routees.size(); i++ ){
		// key = this.routees.get(i).getKey();
		// cctv = (Cctv)key.get();
		// logger.info("++ routee -- [{}], Cctv = {}", i, cctv.toString() );
		// }
		// logger.info("-- [end of routee list information]----------------------------");

	}

	private void SendMasterUpNotification(Member masterMember) {

		// addr = akka.tcp://WatzEyeVAS@203.235.192.41:3333
		Address addr = masterMember.address();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSysemName = array[0];

		/*
		 * VAS_FR_NODE table에서 모든 node 정보를 가져온다
		 */
		List<Node> nodeList = routingProcessor.getNodeList();

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		List<String> nodePathList = new ArrayList<String>();
		String nodePath = null;
		if (nodeList.size() > 0) {
			for (Node node : nodeList) {
				if (node.getRole().equalsIgnoreCase("na"))
					continue;
				nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSysemName).append("@")
						.append(node.getIpAddress()).append(":").append(node.getPort()).append("/user/")
						.append(this.routeeName).toString();
				nodePathList.add(nodePath);
			}
		}

		/*
		 * Node role이 standby, active인 node에 master node member registration
		 * message를 전송한다
		 */
		ActorStatusMessage asMessage = new ActorStatusMessage(ActorStatusMessage.MASTER_NODE_REGISTRATION);
		asMessage.setMasterAddress(Cluster.get(getContext().system()).selfAddress());
		if (nodePathList.size() > 0) {
			for (String workerNodePath : nodePathList) {
				this.getContext().actorSelection(workerNodePath).tell(asMessage, getSelf());
				logger.info("++ Master node up messsage goes to worker node = {}", workerNodePath);
			}
		} else {
			logger.info("++ Master node up messsage doesn't go to worker node, because of none of active/standby node");
		}

	}

	private void SendWorkerMessageWithoutRouter(MasterToWorkerMessage msg) {

		Cluster cluster = Cluster.get(getContext().system());
		// addr = akka.tcp://WatzEyeVAS@203.235.192.41:3333
		Address addr = cluster.selfAddress();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSystemName = array[0];

		/*
		 * VAS_FR_NODE table에서 모든 node 정보를 가져온다
		 */
		List<Node> nodeList = routingProcessor.getNodeList();
		if (nodeList == null) {
			logger.warning("++ There in no node list. So message[{}] doesn't go to workers", msg);
			return;
		}

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		List<String> nodePathList = new ArrayList<String>();
		String nodePath = null;
		if (nodeList.size() > 0) {
			for (Node node : nodeList) {
				if (node.getRole().equalsIgnoreCase("na"))
					continue;
				// node 상태가 started 가 아닌 경우에는 node path list에서 제외한다
				if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {
					nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSystemName)
							.append("@").append(node.getIpAddress()).append(":").append(node.getPort())
							.append("/user/").append(this.routeeName).toString();
					nodePathList.add(nodePath);
				}
			}
		}

		/*
		 * Node role이 standby, active인 node에 message를 전송한다
		 */
		if (nodePathList.size() > 0) {
			for (String workerNodePath : nodePathList) {
				this.getContext().actorSelection(workerNodePath).tell(msg, getSelf());
				logger.info("++ Worker messsage(without router) = {} goes to worker node = {}", msg, workerNodePath);
			}
		} else {
			logger.info("++ Worker message(without router) can't go to worker node, because of none of active/standby node");
		}

	}

	private void SendWorkerMessageWithoutRouter(MasterToWorkerMessage msg, int nodeId) {

		Cluster cluster = Cluster.get(getContext().system());
		// addr = akka.tcp://WatzEyeVAS@203.235.192.41:3333
		Address addr = cluster.selfAddress();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSystemName = array[0];

		/*
		 * VAS_FR_NODE table에서 모든 node id에 해당되는 node 정보를 가져온다
		 */
		Node node = routingProcessor.getNodeInfoById(nodeId);
		if (node == null) {
			logger.warning("++ There in no node list. So message[{}] doesn't go to workers", msg);
			return;
		}

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		if (node.getRole().equalsIgnoreCase("na")) {
			logger.warning("++ Node[{}] role is 'na'. So message[{}] doesn't go to workers", node, msg);
			return;
		}

		/*
		 * Node status가 started인 경우만 해당 node로 메시지를 전송한다
		 */
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {

			String nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSystemName)
					.append("@").append(node.getIpAddress()).append(":").append(node.getPort()).append("/user/")
					.append(this.routeeName).toString();

			this.getContext().actorSelection(nodePath).tell(msg, getSelf());
			logger.info("++ Worker messsage(without router) = {} goes to worker node = {}", msg, nodePath);
		} else {
			logger.info("++ Worker messsage(without router) = {} doen't go to worker node"
					+ " because node status is not 'started', {}", msg, node);
		}

	}

	private void sendWorkerMessageWithoutRouterOndemand(MasterToWorkerMessage msg, Node node) {

		Cluster cluster = Cluster.get(getContext().system());
		// addr = akka.tcp://WatzEyeVAS@203.235.192.41:3333
		Address addr = cluster.selfAddress();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSystemName = array[0];

		if (node == null) {
			logger.warning("++ [Ondemand process] There in no node list. So message[{}] doesn't go to workers", msg);
			return;
		}

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		if (node.getRole().equalsIgnoreCase("na")) {
			logger.warning("++ [Ondemand process] Node[{}] role is 'na'. So message[{}] doesn't go to workers", node,
					msg);
			return;
		}

		/*
		 * Node status가 initial인 경우만 해당 node로 메시지를 전송한다
		 */
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_INITIAL)
				|| node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {

			String nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSystemName)
					.append("@").append(node.getIpAddress()).append(":").append(node.getPort()).append("/user/")
					.append(this.routeeName).toString();

			this.getContext().actorSelection(nodePath).tell(msg, getSelf());
			logger.info("++ [Ondemand process] Worker messsage(without router) = {} goes to worker node = {}", msg,
					nodePath);
		} else {
			logger.info("++ [Ondemand process] Worker messsage(without router) = {} doen't go to worker node"
					+ " because node status is not 'inital', {}", msg, node);
		}

	}

	private void sendWorkerMessageWithoutRouterOndemand(MasterToWorkerMessage msg, int nodeId) {

		Cluster cluster = Cluster.get(getContext().system());
		// addr = akka.tcp://WatzEyeVAS@203.235.192.41:3333
		Address addr = cluster.selfAddress();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSystemName = array[0];

		/*
		 * VAS_FR_NODE table에서 모든 node id에 해당되는 node 정보를 가져온다
		 */
		Node node = routingProcessor.getNodeInfoById(nodeId);
		if (node == null) {
			logger.warning("++ [Ondemand process] There in no node list. So message[{}] doesn't go to workers", msg);
			return;
		}

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		if (node.getRole().equalsIgnoreCase("na")) {
			logger.warning("++ [Ondemand process] Node[{}] role is 'na'. So message[{}] doesn't go to workers", node,
					msg);
			return;
		}

		/*
		 * Node status가 initial인 경우만 해당 node로 메시지를 전송한다
		 */
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_INITIAL)
				|| node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {

			String nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSystemName)
					.append("@").append(node.getIpAddress()).append(":").append(node.getPort()).append("/user/")
					.append(this.routeeName).toString();

			this.getContext().actorSelection(nodePath).tell(msg, getSelf());
			logger.info("++ [Ondemand process] Worker messsage(without router) = {} goes to worker node = {}", msg,
					nodePath);
		} else {
			logger.info("++ [Ondemand process] Worker messsage(without router) = {} doen't go to worker node"
					+ " because node status is not 'started', {}", msg, node);
		}

	}

	private List<Node> getAllNodeList() {
		List<Node> nodeList = routingProcessor.getNodeList();
		return nodeList;
	}

	/*
	 * Member address:port를 정수값으로 변환하면 unique한 master node value를 생성할 수 있다
	 */
	private long getUniqueNodeValueFromAddress(Member member) {

		if (member == null) {
			this.logger.warning("++ Specified member is null, which is not expected.");
			return -1;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address address = member.address();
		// actorAddrNport = actorsystem_name@192.168.0.1:2248
		String actorAddrNport = address.hostPort();
		String array[] = actorAddrNport.split("@|:"); // split with "@" or ":"
		String addressNport = array[1] + array[2]; // 192.168.0.1:2248

		/*
		 * address와 port를 합쳐서 long으로 변환. 이 값은 unique하게 됨
		 */
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		return Long.valueOf(uniqueString);
	}

	/*
	 * Member address:port를 정수값으로 변환하면 unique한 master node value를 생성할 수 있다
	 */
	private long getUniqueNodeValueFromAddress(String address, String port) {

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		String addressNport = address + port; // 192.168.0.1:2248

		/*
		 * address와 port를 합쳐서 long으로 변환. 이 값은 unique하게 됨
		 */
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		return Long.valueOf(uniqueString);
	}

	private Node getNodeFromAddress(Address addr, String prefixLog) {
		/*
		 * 새롭게 AKKA에 등록된 Member의 Ip address, port 정보 획득
		 */
		// Address = akka.tcp://WatzEyeVAS@10.250.46.50:1111, ==>
		// user/faceDetectionService는 없음에 주의
		// Address addr = workerAddress;
		// addrnport = WatzEyeVAS@10.250.46.50:1111
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_FR_NODE table의 node 상태 정보를 이전 상태에 관계 없이 초기화
		 */
		// 해당 node의 현재 정보를 읽어 온다
		Node nodeFromDB = routingProcessor.getNodeInfo(address, port);
		if (nodeFromDB == null) {
			logger.debug("{} current node[{}:{}] doesn't exist in DB", prefixLog, address, port);

		} else {
			logger.debug("{} current node[{}] exists in DB", prefixLog, nodeFromDB);
		}

		return nodeFromDB;
	}

	/*
	 * address,port에 해당되는 값이 master priority TreeSet의 첫 번째에 존재하는지 확인
	 */
	private boolean isFirstElement(Member member) {
		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address address = member.address();
		// actorAddrNport = actorsystem_name@192.168.0.1:2248
		String actorAddrNport = address.hostPort();
		String array[] = actorAddrNport.split("@|:"); // split with "@" or ":"
		String addressNport = array[1] + array[2]; // 192.168.0.1:2248
		// address:port를 숫자로 변환
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		long uniqueValue = Long.valueOf(uniqueString);

		// TreeSet에서 첫번째 값을 구한다
		if (this.masterPriority.size() == 0)
			return true;

		long first = this.masterPriority.first();

		// 입력으로 받은 member가 TreeSet의 첫번째 값에 해당되는지 확인한다
		if (first == uniqueValue)
			return true;
		else
			return false;
	}

	/*
	 * address,port에 해당되는 값이 master priority TreeSet의 첫 번째에 존재하는지 확인
	 */
	private boolean isFirstElement(String address, String port) {
		String addressNport = address + port; // 192.168.0.1:2248
		// address:port를 숫자로 변환
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		long uniqueValue = Long.valueOf(uniqueString);

		// TreeSet에서 첫번째 값을 구한다
		if (this.masterPriority.size() == 0)
			return true;

		long first = this.masterPriority.first();

		// 입력으로 받은 member가 TreeSet의 첫번째 값에 해당되는지 확인한다
		if (first == uniqueValue)
			return true;
		else
			return false;
	}

	private void sendROIUpdateMessage(NodeMessage nm) {

		Cctv cctv = routingProcessor.findCctvByCctvId(nm.getCctvId(), nm.getSystemId());
		if (cctv == null) {
			logger.debug("++ [ROI update process] current cctv [{}] doen't exist in DB", nm.getCctvId());
		}

		MasterToWorkerMessage msg = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ROI_UPDATED,
				cctv.getSystemId(), cctv.getCctvId());

		SendWorkerMessageWithoutRouter(msg, cctv.getNodeId());

	}

	private void sendFREngineUpdateMessage(NodeMessage nm) {
		Cctv cctv = routingProcessor.findCctvByCctvId(nm.getCctvId(), nm.getSystemId());
		if (cctv == null) {
			logger.debug("++ [FR engine paramter update process] current cctv [{}] doen't exist in DB", nm.getCctvId());
		}

		MasterToWorkerMessage msg = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_FR_ENGINE_UPDATED_IN_ONE_NODE,
				cctv.getSystemId(), cctv.getCctvId());

		SendWorkerMessageWithoutRouter(msg, cctv.getNodeId());

	}

	private void sendFREngineUpdateMessageToAll(NodeMessage nm) {

		MasterToWorkerMessage msg = new MasterToWorkerMessage(
				MasterToWorkerMessage.CODE_FR_ENGINE_UPDATED_IN_ALL_NODES, nm.getSystemId());

		SendWorkerMessageWithoutRouter(msg);

	}

	private List<Integer> sendOndemandJob(OndemandJob ondemandJob) {

		List<Integer> transmittedNodeIds = new ArrayList<Integer>();

		if (ondemandJob.getJobCode() == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {

			List<Integer> standbyNodeIds = ondemandJob.getStandbyNodeIds();
			List<Node> standbyOndemandNodes = new ArrayList<Node>();
			for (int nodeId : standbyNodeIds) {
				Node standbyNode = routingProcessor.getNodeInfoById(nodeId);
				if (standbyNode != null && !standbyNode.getRole().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED)
						&& !standbyNode.getRole().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
					standbyOndemandNodes.add(standbyNode);
				}
			}

			if (standbyOndemandNodes.size() == 0) {
				logger.error("++ [Ondemand process] there is no standby ondemand node !!");
				return null;
			}

			if (ondemandJob.getNumOfSubJobs() == 0) {
				logger.error("++ [Ondemand process] there in no ondemand job in [{}] !!!", ondemandJob);
				return null;
			}

			// DB table에서 읽어 온 standby node 수 보다 ondemand subjob의 수가 많으면 error로
			// 종료
			if (standbyNodeIds.size() < ondemandJob.getNumOfSubJobs()) {
				logger.warning("++ [Ondemand processs] num of standby nodes [{}] is less than num of sub jobs [{}]"
						+ " So [job start] message doesn't go worker node !!!", standbyNodeIds.size(),
						ondemandJob.getNumOfSubJobs());
				return null;
			}

			// worker node에 message 전송
			List<MasterToWorkerMessage> mtws = makeMasterToWorkerMessageOndemand(ondemandJob, standbyOndemandNodes);
			for (int index = 0; index < mtws.size(); index++) {
				sendWorkerMessageWithoutRouterOndemand(mtws.get(index), standbyOndemandNodes.get(index));

				// fail-over에 대비해서 VAS_FR_NODE_ONDEMAND table에 저장
				storeSubJob(mtws.get(index), standbyOndemandNodes.get(index), ondemandJob.getJobId());

				transmittedNodeIds.add(standbyOndemandNodes.get(index).getNodeId());

			}
		}

		if (ondemandJob.getJobCode() == OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT) {

			// job Id에 해당 되는 ongoing node list를 가져온다
			List<Integer> onGoingOndemandDBNodes = routingProcessor
					.getOngoingOndemandDBNodeList(ondemandJob.getJobId());
			List<Integer> onGoingOndemandVMSNodes = routingProcessor.getOngoingOndemandVMSNodeList(ondemandJob
					.getJobId());
			List<Integer> onGoingOndemandVideoNodes = routingProcessor.getOngoingOndemandVideoNodeList(ondemandJob
					.getJobId());
			boolean doesTransmitted = false;

			if (onGoingOndemandDBNodes != null && onGoingOndemandDBNodes.size() > 0) {
				for (Integer nodeId : onGoingOndemandDBNodes) {

					// abort의 경우 ActorStatusMessage를 받지 않기 때문에 미리 abort 상태를 기록한다
					OndemandDBSubJobVO dbSubJobVO = ConversionBetweenSubJobAndVO.updateDBSubJob(nodeId,
							ondemandJob.getJobId(), BaseUtils.formatToYear2SecString(new Date()),
							OndemandJobConstant.JobStatus.ABROTED, 1);
					routingProcessor.updateOndemandDBSubJobUpdateWithThread(dbSubJobVO);

					MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(
							MasterToWorkerMessage.CODE_ONDEMAND_JOB_ABORT, OndemandJobConstant.JobType.DBJOB, nodeId,
							ondemandJob.getJobId());
					sendWorkerMessageWithoutRouterOndemand(mtw, nodeId);

					transmittedNodeIds.add(nodeId);
					doesTransmitted = true;
				}
			}
			if (onGoingOndemandVMSNodes != null && onGoingOndemandVMSNodes.size() > 0) {
				for (Integer nodeId : onGoingOndemandVMSNodes) {

					// abort의 경우 ActorStatusMessage를 받지 않기 때문에 미리 abort 상태를 기록한다
					OndemandVMSSubJobVO vmsSubJobVO = ConversionBetweenSubJobAndVO.updateVMSSubJob(nodeId,
							ondemandJob.getJobId(), BaseUtils.formatToYear2SecString(new Date()),
							OndemandJobConstant.JobStatus.ABROTED, 1);
					routingProcessor.updateOndemandVMSSubJobUpdateWithThread(vmsSubJobVO);

					MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(
							MasterToWorkerMessage.CODE_ONDEMAND_JOB_ABORT, OndemandJobConstant.JobType.VMSJOB, nodeId,
							ondemandJob.getJobId());
					sendWorkerMessageWithoutRouterOndemand(mtw, nodeId);

					transmittedNodeIds.add(nodeId);
					doesTransmitted = true;
				}
			}
			if (onGoingOndemandVideoNodes != null && onGoingOndemandVideoNodes.size() > 0) {
				for (Integer nodeId : onGoingOndemandVideoNodes) {

					// abort의 경우 ActorStatusMessage를 받지 않기 때문에 미리 abort 상태를 기록한다
					OndemandVideoSubJobVO videoSubJobVO = ConversionBetweenSubJobAndVO.updateVideoSubJob(nodeId,
							ondemandJob.getJobId(), BaseUtils.formatToYear2SecString(new Date()),
							OndemandJobConstant.JobStatus.ABROTED, 1);
					routingProcessor.updateOndemandVideoSubJobUpdateWithThread(videoSubJobVO);

					MasterToWorkerMessage mtw = makeMasterToWorkerMessageOndemand(
							MasterToWorkerMessage.CODE_ONDEMAND_JOB_ABORT, OndemandJobConstant.JobType.VIDEOJOB,
							nodeId, ondemandJob.getJobId());
					sendWorkerMessageWithoutRouterOndemand(mtw, nodeId);

					transmittedNodeIds.add(nodeId);
					doesTransmitted = true;
				}
			}
			if (!doesTransmitted) {
				logger.warning("++ [Ondemand process] there is no On-going ondemand node. job Id = [{}] !!!."
						+ " So [Abort] message doesn't go worker node", ondemandJob.getJobId());

				return null;
			}
		}

		return transmittedNodeIds;

	}

	private List<MasterToWorkerMessage> makeMasterToWorkerMessageOndemand(OndemandJob ondemandJob,
			List<Node> standbyNodes) {

		List<MasterToWorkerMessage> mtws = new ArrayList<MasterToWorkerMessage>();
		int index = 0;

		if (ondemandJob.getJobType() == OndemandJobConstant.JobType.DBJOB) {

			for (OndemandDBSubJob subJob : ondemandJob.getDBSubJobs()) {
				MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START,
						subJob, standbyNodes.get(index).getNodeId(), this.masterURL);
				mtws.add(mtw);
				index++;
			}
		}

		if (ondemandJob.getJobType() == OndemandJobConstant.JobType.VMSJOB) {
			for (OndemandVMSSubJob subJob : ondemandJob.getVMSSubJobs()) {
				MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START,
						subJob, standbyNodes.get(index).getNodeId(), this.masterURL);
				mtws.add(mtw);
				index++;
			}
		}

		if (ondemandJob.getJobType() == OndemandJobConstant.JobType.VIDEOJOB) {
			for (OndemandVideoSubJob subJob : ondemandJob.getVideoSubJobs()) {
				MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START,
						subJob, standbyNodes.get(index).getNodeId(), this.masterURL);
				mtws.add(mtw);
				index++;
			}
		}

		return mtws;

	}

	private MasterToWorkerMessage makeMasterToWorkerMessageOndemand(OndemandDBSubJob dbSubJob, int nodeId) {

		MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START, dbSubJob,
				nodeId, this.masterURL);
		return mtw;
	}

	private MasterToWorkerMessage makeMasterToWorkerMessageOndemand(OndemandVMSSubJob vmsSubJob, int nodeId) {

		MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START, vmsSubJob,
				nodeId, this.masterURL);
		return mtw;
	}

	private MasterToWorkerMessage makeMasterToWorkerMessageOndemand(OndemandVideoSubJob videoSubJob, int nodeId) {

		MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_START,
				videoSubJob, nodeId, this.masterURL);
		return mtw;
	}

	private MasterToWorkerMessage makeMasterToWorkerMessageOndemand(int messageCode, int ondemandJobType, int nodeId,
			String jobId) {
		MasterToWorkerMessage mtw = new MasterToWorkerMessage(MasterToWorkerMessage.CODE_ONDEMAND_JOB_ABORT,
				ondemandJobType, nodeId, this.masterURL, jobId);
		return mtw;
	}

	private void storeSubJob(MasterToWorkerMessage mtw, Node node, String jobId) {

		int jobType = mtw.getOndemandJobType();

		if (jobType == OndemandJobConstant.JobType.DBJOB) {

			OndemandDBSubJobVO dbSubJobVO = ConversionBetweenSubJobAndVO.convert(mtw.getOndemandDBSubJob(),
					node.getNodeId(), OndemandJobConstant.JobStatus.ALLOCATED,
					BaseUtils.formatToYear2SecString(new Date()), "");

			routingProcessor.storeOndemandDBSubJob(dbSubJobVO);
		}
		if (jobType == OndemandJobConstant.JobType.VMSJOB) {

			OndemandVMSSubJobVO vmsSubJobVO = ConversionBetweenSubJobAndVO.convert(mtw.getOndemandVMSSubJob(),
					node.getNodeId(), OndemandJobConstant.JobStatus.ALLOCATED,
					BaseUtils.formatToYear2SecString(new Date()), "");

			routingProcessor.storeOndemandVMSSubJob(vmsSubJobVO);
		}
		if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {
			OndemandVideoSubJobVO videoSubJobVO = ConversionBetweenSubJobAndVO.convert(mtw.getOndemandVideoSubJob(),
					node.getNodeId(), OndemandJobConstant.JobStatus.ALLOCATED,
					BaseUtils.formatToYear2SecString(new Date()), "");

			routingProcessor.storeOndemandVideoSubJob(videoSubJobVO);
		}
	}

	private boolean isOndemandJobofAllNodeCompleted(String ondemandJobId, int ondemandJobType) {

		if (ondemandJobType == OndemandJobConstant.JobType.DBJOB) {
			return routingProcessor.isOndemandDBJobofAllNodeCompleted(ondemandJobId);

		} else if (ondemandJobType == OndemandJobConstant.JobType.VMSJOB) {
			return routingProcessor.isOndemandVMSJobofAllNodeCompleted(ondemandJobId);

		} else if (ondemandJobType == OndemandJobConstant.JobType.VIDEOJOB) {
			return routingProcessor.isOndemandVideoJobofAllNodeCompleted(ondemandJobId);

		} else {
			return false;
		}

	}

	private boolean getOndemandJobStatusFromAllNodes(String ondemandJobId, int ondemandJobType) {

		boolean jobSuccessFlag = false;

		if (ondemandJobType == OndemandJobConstant.JobType.DBJOB) {
			jobSuccessFlag = routingProcessor.isOndemandDBJobSuccessful(ondemandJobId);

		} else if (ondemandJobType == OndemandJobConstant.JobType.VMSJOB) {
			jobSuccessFlag = routingProcessor.isOndemandVMSJobSuccessful(ondemandJobId);

		} else if (ondemandJobType == OndemandJobConstant.JobType.VIDEOJOB) {
			jobSuccessFlag = routingProcessor.isOndemandVideoJobSuccessful(ondemandJobId);

		} else {
			jobSuccessFlag = false;
		}

		return jobSuccessFlag;
	}

	private void updateJobMaster(String ondemandJobId, String resultStatus) {

		OndemandJobMasterVO jobMasterVO = new OndemandJobMasterVO();
		jobMasterVO.setProgress((float) 100.0);
		jobMasterVO.setResultStatus(resultStatus);
		routingProcessor.updateJobMaster(ondemandJobId, jobMasterVO);
		logger.info("++ [Ondemand response or Removed process] update VAS_JOB_MATER table. Job Id =[{}],"
				+ " result = [{}]", ondemandJobId, resultStatus);

	}

	private boolean compareNumOfHttpResponseWithNumOfSubJobThread(OndemandJobResponse ondemandJobResponse) {
		int jobType = ondemandJobResponse.getJobType();
		int nodeId = ondemandJobResponse.getNodeId();
		String jobId = ondemandJobResponse.getJobId();
		int jobCode = ondemandJobResponse.getJobCode();
		int subJobResult = ondemandJobResponse.getSubJobResult();

		if (jobType == OndemandJobConstant.JobType.DBJOB) {
			List<Integer> totalThreads = routingProcessor.checkDBSubJobThread(nodeId, jobId);
			if (totalThreads == null) {
				logger.warning("++ [Ondemand response: DB Job] Job Id = [{}], Node Id = [{}] "
						+ "There is no node info in VAS_FR_NODE_ONDEMNAD_DB table", jobId, nodeId);
				return false;
			}
			int totalStartThread = totalThreads.get(0);
			int totalCompletedThread = totalThreads.get(1);

			if (totalCompletedThread >= totalStartThread) {
				logger.info("++ [Ondemand response: DB Job] Job Id = [{}], Node =[{}] the number of completed thread"
						+ "is already same number of start thread.", jobId, nodeId);
				return true;
			}

			routingProcessor.updateOndemandDBCompletedThread(nodeId, jobId, totalCompletedThread + 1);

			logger.info("++ [Ondemand response: DB Job] Job Id = [{}], Node =[{}] total start thread = [{}], "
					+ "current completed thread = [{}]", jobId, nodeId, totalStartThread, totalCompletedThread + 1);

			// +1 means current http reqeust message
			if (totalStartThread <= (totalCompletedThread + 1)) {
				if (jobCode == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandDBSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED);
						logger.info("++ [Ondemand response: DB Job] Job Id =[{}], Node =[{}] completed the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandDBSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: DB Job] Job Id =[{}], Node =[{}] failed to completed"
								+ " the SubJob", jobId, nodeId);
					}
				} else {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandDBSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED);
						logger.info("++ [Ondemand response: DB Job] Job Id =[{}], Node =[{}] aborted the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandDBSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: DB Job] Job Id =[{}], Node =[{}] failed to abort"
								+ " the SubJob", jobId, nodeId);
					}
				}

				return true;
			} else {
				logger.info("++ [Ondemand response: DB Job] Job Id =[{}], Node =[{}] not yet completed the SubJob",
						jobId, nodeId);
				return false;
			}
		} else if (jobType == OndemandJobConstant.JobType.VMSJOB) {
			List<Integer> totalThreads = routingProcessor.checkVMSSubJobThread(nodeId, jobId);
			if (totalThreads == null) {
				logger.warning("++ [Ondemand response: VMS Job] Job Id = [{}], Node Id = [{}] "
						+ "There is no node info in VAS_FR_NODE_ONDEMNAD_VMS table", jobId, nodeId);
				return false;
			}
			int totalStartThread = totalThreads.get(0);
			int totalCompletedThread = totalThreads.get(1);

			if (totalCompletedThread >= totalStartThread) {
				logger.info("++ [Ondemand response: VMS Job] Job Id = [{}], Node =[{}] the number of completed thread"
						+ "is already same number of start thread.", jobId, nodeId);
				return true;
			}

			routingProcessor.updateOndemandVMSCompletedThread(nodeId, jobId, totalCompletedThread + 1);

			logger.info("++ [Ondemand response: VMS Job] Job Id = [{}], Node =[{}] total start thread = [{}], "
					+ "current completed thread = [{}]", jobId, nodeId, totalStartThread, totalCompletedThread + 1);

			// +1 means current http reqeust message
			if (totalStartThread <= (totalCompletedThread + 1)) {
				if (jobCode == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandVMSSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED);
						logger.info("++ [Ondemand response: VMS Job] Job Id =[{}], Node =[{}] completed the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandVMSSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: VMS Job] Job Id =[{}], Node =[{}] failed to completed"
								+ " the SubJob", jobId, nodeId);
					}
				} else {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandVMSSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED);
						logger.info("++ [Ondemand response: VMS Job] Job Id =[{}], Node =[{}] aborted the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandVMSSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: VMS Job] Job Id =[{}], Node =[{}] failed to abort"
								+ " the SubJob", jobId, nodeId);
					}
				}

				return true;
			} else {
				logger.info("++ [Ondemand response: VMS Job] Job Id =[{}], Node =[{}] not yet completed the SubJob",
						jobId, nodeId);
				return false;
			}
		} else {
			List<Integer> totalThreads = routingProcessor.checkVideoSubJobThread(nodeId, jobId);
			if (totalThreads == null) {
				logger.warning("++ [Ondemand response: Video Job] Job Id = [{}], Node Id = [{}] "
						+ "There is no node info in VAS_FR_NODE_ONDEMNAD_VIDEO table", jobId, nodeId);
				return false;
			}
			int totalStartThread = totalThreads.get(0);
			int totalCompletedThread = totalThreads.get(1);

			if (totalCompletedThread >= totalStartThread) {
				logger.info(
						"++ [Ondemand response: Video Job] Job Id = [{}], Node =[{}] the number of completed thread"
								+ "is already same number of start thread.", jobId, nodeId);
				return true;
			}

			routingProcessor.updateOndemandVideoCompletedThread(nodeId, jobId, totalCompletedThread + 1);

			logger.info("++ [Ondemand response: Video Job] Job Id = [{}], Node =[{}] total start thread = [{}], "
					+ "current completed thread = [{}]", jobId, nodeId, totalStartThread, totalCompletedThread + 1);

			// +1 means current http reqeust message
			if (totalStartThread <= (totalCompletedThread + 1)) {
				if (jobCode == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandVideoSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED);
						logger.info("++ [Ondemand response: Video Job] Job Id =[{}], Node =[{}] completed the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandVideoSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: Video Job] Job Id =[{}], Node =[{}] failed to completed"
								+ " the SubJob", jobId, nodeId);
					}
				} else {
					if (subJobResult == OndemandJobResponse.SUB_JOB_SUCCESS) {
						routingProcessor.updateOndemandVideoSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED);
						logger.info("++ [Ondemand response: Video Job] Job Id =[{}], Node =[{}] aborted the SubJob",
								jobId, nodeId);
					} else {
						routingProcessor.updateOndemandVideoSubJobUpdate(nodeId, jobId,
								OndemandJobConstant.JobStatus.ABORT_COMPLETED_WITH_ERROR);
						logger.info("++ [Ondemand response: Video Job] Job Id =[{}], Node =[{}] failed to abort"
								+ " the SubJob", jobId, nodeId);
					}
				}

				return true;
			} else {
				logger.info("++ [Ondemand response: Video Job] Job Id =[{}], Node =[{}] not yet completed the SubJob",
						jobId, nodeId);
				return false;
			}

		}
	}

	private void checkAllNodeSubJobThreadFinishedAndUpdateJobMaster(OndemandJobResponse ondemandJobResponse) {
		int jobType = ondemandJobResponse.getJobType();
		String jobId = ondemandJobResponse.getJobId();
		int jobCode = ondemandJobResponse.getJobCode();

		boolean isCompleted = true;
		boolean doesJobHaveError = false;

		if (jobType == OndemandJobConstant.JobType.DBJOB) {
			List<OndemandDBSubJobVO> ondemandSubJobVOs = routingProcessor.getDBAllNodeSubJobThread(jobId);
			if (ondemandSubJobVOs == null) {
				logger.warning("++ [Ondemand response: DB] Job Id =[{}], there is no node info in "
						+ "VAS_FR_NODE_ONDEMAND_DB table", jobId);
				return;
			}

			for (OndemandDBSubJobVO subJobVO : ondemandSubJobVOs) {
				if (subJobVO.getTotalStartThread() > subJobVO.getTotalCompletedThread()) {
					isCompleted = false;
					break;
				}
			}
			if (isCompleted) {
				for (OndemandDBSubJobVO subJobVO : ondemandSubJobVOs) {
					if (doesJobFailed(subJobVO.getJobStatus())) {
						doesJobHaveError = true;
						break;
					}
				}
			}

		} else if (jobType == OndemandJobConstant.JobType.VMSJOB) {
			List<OndemandVMSSubJobVO> ondemandSubJobVOs = routingProcessor.getVMSAllNodeSubJobThread(jobId);
			if (ondemandSubJobVOs == null) {
				logger.warning("++ [Ondemand response: VMS] Job Id =[{}], there is no node info in "
						+ "VAS_FR_NODE_ONDEMAND_VMS table", jobId);
				return;
			}
			for (OndemandVMSSubJobVO subJobVO : ondemandSubJobVOs) {
				if (subJobVO.getTotalStartThread() > subJobVO.getTotalCompletedThread()) {
					isCompleted = false;
					break;
				}
			}
			if (isCompleted) {
				for (OndemandVMSSubJobVO subJobVO : ondemandSubJobVOs) {
					if (doesJobFailed(subJobVO.getJobStatus())) {
						doesJobHaveError = true;
						break;
					}
				}
			}

		} else {
			List<OndemandVideoSubJobVO> ondemandSubJobVOs = routingProcessor.getVideoAllNodeSubJobThread(jobId);
			if (ondemandSubJobVOs == null) {
				logger.warning("++ [Ondemand response: Video] Job Id =[{}], there is no node info in "
						+ "VAS_FR_NODE_ONDEMAND_VIDEO table", jobId);
				return;
			}

			for (OndemandVideoSubJobVO subJobVO : ondemandSubJobVOs) {
				if (subJobVO.getTotalStartThread() > subJobVO.getTotalCompletedThread()) {
					isCompleted = false;
					break;
				}
			}
			if (isCompleted) {
				for (OndemandVideoSubJobVO subJobVO : ondemandSubJobVOs) {
					if (doesJobFailed(subJobVO.getJobStatus())) {
						doesJobHaveError = true;
						break;
					}
				}
			}
		}

		if (isCompleted && (doesJobHaveError == false)) {
			if (jobCode == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {
				updateJobMaster(jobId, OndemandJobConstant.JobMasterStatus.COMPLETED);
				logger.info("++ [Ondemand response: {}] Job Id =[{}], completed the job successfully",
						OndemandJobConstant.JobType.getJobName(jobType), jobId);
			} else {
				updateJobMaster(jobId, OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED);
				logger.info("++ [Ondemand response: {}] Job Id =[{}], completed to abort the job successfully",
						OndemandJobConstant.JobType.getJobName(jobType), jobId);
			}
		}
		if (isCompleted && (doesJobHaveError == true)) {
			if (jobCode == OndemandJobConstant.JobCode.ONDEMNAD_JOB_START) {
				updateJobMaster(jobId, OndemandJobConstant.JobMasterStatus.COMPLETED_WITH_ERROR);
				logger.info("++ [Ondemand response: {}] Job Id =[{}], fail to completed the job",
						OndemandJobConstant.JobType.getJobName(jobType), jobId);
			} else {
				updateJobMaster(jobId, OndemandJobConstant.JobMasterStatus.ABORT_COMPLETED_WITH_ERROR);
				logger.info("++ [Ondemand response: {}] Job Id =[{}], fail to abort the job",
						OndemandJobConstant.JobType.getJobName(jobType), jobId);
			}
		}
	}

	private boolean doesJobFailed(String jobStatus) {
		if (jobStatus.equalsIgnoreCase(OndemandJobConstant.JobStatus.ABORT_COMPLETED_WITH_ERROR)) {
			return true;
		} else if (jobStatus.equalsIgnoreCase(OndemandJobConstant.JobStatus.COMPLETED_WITH_ERROR)) {
			return true;
		} else if (jobStatus.equalsIgnoreCase(OndemandJobConstant.JobStatus.START_FAILED)) {
			return true;
		} else if (jobStatus.equalsIgnoreCase(OndemandJobConstant.JobStatus.ABROT_FAILED)) {
			return true;
		} else {
			return false;
		}
	}

	private boolean isRemainedAnotherJobinNode(int nodeId) {

		List<String> dbJobId = routingProcessor.selectOngoingDBJob(nodeId);
		List<String> vmsJobId = routingProcessor.selectOngoingVMSJob(nodeId);
		List<String> videoJobId = routingProcessor.selectOngoingVideoJob(nodeId);

		boolean isReamindedJob = false;

		if (dbJobId != null && dbJobId.size() != 0) {
			logger.info("++ [Ondemand response] Node Id[{}], remainded job is DB, job id list = [{}]", nodeId,
					getString(dbJobId));
			isReamindedJob = true;
		}
		if (vmsJobId != null && vmsJobId.size() != 0) {
			logger.info("++ [Ondemand response] Node Id[{}], remainded job is VMS, job id list = [{}]", nodeId,
					getString(vmsJobId));
			isReamindedJob = true;
		}
		if (videoJobId != null && videoJobId.size() != 0) {
			logger.info("++ [Ondemand response] Node Id[{}], remainded job is Video, job id list = [{}]", nodeId,
					getString(videoJobId));
			isReamindedJob = true;
		}

		return isReamindedJob;

	}

	private String getString(List<String> stringList) {

		String string = "";
		if (stringList == null || stringList.size() == 0)
			return string;

		for (String str : stringList) {
			string += str;
			string += ", ";
		}
		return string;
	}

	public static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}

	private void publishCncrnFaceUpdate(String command, String[] matchNodeIdArr, String reason) {

		this.logger.info("Refresh Node Value : {} ", Arrays.deepToString(matchNodeIdArr));

		ConcernedFaceUpdateMessage concernedFaceUpdateMessage = new ConcernedFaceUpdateMessage().setCommand(command)
				.setMatchNodeIdList(matchNodeIdArr).setReason(reason);
		concernedFaceUpdatePulisher.publish(concernedFaceUpdateMessage);
	
	}

	private String[] getNodesByFaceIds(List<String> faceIds) {

		ArrayList<String> matchNodeIdList = new ArrayList<String>();
		ArrayList<String> matchNodeIdListDistinct = new ArrayList<String>();

		for (int i = 0; i < faceIds.size(); i++) {
			String[] nodeIds = this.getFaceDataManager().getNodeByCncrnFaceIdx(Integer.parseInt(faceIds.get(i)));
			this.logger.info("Not exist a node for the Face Id. Face Id : {} ", faceIds.get(i));
			
			for(int j = 0; j < nodeIds.length; j++){
				matchNodeIdList.add(nodeIds[j]);
			}
		}

		for (String str : matchNodeIdList) {
			if (!matchNodeIdListDistinct.contains(str)) {
				matchNodeIdListDistinct.add(str);
			}
		}

		String[] matchNodeIdArr = new String[matchNodeIdListDistinct.size()];
		matchNodeIdArr = matchNodeIdListDistinct.toArray(matchNodeIdArr);

		return matchNodeIdArr;
	}
	
	private int findFailoverNodeOfGroup(String nodeClass, int nodeId) {

		int error = -1;

		/*
		 * 동일한 matching group의 node list를 가져온다
		 */
		List<Node> nodeList = routingProcessor.getDetectionNodeListOfGroup(nodeClass, nodeId);

		if (nodeList == null) {
			return error;
		}

		if (nodeList.size() == 0) {
			return error;
		}

		return nodeList.get(0).getNodeId();

	}

}// end of main
