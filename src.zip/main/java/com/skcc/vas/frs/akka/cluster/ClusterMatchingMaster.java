package com.skcc.vas.frs.akka.cluster;

import static com.skcc.vas.frs.akka.model.ActorProfile.*;

import java.net.*;
import java.util.concurrent.*;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;

import scala.concurrent.Future;
import scala.concurrent.duration.*;
import akka.actor.*;
import akka.camel.*;
import akka.util.*;

import com.fasterxml.jackson.databind.*;
import com.typesafe.config.*;
import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.akka.actor.MatchingRoutingNStateControllActor;
import com.skcc.vas.frs.akka.actor.MatchingWebServiceActor;
import com.skcc.vas.frs.akka.model.ClusterConfig;
import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.akka.service.VasNodeService;
import com.skcc.vas.frs.akka.util.ConfigUtil;
import com.skcc.vas.frs.akka.util.LicenseUtil;
import com.skcc.vas.frs.common.util.spring.Profile;

/**
 * @author
 * @since 2016-06-22
 *
 */
public class ClusterMatchingMaster extends ClusterNodeBase {

	public static final int NODE_PORT_DEFAULT = 2551;

	public static final String ROLE = "master";

	private final int httpPort;

	public int getHttpPort() {
		return this.httpPort;
	}

	private final String baseUrl;

	public String getBaseUrl() {
		return this.baseUrl;
	}

	boolean useConfFile;

	ClusterConfig clusterConfig;

	public ClusterMatchingMaster(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, @Nullable String configSubtree, boolean useConfFile,
			ClusterConfig clusterConfig) throws Exception {

		super(systemName, applName, NO_DEFINED_PORT, configSubtree, useConfFile);

		// http port를 appliation.conf에서 읽어 온다
		this.httpPort = this.getConfig().getInt("nodes.master.httpport");

		// build base URL
		InetAddress addr = InetAddress.getLocalHost();
		this.baseUrl = new StringBuilder().append("http://").append(addr.getHostAddress()).append(":")
				.append(this.getHttpPort()).append("/").append(applName).toString();

		// validate the master
		this.useConfFile = useConfFile;
		if (useConfFile) {
			String addr2 = null;
			int port2 = -1;
			try {
				addr2 = this.getConfig().getString("nodes.master.address");
				port2 = this.getConfig().getInt("nodes.master.port");
			} catch (Exception ex) {
				throw new IllegalStateException("The address or port for the master is not defined at configuration");
			}

			if (!StringUtils.equals(addr2, this.getAddress().getHostAddress()) || port2 != this.getPort()) {
				throw new IllegalStateException(
						"The address or port for this master is not same with thosed defined in configuration.");
			}
		}

		this.clusterConfig = clusterConfig;

	}

	@Override
	@Nonnull
	protected Config buildConfig(@Nullable String configSubtree) throws Exception {

		Config config = ConfigFactory.load();

		if (configSubtree != null) {
			config = config.getConfig(this.getConfigSubtree()).withFallback(config);
		}

		String ipAddress = config.getString("akka.remote.netty.tcp.hostname");
		String port = config.getString("akka.remote.netty.tcp.port");

		logger.info("ipaddress [{}], port [{}]", ipAddress, port);

		config = ConfigFactory.parseString("akka.actor.provider = \"akka.cluster.ClusterActorRefProvider\"")
				.withFallback(ConfigFactory.parseString("akka.cluster.roles = [" + ROLE + "]")).withFallback(config);

		return config;
	}

	@Override
	@Nonnull
	protected ActorSystem buildActorSystem(@Nonnull Config config) throws Exception {

		// acquire necessary beans from Spring container
		ObjectMapper jacksonMapper = this.getSpringContainer().getBean("jacksonObjectMapper", ObjectMapper.class);

		DynamicNodeRoutingProcessor dynamicNodeProcessor = this.getSpringContainer().getBean(
				"dynamicNodeRoutingProcessor", DynamicNodeRoutingProcessor.class);

		VasNodeService vasNodeService = this.getSpringContainer().getBean("vasNodeService", VasNodeService.class);
		
		Profile springProfile = this.getSpringContainer().getBean("spring.Profile", Profile.class);

		String[] profiles = springProfile.getSpringProfiles();
		for (String profile : profiles) {
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			logger.debug("current spring profile : [{}]", profile);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		}	
		
		LicenseUtil.checkHBinnoLicense(this.getSpringContainer().getBean("hbInnoAdapter", HbInnoAdapter.class));
		
		Validate.validState(jacksonMapper != null, "Jackson ObjectMapper bean can't be found in the Spring container.");
		Validate.validState(dynamicNodeProcessor != null,
				"DynamicNodeRoutingProcessor bean can't be found in the Spring container.");
		Validate.validState(vasNodeService != null, "VasNodeService bean can't be found in the Spring container.");

		Config configNew = ConfigFactory
				.parseString("akka.remote.netty.tcp.hostname=" + this.clusterConfig.getIpAddress())
				.withFallback(
						ConfigFactory.parseString("akka.remote.netty.tcp.port=" + this.clusterConfig.getPortInt()))
				.withFallback(config);

		// add Seed Nodes for AKKA
		Config configFinal = ConfigUtil.addSeedNodes(vasNodeService, configNew, ROLE, this.getSystemName(),
				this.clusterConfig.getSystemId());

		// build Akka cluster member
		ActorSystem system = ActorSystem.create(this.getSystemName(), configFinal);
		Camel camel = CamelExtension.get(system);

		ActorRef routingnControllerActor = system.actorOf(Props.create(MatchingRoutingNStateControllActor.class,
				FACE_MATCHING_ACTOR.getActorName(), dynamicNodeProcessor, this.clusterConfig.getIpAddress(),
				this.clusterConfig.getPort(), httpPort, this.getSystemName()), FACE_MATCHING_ROUTING_ACTOR
				.getActorName());

		ActorRef webService = system.actorOf(Props.create(MatchingWebServiceActor.class, this.baseUrl + "/matching",
				jacksonMapper, WebServiceBase.TIMEOUT_DEFAULT, routingnControllerActor), FACE_MATCHING_WEB_ACTOR.getActorName());

		Future<ActorRef> activationFuture = camel.activationFutureFor(webService,
				new Timeout(Duration.create(10, TimeUnit.SECONDS)), system.dispatcher());

		return system;
	}

	@Override
	protected void beforeStop() throws Exception {

	}

}
