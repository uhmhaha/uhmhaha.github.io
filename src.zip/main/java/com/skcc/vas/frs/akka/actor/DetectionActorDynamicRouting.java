package com.skcc.vas.frs.akka.actor;

import java.io.*;

import javax.annotation.*;

import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.akka.model.ActorStatusMessage;
import com.skcc.vas.frs.akka.model.MasterToWorkerMessage;
import com.skcc.vas.frs.akka.model.OndemandJobConstant;
import com.skcc.vas.frs.akka.routing.KeyedMessage;
import com.skcc.vas.frs.live.biz.DetectionProcessor;
import com.skcc.vas.frs.live.biz.DetectionProcessorFactory;
import com.skcc.vas.frs.ondemand.db.biz.OndemandDBProcessor;
import com.skcc.vas.frs.ondemand.video.biz.OndemandVideoProcessor;
import com.skcc.vas.frs.ondemand.vms.biz.OndemandVMSProcessor;

import akka.actor.*;
import akka.cluster.*;
import akka.event.*;

public class DetectionActorDynamicRouting extends UntypedActor {
	private final LoggingAdapter logger = Logging.getLogger(getContext().system(), this);

	private final DetectionProcessorFactory processorFactory;

	private DetectionProcessor processor;

	private final OndemandDBProcessor clusterDBProcessor;
	private final OndemandVMSProcessor clusterVMSProcessor;
	private final OndemandVideoProcessor clusterVideoProcessor;

	public DetectionActorDynamicRouting(@Nonnull final DetectionProcessorFactory factory,
			OndemandDBProcessor clusterDBProcessor, OndemandVMSProcessor clusterVMSProcessor,
			OndemandVideoProcessor clusterVideoProcessor) {

		this.processorFactory = factory;
		this.clusterDBProcessor = clusterDBProcessor;
		this.clusterVMSProcessor = clusterVMSProcessor;
		this.clusterVideoProcessor = clusterVideoProcessor;
	}

	@Override
	public void preStart() {

	}

	@Override
	public void onReceive(Object msg) throws Exception {

		if (msg instanceof KeyedMessage<?, ?>) {

			KeyedMessage<Cctv, Boolean> km = (KeyedMessage<Cctv, Boolean>) msg;

			Cctv key = km.getKey().get();
			boolean starts = km.getMessage();
			String systemId = key.getSystemId();

			logger.info("++ [KeyedMessage] message arrived cctv = {} : flag = {} ", key, starts);

			processor = this.processorFactory.getDetectionProcessor(key.getSystemId());

			if (starts) {
				try {
					logger.debug("++ call start detection device id = {}", key.getCctvId());
					boolean ret = processor.startDetection(key.getCctvId());
					if (ret == false) {
						// master에 실패를 보고할 메시지를 만들고 전송한다
						ActorStatusMessage asm = new ActorStatusMessage(
								ActorStatusMessage.WORKER_NODE_START_DETECTION_FAILED);
						asm.setDeviceId(key.getCctvId());

						Cluster cluster = Cluster.get(getContext().system());
						asm.setWorkerAddress(cluster.selfAddress());

						getSender().tell(asm, getSelf());
						logger.info("++ [start detection process]start detection failed. "
								+ "So ActorStatusMessage[{}] message goes to master", asm);
					}
				} catch (Exception ex) {
					logger.error("++ [start detection process] start detection exception happens: {}",
							getPrintStacTraceString(ex));

				}
			} else {
				logger.debug("++ call stop detection device id = {}", key.getCctvId());
				try {
					processor.stopDetection(key.getCctvId());
				} catch (Exception ex) {
					logger.error("++ [stop detection process] stop detection exception happens: {}",
							getPrintStacTraceString(ex));
				}
			}

		} else if (msg instanceof MasterToWorkerMessage) {

			MasterToWorkerMessage masterMessage = (MasterToWorkerMessage) msg;
			logger.info("++ MastgerToWorkerMessage arrived. message = {}", masterMessage);

			int messageCode = masterMessage.getMessageCode();

			if (messageCode == MasterToWorkerMessage.CODE_CNCRN_FACE_DB_UPDATED) {

				String[] systemIdList = this.processorFactory.getSystemIdsOfDetectionProcessors();
				if (systemIdList.length != 0) {
					try {
						this.processorFactory.getDetectionProcessor(systemIdList[0])
								.updateTargetFeaturesWithoutTaskStop();
					} catch (Exception ex) {
						logger.error("++ [update target feature process] exception happens: {}",
								getPrintStacTraceString(ex));
					}
				} else {
					logger.warning("++ there is no DetectionProcessor in order to update target features");
				}
			}

			if (messageCode == MasterToWorkerMessage.CODE_ROI_UPDATED) {
				String[] systemIdList = this.processorFactory.getSystemIdsOfDetectionProcessors();
				if (systemIdList.length != 0) {
					try {
						this.processorFactory.getDetectionProcessor(systemIdList[0]).updateROI(
								masterMessage.getDeviceId());
					} catch (Exception ex) {
						logger.error("++ [ROI update process] exception happens: {}", getPrintStacTraceString(ex));
					}
				} else {
					logger.warning("++ there is no DetectionProcessor in order to update ROI");
				}
			}

			if (messageCode == MasterToWorkerMessage.CODE_FR_ENGINE_UPDATED_IN_ONE_NODE) {
				String[] systemIdList = this.processorFactory.getSystemIdsOfDetectionProcessors();
				if (systemIdList.length != 0) {
					try {
						this.processorFactory.getDetectionProcessor(systemIdList[0]).updateFREngineParameters(
								masterMessage.getDeviceId());
					} catch (Exception ex) {
						logger.error("++ [FR engine update for one node process] exception happens: {}",
								getPrintStacTraceString(ex));
					}
				} else {
					logger.warning("++ there is no DetectionProcessor in order to update FR engine parameters in one node");
				}
			}

			if (messageCode == MasterToWorkerMessage.CODE_FR_ENGINE_UPDATED_IN_ALL_NODES) {
				String[] systemIdList = this.processorFactory.getSystemIdsOfDetectionProcessors();
				if (systemIdList.length != 0) {
					try {
						this.processorFactory.getDetectionProcessor(systemIdList[0]).updateFREngineParameters();
					} catch (Exception ex) {
						logger.error("++ [FR engine update for all node process] exception happens: {}",
								getPrintStacTraceString(ex));
					}
				} else {
					logger.warning("++ there is no DetectionProcessor in order to update FR engine parameters in all nodes");
				}
			}

			if (messageCode == MasterToWorkerMessage.CODE_ONDEMAND_JOB_START) {
				int jobType = masterMessage.getOndemandJobType();
				int nodeId = masterMessage.getNodeId();
				String masterURL = masterMessage.getMasterURL();
				String jobId = masterMessage.getOndemandJobId();
				int numOfthread = 0;
				ActorStatusMessage asm;
				int asmMessageCode;

				if (jobType == OndemandJobConstant.JobType.DBJOB) {
					try {
						numOfthread = clusterDBProcessor.search(masterMessage.getOndemandDBSubJob(), nodeId, masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand DB start] Job Id =[{}], search() exception happens: [{}]",
								getPrintStacTraceString(ex));
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED;
					}
					// send ActorStatusMessage to Master node
					asm = makeActorStatusMessage4Ondemand(asmMessageCode, jobId, numOfthread, jobType);
					getSender().tell(asm, getSelf());

				}

				if (jobType == OndemandJobConstant.JobType.VMSJOB) {
					try {
						numOfthread = clusterVMSProcessor.search(masterMessage.getOndemandVMSSubJob(), nodeId,
								masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand VMS start] Job Id =[{}], search() exception happens: [{}]", jobId,
								getPrintStacTraceString(ex));
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED;
					}
					// send ActorStatusMessage to Master node
					asm = makeActorStatusMessage4Ondemand(asmMessageCode, jobId, numOfthread, jobType);
					getSender().tell(asm, getSelf());
				}
				if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {
					try {
						numOfthread = clusterVideoProcessor.search(masterMessage.getOndemandVideoSubJob(), nodeId,
								masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand Video start] Job Id =[{}], search() exception happens: [{}]",
								getPrintStacTraceString(ex));
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMAND_JOB_START_FAILED;
					}

					// send ActorStatusMessage to Master node
					asm = makeActorStatusMessage4Ondemand(asmMessageCode, jobId, numOfthread, jobType);
					getSender().tell(asm, getSelf());
				}

			}

			if (messageCode == MasterToWorkerMessage.CODE_ONDEMAND_JOB_ABORT) {
				int jobType = masterMessage.getOndemandJobType();
				int nodeId = masterMessage.getNodeId();
				String masterURL = masterMessage.getMasterURL();
				String jobId = masterMessage.getOndemandJobId();
				int numOfthread = 0;
				ActorStatusMessage asm;
				int asmMessageCode;

				if (jobType == OndemandJobConstant.JobType.DBJOB) {
					try {
						numOfthread = clusterDBProcessor.abort(nodeId, masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand DB abort] Job Id =[{}], abort() exception happens: [{}]",
								ex.toString());
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED;
					}
					// send ActorStatusMessage to Master node
					// asm = makeActorStatusMessage4Ondemand(asmMessageCode,
					// jobId, numOfthread, jobType);
					// getSender().tell(asm, getSelf());
				}

				if (jobType == OndemandJobConstant.JobType.VMSJOB) {
					try {
						numOfthread = clusterVMSProcessor.abort(nodeId, masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand VMS abort] Job Id =[{}], abort() exception happens: [{}]",
								getPrintStacTraceString(ex));
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED;
					}
					// send ActorStatusMessage to Master node
					// asm = makeActorStatusMessage4Ondemand(asmMessageCode,
					// jobId, numOfthread, jobType);
					// getSender().tell(asm, getSelf());
				}
				if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {
					try {
						numOfthread = clusterVideoProcessor.abort(nodeId, masterURL);
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS;
					} catch (Exception ex) {
						logger.error("++ [Ondemand Video abort] Job Id =[{}], abort() exception happens: [{}]",
								getPrintStacTraceString(ex));
						asmMessageCode = ActorStatusMessage.WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED;
					}
					// send ActorStatusMessage to Master node
					// asm = makeActorStatusMessage4Ondemand(asmMessageCode,
					// jobId, numOfthread, jobType);
					// getSender().tell(asm, getSelf());
				}

			}

		}
	}

	private ActorStatusMessage makeActorStatusMessage4Ondemand(int messageCode, String jobId, int totalNumofThread,
			int jobType) {

		ActorStatusMessage asm = new ActorStatusMessage(messageCode);
		asm.setOndemandJobId(jobId);
		asm.setOndemandTotalThread(totalNumofThread);
		asm.setOndemandJobType(jobType);

		Cluster cluster = Cluster.get(getContext().system());

		asm.setWorkerAddress(cluster.selfAddress());

		return asm;

	}

	public static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}
}
