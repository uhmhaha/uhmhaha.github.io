package com.skcc.vas.frs.akka.actor;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;

import akka.actor.ActorSystem;
import akka.actor.Address;
import akka.actor.UntypedActor;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent;
import akka.cluster.ClusterEvent.MemberEvent;
import akka.cluster.ClusterEvent.MemberRemoved;
import akka.cluster.ClusterEvent.MemberUp;
import akka.cluster.ClusterEvent.ReachableMember;
import akka.cluster.ClusterEvent.UnreachableMember;
import akka.cluster.Member;
import akka.cluster.MemberStatus;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import akka.routing.Router;

import com.skcc.vas.frs.akka.db.rdb.domain.*;
import com.skcc.vas.frs.akka.db.rdb.domain.Node.Role;
import com.skcc.vas.frs.akka.model.*;
import com.skcc.vas.frs.akka.routing.*;
import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.akka.util.*;
import com.skcc.vas.frs.common.util.base.BaseUtils;

public class MatchingRoutingNStateControllActor<T extends java.io.Serializable> extends UntypedActor {

	private final static String MASTER_ROLE = "master";

	private final LoggingAdapter logger = Logging.getLogger(getContext().system(), this);

	private final Cluster cluster;

	private final String routeeName;

	DynamicNodeRoutingProcessor routingProcessor;

	private String masterAddress;
	private String masterPort;
	private String masterURL;

	private String AKKAProtocol = "akka.tcp://WatzEyeVAS@";

	/*
	 * master가 2개 이상 존재하는 경우 member up, member remove를 처리하기 위한 master를 결정
	 */
	private TreeSet<Long> masterPriority = new TreeSet<Long>();
	private boolean firstMaster = true; // master가 up 되기전에 worker node가 먼저 up되는
										// 경우가 있으므로 반드시 true로 해야 함
	/*
	 * master가 여러 개인 경우 master priority 로직을 사용할지 말지를 결정 supportMasterPriority =
	 * true : the master of master만 member up and member removed 처리를 수행
	 * supportMasterPriority = false : 모든 master는 동일하게 member up and member
	 * removed 처리를 수행
	 */
	private final boolean supportMasterPriority = true;

	/*
	 * cctv가 할당되고 detection을 수행 중인 node가 죽게되는 경우, failover를 하지 못하게 되면 node의 상태는
	 * removed로 됨 운영자가 재 기동시 자동으로 node role을 standby가 아닌 active로 변경하고, 자동으로 cctv
	 * detection 수행 할지 말지를 결정
	 */
	private final boolean supportAutoActive = true;

	public MatchingRoutingNStateControllActor(@NotBlank String routeeName,
			@Nonnull DynamicNodeRoutingProcessor routingProcessor, String masterAddress, String masterPort,
			int httpPort, String clusterName) {

		Validate.isTrue(StringUtils.isNotBlank(routeeName), "Actor name for the routee should be specified");
		Validate.isTrue(routingProcessor != null, "The dynamic routing processor should be provided.");

		this.routeeName = routeeName;
		this.routingProcessor = routingProcessor;
		this.masterAddress = masterAddress;
		this.masterPort = masterPort;

		this.cluster = Cluster.get(this.getContext().system());
		this.cluster.subscribe(getSelf(), ClusterEvent.initialStateAsEvents(),
		// MemberEvent.class, UnreachableMember.class, ReachableMember.class,
		// MemberRemoved.class, SeenChanged.class, AssociatedEvent.class);
				MemberEvent.class, UnreachableMember.class, ReachableMember.class, MemberRemoved.class);

		/*
		 * master node가 여러 개인 경우에 대비해 Priority TreeSet에 자기 자신을 등록한다
		 */

		this.firstMaster = true;

		/*
		 * master http 주소를 만든다
		 */
		this.masterURL = "http://" + this.masterAddress + ":" + String.valueOf(httpPort) + "/vas/face";

		/*
		 * cluster name을 기반으로 AKAK protocol을 설정한다
		 */
		AKKAProtocol = "akka.tcp://" + clusterName + "@";

		logger.debug("++ MatchingRoutingNStateControllerActor constructor called ");

	}

	@Override
	public void onReceive(Object msg) throws Exception {

		logger.debug("++ RoutingNStateControllerActor - onReceived called");

		/*
		 * From: AKKA cluster
		 */
		if (msg instanceof MemberUp) {
			try {
				MemberEvent ev = (MemberEvent) msg;
				Member member = ev.member();

				if (isMasterNode(member)) {

					this.logger.info("++ Master node = {} is up", member.address());

					/*
					 * master priority에 등록
					 */
					long masterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.add(masterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ I[master] am the master of master. So Now I control member up and member removed");
					} else {
						logger.info("++ I[master] am not the master of master. So Another master "
								+ "contols member up and member removed");
					}

					/*
					 * Node role이 active, standby인 모든 worker node에게 master node가
					 * member up이 되었다는 것을 알린다
					 */
					// SendMasterUpNotification(member);

					return;
				} else if (isAnotherMasterNode(member)) {
					this.logger.info("++ Another Master node = {} is up", member.address());
					/*
					 * master priority에 등록
					 */
					long anotherMasterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.add(anotherMasterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ I[master] am the master of master. So Now I control member up and member removed");
					} else {
						logger.info("++ I[master] am not the master of master. So Another master[{}] contols "
								+ "member up and member removed", member.address());
					}

					return;
				}

				this.logger.info("++ Worker node(address:{}) is up", member.address());

				/*
				 * master node가 여러개 있는 경우 the master of master가 아닌 경우 아무런 처리를 하지
				 * 않는다
				 */
				if (this.supportMasterPriority == true && this.firstMaster == false) {
					this.logger.info("++ I am not the master of master. So I don't control worker node member up");
					return;
				}

				registerMatchingWorkerNode(member.address());

			} catch (Exception ex5) {
				logger.error("++ [Exception] Fail to handle [Member up]. Exception : [{}]",
						getPrintStacTraceString(ex5));
			}

		}
		/*
		 * AKKA cluster
		 */
		else if (msg instanceof UnreachableMember) {

			try {
				UnreachableMember ev = (UnreachableMember) msg;
				Member member = ev.member();
				Node node = getNodeFromAddress(member.address(), "++ [Unreachable]");
				if (node != null) {
					logger.info("++ [Unreachable]Memeber(address:{}) Node Id =[{}] has unreachable", member.address(),
							node.getNodeId());
				} else {
					logger.info("++ [Unreachable]Memeber(address:{}) has unreachable but there is no Node info in DB",
							member.address());
				}
			} catch (Exception ex6) {
				logger.error("++ [Exception] Fail to handle [UnreachableMember]. Exception : [{}]",
						getPrintStacTraceString(ex6));
			}

		}
		/*
		 * from AKKA cluster
		 */
		else if (msg instanceof MemberRemoved) {
			try {
				MemberRemoved ev = (MemberRemoved) msg;
				Member member = ev.member();
				Node node = getNodeFromAddress(member.address(), "++ [Removed process]");
				if (node != null) {
					logger.info("++ [Removed process]Member(address: {}) Node Id =[{}] removed ", member.address(),
							node.getNodeId());
				} else {
					logger.info("++ [Removed process]Member(address: {}) removed. but there is no Node info in DB"
							+ "Maybe this node is another master node. ", member.address());
				}

				if (isAnotherMasterNode(member)) {
					this.logger.info("++ [Removed process]Another Master node = {} is removed " + "but nothing to do",
							member.address());

					/*
					 * master priority에서 삭제
					 */
					long anotherMasterValue = getUniqueNodeValueFromAddress(member);
					this.masterPriority.remove(anotherMasterValue);
					this.firstMaster = isFirstElement(this.masterAddress, this.masterPort);
					logger.info("++ [Removed process]total number of master is [{}]", this.masterPriority.size());
					if (this.firstMaster) {
						logger.info("++ [Removed process]I[master] am the master of master. "
								+ "So Now I control member up and member removed");
					} else {
						logger.info("++ [Removed process]I[master] am not the master of master."
								+ " So Another master[{}] contols member up and member removed", member.address());
					}

					return;
				}

				/*
				 * master node가 여러개 있는 경우 the master of master가 아닌 경우 아무런 처리를 하지
				 * 않는다
				 */
				if (this.supportMasterPriority == true && this.firstMaster == false) {
					this.logger.info("++ [Removed process]I am not the master of master. So I don't control "
							+ "worker node removed and failover");
					return;
				}

				/*
				 * down된 node의 상태를 VAS_FR_NODE table에서 removed로 변경하고 변경전 node
				 * 정보를 가져온다
				 */
				Node deletedNode = changeMatchingNodeStatusAndgetOldStatus(member);
				if (deletedNode == null) {
					logger.info("++ [Removed process]Failed fail-over this Member[address:{}] "
							+ "because of already failover by another master node or DB error", member.address());
					return;
				}

				logger.info("++ [Removed process]Node Id = [{}] changed into [removed]", deletedNode.getNodeId());

				/*
				 * down된 node가 standby 상태였다면 아무것도 하지 않는다. 상태를 removed르 변경한다.
				 */
				if (deletedNode.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)) {

					logger.info("++ [Removed process]Node Id = [{}] role is [standby]. So nothing to do !!",
							deletedNode.getNodeId());
					return;
				}

				/*
				 * down된 node가 active 상태였다면 standby node가 없는경우 from to를 삭제하지
				 * 않는다. standby node가 있는 경우 from to 를 삭제한다.
				 */
				else if (deletedNode.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_ACTIVE)) {
					/*
					 * 1. failover를 위한 standby node가 있는지 찾는다
					 */
					int failoverNodeId = findFailoverNodeOfGroup(deletedNode.getNodeClass(), deletedNode.getNodeId());

					/*
					 * 2. standby node가 없는경우 from to를 삭제하지 않는다.
					 */
					if (failoverNodeId < 0 && deletedNode.getNodeClass().equals(Node.NodeClass.NODE_CLASS_MATCHING)) {
						this.logger.info("++ [Removed process] Member(address:{}, Node Id=[{}])"
								+ " becomes [removed] but there are no standby node in same matching group !!!. "
								+ "removed process ends", member.address(), deletedNode.getNodeId());
						if (supportAutoActive) {
							// VAS_FR_NODE에 할당된 관심인물 index info를 삭제하지 않는다
							// 재 기동에 대비해서 그대로 둔다

						} else {
							routingProcessor.clearConcernIndex(deletedNode.getNodeId());
						}

						return;

					} else if (failoverNodeId > 0
							&& deletedNode.getNodeClass().equals(Node.NodeClass.NODE_CLASS_MATCHING)) {
						logger.info("++ [Removed process]Removed node(Node Id=[{}]) find fail-over node Id=[{}]",
								deletedNode.getNodeId(), failoverNodeId);

						HashMap<Integer, Integer> volumeInfo = routingProcessor
								.selectConcernMatchingVolumeInfo(deletedNode.getNodeId());
						/*
						 * 3. standby node가 있는경우 deleted node의 from to를 삭제하고
						 */
						routingProcessor.clearConcernIndex(deletedNode.getNodeId());
						/*
						 * 4. standby node가 있는경우 failoverNode의 from to를 기록한
						 */
						routingProcessor.insertMatchingNodeCncrnIndex(failoverNodeId, volumeInfo.get("from_idx"),
								volumeInfo.get("to_idx"));

					} else {
						logger.info(
								"++ [Removed process] Removed node(Node Id=[{}]) class is not [matching-cluster]. Nothing to do",
								deletedNode.getNodeId());

						return;
					}

					if (deletedNode.getNodeClass().equalsIgnoreCase(Node.NodeClass.NODE_CLASS_MATCHING)) {
						startFailoverNodeAndUpdateForMatching(deletedNode, failoverNodeId);
					}
				}

			} catch (Exception ex7) {
				logger.error("++ [Exception] Fail to handle [Member removed]. Exception : [{}]",
						getPrintStacTraceString(ex7));
			}

		}

		/*
		 * from: AKKA cluster
		 */
		else if (msg instanceof ReachableMember) {
			try {

				ReachableMember ev = (ReachableMember) msg;
				Member member = ev.member();
				this.logger.info("++ Member(address:{}) becomes reachable.", member.address());

				if (isAnotherMasterNode(member)) {
					this.logger
							.info("++ Another Master node = {} becomes rechable but nothing to do", member.address());

					return;
				}

				// reachable, unreachable상태 모두 아무런 처리를 하지 않는다. 그래서 주석처리
				// registerWorkerNode(ev.member().address());
			} catch (Exception ex8) {
				logger.error("++ [Exception] Fail to handle [ReachableMember]. Exception : [{}]",
						getPrintStacTraceString(ex8));
			}
		}
		/*
		 * from AKKA cluster
		 */
		else if (msg instanceof MemberEvent) {
			MemberEvent ev = (MemberEvent) msg;
			MemberStatus ms = ev.member().status();
			if (ms == MemberStatus.joining()) {
				logger.info("++ MeberEvent called member{} is joining", ev.member());
			}
			if (ms == MemberStatus.up()) {
				logger.info("++ MeberEvent called member{} is up", ev.member());
			}
			if (ms == MemberStatus.down()) {
				logger.info("++ MeberEvent called member{} is down", ev.member());
			}
			if (ms == MemberStatus.removed()) {
				logger.info("++ MeberEvent called member{} is removed", ev.member());
			}
			if (ms == MemberStatus.leaving()) {
				logger.info("++ MeberEvent called member{} is leaving", ev.member());
			}
			if (ms == MemberStatus.exiting()) {
				logger.info("++ MemberEvent called member{}; is exiting", ev.member());
			}
		} else {
			this.unhandled(msg);
		}
	}

	private void registerMatchingWorkerNode(Address workerAddress) {

		/*
		 * 새롭게 AKKA에 등록된 Member의 Ip address, port 정보 획득
		 */
		// Address = akka.tcp://WatzEyeVAS@10.250.46.50:1111, ==>
		// user/faceDetectionService는 없음에 주의
		Address addr = workerAddress;
		// addrnport = WatzEyeVAS@10.250.46.50:1111
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		int fromIdx = -1;
		int toIdx = -1;

		/*
		 * VAS_FR_NODE table의 node 상태 정보를 이전 상태에 관계 없이 초기화
		 */
		// 해당 node의 현재 정보를 읽어 온다
		Node nodeFromDB = routingProcessor.getNodeInfo(address, port);
		HashMap<Integer, Integer> volumeInfo = routingProcessor.selectConcernMatchingVolumeInfo(address, port);

		if (nodeFromDB == null) {
			logger.debug("++ [MemberUP process]current node[{}:{}] is new one and No data in VAS_FR_NODE table",
					address, port);

		} else {
			logger.debug("++ [MemberUP process]current node[{}] already exists in DB", nodeFromDB);
		}

		if (nodeFromDB == null) {

			// VAS_FR_NODE table에 해당 node가 없으면 새로운 node를 만들고 초기화한다
			logger.debug("++ [MemberUP process] make new node in VAS_FR_NODE table ");

			volumeInfo = routingProcessor.selectConcernMatchingVolumeInfo(address, port);

			boolean ret = false;

			// make new node
			if (volumeInfo == null) {
				ret = routingProcessor.makeNewMatchingNode(address, port, Role.NODE_ROLE_STANDBY);
			} else {
				fromIdx = volumeInfo.get("from_idx");
				toIdx = volumeInfo.get("to_idx");
				ret = routingProcessor.makeNewMatchingNode(address, port, Role.NODE_ROLE_ACTIVE);
			}

			if (ret == false) {
				logger.error("++ [MemberUP process] fail to insert node data in VAS_FR_NODE, "
						+ "because there is no related-Node info in VAS_NODE where IP = [{}], Port = [{}] !!!"
						+ "Please, check VAS_NODE table", address, port);
				return;
			}

			// DB에 insert한 해당 node 정보를 다시 VAS_FR_NODE에서 가져온다
			nodeFromDB = routingProcessor.getNodeInfo(address, port);
			if (nodeFromDB.getRole().equalsIgnoreCase(Role.NODE_ROLE_ACTIVE)) {
				updateNodeStatusWithNodeClass(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START,
						Node.NodeClass.NODE_CLASS_MATCHING);
			}

			logger.debug(
					"++ [MemberUP process] Making new matching node is done. node id = [{}], node role = [{}] concern face from index = [{}],"
							+ "to index = [{}]", nodeFromDB.getNodeId(), nodeFromDB.getRole(), fromIdx, toIdx);
			return;
		}

		/*
		 * VAS_FR_NODE table에 이미 기존 정보가 있는 경우
		 */

		int nodeId = nodeFromDB.getNodeId();
		String role = nodeFromDB.getRole();
		String nodeStatus = nodeFromDB.getNodeStatus();
		String nodeClass = nodeFromDB.getNodeClass();
		if (volumeInfo != null) {
			fromIdx = volumeInfo.get("from_idx");
			toIdx = volumeInfo.get("to_idx");
		} else {
			fromIdx = toIdx = -1;
		}

		// DB에 기록된 role이 없는 경우
		if (nodeFromDB.getRole() == null || nodeFromDB.getRole() == "") {

			if (fromIdx != -1 && toIdx != -1) {
				nodeFromDB.setRole(Node.Role.NODE_ROLE_ACTIVE);
				updateNodeStatusWithNodeClass(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_START,
						Node.NodeClass.NODE_CLASS_MATCHING);

				logger.debug("++ [MemberUP process] current node Id = [{}] already exists in DB. "
						+ "but doen't have any role." + "So. role changned into [active]", nodeId);

			} else {
				// concerned face index가 없으면 standby로 설정
				nodeFromDB.setRole(Node.Role.NODE_ROLE_STANDBY);
				updateNodeStatusWithNodeClass(nodeFromDB.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_INITIAL,
						Node.NodeClass.NODE_CLASS_MATCHING);
				logger.debug("++ [MemberUP process] current node Id = [{}] already exists in DB. "
						+ "but doen't have any role." + "So. role changned into [standby]", nodeId);
			}

			return;
		}

		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_ACTIVE)) {
			/*
			 * Active 상태이면, 아무것도 하지 않는다 worker node는 정상이지만 master node만 down되었다가
			 * 재 기동되었기 때문임
			 */
			logger.debug("++ [MemberUP process]Member is up but node's role is [active]."
					+ " So remain concern face index from DB : node id = [{}] ", nodeId);

			/*
			 * send active message to worker node
			 */			
			logger.debug("++ [MemberUP process] node id = [{}] will get message [{}] !", nodeId);
			sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, nodeId);

		}

		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)) {
			/*
			 * Standby 상태이면, VAS_FR_NODE_CCTV table에서 해당 Node id에 할당된 concern
			 * face id를 clear
			 */
			logger.debug("++ [MemberUP process]Member is up but node's role is [standby]. "
					+ "So clear cncern face index from DB : node id = [{}]", nodeId);
			routingProcessor.clearConcernIndex(nodeFromDB.getNodeId());

			/*
			 * send standby message to worker node
			 */
			logger.debug("++ [MemberUP process] node id = [{}] will get message [upload concerned face data again from DB ] !",
					nodeId);
			sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, nodeId);

		}

		// VAS_FR_NODE에 해당 node가 기 존재하고 node.role이 "na"이면 node 정보를 초기화한다
		if (role.equalsIgnoreCase(Node.Role.NODE_ROLE_NA)) {

			if (nodeStatus.equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
				logger.debug(
						"++ [MemberUP process]Member is up but node's role is [na] and status is [removed_failover]. "
								+ "So role changed into [standby]. clear cncern face index from DB : node id = [{}]",
						nodeId);
				routingProcessor.resetMatchingNode(address, port, nodeClass, Node.Role.NODE_ROLE_STANDBY);
				routingProcessor.clearConcernIndex(nodeId);

				/*
				 * send standby message to worker node
				 */
				logger.debug("++ [MemberUP process] node id = [{}] will get message [{}] !", nodeId);
				sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, nodeId);

			} else {

				if (fromIdx != -1 && toIdx != -1) {
					logger.debug("++ [MemberUP process]Member is up but node's role is [na], status is [{}] "
							+ "and has concerned face index." + "So role changed into [active]. node id = [{}]", nodeId);

					routingProcessor.resetMatchingNode(address, port, nodeClass, Node.Role.NODE_ROLE_ACTIVE,
							Node.NodeStatus.NODE_STATUS_STARTED);

					/*
					 * send active message to worker node
					 */
					logger.debug("++ [MemberUP process] node id = [{}] will get message [{}] !", nodeId);
					sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, nodeId);

				} else {
					logger.debug("++ [MemberUP process]Member is up but node's role is [na], status is [{}] "
							+ "and has no concerned face index." + "So role changed into [standby]. node id = [{}]",
							nodeId);
					routingProcessor.resetMatchingNode(address, port, nodeClass, Node.Role.NODE_ROLE_STANDBY);

					/*
					 * send standby message to worker node
					 */
					logger.debug("++ [MemberUP process] node id = [{}] will get message [{}] !", nodeId);
					sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, nodeId);
				}
			}
		}

	}
	private void startFailoverNodeAndUpdateForMatching(Node deletedNode, int failoverNodeId) {
		/*
		 * down된 node가 start 상태인 경우 start 상태로 전송
		 */
		if (deletedNode.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STARTED)) {
			logger.debug(
					"++ [Removed process]Node [start] command goes to failover node Id=[{}]. Removed process ends",
					failoverNodeId);
			
			sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, failoverNodeId);

			// update Node in VAS_FR_NODE table
			updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_START,
					Node.NodeClass.NODE_CLASS_MATCHING);
			updateNodeStatusWithNodeClass(deletedNode.getNodeId(),
					NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER, Node.NodeClass.NODE_CLASS_MATCHING);

		}
		/*
		 * down된 node가 stop 상태인 경우 stop 상태로 전송
		 */
		else if (deletedNode.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_STOPPED)) {
			logger.debug("++ [Removed process]Node [stop] command goes to failover node Id=[{}]. Removed process ends",
					failoverNodeId);
			
			sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, failoverNodeId);

			// update Node in VAS_FR_NODE table
			updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_STOP,
					Node.NodeClass.NODE_CLASS_MATCHING);
			updateNodeStatusWithNodeClass(deletedNode.getNodeId(),
					NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER, Node.NodeClass.NODE_CLASS_MATCHING);

		} else {
			logger.debug(
					"++ [Removed process]Node status is [{}], but  [start] command goes to failover node Id=[{}]. Removed process ends",
					deletedNode.getNodeStatus(), failoverNodeId);
			
			sendWorkerMessage(MasterToMatchingWorkerMessage.CODE_UPLOAD_CNCRN_DATA_FROM_DB, failoverNodeId);

			// update Node in VAS_FR_NODE table
			updateNodeStatusWithNodeClass(failoverNodeId, NodeMessage.NodeMessageCode.NM_NODE_START,
					Node.NodeClass.NODE_CLASS_MATCHING);
			updateNodeStatusWithNodeClass(deletedNode.getNodeId(),
					NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER, Node.NodeClass.NODE_CLASS_MATCHING);
		}

	}

	private void updateNodeStatus(int nodeId, int NodeMessageCode) {

		/*
		 * VAS_FR_NODE에서 node 정보를 읽어온다
		 */
		Node updatedNode = routingProcessor.getNodeInfoById(nodeId);
		if (updatedNode == null) {
			logger.error("++ there is no node to update Node status node id = {}", nodeId);
			return;
		}

		// node의 status를 변경
		switch (NodeMessageCode) {
			case NodeMessage.NodeMessageCode.NM_NODE_START :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STARTED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_STOP :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STOPPED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;
			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_INITIAL :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_INITIAL);
				// node의 role을 변경 --> standby로
				updatedNode.setRole(Node.Role.NODE_ROLE_STANDBY);
				break;
		}

		// node의 update time을 변경
		updatedNode.setUpdateTime(BaseUtils.formatToYear2SecString(new Date()));

		// VAS_FR_NODE_CCTV table은 변경하지 않음

		/*
		 * VAS_FR_NODE table의 node에 해당되는 정보를 update (worker node한테 start or stop
		 * message를 보냈으므로)
		 */
		routingProcessor.updateNode(updatedNode);

	}

	private void updateNodeStatusWithNodeClass(int nodeId, int NodeMessageCode, String nodeClass) {

		/*
		 * VAS_FR_NODE에서 node 정보를 읽어온다
		 */
		Node updatedNode = routingProcessor.getNodeInfoById(nodeId);
		if (updatedNode == null) {
			logger.error("++ there is no node to update Node status node id = {}", nodeId);
			return;
		}

		// node의 status를 변경
		switch (NodeMessageCode) {
			case NodeMessage.NodeMessageCode.NM_NODE_START :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STARTED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_STOP :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_STOPPED);
				// node의 role을 변경 --> active로
				updatedNode.setRole(Node.Role.NODE_ROLE_ACTIVE);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;
			case NodeMessage.NodeMessageCode.NM_NODE_REMOVED_FAILOVER :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER);
				// node의 role을 변경 --> not available로
				updatedNode.setRole(Node.Role.NODE_ROLE_NA);
				break;

			case NodeMessage.NodeMessageCode.NM_NODE_INITIAL :
				updatedNode.setNodeStatus(Node.NodeStatus.NODE_STATUS_INITIAL);
				// node의 role을 변경 --> standby로
				updatedNode.setRole(Node.Role.NODE_ROLE_STANDBY);
				break;
		}

		// node의 update time을 변경
		updatedNode.setUpdateTime(BaseUtils.formatToYear2SecString(new Date()));

		// node class 를 변경
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_LIVE)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_LIVE);
		}
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_ONDEMAND)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_ONDEMAND);
		}
		if (nodeClass.equalsIgnoreCase(Node.NodeClass.NODE_CLASS_INITAL)) {
			updatedNode.setNodeClass(Node.NodeClass.NODE_CLASS_INITAL);
		}

		// VAS_FR_CCTV table은 변경하지 않음

		/*
		 * VAS_FR_NODE table의 node에 해당되는 정보를 update (worker node한테 start or stop
		 * message를 보냈으므로)
		 */
		routingProcessor.updateNode(updatedNode);

	}

	private Node changeNodeStatusAndgetOldStatus(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return null;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address addr = member.address();
		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_NODE_SRVC table의 node 상태 정보를 [removed]로 변경
		 */

		// 해당 node의 현재 정보를 읽어 온다
		Node node = routingProcessor.getNodeInfo(address, port);
		if (node == null) {
			// 해당 node가 없으면 예외상황으로 종료
			this.logger.warning("++ removed node = {} from AKKA doesn't have any information in VAS_FR_NODE table",
					addr.toString());
			return null;
		}

		// 다른 master node가 이미 removed-failover 한 상태인지 확인
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
			return null;
		}

		// 해당 node의 상태 정보를 removed로 변경한다
		updateNodeStatus(node.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_REMOVED);

		return node;

	}

	private Node changeMatchingNodeStatusAndgetOldStatus(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return null;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address addr = member.address();
		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_NODE_SRVC table의 node 상태 정보를 [removed]로 변경
		 */

		// 해당 node의 현재 정보를 읽어 온다
		Node node = routingProcessor.getNodeInfo(address, port);
		if (node == null) {
			// 해당 node가 없으면 예외상황으로 종료
			this.logger
					.warning(
							"++ [Removed process] removed node = [{}] doesn't have any info in VAS_FR_NODE table. nothing to do",
							addr.toString());
			return null;
		}

		// 다른 master node가 이미 removed-failover 한 상태인지 확인
		if (node.getNodeStatus().equalsIgnoreCase(Node.NodeStatus.NODE_STATUS_REMOVED_FAILOVER)) {
			return null;
		}

		// 해당 node의 상태 정보를 removed로 변경한다
		updateNodeStatus(node.getNodeId(), NodeMessage.NodeMessageCode.NM_NODE_REMOVED);

		return node;

	}

	private int findFailoverNode(String nodeClass) {

		int error = -1;

		/*
		 * VAS_FR_NODE table에서 standby인 node를 찾는다
		 */
		List<Node> nodeList = routingProcessor.getNodeList();

		if (nodeList == null) {
			return error;
		}

		if (nodeList.size() == 0) {
			return error;
		}

		for (Node node : nodeList) {
			if (node.getRole().equalsIgnoreCase(Node.Role.NODE_ROLE_STANDBY)
					&& node.getNodeClass().equalsIgnoreCase(nodeClass)) {
				return node.getNodeId();
			}
		}
		return error;

	}

	private int findFailoverNodeOfGroup(String nodeClass, int nodeId) {

		int error = -1;

		/*
		 * 동일한 matching group의 node list를 가져온다
		 */
		List<Node> nodeList = routingProcessor.getMatchingNodeListOfGroup(nodeId);

		if (nodeList == null) {
			return error;
		}

		if (nodeList.size() == 0) {
			return error;
		}

		return nodeList.get(0).getNodeId();

	}

	/*
	 * Member Up이 될 때 Master가 member up이 되는지 확인
	 */
	private boolean isMasterNode(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return true;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address addr = member.address();
		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		if (masterAddress.equals(address) && masterPort.equals(port)) {
			return true;
		}

		return false;
	}

	/*
	 * Member Up이 될 때 다른 쪽에 설치된 Master가 member up이 되는지 확인
	 */
	private boolean isAnotherMasterNode(Member member) {

		if (member == null) {
			this.logger.warning("Specified member is null, which is not expected.");
			return true;
		}

		/*
		 * 다른 master node가 member up 되는 경우를 확인
		 */
		Set<String> roleSet = member.getRoles();
		for (String role : roleSet) {
			if (role.equalsIgnoreCase(MASTER_ROLE))
				return true;
		}

		return false;
	}

	/*
	 * Member address:port를 정수값으로 변환하면 unique한 master node value를 생성할 수 있다
	 */
	private long getUniqueNodeValueFromAddress(Member member) {

		if (member == null) {
			this.logger.warning("++ Specified member is null, which is not expected.");
			return -1;
		}

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		Address address = member.address();
		// actorAddrNport = actorsystem_name@192.168.0.1:2248
		String actorAddrNport = address.hostPort();
		String array[] = actorAddrNport.split("@|:"); // split with "@" or ":"
		String addressNport = array[1] + array[2]; // 192.168.0.1:2248

		/*
		 * address와 port를 합쳐서 long으로 변환. 이 값은 unique하게 됨
		 */
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		return Long.valueOf(uniqueString);
	}

	/*
	 * Member address:port를 정수값으로 변환하면 unique한 master node value를 생성할 수 있다
	 */
	private long getUniqueNodeValueFromAddress(String address, String port) {

		/*
		 * Member의 Ip address, port 정보 획득
		 */
		String addressNport = address + port; // 192.168.0.1:2248

		/*
		 * address와 port를 합쳐서 long으로 변환. 이 값은 unique하게 됨
		 */
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		return Long.valueOf(uniqueString);
	}

	private Node getNodeFromAddress(Address addr, String prefixLog) {
		/*
		 * 새롭게 AKKA에 등록된 Member의 Ip address, port 정보 획득
		 */
		// Address = akka.tcp://WatzEyeVAS@10.250.46.50:1111, ==>
		// user/faceDetectionService는 없음에 주의
		// Address addr = workerAddress;
		// addrnport = WatzEyeVAS@10.250.46.50:1111
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@|:"); // split with "@" or ":"
		String address = array[1];
		String port = array[2];

		/*
		 * VAS_FR_NODE table의 node 상태 정보를 이전 상태에 관계 없이 초기화
		 */
		// 해당 node의 현재 정보를 읽어 온다
		Node nodeFromDB = routingProcessor.getNodeInfo(address, port);
		if (nodeFromDB == null) {
			logger.debug("{} current node[{}:{}] doesn't exist in DB", prefixLog, address, port);

		} else {
			logger.debug("{} current node[{}] exists in DB", prefixLog, nodeFromDB);
		}

		return nodeFromDB;
	}

	/*
	 * address,port에 해당되는 값이 master priority TreeSet의 첫 번째에 존재하는지 확인
	 */
	private boolean isFirstElement(String address, String port) {
		String addressNport = address + port; // 192.168.0.1:2248
		// address:port를 숫자로 변환
		String uniqueString = addressNport.replaceAll("[.]|[:]", ""); // 192168012248
		long uniqueValue = Long.valueOf(uniqueString);

		// TreeSet에서 첫번째 값을 구한다
		if (this.masterPriority.size() == 0)
			return true;

		long first = this.masterPriority.first();

		// 입력으로 받은 member가 TreeSet의 첫번째 값에 해당되는지 확인한다
		if (first == uniqueValue)
			return true;
		else
			return false;
	}

	public static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}
	
	private void sendWorkerMessage(int messageCode, int nodeId) {
		
		MasterToMatchingWorkerMessage mtm = new MasterToMatchingWorkerMessage(
				messageCode, nodeId);
		
		sendWorkerMessageWithoutRouter(mtm, nodeId);
		
	}

	private void sendWorkerMessageWithoutRouter(MasterToMatchingWorkerMessage msg, int nodeId) {

		Cluster cluster = Cluster.get(getContext().system());
		// addr = akka.tcp://WatzEyeFRSMatching@203.235.192.41:3333
		Address addr = cluster.selfAddress();

		// addrnport = actorsystem_name@localhost:port
		String addrnport = addr.hostPort();
		String array[] = addrnport.split("@"); // split with "@"
		String actorSystemName = array[0];

		/*
		 * VAS_FR_NODE table에서 모든 node id에 해당되는 node 정보를 가져온다
		 */
		Node node = routingProcessor.getNodeInfoById(nodeId);
		if (node == null) {
			logger.warning("++ There in no node list. So message[{}] doesn't go to workers", msg);
			return;
		}

		/*
		 * Node role이 standby, active인 경우 node path를 생성한다
		 */
		if (node.getRole().equalsIgnoreCase("na")) {
			logger.warning("++ Node[{}] role is 'na'. So message[{}] doesn't go to workers", node, msg);
			return;
		}

		String nodePath = new StringBuilder().append(addr.protocol()).append("://").append(actorSystemName).append("@")
				.append(node.getIpAddress()).append(":").append(node.getPort()).append("/user/")
				.append(this.routeeName).toString();

		this.getContext().actorSelection(nodePath).tell(msg, getSelf());
		logger.info("++ Worker messsage(without router) = {} goes to worker node = {}", msg, nodePath);

	}

}// end of main
