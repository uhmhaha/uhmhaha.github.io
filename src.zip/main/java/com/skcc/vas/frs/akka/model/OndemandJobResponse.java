package com.skcc.vas.frs.akka.model;

public class OndemandJobResponse implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public static final int SUB_JOB_SUCCESS = 1;

	private int jobType;

	private String jobId;

	private int jobCode;

	private int nodeId;

	private int subJobResult;

	private String subJobResultMessage;

	public OndemandJobResponse(String jobId, int jobType, int jobCode, int nodeId, int subJobResult,
			String subJobResultMessage) {
		this.jobId = jobId;
		this.jobType = jobType;
		this.jobCode = jobCode;
		this.nodeId = nodeId;
		this.subJobResult = subJobResult;
		this.subJobResultMessage = subJobResultMessage;
	}

	public int getJobType() {
		return jobType;
	}

	public void setJobType(int jobType) {
		this.jobType = jobType;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getJobCode() {
		return jobCode;
	}

	public void setJobCode(int jobCode) {
		this.jobCode = jobCode;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public int getSubJobResult() {
		return subJobResult;
	}

	public void setSubJobResult(int subJobResult) {
		this.subJobResult = subJobResult;
	}

	public String getSubJobResultMessage() {
		return subJobResultMessage;
	}

	public void setSubJobResultMessage(String subJobResultMessage) {
		this.subJobResultMessage = subJobResultMessage;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("OndemandJobResponse class =");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" Job Type = [" + OndemandJobConstant.JobType.getJobName(jobType) + "]");
		sb.append(" Job Code = [" + OndemandJobConstant.JobCode.getJobCodeName(jobCode) + "]");
		sb.append(" Node id =[" + nodeId + "]");
		sb.append(" subJobResult = [" + subJobResult + "]");
		sb.append(" subJobResult Message = [" + subJobResultMessage + "]");

		return sb.toString();
	}

}
