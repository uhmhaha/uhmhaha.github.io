package com.skcc.vas.frs.akka.routing;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import org.apache.commons.lang3.Validate;

/**
 * @author
 * @since 2016-06-16
 *
 * @param <K>
 *            type for the key core
 * @param <M>
 *            type for the message
 */
@Immutable
public final class KeyedMessage<K extends java.io.Serializable, M extends java.io.Serializable>
		implements
			Keyed<K>,
			java.io.Serializable {

	private static final long serialVersionUID = 2L;

	private final Key<K> key;

	private final M message;

	public KeyedMessage(@Nonnull Key<K> key, @Nullable M msg) {
		Validate.isTrue(key != null, "The key should be provided.");

		this.key = key;
		this.message = msg;
	}

	public KeyedMessage(@Nonnull K key, @Nullable M msg) {
		Validate.isTrue(key != null, "The key should be provided.");

		this.key = new Key<K>(key);
		this.message = msg;
	}

	@Override
	@Nonnull
	public Key<K> getKey() {
		return this.key;
	}

	@Nullable
	public M getMessage() {
		return this.message;
	}
}
