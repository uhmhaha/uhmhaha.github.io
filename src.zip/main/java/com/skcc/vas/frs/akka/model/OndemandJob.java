package com.skcc.vas.frs.akka.model;

import java.util.List;

public class OndemandJob implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int jobType;

	private String jobId;

	private int jobCode;

	private List<OndemandDBSubJob> dbSubJobs;
	private List<OndemandVMSSubJob> vmsSubJobs;
	private List<OndemandVideoSubJob> videoSubJobs;

	private List<Integer> standbyNodeIds;

	public OndemandJob(int jobType, String jobId, int jobCode) {
		this.jobType = jobType;
		this.jobId = jobId;
		this.jobCode = jobCode;
		this.dbSubJobs = null;
		this.vmsSubJobs = null;
		this.videoSubJobs = null;
		this.standbyNodeIds = null;
	}

	public OndemandJob(int jobType, String jobId, int jobCode, List<OndemandDBSubJob> dbSubJobs,
			List<OndemandVMSSubJob> vmsSubJobs, List<OndemandVideoSubJob> videoSubJobs, List<Integer> standbyNodes) {
		this.jobType = jobType;
		this.jobId = jobId;
		this.jobCode = jobCode;
		this.dbSubJobs = dbSubJobs;
		this.vmsSubJobs = vmsSubJobs;
		this.videoSubJobs = videoSubJobs;
		this.standbyNodeIds = standbyNodes;
	}

	public int getJobType() {
		return jobType;
	}

	public void setJobType(int jobType) {
		this.jobType = jobType;
	}

	public List<OndemandDBSubJob> getDBSubJobs() {
		return dbSubJobs;
	}

	public void setDBSubJobs(List<OndemandDBSubJob> dbSubJobs) {
		this.dbSubJobs = dbSubJobs;
	}

	public List<OndemandVideoSubJob> getVideoSubJobs() {
		return videoSubJobs;
	}

	public void setVideoSubJobs(List<OndemandVideoSubJob> videoSubJobs) {
		this.videoSubJobs = videoSubJobs;
	}

	public List<OndemandVMSSubJob> getVMSSubJobs() {
		return vmsSubJobs;
	}

	public void setVMSSubJobs(List<OndemandVMSSubJob> vmsSubJobs) {
		this.vmsSubJobs = vmsSubJobs;
	}

	public int getNumOfSubJobs() {
		if (jobType == OndemandJobConstant.JobType.DBJOB) {

			return dbSubJobs.size();

		} else if (jobType == OndemandJobConstant.JobType.VMSJOB) {

			return vmsSubJobs.size();

		} else if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {

			return videoSubJobs.size();

		} else {
			return 0;
		}
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getJobCode() {
		return jobCode;
	}

	public void setJobCode(int jobCode) {
		this.jobCode = jobCode;
	}

	public List<OndemandDBSubJob> getDbSubJobs() {
		return dbSubJobs;
	}

	public void setDbSubJobs(List<OndemandDBSubJob> dbSubJobs) {
		this.dbSubJobs = dbSubJobs;
	}

	public List<OndemandVMSSubJob> getVmsSubJobs() {
		return vmsSubJobs;
	}

	public void setVmsSubJobs(List<OndemandVMSSubJob> vmsSubJobs) {
		this.vmsSubJobs = vmsSubJobs;
	}

	public List<Integer> getStandbyNodeIds() {
		return standbyNodeIds;
	}

	public void setStandbyNodeIds(List<Integer> standbyNodeIds) {
		this.standbyNodeIds = standbyNodeIds;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("OndemandJob class =");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" Job Type = [" + OndemandJobConstant.JobType.getJobName(jobType) + "]");
		sb.append(" Job Code = [" + OndemandJobConstant.JobCode.getJobCodeName(jobCode) + "]");
		if (standbyNodeIds != null) {
			sb.append(" Stanby Node id = [ ");
			for (int standbyNodeId : standbyNodeIds) {
				sb.append(standbyNodeId + ", ");
			}
			sb.append(" ]");
		}
		if (jobType == OndemandJobConstant.JobType.DBJOB) {
			if (dbSubJobs != null)
				for (OndemandDBSubJob subJob : dbSubJobs)
					sb.append(" subJob: " + subJob.toString());
		} else if (jobType == OndemandJobConstant.JobType.VMSJOB) {
			if (vmsSubJobs != null)
				for (OndemandVMSSubJob subJob : vmsSubJobs)
					sb.append(" subJob: " + subJob.toString());
		} else if (jobType == OndemandJobConstant.JobType.VIDEOJOB) {
			if (videoSubJobs != null)
				for (OndemandVideoSubJob subJob : videoSubJobs)
					sb.append(" subJob: " + subJob.toString());
		}

		return sb.toString();
	}

}
