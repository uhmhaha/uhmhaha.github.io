package com.skcc.vas.frs.akka.routing;

import javax.annotation.Nonnull;
import org.apache.commons.lang3.Validate;
import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.routing.ActorSelectionRoutee;

/**
 * @author
 * @since 2016-06-07
 *
 * @param <T>
 */
public class KeyedActorSelectionRoutee<T extends java.io.Serializable> extends ActorSelectionRoutee
		implements
			KeyedRoutee<T> {

	private final Key<T> key;

	public KeyedActorSelectionRoutee(@Nonnull T key, @Nonnull ActorSelection selection) {
		this(new Key<T>(key), selection);
	}

	public KeyedActorSelectionRoutee(@Nonnull Key<T> key, @Nonnull ActorSelection selection) {
		super(selection);

		Validate.isTrue(key != null, "The key should be non-null value.");
		Validate.isTrue(selection != null, "The actor selection for this routee should be provided.");
		this.key = key;
	}

	@Override
	public Key<T> getKey() {
		return this.key;
	}

	@Override
	public void send(Object msg, ActorRef sender) {
		if (!(msg instanceof Keyed)) {
			// @TODO Not yet implemented.
			// Raise exception or ?
		}
		super.send(msg, sender);

	}

}
