package com.skcc.vas.frs.akka.model;

import java.util.List;

/**
 * Message definition between master and worker nodes
 * 
 * @author Na Hoon
 * @since 2016. 9. 12
 *
 */
public class NodeMessage implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private static int NODE_ID_NOT_DEFINED = -1;
	private static int CCTV_ID_NOT_DEFINED = -2;

	public static class NodeMessageCode {
		// define message code
		public static final int NM_NODE_START = 1;
		public static final int NM_NODE_STOP = 2;
		public static final int NM_NODE_REMOVED = 3;
		public static final int NM_NODE_REMOVED_FAILOVER = 4;
		public static final int NM_NODE_INITIAL = 5;

		public static final int NM_NODE_ADD_CCTV = 10;
		public static final int NM_NODE_REMOVE_CCTV = 11;

		public static final int NM_CNCRN_FACE_DB_UPDATED = 23;

		public static final int NM_NODE_START_ALL = 30;
		public static final int NM_NODE_STOP_ALL = 31;

		public static final int NM_NODE_ROI_UPDATED_IN_ONE_DEVICE = 40;

		public static final int NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES = 50;
		public static final int NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ONE_DEVICE = 51;
	}

	// message code
	private int messageCode;

	// VMS Id
	private String systemId;

	// node Id
	private int nodeId;

	// cctv id in node
	private String cctvId;

	private String personId;

	private List<String> faceIds;
	
	private int faceIdFrom;
	
	private int faceIdTo;

	public int getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(int messageCode) {
		this.messageCode = messageCode;
	}

	public String getSystemId() {
		return systemId;
	}

	public NodeMessage(int code, String systemId) {
		this.messageCode = code;
		this.systemId = systemId;
		this.nodeId = NODE_ID_NOT_DEFINED;
		this.cctvId = Integer.toString(CCTV_ID_NOT_DEFINED);

	}

	public NodeMessage(int code, String systemId, int nodeId) {
		this.messageCode = code;
		this.systemId = systemId;
		this.nodeId = nodeId;
		this.cctvId = Integer.toString(CCTV_ID_NOT_DEFINED);

	}

	public NodeMessage(int code, String systemId, int nodeId, String cctvId) {
		this.messageCode = code;
		this.systemId = systemId;
		this.nodeId = nodeId;
		this.cctvId = cctvId;
	}

	public NodeMessage(int code, String systemId, String cctvId) {
		this.messageCode = code;
		this.systemId = systemId;
		this.nodeId = NODE_ID_NOT_DEFINED;
		this.cctvId = cctvId;
	}

	public NodeMessage(int code, String systemId, String cctvId, String personId) {
		this.messageCode = code;
		this.systemId = systemId;
		this.cctvId = Integer.toString(CCTV_ID_NOT_DEFINED);
		this.personId = personId;
	}

	public NodeMessage(int code, String systemId, String cctvId, List<String> faceList) {
		this.messageCode = code;
		this.systemId = systemId;
		this.cctvId = Integer.toString(CCTV_ID_NOT_DEFINED);
		this.faceIds = faceList;
	}
	
	public NodeMessage(int code, String systemId, int faceIdFrom, int faceIdTo) {
		this.messageCode = code;
		this.systemId = systemId;
		this.faceIdFrom = faceIdFrom;
		this.faceIdTo = faceIdTo;
		this.cctvId = Integer.toString(CCTV_ID_NOT_DEFINED);
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getCctvId() {
		return cctvId;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public List<String> getFaceIds() {
		return faceIds;
	}

	public void setFaceIds(List<String> faceIds) {
		this.faceIds = faceIds;
	}
	
	public int getFaceIdFrom() {
		return faceIdFrom;
	}

	public void setFaceIdFrom(int faceIdFrom) {
		this.faceIdFrom = faceIdFrom;
	}

	public int getFaceIdTo() {
		return faceIdTo;
	}

	public void setFaceIdTo(int faceIdTo) {
		this.faceIdTo = faceIdTo;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("NodeMessage class =");

		if (nodeId == NODE_ID_NOT_DEFINED) {
			sb.append(" Node ID [ not defined ]");
		} else {
			sb.append(" Node ID [" + nodeId + "]");
		}

		if (systemId != null) {
			sb.append(" system Id [" + systemId + "]");
		}

		if (!cctvId.equalsIgnoreCase(Integer.toString(CCTV_ID_NOT_DEFINED))) {
			sb.append(" cctv id [" + cctvId + "]");
		}

		if (personId != null) {
			sb.append(" person id [" + personId + "]");
		}

		if (faceIds != null && faceIds.size() != 0) {
			sb.append("face id [ ");
			for (int i = 0; i < faceIds.size(); i++) {
				sb.append(faceIds.get(0));
			}
			sb.append(" ] ");
		}

		sb.append(" Message code [" + messageCodeToString(messageCode) + "]");

		return sb.toString();

	}

	private String messageCodeToString(int messageCode) {

		String messageCodeString = "not defined";

		switch (messageCode) {
			case NodeMessageCode.NM_NODE_START :
				messageCodeString = "node_start";
				break;
			case NodeMessageCode.NM_NODE_STOP :
				messageCodeString = "node_stop";
				break;
			case NodeMessageCode.NM_NODE_REMOVED :
				messageCodeString = "node_removed";
				break;
			case NodeMessageCode.NM_NODE_REMOVED_FAILOVER :
				messageCodeString = "node_removed_failover";
				break;
			case NodeMessageCode.NM_NODE_INITIAL :
				messageCodeString = "node_initial";
				break;
			case NodeMessageCode.NM_NODE_ADD_CCTV :
				messageCodeString = "node_add_cctv";
				break;
			case NodeMessageCode.NM_NODE_REMOVE_CCTV :
				messageCodeString = "node_remove_cctv";
				break;
			case NodeMessageCode.NM_CNCRN_FACE_DB_UPDATED :
				messageCodeString = "node_concerned_face_db_updated";
				break;
			case NodeMessageCode.NM_NODE_START_ALL :
				messageCodeString = "node_start_all";
				break;
			case NodeMessageCode.NM_NODE_STOP_ALL :
				messageCodeString = "node_stop_all";
				break;
			case NodeMessageCode.NM_NODE_ROI_UPDATED_IN_ONE_DEVICE :
				messageCodeString = "ROI_updated_in_one_cctv";
				break;
			case NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES :
				messageCodeString = "FR_engine_parameters_updated_in_all_node";
				break;
			case NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ONE_DEVICE :
				messageCodeString = "FR_engine_parameters_updated_in_one_cctv";
				break;
		}

		return messageCodeString;

	}

}
