package com.skcc.vas.frs.akka.cluster;

import java.net.*;
import javax.annotation.*;
import javax.validation.constraints.*;
import org.apache.commons.lang3.*;
import com.typesafe.config.*;

/**
 * @author
 * @since 2016-06-21
 *
 */
public abstract class ClusterNodeBase extends ServerBase implements ClusterNode {

	private final InetAddress address;

	public InetAddress getAddress() {
		return this.address;
	}

	/**
	 * the TCP/IP port used for this node to communicate with other nodes in the
	 * cluster.
	 */
	private int port;

	/**
	 * Gets thhe TCP/IP port used for this node to communicate with other nodes
	 * in the cluster.
	 *
	 * @return
	 */
	@Min(1)
	@Max(0xFFFF)
	public int getPort() {
		return this.port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public static final int NO_DEFINED_PORT = 1;

	/**
	 * @param systemName
	 * @param applName
	 * @param nodePort
	 *            the TCP/IP port used for this node to communicate with other
	 *            nodes in the cluster
	 * @param configSubtree
	 */
	public ClusterNodeBase(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, @Min(1) @Max(0xFFFF) int nodePort,
			@Nullable String configSubtree, boolean useConfFile) {
		super(systemName, applName, configSubtree);

		try {
			this.address = InetAddress.getLocalHost();
		} catch (Throwable ex) {
			this.logger.error("Fail to catch the IP address of this machine.", ex);
			throw new IllegalStateException("Fail to catch the IP address of this machine.", ex);
		}

		/*
		 * lan card address와 AKKA의 application.conf에 있는 ip address를 비교해서 동일한지 확인
		 */
		if (useConfFile) {
			try {
				String lanAddress = InetAddress.getLocalHost().getHostAddress();
				String configAddress = this.getConfig().getString("akka.remote.netty.tcp.hostname");

				if (!StringUtils.equals(lanAddress, configAddress)) {
					this.logger.error(
							"address = {} from LAN card and address = {} from application.conf are different",
							lanAddress, configAddress);
					throw new IllegalStateException("IP address mismatch happens !!!");

				}
			} catch (Exception ex) {
				throw new IllegalStateException("Fail to catch the IP address of this machine.", ex);
			}
		}

		// application.conf 파일에 port 정보가 있으면 이를 그대로 사용
		if (nodePort == NO_DEFINED_PORT) {
			this.port = this.getConfig().getInt("akka.remote.netty.tcp.port");
		} else {
			this.port = nodePort;
		}

		if (useConfFile) {
			Config config = ConfigFactory
					.parseString("akka.remote.netty.tcp.hostname=" + this.getAddress().getHostAddress())
					.withFallback(ConfigFactory.parseString("akka.remote.netty.tcp.port=" + this.getPort()))
					.withFallback(this.getConfig());
			this.setConfig(config);
		}
	}

	@Override
	final public void start(boolean allowsLocalRoutees) throws Exception {
		Config config = this.getConfig();

		if (config == null) {
			this.logger.error("The actor system config is not built which is not expected.");
			throw new IllegalStateException("The actor system config is not built which is not expected.");
		}

		config = ConfigFactory.parseString(
				"akka.actor.deployment.default.cluster.allow-local-routees = " + (allowsLocalRoutees ? "on" : "off"))
				.withFallback(config);

		this.setConfig(config);

		this.start();

	}

}
