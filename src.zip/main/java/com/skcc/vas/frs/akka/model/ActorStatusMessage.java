package com.skcc.vas.frs.akka.model;

import akka.actor.Address;
import akka.cluster.Member;

import com.skcc.vas.frs.akka.model.OndemandJobConstant;

public class ActorStatusMessage implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public final static int MASTER_NODE_REGISTRATION = 1;
	public final static int MASTER_NODE_CONFIRMED = 2;
	public final static int WORKER_NODE_REGISTRATION = 3;
	public final static int WORKER_NODE_START_DETECTION_FAILED = 4;
	public final static int WORKER_NODE_STOP_DETECTION_FAILED = 5;
	public final static int WORKER_NODE_UPDATE_TARGET_FAILED = 6;
	public final static int WORKER_NODE_START_DETECTION_SUCCESS = 7;
	public final static int WORKER_NODE_STOP_DETECTION_SUCCESS = 8;
	public final static int WORKER_NODE_UPDATE_TARGET_SUCCESS = 9;
	public final static int WORKER_NODE_ONDEMAND_JOB_START_SUCCESS = 10;
	public final static int WORKER_NODE_ONDEMAND_JOB_START_FAILED = 11;
	public final static int WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS = 12;
	public final static int WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED = 13;

	private int messageCode;

	private Member member;

	private String deviceId;

	private Address masterAddress;
	private Address workerAddress;

	private String ondemandJobId;
	private int ondemandJobType;
	private int ondemandTotalThread;

	public ActorStatusMessage(int messageCode) {
		this.messageCode = messageCode;
		masterAddress = null;
		workerAddress = null;
		member = null;
		deviceId = null;
		ondemandJobId = null;
		ondemandJobType = OndemandJobConstant.JobType.NOT_DEFINED;
		ondemandTotalThread = 0;
	}

	public int getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(int messsageCode) {
		this.messageCode = messsageCode;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Address getWorkerAddress() {
		return workerAddress;
	}

	public void setWorkerAddress(Address workerAddress) {
		this.workerAddress = workerAddress;
	}
	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public Address getMasterAddress() {
		return masterAddress;
	}

	public void setMasterAddress(Address masterAddress) {
		this.masterAddress = masterAddress;
	}

	public String getOndemandJobId() {
		return ondemandJobId;
	}

	public void setOndemandJobId(String ondemandJobId) {
		this.ondemandJobId = ondemandJobId;
	}

	public int getOndemandJobType() {
		return ondemandJobType;
	}

	public void setOndemandJobType(int ondemandJobType) {
		this.ondemandJobType = ondemandJobType;
	}

	public int getOndemandTotalThread() {
		return ondemandTotalThread;
	}

	public void setOndemandTotalThread(int ondemandTotalThread) {
		this.ondemandTotalThread = ondemandTotalThread;
	}

	public boolean isOndemandMessage() {
		if (messageCode == WORKER_NODE_ONDEMAND_JOB_START_SUCCESS)
			return true;
		if (messageCode == WORKER_NODE_ONDEMAND_JOB_START_FAILED)
			return true;
		if (messageCode == WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS)
			return true;
		if (messageCode == WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED)
			return true;

		return false;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("ActorStatusMessage class =");

		sb.append(" messageCode [" + messageCodeToString(messageCode) + "]");

		if (member != null) {
			sb.append(" Member [" + member.toString() + "]");
		}
		if (masterAddress != null) {
			sb.append(" Master Address [" + masterAddress + "]");
		}
		if (workerAddress != null) {
			sb.append(" Worker Address [" + workerAddress + "]");
		}
		if (deviceId != null) {
			sb.append(" Device Id [" + deviceId + "]");
		}
		if (ondemandJobType != OndemandJobConstant.JobType.NOT_DEFINED) {
			sb.append(" Ondemand Job Type = [" + OndemandJobConstant.JobType.getJobName(ondemandJobType) + "]");
			sb.append(" Ondemand Job Id = [" + ondemandJobId + "]");
			sb.append(" Ondemand total thread = [" + ondemandTotalThread + "]");
		}

		return sb.toString();

	}

	private String messageCodeToString(int messageCode) {

		String messageCodeString = "not defined";

		switch (messageCode) {
			case MASTER_NODE_REGISTRATION :
				messageCodeString = "master node registration";
				break;
			case MASTER_NODE_CONFIRMED :
				messageCodeString = "master node confirmed by worker node";
				break;
			case WORKER_NODE_REGISTRATION :
				messageCodeString = "worker node registration";
				break;
			case WORKER_NODE_START_DETECTION_FAILED :
				messageCodeString = "start detection failed";
				break;
			case WORKER_NODE_STOP_DETECTION_FAILED :
				messageCodeString = "stop detection failed";
				break;
			case WORKER_NODE_UPDATE_TARGET_FAILED :
				messageCodeString = "update target failed";
				break;
			case WORKER_NODE_START_DETECTION_SUCCESS :
				messageCodeString = "start detection success";
				break;
			case WORKER_NODE_STOP_DETECTION_SUCCESS :
				messageCodeString = "stop detection success";
				break;
			case WORKER_NODE_UPDATE_TARGET_SUCCESS :
				messageCodeString = "update target success";
				break;
			case WORKER_NODE_ONDEMAND_JOB_START_SUCCESS :
				messageCodeString = "Ondemand job [started] successfully";
				break;
			case WORKER_NODE_ONDEMAND_JOB_START_FAILED :
				messageCodeString = "Ondemand job [started] failed";
				break;
			case WORKER_NODE_ONDEMNAD_JOB_ABORT_SUCCESS :
				messageCodeString = "Ondemand job [aborted] successfully";
				break;
			case WORKER_NODE_ONDEMNAD_JOB_ABORT_FAILED :
				messageCodeString = "Ondemand job [aborted] failed";
				break;
		}

		return messageCodeString;

	}

}
