package com.skcc.vas.frs.akka.model;

import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 *
 */
public class FaceRequest {

	public enum Type {

		@Deprecated
		FACE, @Deprecated
		ADD_FACE,

		@Deprecated
		UPDATE_FACE, @Deprecated
		ADD_FEATURE,

		// @Deprecated REMOVE_FACE,

		@Deprecated
		REMOVE_FEATURE,

		START_CCTV, STOP_CCTV,

		GENERATE_FACE_METAS_BY_PERSON, GENERATE_FACE_METAS, REMOVE_PERSON, UPDATE_PERSON, REMOVE_FACES,

		@Deprecated
		ONDEMAND_FACE_SEARCH, // replaced by SEARCH_FACES
		SEARCH_FACES_VMS, SEARCH_FACES_DB, // DB SEARCH START// on-demand search
		STOP_FACES_DB, // DB SEARCH STOP// on-demand search
		SEARCH_FACE_VIDEO,

		VERIFY_ACCESS, UPDATE_VISITOR, REGISTER_CONCERNED_FACE,

		REGISTER_CONCERNED_FACE_DONE,

		// dynamic routing
		START_NODE, STOP_NODE,

		// dynamic routing
		START_NODE_ALL, STOP_NODE_ALL,

		ROI_UPDATED,

		FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES, FR_ENGINE_PARAMETER_UPDATED_IN_ONE_CCTV,

		// master node checker send this
		HEALTH_CHECK,

		STOP_FACES_VMS, STOP_FACES_VIDEO,

		// ondemand parallel processing
		ONDEMAND_DB_RESULT, ONDEMAND_VMS_RESULT, ONDEMAND_VIDEO_RESULT, ONDEMAND_DB_ABORT_RESULT, ONDEMAND_VMS_ABORT_RESULT, ONDEMAND_VIDEO_ABORT_RESULT;

	}

	private Type type;

	private String id;

	/**
	 * custom parameter object which can be specific to request type.
	 */
	private Object obj;

	/**
	 * the user who made this request.
	 */
	private String userId;

	private String personId;
	private String name;
	private String gender;
	private String concernType;
	private String isValid;
	private String lastUpdateAt;
	private String lastUpdateBy;
	private String firstName;
	private String middleName;
	private String lastName;
	private String nationality;

	private String img;
	private String imgFormat;
	private String imgWidth;
	private String imgHeight;
	private String landmarks;
	private String remarks;
	private String isValidFace;
	private String faceImgPath;

	private int nodeId;
	private int subJobResult;
	private String subJobMessage;
	
	private Object faceIds;
	private int facesCount;
	private int faceIdFrom;
	private int faceIdTo;
	
	
	

	/**
	 * optional
	 */
	@Nullable
	private String systemId;

	public FaceRequest() {
		// TODO Auto-generated constructor stub
	}

	public Type getType() {
		return type;
	}

	public FaceRequest setType(Type type) {
		this.type = type;
		return this;
	}

	public String getId() {
		return id;
	}

	public FaceRequest setId(String id) {
		this.id = id;
		return this;
	}

	public Object getObject() {
		return this.obj;
	}

	/**
	 * Sets the custom parameter object which can be specific to request type.
	 *
	 * @param obj
	 * @return
	 */
	@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, include = JsonTypeInfo.As.PROPERTY, property = "class")
	public FaceRequest setObject(Object obj) {
		this.obj = obj;
		return this;
	}

	public String getUserId() {
		return this.userId;
	}

	public FaceRequest setUserId(String id) {
		this.userId = id;
		return this;
	}

	@Nullable
	public String getSystemId() {
		return this.systemId;
	}

	public FaceRequest setSystemId(String id) {
		this.systemId = id;
		return this;

	}

	public String getName() {
		return name;
	}

	public void setName(String NAME) {
		this.name = NAME;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getImgFormat() {
		return imgFormat;
	}

	public void setImgFormat(String imgFormat) {
		this.imgFormat = imgFormat;
	}

	public String getImgWidth() {
		return imgWidth;
	}

	public void setImgWidth(String imgWidth) {
		this.imgWidth = imgWidth;
	}

	public String getImgHeight() {
		return imgHeight;
	}

	public void setImgHeight(String imgHeight) {
		this.imgHeight = imgHeight;
	}

	public String getLandmarks() {
		return landmarks;
	}

	public void setLandmarks(String landmarks) {
		this.landmarks = landmarks;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getConcernType() {
		return concernType;
	}

	public void setConcernType(String concernType) {
		this.concernType = concernType;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getLastUpdateAt() {
		return lastUpdateAt;
	}

	public void setLastUpdateAt(String lastUpdateAt) {
		this.lastUpdateAt = lastUpdateAt;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIsValidFace() {
		return isValidFace;
	}

	public void setIsValidFace(String isValidFace) {
		this.isValidFace = isValidFace;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getFaceImgPath() {
		return faceImgPath;
	}

	public void setFaceImgPath(String faceImgPath) {
		this.faceImgPath = faceImgPath;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public int getSubJobResult() {
		return subJobResult;
	}

	public void setSubJobResult(int subJobResult) {
		this.subJobResult = subJobResult;
	}

	public String getSubJobMessage() {
		return subJobMessage;
	}

	public void setSubJobMessage(String subJobMessage) {
		this.subJobMessage = subJobMessage;
	}

	public Object getFaceIds() {
		return faceIds;
	}

	public void setFaceIds(Object faceIds) {
		this.faceIds = faceIds;
	}

	public int getFacesCount() {
		return facesCount;
	}

	public void setFacesCount(int facesCount) {
		this.facesCount = facesCount;
	}

	public int getFaceIdFrom() {
		return faceIdFrom;
	}

	public void setFaceIdFrom(int faceIdFrom) {
		this.faceIdFrom = faceIdFrom;
	}

	public int getFaceIdTo() {
		return faceIdTo;
	}

	public void setFaceIdTo(int faceIdTo) {
		this.faceIdTo = faceIdTo;
	}
	
	
	

}
