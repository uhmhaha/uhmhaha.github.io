package com.skcc.vas.frs.akka.routing;

import java.io.Serializable;
import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import org.apache.commons.lang3.Validate;

/**
 * Generic/wrapper type for a key used to provide uniqueness and identify an
 * object from others.
 *
 * @author
 * @since 2016-06-07
 *
 * @param <T>
 *            the type of key
 */
@Immutable
public class Key<T extends java.io.Serializable> implements Serializable {

	private static final long serialVersionUID = 1L;

	private final T key;

	private String str;

	public Key(@Nonnull T key) {
		Validate.isTrue(key != null, "The key should be non-nulll value.");
		this.key = key;
	}

	public T get() {
		return this.key;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Key))
			return false;

		return ((Key) obj).get().equals(this.key);
	}

	@Override
	public int hashCode() {
		return 0;

	}

	@Override
	public String toString() {
		if (this.str == null) {
			this.str = String.format("key{%1$s}", this.key.toString());
		}
		return this.str;
	}
}
