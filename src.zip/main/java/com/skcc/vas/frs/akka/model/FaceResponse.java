package com.skcc.vas.frs.akka.model;

import com.fasterxml.jackson.annotation.JsonFilter;

@JsonFilter("FaceResponeJSONFilter")
public class FaceResponse {

	// define response code
	final static public int RESPONSE_CODE_SUCCESS = 1;
	final static public int RESPONSE_CODE_FAIL = -100;
	final static public int RESPONSE_CODE_NOT_DEFINED_REQUEST = -110;
	final static public int RESPONSE_CODE_REQUEST_FORMAT_ERROR = -120;
	final static public int RESPONSE_CODE_NOT_DEFINED = -130;
	final static public int RESPONSE_CODE_REMOVE_PERSON_FAIL = -140;
	final static public int RESPONSE_CODE_REMOVE_FACE_FAIL = -150;
	final static public int RESPONSE_CODE_SEARCH_FACE_BY_DB_FAIL = -160;
	final static public int RESPONSE_CODE_SEARCH_FACE_BY_VMS_FILE_FAIL = -170;
	final static public int RESPONSE_CODE_REGISTER_FACE_NO_IMAGE = -181;
	final static public int RESPONSE_CODE_REGISTER_FACE_DETECT_FAIL = -182;
	final static public int RESPONSE_CODE_REGISTER_FACE_MULTIPLE_FACES = -183;
	final static public int RESPONSE_CODE_REGISTER_FACE_OVER_CAPACITY = -184;
	final static public int RESPONSE_CODE_REGISTER_FACE_NO_FILE_EXTENSION = -185;
	final static public int RESPONSE_CODE_WORKING_JOB_BY_VMS_FILE_FAIL = -171;
	final static public int RESPONSE_CODE_ONDEMAND_NO_STANDBY_NODE = -200;
	final static public int RESPONSE_CODE_ONDEMNAD_DB_SPLITJOB_FAIL = -201;
	final static public int RESPONSE_CODE_ONDEMNAD_VMS_SPLITJOB_FAIL = -202;
	final static public int RESPONSE_CODE_ONDEMNAD_VIDEO_SPLITJOB_FAIL = -203;
	final static public int RESPONSE_CODE_ONDEMNAD_DB_NO_DETECTED_FACES = -204;

	// define response message
	final static public String RESPONSE_MESSAGE_SUCCESS = "Success";
	final static public String RESPONSE_MESSAGE_FAIL = "Fail";
	final static public String RESPONSE_MESSAGE_NOT_DEFINED_REQUEST = "Request is not defined in FRS ";
	final static public String RESPONSE_MESSAGE_REQUEST_FORMAT_ERROR = "Request format is wrong";
	final static public String RESPONSE_MESSAGE_NOT_DEFINED = "Response message is not defined";
	final static public String RESPONSE_MESSAGE_REMOVE_PERSON_FAIL = "Fail to remove a person of ";
	final static public String RESPONSE_MESSAGE_REMOVE_FACE_FAIL = "Fail to remove a face(image) of ";
	final static public String RESPONSE_MESSAGE_SEARCH_FACE_BY_DB_FAIL = "Fail to process the face search using DB. job Id: ";
	final static public String RESPONSE_MESSAGE_SEARCH_FACE_BY_BY_VMS_FILE_FAIL = "Fail to process the face search using VMS file. job Id: ";
	final static public String RESPONSE_MESSAGE_REGISTER_FACE_NO_IMAGE = "There is no image in request";
	final static public String RESPONSE_MESSAGE_REGISTER_FACE_DETECT_FAIL = "Fail to detect face in the face image";
	final static public String RESPONSE_MESSAGE_REGISTER_FACE_MULTIPLE_FACES = "Face image has multiple faces";
	final static public String RESPONSE_MESSAGE_REGISTER_FACE_OVER_CAPACITY = "Fail to store face image in DB because of over the storable capacity";
	final static public String RESPONSE_MESSAGE_REGISTER_FACE_NO_FILE_EXTENSION = "There is no file extension";
	final static public String RESPONSE_MESSAGE_WORKING_JOB_BY_VMS_FILE_FAIL = "Thread is duplicated job search using VMS file. job Id: ";
	final static public String RESPONSE_MESSAGE_ONDEMAND_NO_STANDBY_NODE = "Some job is running. So there is no standby node for ondemand";
	final static public String RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL = "Fail to split the DB job. job id: ";
	final static public String RESPONSE_MESSAGE_ONDEMNAD_VMS_SPLITJOB_FAIL = "Fail to split the VMS job. job id: ";
	final static public String RESPONSE_MESSAGE_ONDEMNAD_VIDEO_SPLITJOB_FAIL = "Fail to split the VIDEO job. job id: ";
	final static public String RESPONSE_MESSAGE_ONDEMNAD_DB_NO_DETECTED_FACES = "There is any detected faces to analysis. job id: ";

	int responseCode;
	String responseMessage;
	Object feature;

	public FaceResponse() {
		this.responseCode = RESPONSE_CODE_NOT_DEFINED;
		this.responseMessage = getResponseMessage(RESPONSE_CODE_NOT_DEFINED);
		this.feature = null;
	}

	public FaceResponse(int responseCode, String responseMessage) {
		this.responseCode = responseCode;
		this.responseMessage = responseMessage;
		this.feature = null;
	}

	public FaceResponse(int responseCode) {
		this.responseCode = responseCode;
		this.responseMessage = getResponseMessage(responseCode);
		this.feature = null;

	}

	public FaceResponse(int responseCode, Object feature) {
		this.responseCode = responseCode;
		this.responseMessage = getResponseMessage(responseCode);
		this.feature = feature;

	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public Object getFeature() {
		return feature;
	}

	public void setFeature(Object feature) {
		this.feature = feature;
	}

	private String getResponseMessage(int responseCode) {

		String message = RESPONSE_MESSAGE_NOT_DEFINED;

		switch (responseCode) {
			case RESPONSE_CODE_SUCCESS :
				message = RESPONSE_MESSAGE_SUCCESS;
				break;
			case RESPONSE_CODE_FAIL :
				message = RESPONSE_MESSAGE_FAIL;
				break;
			case RESPONSE_CODE_NOT_DEFINED_REQUEST :
				message = RESPONSE_MESSAGE_NOT_DEFINED_REQUEST;
				break;
			case RESPONSE_CODE_REQUEST_FORMAT_ERROR :
				message = RESPONSE_MESSAGE_REQUEST_FORMAT_ERROR;
				break;
			case RESPONSE_CODE_NOT_DEFINED :
				message = RESPONSE_MESSAGE_NOT_DEFINED;
				break;
			case RESPONSE_CODE_REMOVE_PERSON_FAIL :
				message = RESPONSE_MESSAGE_REMOVE_PERSON_FAIL;
				break;
			case RESPONSE_CODE_REMOVE_FACE_FAIL :
				message = RESPONSE_MESSAGE_REMOVE_FACE_FAIL;
				break;
			case RESPONSE_CODE_SEARCH_FACE_BY_DB_FAIL :
				message = RESPONSE_MESSAGE_SEARCH_FACE_BY_DB_FAIL;
				break;
			case RESPONSE_CODE_SEARCH_FACE_BY_VMS_FILE_FAIL :
				message = RESPONSE_MESSAGE_SEARCH_FACE_BY_BY_VMS_FILE_FAIL;
				break;
			case RESPONSE_CODE_REGISTER_FACE_NO_IMAGE :
				message = RESPONSE_MESSAGE_REGISTER_FACE_NO_IMAGE;
				break;
			case RESPONSE_CODE_REGISTER_FACE_DETECT_FAIL :
				message = RESPONSE_MESSAGE_REGISTER_FACE_DETECT_FAIL;
				break;
			case RESPONSE_CODE_REGISTER_FACE_MULTIPLE_FACES :
				message = RESPONSE_MESSAGE_REGISTER_FACE_MULTIPLE_FACES;
				break;
			case RESPONSE_CODE_REGISTER_FACE_OVER_CAPACITY :
				message = RESPONSE_MESSAGE_REGISTER_FACE_OVER_CAPACITY;
				break;
			case RESPONSE_CODE_REGISTER_FACE_NO_FILE_EXTENSION :
				message = RESPONSE_MESSAGE_REGISTER_FACE_NO_FILE_EXTENSION;
				break;
			case RESPONSE_CODE_WORKING_JOB_BY_VMS_FILE_FAIL :
				message = RESPONSE_MESSAGE_WORKING_JOB_BY_VMS_FILE_FAIL;
				break;
			case RESPONSE_CODE_ONDEMNAD_DB_NO_DETECTED_FACES :
				message = RESPONSE_MESSAGE_ONDEMNAD_DB_NO_DETECTED_FACES;
				break;
			default :
				message = RESPONSE_MESSAGE_NOT_DEFINED;
		}

		return message;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(" FaceResponse.class = ");
		sb.append(" response message: " + getResponseMessage(getResponseCode()));
		return sb.toString();
	}

}
