package com.skcc.vas.frs.akka.model;

import com.skcc.vas.frs.akka.model.OndemandDBSubJob;
import com.skcc.vas.frs.akka.model.OndemandJobConstant;
import com.skcc.vas.frs.akka.model.OndemandVMSSubJob;
import com.skcc.vas.frs.akka.model.OndemandVideoSubJob;

public class MasterToWorkerMessage implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public final static int CODE_CNCRN_FACE_DB_UPDATED = 1;
	public final static int CODE_ROI_UPDATED = 2;
	public final static int CODE_FR_ENGINE_UPDATED_IN_ALL_NODES = 3;
	public final static int CODE_FR_ENGINE_UPDATED_IN_ONE_NODE = 4;
	public final static int CODE_ONDEMAND_JOB_START = 5;
	public final static int CODE_ONDEMAND_JOB_ABORT = 6;
	public final static int CODE_LIVE_START_CCTV = 7;
	public final static int CODE_LIVE_STOP_CCTV = 8;

	private int messageCode;

	// VMS Id
	private String systemId;

	// cctv(device id)
	private String deviceId;

	private int ondemandJobType = OndemandJobConstant.JobType.NOT_DEFINED;

	private OndemandDBSubJob ondemandDBSubJob;
	private OndemandVMSSubJob ondemandVMSSubJob;
	private OndemandVideoSubJob ondemandVideoSubJob;

	private String ondemandJobId;

	private int nodeId;

	private String masterURL;

	public MasterToWorkerMessage(int messageCode) {
		this.messageCode = messageCode;
	}

	public MasterToWorkerMessage(int messageCode, String systemId) {
		this.messageCode = messageCode;
		this.systemId = systemId;
	}

	public MasterToWorkerMessage(int messageCode, String systemId, String deviceId) {
		this.messageCode = messageCode;
		this.systemId = systemId;
		this.deviceId = deviceId;
	}

	public MasterToWorkerMessage(int messageCode, OndemandDBSubJob ondemandDBSubJob, int nodeId, String masterURL) {
		this.messageCode = messageCode;
		this.ondemandDBSubJob = ondemandDBSubJob;
		this.ondemandJobType = OndemandJobConstant.JobType.DBJOB;
		this.nodeId = nodeId;
		this.masterURL = masterURL;
		this.ondemandJobId = ondemandDBSubJob.getJobId();
	}

	public MasterToWorkerMessage(int messageCode, OndemandVMSSubJob ondemandVMSSubJob, int nodeId, String masterURL) {
		this.messageCode = messageCode;
		this.ondemandVMSSubJob = ondemandVMSSubJob;
		this.ondemandJobType = OndemandJobConstant.JobType.VMSJOB;
		this.nodeId = nodeId;
		this.masterURL = masterURL;
		this.ondemandJobId = ondemandVMSSubJob.getJobId();
	}

	public MasterToWorkerMessage(int messageCode, OndemandVideoSubJob ondemandVideoSubJob, int nodeId, String masterURL) {
		this.messageCode = messageCode;
		this.ondemandVideoSubJob = ondemandVideoSubJob;
		this.ondemandJobType = OndemandJobConstant.JobType.VIDEOJOB;
		this.nodeId = nodeId;
		this.masterURL = masterURL;
		this.ondemandJobId = ondemandVideoSubJob.getJobId();
	}

	public MasterToWorkerMessage(int messageCode, int ondemandJobType, int nodeId, String masterURL,
			String ondemandJobId) {
		this.messageCode = messageCode;
		this.ondemandJobType = ondemandJobType;
		this.nodeId = nodeId;
		this.masterURL = masterURL;
		this.ondemandJobId = ondemandJobId;
	}

	public int getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(int messageCode) {
		this.messageCode = messageCode;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public int getOndemandJobType() {
		return this.ondemandJobType;
	}

	public OndemandDBSubJob getOndemandDBSubJob() {
		return ondemandDBSubJob;
	}

	public void setOndemandDBSubJob(OndemandDBSubJob ondemandDBSubJob) {
		this.ondemandDBSubJob = ondemandDBSubJob;
	}

	public OndemandVMSSubJob getOndemandVMSSubJob() {
		return ondemandVMSSubJob;
	}

	public void setOndemandVMSSubJob(OndemandVMSSubJob ondemandVMSSubJob) {
		this.ondemandVMSSubJob = ondemandVMSSubJob;
	}

	public OndemandVideoSubJob getOndemandVideoSubJob() {
		return ondemandVideoSubJob;
	}

	public void setOndemandVideoSubJob(OndemandVideoSubJob ondemandVideoSubJob) {
		this.ondemandVideoSubJob = ondemandVideoSubJob;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getMasterURL() {
		return masterURL;
	}

	public void setMasterURL(String masterURL) {
		this.masterURL = masterURL;
	}

	public String getOndemandJobId() {
		return ondemandJobId;
	}

	public void setOndemandJobId(String ondemandJobId) {
		this.ondemandJobId = ondemandJobId;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("MasterToWorkerMessage class =");

		sb.append(" messageCode [" + messageCodeToString(messageCode) + "]");
		if (systemId != null) {
			sb.append(" systemId [" + systemId + "]");
		}
		if (deviceId != null) {
			sb.append(" deviceId [" + deviceId + "]");
		}

		if (ondemandJobType == OndemandJobConstant.JobType.DBJOB) {
			if (ondemandDBSubJob != null)
				sb.append(" Ondemand with DB Job " + ondemandDBSubJob);
			sb.append(" job id [" + ondemandJobId + "]");
			sb.append(" node Id [" + nodeId + "]");
			sb.append(" master HTTP URL [" + masterURL + "]");
		}

		if (ondemandJobType == OndemandJobConstant.JobType.VMSJOB) {
			if (ondemandVMSSubJob != null)
				sb.append(" Ondemand with VMS Job " + ondemandVMSSubJob);
			sb.append(" job id [" + ondemandJobId + "]");
			sb.append(" node Id [" + nodeId + "]");
			sb.append(" master HTTP URL [" + masterURL + "]");
		}

		if (ondemandJobType == OndemandJobConstant.JobType.VIDEOJOB) {
			if (ondemandVideoSubJob != null)
				sb.append(" Ondemand with Video Job " + ondemandVideoSubJob);
			sb.append(" job id [" + ondemandJobId + "]");
			sb.append(" node Id [" + nodeId + "]");
			sb.append(" master HTTP URL [" + masterURL + "]");
		}

		return sb.toString();

	}

	private String messageCodeToString(int messageCode) {

		String messageCodeString = "not defined";

		switch (messageCode) {
			case CODE_CNCRN_FACE_DB_UPDATED :
				messageCodeString = "CONCERN FACE updated by FRS UI";
				break;
			case CODE_ROI_UPDATED :
				messageCodeString = "ROI updated by FRS UI";
				break;
			case CODE_FR_ENGINE_UPDATED_IN_ALL_NODES :
				messageCodeString = "FR Engine parameters of all nodes updated by FRS UI";
				break;
			case CODE_FR_ENGINE_UPDATED_IN_ONE_NODE :
				messageCodeString = "FR Engine parameters of one cctv  updated by FRS UI";
				break;
			case CODE_ONDEMAND_JOB_START :
				messageCodeString = "Ondemand Job started by FRS UI";
				break;
			case CODE_ONDEMAND_JOB_ABORT :
				messageCodeString = "Ondemand Job aborted by FRS UI";
				break;
			case CODE_LIVE_START_CCTV :
				messageCodeString = "start live cctv by FRS UI";
				break;
			case CODE_LIVE_STOP_CCTV :
				messageCodeString = "Stop live cctv by FRS UI";
				break;	
				
		}

		return messageCodeString;

	}

}
