package com.skcc.vas.frs.akka.actor;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;
import org.hibernate.validator.constraints.*;

import akka.actor.*;
import akka.camel.*;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.ser.impl.*;
import com.skcc.vas.frs.akka.cluster.*;
import com.skcc.vas.frs.akka.model.*;

public class MatchingWebServiceActor extends WebServiceBase {

	private final ActorRef routingNStateControllerActor;

	/**
	 * @param uri
	 *            expected to be start with "http://"
	 * @param jacksonMapper
	 * @param timeout
	 */
	public MatchingWebServiceActor(@NotBlank String uri, @Nonnull ObjectMapper jacksonMapper,
			@Min(TIMEOUT_MIN) int timeout, @Nonnull ActorRef routingNStateControllerActor) {

		// @TODO Check it is safe or not to hand over an actor reference to the
		// constructor.
		super(uri, jacksonMapper, timeout);

		Validate.isTrue(routingNStateControllerActor != null,
				"Actor for routing and state controller service should be provided.");

		this.routingNStateControllerActor = routingNStateControllerActor;

	}

	@Override
	public void onReceive(Object msg) throws Exception {

		if (msg instanceof CamelMessage) {

			final CamelMessage cm = (CamelMessage) msg;
			final String body;
			final FaceRequest req;
			FaceResponse response = new FaceResponse();
			String jsonResponse;

			try {
				body = cm.getBodyAs(String.class, getCamelContext());
				logger.info("++ HTTP request body message = [{}]", body);
				req = this.getJacksonMapper().readValue(body, FaceRequest.class);
			} catch (Exception ex) {
				this.logger.error("Fail to parse the request.", ex.getMessage());
				// make response message
				response.setResponseCode(FaceResponse.RESPONSE_CODE_REQUEST_FORMAT_ERROR);
				response.setResponseMessage("Fail to parse the request. : " + ex.getMessage());
				// jsonResponse =
				// this.getJacksonMapper().writeValueAsString(response);
				jsonResponse = this.getJacksonMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response);
				this.getSender().tell(jsonResponse, this.getSelf());
				return;
			}

			final FaceRequest.Type type = req.getType();

			switch (type) {

				case HEALTH_CHECK :
					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
				default :

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_NOT_DEFINED,
							FaceResponse.RESPONSE_MESSAGE_NOT_DEFINED_REQUEST + type);
					break;

			}// switch()

		} else {
			if (msg != null) {
				this.logger.warning("Received unexpected type of message. {}", msg.getClass().getSimpleName());
			} else {
				this.logger.warning("Received null message.");
			}

			this.unhandled(msg);
		}

	} // end of OnReceive()

	private void sendResponse(FaceResponse response, int code, String message) {

		try {
			response.setResponseCode(code);
			response.setResponseMessage(message);

			this.getJacksonMapper().setFilterProvider(
					new SimpleFilterProvider().addFilter("FaceResponeJSONFilter", new FaceResponeJSONFilter()));
			String jsonResponse = this.getJacksonMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response);
			// String jsonResponse =
			// this.getJacksonMapper().writeValueAsString(response);
			this.getSender().tell(jsonResponse, this.getSelf());
			logger.debug("++ http response : [{}]", response);
		} catch (Exception ex) {
			this.logger.warning("JacksonMapper Exception : {}", ex.toString());
		}

	}// end of sendResponse();

}
