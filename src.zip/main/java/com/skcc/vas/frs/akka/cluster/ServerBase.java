package com.skcc.vas.frs.akka.cluster;

import java.lang.management.*;
import java.util.concurrent.atomic.*;
import javax.annotation.*;
import javax.validation.constraints.*;
import org.apache.commons.lang3.*;
import org.slf4j.*;
import org.springframework.context.*;
import akka.actor.*;
import com.typesafe.config.*;
import com.skcc.vas.frs.common.util.spring.*;

/**
 * @author
 * @since 2016-06-21
 *
 */
public abstract class ServerBase implements Server {

	public static final String AKKA_CONFIG_PATH_FOR_SPRING_CONFIG_LOC = "vas.spring.config-location";

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private final String systemName;

	public String getSystemName() {
		return this.systemName;
	}

	private final String applName;

	public String getApplicationName() {
		return this.applName;
	}

	private final String configSubtree;

	public String getConfigSubtree() {
		return this.configSubtree;
	}

	private Config config;

	protected Config getConfig() {
		return this.config;
	}

	protected void setConfig(@Nonnull Config config) {
		this.config = config;
	}

	private final ApplicationContext springContainer;

	protected ApplicationContext getSpringContainer() {
		return this.springContainer;
	}

	private ActorSystem system;

	protected ActorSystem getActorSystem() {
		return this.system;
	}

	private final String pid;

	public String getPID() {
		return this.pid;
	}

	private final AtomicBoolean started = new AtomicBoolean(Boolean.FALSE);

	public boolean hasStarted() {
		return this.started.get();
	}

	public ServerBase(@Pattern(regexp = "[a-zA-Z0-9]+") String systemName,
			@Pattern(regexp = "[a-zA-Z0-9]+") String applName, @Nullable String configSubtree) {

		Validate.isTrue(StringUtils.isAlphanumeric(systemName), "The system name should be alpha-numeric.");
		Validate.isTrue(StringUtils.isAlphanumeric(applName), "The application name should be  alpha-numeric.");

		this.systemName = systemName;
		this.applName = applName;
		this.configSubtree = configSubtree;

		// build Akka config - externalized
		try {
			this.config = this.buildConfig(this.configSubtree);
		} catch (Throwable ex) {
			this.logger.error("Fail to build configuration for actor system with the subtree of {}. {}", configSubtree,
					ex.toString());
			throw new IllegalStateException("Fail to build configuration for actor system.", ex);
		}

		// load Spring container
		final String springConfigLoc;
		if (this.config.hasPath(AKKA_CONFIG_PATH_FOR_SPRING_CONFIG_LOC)) {
			springConfigLoc = this.config.getString(AKKA_CONFIG_PATH_FOR_SPRING_CONFIG_LOC);
		} else {
			springConfigLoc = Server.SPRING_CONFIG_LOCATION_DEFAULT;
		}

		try {
			this.springContainer = SpringContainerLocator.getSingleton().getSpringContainer(springConfigLoc);
		} catch (Throwable ex) {
			this.logger.error("Fail to load Spring container at {}.", springConfigLoc);
			throw new IllegalStateException("Fail to load Spring container at" + springConfigLoc, ex);
		}

		// catch PID
		String pid = null;
		try {
			pid = this.catchPID();
		} catch (Throwable ex) {
			this.logger.warn("Fail to catch PID of the process running this server.");
		}
		this.pid = pid;
		MDC.put("pid", pid);

	}

	@Nonnull
	protected abstract Config buildConfig(@Nullable String configSubtree) throws Exception;

	protected String catchPID() {
		RuntimeMXBean mbean = ManagementFactory.getRuntimeMXBean();
		String pid = mbean.getName();
		if (pid != null && pid.length() > 0) {
			if (pid.contains("@"))
				pid = pid.substring(0, pid.indexOf("@"));
		}
		return pid;
	}

	@Override
	final public void start() throws Exception {
		// @TODO Need more consideration on restart. Is it allowable ?

		try {
			this.system = this.buildActorSystem(this.config);
			this.started.set(Boolean.TRUE);
		} catch (Throwable ex) {
			this.logger.error("Fail to build actor system.", ex);
			throw new IllegalStateException("Fail to build actor system.", ex);
		}
	}

	@Nonnull
	protected abstract ActorSystem buildActorSystem(@Nonnull Config config) throws Exception;

	@Override
	final public void stop() throws Exception {

		try {
			this.beforeStop();
		} catch (Throwable ex) {
			this.logger.error("Fail to process beforeStop callback.", ex);
		}

		if (this.started.get() && this.system != null) {
			this.system.shutdown();
		}
	}

	@Nonnull
	protected abstract void beforeStop() throws Exception;

}
