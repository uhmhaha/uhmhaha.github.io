package com.skcc.vas.frs.akka.routing;

import javax.annotation.Nonnull;

/**
 * @author
 * @since 2016-06-07
 *
 * @param <T>
 */
public interface Keyed<T extends java.io.Serializable> {

	@Nonnull
	public Key<T> getKey();

}
