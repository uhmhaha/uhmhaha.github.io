package com.skcc.vas.frs.akka.cluster;

/**
 * @author
 * @since 2016-06-15
 *
 */
public interface ClusterNode extends Server {

	void start(boolean allowsLocalRoutees) throws Exception;

}