package com.skcc.vas.frs.akka.cluster;

/**
 * @author
 * @since 2016-06-15
 *
 */
public interface Server {

	public final static int HTTP_PORT_DEFAULT = 8081;

	public final static int REDIS_PORT_DEFAULT = 6379;

	public final static String REDIS_LOG_LEVEL_DEFAULT = "verbose";

	public final static String SPRING_CONFIG_LOCATION_DEFAULT = "spring.xml";

	void start() throws Exception;

	void stop() throws Exception;

}
