package com.skcc.vas.frs.akka.launcher;

import org.slf4j.*;

import com.skcc.vas.frs.akka.cluster.ClusterMatchingMaster;
import com.skcc.vas.frs.akka.cluster.Server;
import com.skcc.vas.frs.akka.model.ClusterConfig;
import com.skcc.vas.frs.akka.util.ConfigUtil;
import com.skcc.vas.frs.akka.util.PIDUtil;

/**
 * @author
 * @since 2016-06-22
 *
 */
public class ClusterMatchingMasterLauncher {

	/*
	 * change <../log> in logback.xml into full path directory including log
	 * folder.
	 */
	/*
	 * static {
	 * 
	 * if(FileUtil.runOnEclipse("bin")) { // nothing to do } else { Path
	 * currentPath = Paths.get(System.getProperty("user.dir")); String parentDir
	 * = currentPath.getParent().toAbsolutePath().normalize().toString();
	 * 
	 * String logbackDir = parentDir + "/conf"; String logbackFile =
	 * "logback.xml";
	 * 
	 * String originalText = "../log"; String replaceText = parentDir + "/log";
	 * 
	 * FileUtil.replaceText(logbackDir, logbackFile, originalText, replaceText);
	 * } }
	 */

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(ClusterMatchingMasterLauncher.class);

	public static void main(String[] args) {

		final String systemName = "WatzEyeFRSMatching";
		final String applName = "frs";

		Server server = null;
		boolean useOldAkkaSetup = false;
		try {

			/*
			 * 현재 java VM의 PID 값을 가지는 PID 파일을 생성한다
			 */
			PIDUtil.createJVMPidFile(System.getProperty("user.dir"));

			/*
			 * log4cplus의 설정 정보를 변경한다
			 */
			ConfigUtil.modifyLog4cplusConfigFile();

			/*
			 * find out my node id using application.conf and DB
			 */
			ClusterConfig clusterConfig = ConfigUtil.setupAutomaticAkkaConfigurationAndGetSelfNodeId(useOldAkkaSetup,
					ClusterMatchingMaster.ROLE);
			logger.info("[AKKA setup]-----Notice----------------------------------");
			if (useOldAkkaSetup) {
				logger.info("[AKKA setup] AKKA setup will use applcation.conf file only !!! ");
				logger.info("[AKKA setup] My Cluster config = [{}]", clusterConfig);
			} else {
				logger.info("[AKKA setup] AKKA setup will use VAS_NODE DB table. Applcation.conf file will be updated automatically !!! ");
				logger.info("[AKKA setup] My Cluster config = [{}]", clusterConfig);
			}
			logger.info("[AKKA setup]--------------------------------------------");

			/*
			 * replace node id of activemq.xml, spring.xml files into real self
			 * node id
			 */
			ConfigUtil.updateSetupFile("conf", "activemq.xml", clusterConfig.getNodeIdInt());
			ConfigUtil.updateSetupFile("conf", "spring.xml", clusterConfig.getNodeIdInt());

			/*
			 * 기존과 달리 httpPort, nodePort는 사용하지 않음 해당 정보를 application.conf에서 가져온다
			 */
			server = new ClusterMatchingMaster(systemName, applName, null, useOldAkkaSetup, clusterConfig);
			server.start();

			ClusterMatchingMaster cm = (ClusterMatchingMaster) server;

			logger.info("The cluster matching master has started");

		} catch (Throwable ex) {
			logger.error("Fail to start cluster master", ex);

			if (server != null) {
				try {
					server.stop(); // @FIXME Seems to cause hang. Check it !
				} catch (Throwable ex2) {
					logger.error("Fail to stop cluster matching master after startup failure.", ex2);
				}
			}
			System.exit(-1);
		} finally {

		}

	}
}
