package com.skcc.vas.frs.akka.model;

import java.util.List;

import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.akka.db.rdb.domain.Node;

/**
 * Manages the one node and multiple cctvs This is used for dynamic node control
 * and routing
 * 
 * @author Na Hoon
 * @since 2016. 9. 8.
 *
 */
public class NodeCctv {

	// one worker node
	Node node;

	// allocated cctvs list in this node
	List<Cctv> cctvList;

	// worker node AKKA path
	String nodePath;

	public NodeCctv(Node node, List<Cctv> cctvList, String nodePath) {
		this.node = node;
		this.cctvList = cctvList;
		this.nodePath = nodePath;
	}

	public String getNodePath() {
		return nodePath;
	}

	public void setNodePath(String nodePath) {
		this.nodePath = nodePath;
	}

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	public List<Cctv> getCctvList() {
		return cctvList;
	}

	public void setCctvList(List<Cctv> cctvList) {
		this.cctvList = cctvList;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("NodeCctv class = ");
		if (node != null) {
			sb.append(" node =  [" + node.toString() + "]");
		}
		sb.append(" cctv list = ");
		if (cctvList == null) {
			sb.append(" [cctv list is null]");
		} else {
			for (Cctv cctv : cctvList) {
				sb.append(" cctv [" + cctv.toString() + "]");
				sb.append(" , ");
			}
		}
		if (nodePath != null) {
			sb.append(" node path =  [" + nodePath + "]");
		}

		return sb.toString();

	}

}
