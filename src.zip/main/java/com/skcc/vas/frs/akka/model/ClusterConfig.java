package com.skcc.vas.frs.akka.model;

public class ClusterConfig {

	private final static String INTIAL_VALUE = "not defined";

	// akka ip address
	String ipAddress;

	// akka port
	String port;

	// self node id
	String nodeId;

	// system id
	String systemId;

	// node type : MAST-NODE, WORK-NODE
	String nodeType;

	public ClusterConfig() {
		this.ipAddress = INTIAL_VALUE;
		this.port = INTIAL_VALUE;
		this.nodeId = INTIAL_VALUE;
		this.systemId = INTIAL_VALUE;
		this.nodeType = INTIAL_VALUE;
	}

	public ClusterConfig(String ipAddress, String port, String nodeId, String systemId, String nodeType) {
		this.ipAddress = ipAddress;
		this.port = port;
		this.nodeId = nodeId;
		this.systemId = systemId;
		this.nodeType = nodeType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPort() {
		return port;
	}

	public int getPortInt() {
		return Integer.parseInt(port);
	}

	public void setPort(String port) {
		this.port = port;
	}

	public void setPort(int port) {
		this.port = Integer.toString(port);
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getNodeIdString() {
		return nodeId;
	}

	public int getNodeIdInt() {
		return Integer.parseInt(nodeId);
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = Integer.toString(nodeId);
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= \n");
		sb.append(" node Id = [" + nodeId + "]\n");
		sb.append(" system Id = [" + systemId + "]\n");
		sb.append(" akka IP address = [" + ipAddress + "]\n");
		sb.append(" akka port = [" + port + "]\n");
		sb.append(" node type = [" + nodeType + "]\n");

		return sb.toString();

	}

}
