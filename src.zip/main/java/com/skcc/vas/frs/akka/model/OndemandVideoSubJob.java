package com.skcc.vas.frs.akka.model;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;

import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;

public class OndemandVideoSubJob implements java.io.Serializable {

	private static final long serialVersionUID = -1590376098730197589L;

	private float portionOfProgress;

	private String jobId;

	private String baseDir;

	private Map<String, byte[]> concernFaces;

	private List<AnalysisResource> analysisResources;

	private List<Pair<Integer, Integer>> filePeriods;

	private int threshold;

	public OndemandVideoSubJob() {
	}

	public OndemandVideoSubJob(float portionOfProgress, String jobId, String baseDir, Map<String, byte[]> concernFaces,
			List<AnalysisResource> analysisResources, List<Pair<Integer, Integer>> filePeriods, int threshold) {
		this.portionOfProgress = portionOfProgress;
		this.jobId = jobId;
		this.baseDir = baseDir;
		this.concernFaces = concernFaces;
		this.analysisResources = analysisResources;
		this.filePeriods = filePeriods;
		this.threshold = threshold;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}

	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getBaseDir() {
		return baseDir;
	}

	public void setBaseDir(String baseDir) {
		this.baseDir = baseDir;
	}

	public Map<String, byte[]> getConcernFaces() {
		return concernFaces;
	}

	public void setConcernFaces(Map<String, byte[]> concernFaces) {
		this.concernFaces = concernFaces;
	}

	public List<AnalysisResource> getAnalysisResources() {
		return analysisResources;
	}

	public void setAnalysisResources(List<AnalysisResource> analysisResources) {
		this.analysisResources = analysisResources;
	}

	public List<Pair<Integer, Integer>> getFilePeriods() {
		return filePeriods;
	}

	public void setFilePeriods(List<Pair<Integer, Integer>> filePeriods) {
		this.filePeriods = filePeriods;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" baseDir = [" + baseDir + "]");
		sb.append(" threshold = [" + threshold + "]");
		if (concernFaces != null) {
			sb.append(" concernFaces = [" + concernFaces.size() + "]");
		} else {
			sb.append(" concernFaces = [null]");
		}
		if (analysisResources != null) {
			sb.append(" analysisResources = [" + analysisResources.size() + "]");
		} else {
			sb.append(" analysisResources = [null]");
		}
		if (filePeriods != null) {
			sb.append(" filePeriods = [" + filePeriods.size() + "]");
		} else {
			sb.append(" filePeriods = [null]");
		}

		return sb.toString();
	}

}
