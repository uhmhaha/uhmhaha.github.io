package com.skcc.vas.frs.akka.model;

/**
 * @author
 * @since 2016-06-24
 *
 */
public enum ActorProfile {

	FACE_WEB_ACTOR("faceWebService"),
	FACE_DETECTION_ROUTING_ACTOR("faceDetectionRoutingService"), 
	FACE_DETECTION_ACTOR("faceDetectionService"), 
	FACE_MATCHING_ACTOR("faceMatchingService"),
	FACE_MATCHING_ROUTING_ACTOR("faceMatchingRoutingService"),
	FACE_MATCHING_WEB_ACTOR("faceMatchingWebService");

	private final String actorName;

	private ActorProfile(String name) {
		this.actorName = name;
	}

	public String getActorName() {
		return this.actorName;
	}

}
