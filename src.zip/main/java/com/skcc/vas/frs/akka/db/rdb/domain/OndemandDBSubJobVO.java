package com.skcc.vas.frs.akka.db.rdb.domain;

public class OndemandDBSubJobVO {

	private int nodeId;

	private String jobId;

	private String jobStatus;

	private String startTime;

	private String endTime;

	private float portionOfProgress;

	private String startId;

	private int detectedFaceCount;

	private String timeType;

	private int totalStartThread;

	private int totalCompletedThread;

	public float getPortionOfProgress() {
		return portionOfProgress;
	}
	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getStartId() {
		return startId;
	}
	public void setStartId(String startId) {
		this.startId = startId;
	}
	public int getDetectedFaceCount() {
		return detectedFaceCount;
	}
	public void setDetectedFaceCount(int detectedFaceCount) {
		this.detectedFaceCount = detectedFaceCount;
	}

	public int getNodeId() {
		return nodeId;
	}
	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getTimeType() {
		return timeType;
	}
	public void setTimeType(String timeType) {
		this.timeType = timeType;
	}

	public int getTotalStartThread() {
		return totalStartThread;
	}
	public void setTotalStartThread(int totalStartThread) {
		this.totalStartThread = totalStartThread;
	}
	public int getTotalCompletedThread() {
		return totalCompletedThread;
	}
	public void setTotalCompletedThread(int totalCompletedThread) {
		this.totalCompletedThread = totalCompletedThread;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Node Id = [" + nodeId + "]");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" start time = [" + startTime + "]");
		sb.append(" end time = [" + endTime + "]");
		sb.append(" job status = [" + jobStatus + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" start Id = [" + startId + "]");
		sb.append(" detectedFaceCount = [" + detectedFaceCount + "]");
		sb.append(" time type = [" + timeType + "]");
		sb.append(" total start thread = [" + totalStartThread + "]");
		sb.append(" total completed thread = [" + totalCompletedThread + "]");

		return sb.toString();
	}

}
