package com.skcc.vas.frs.akka.routing;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import akka.actor.ActorSystem;
import akka.routing.CustomRouterConfig;
import akka.routing.Routee;
import akka.routing.Router;

/**
 * @author
 * @since 2016-06-08
 *
 * @param <T>
 */
public class MappedRouterConfig<T extends java.io.Serializable> extends CustomRouterConfig {

	// private final org.slf4j.Logger logger =
	// LoggerFactory.getLogger(this.getClass());

	private static final long serialVersionUID = 1L;

	private final List<Routee> routees = new ArrayList<Routee>();

	/**
	 * @param routees
	 *            if any, will be swallow-copied, not referenced
	 */
	public MappedRouterConfig(@Nullable List<KeyedRoutee<T>> routees) {
		if (routees != null) {
			for (KeyedRoutee<T> routee : routees) {
				this.routees.add(routee);
			}
		}
	}

	@Override
	@Nonnull
	public Router createRouter(ActorSystem system) {

		return new Router(new MappedRoutingLogic<T>(), this.routees);
	}

}
