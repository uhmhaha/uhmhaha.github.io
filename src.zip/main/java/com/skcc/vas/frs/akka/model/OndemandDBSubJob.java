package com.skcc.vas.frs.akka.model;

import java.util.Map;

public class OndemandDBSubJob implements java.io.Serializable {
	private static final long serialVersionUID = 5012233618629525357L;

	private float portionOfProgress;
	private String jobId;
	private String startId;
	private int detectedFaceCount;
	private Map<String, byte[]> concernFaces;
	private String timeType;

	public OndemandDBSubJob() {

	}

	public OndemandDBSubJob(float portionOfProgress, String jobId, String startId, int detectedFaceCount,
			Map<String, byte[]> concernFaces, String timeType) {
		this.portionOfProgress = portionOfProgress;
		this.jobId = jobId;
		this.startId = startId;
		this.detectedFaceCount = detectedFaceCount;
		this.concernFaces = concernFaces;
		this.timeType = timeType;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}
	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getStartId() {
		return startId;
	}
	public void setStartId(String startId) {
		this.startId = startId;
	}
	public int getDetectedFaceCount() {
		return detectedFaceCount;
	}
	public void setDetectedFaceCount(int detectedFaceCount) {
		this.detectedFaceCount = detectedFaceCount;
	}
	public Map<String, byte[]> getConcernFaces() {
		return concernFaces;
	}
	public void setConcernFaces(Map<String, byte[]> concernFaces) {
		this.concernFaces = concernFaces;
	}
	public String getTimeType() {
		return timeType;
	}
	public void setTimeType(String timeType) {
		this.timeType = timeType;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" startId = [" + startId + "]");
		sb.append(" timeType = [" + timeType + "]");
		if (concernFaces != null) {
			sb.append(" concernFaces = [" + concernFaces.size() + "]");
		} else {
			sb.append(" concernFaces = [null]");
		}
		sb.append(" detectedFaceCount = [" + detectedFaceCount + "]");

		return sb.toString();
	}

}
