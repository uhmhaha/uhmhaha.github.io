package com.skcc.vas.frs.akka.db.rdb.domain;

public class OndemandVideoSubJobVO {
	private int nodeId;

	private String jobId;

	private String jobStatus;

	private String startTime;

	private String endTime;

	private float portionOfProgress;

	private String baseDir;

	private int matchingThreshold;

	private String filePeriods;

	private String rscIds;

	private int totalStartThread;

	private int totalCompletedThread;

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}

	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}

	public String getBaseDir() {
		return baseDir;
	}

	public void setBaseDir(String baseDir) {
		this.baseDir = baseDir;
	}

	public int getMatchingThreshold() {
		return matchingThreshold;
	}

	public void setMatchingThreshold(int matchingThreshold) {
		this.matchingThreshold = matchingThreshold;
	}

	public String getFilePeriods() {
		return filePeriods;
	}

	public void setFilePeriods(String filePeriods) {
		this.filePeriods = filePeriods;
	}

	public String getRscIds() {
		return rscIds;
	}

	public void setRscIds(String fileIds) {
		this.rscIds = fileIds;
	}

	public int getTotalStartThread() {
		return totalStartThread;
	}
	public void setTotalStartThread(int totalStartThread) {
		this.totalStartThread = totalStartThread;
	}
	public int getTotalCompletedThread() {
		return totalCompletedThread;
	}
	public void setTotalCompletedThread(int totalCompletedThread) {
		this.totalCompletedThread = totalCompletedThread;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Node Id = [" + nodeId + "]");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" start time = [" + startTime + "]");
		sb.append(" end time = [" + endTime + "]");
		sb.append(" job status = [" + jobStatus + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" base dir = [" + baseDir + "]");
		sb.append(" matching threshold = [" + matchingThreshold + "]");
		sb.append(" file period = [" + filePeriods + "]");
		sb.append(" file id = [" + rscIds + "]");
		sb.append(" total start thread = [" + totalStartThread + "]");
		sb.append(" total completed thread = [" + totalCompletedThread + "]");

		return sb.toString();
	}

}
