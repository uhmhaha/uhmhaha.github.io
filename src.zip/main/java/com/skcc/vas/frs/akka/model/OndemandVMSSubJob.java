package com.skcc.vas.frs.akka.model;

import java.util.List;
import java.util.Map;

import com.skcc.vas.frs.common.biz.model.SearchRequest.Cctv;

public class OndemandVMSSubJob implements java.io.Serializable {

	private static final long serialVersionUID = -613143875862047016L;

	private float portionOfProgress;

	private String jobId;

	private List<String> baseDirList;

	private Map<String, byte[]> concernFaces;

	private List<Cctv> cctvs;

	private String analysisTimeFrom;
	private String analysisTimeTo;

	private int threshold;

	private String timeType;

	public OndemandVMSSubJob(float portionOfProgress, String jobId, Map<String, byte[]> faceFeatureList,
			List<Cctv> cctvs, int threshold, String analysisTimeFrom, String analysisTimeTo, String timeType) {
		this.portionOfProgress = portionOfProgress;
		this.jobId = jobId;
		this.concernFaces = faceFeatureList;
		this.cctvs = cctvs;
		this.threshold = threshold;
		this.analysisTimeFrom = analysisTimeFrom;
		this.analysisTimeTo = analysisTimeTo;
		this.timeType = timeType;
	}

	public float getPortionOfProgress() {
		return portionOfProgress;
	}

	public void setPortionOfProgress(float portionOfProgress) {
		this.portionOfProgress = portionOfProgress;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public Map<String, byte[]> getConcernFaces() {
		return concernFaces;
	}

	public void setConcernFaces(Map<String, byte[]> concernFaces) {
		this.concernFaces = concernFaces;
	}

	public List<Cctv> getCctvs() {
		return cctvs;
	}

	public void setCctvs(List<Cctv> cctvs) {
		this.cctvs = cctvs;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	public String getAnalysisTimeFrom() {
		return analysisTimeFrom;
	}

	public void setAnalysisTimeFrom(String analysisTimeFrom) {
		this.analysisTimeFrom = analysisTimeFrom;
	}

	public String getAnalysisTimeTo() {
		return analysisTimeTo;
	}

	public void setAnalysisTimeTo(String analysisTimeTo) {
		this.analysisTimeTo = analysisTimeTo;
	}

	public String getTimeType() {
		return timeType;
	}

	public void setTimeType(String timeType) {
		this.timeType = timeType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append(this.getClass().getSimpleName() + "= ");
		sb.append(" Job Id = [" + jobId + "]");
		sb.append(" portionOfProgess = [" + portionOfProgress + "]");
		sb.append(" threshold = [" + threshold + "]");
		if (baseDirList != null) {
			sb.append(" baseDir = [");
			for (String baseDir : baseDirList)
				sb.append(baseDir + ",");
			sb.append(" ]");
		} else {
			sb.append(" baseDir = [null]");
		}
		if (cctvs != null) {
			sb.append(" Cctv = [");
			for (Cctv cctv : cctvs)
				sb.append(cctv.toString() + ",");
			sb.append(" ]");
		} else {
			sb.append(" Cctv = [null]");
		}

		if (concernFaces != null) {
			sb.append(" concernFaces = [" + concernFaces.size() + "]");
		} else {
			sb.append(" concernFaces = [null]");
		}
		sb.append(" analysisTimeFrom = [" + analysisTimeFrom + "]");
		sb.append(" analysisTimeFrom = [" + analysisTimeTo + "]");
		sb.append(" timeType = [" + timeType + "]");

		return sb.toString();
	}

}
