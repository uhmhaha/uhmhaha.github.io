package com.skcc.vas.frs.akka.util;

import java.net.InetAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;

public class LicenseUtil {
	private static final Logger logger = LoggerFactory.getLogger(LicenseUtil.class);

	public static void checkHBinnoLicense(HbInnoAdapter hbinnoAdapter) {

		if(hbinnoAdapter == null) {
			throw new RuntimeException("++ [hbinno] spring container doesn't have hbinnoAdapter bean !!!");
		}
		
		// get local IP address
		String localIPAddress = null;
	
		try {
			InetAddress addr = InetAddress.getLocalHost();
			localIPAddress = addr.getHostAddress();
		} catch (Exception ex) {
			logger.error("++ failed to get local IP address. [{}]", ex.toString());
			throw new RuntimeException("++ failed to get local IP Address. " + ex.toString());
		}
		
		// check hbinno license
		boolean result = hbinnoAdapter.isValidLicense();
		
		if(result) {
			logger.info("++ [hbinno] ++++++++++++++++++++++++++++++++++++++++++++++++++");
			logger.info("++ [hbinno] HBinno Machine Info : [{}]", hbinnoAdapter.getMachineInfo());
			logger.info("++ [hbinno] HBinno license : [{}]", hbinnoAdapter.getLicenseKey());
			logger.info("++ [hbinno] Local IP address: [{}]", localIPAddress);
			logger.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		} else {	
			StringBuffer sb = new StringBuffer();
			sb.append("++ [hbinno] ++++++++++++++++++++++++++++++++++++++++++++++++++++ \n");
			sb.append("++ [hbinno] HBFRfacePro.HBFRSetLicense() meets an error !!!!. return value = ["
					+ hbinnoAdapter.getLicenseResult() + "]\n");
			sb.append("++ [hbinno] HBinno Machine Info : [" + hbinnoAdapter.getMachineInfo() + "]\n");
			sb.append("++ [hbinno] HBinno license : [" + hbinnoAdapter.getLicenseKey() + "]\n");
			sb.append("++ [hbinno] Local IP address: [" + localIPAddress + "]\n");
			sb.append("++ [hbinno] Check VAS_LICENSE_NODE DB table has license value \n");
			sb.append("++ [hbinno] or Verify Hbinno Machine Info and local IP address \n");
			sb.append("++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			
			logger.error(sb.toString());
			
			throw new RuntimeException(sb.toString());
		}
		
	}
}
