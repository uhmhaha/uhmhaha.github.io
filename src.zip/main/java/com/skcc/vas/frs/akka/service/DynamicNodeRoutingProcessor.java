package com.skcc.vas.frs.akka.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest;
import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.akka.db.rdb.domain.Node;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandDBSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandJobMasterVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVMSSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVideoSubJobVO;

/**
 * The main logic to handle routing process This is used for dynamic node
 * control and routing
 * 
 * @author Na Hoon
 * @since 2016. 9. 8.
 *
 */
public class DynamicNodeRoutingProcessor {

   // database manager
   private final FaceDataManager faceDataManager;
   private final FaceMatchJobService faceMatchJobService;

   public DynamicNodeRoutingProcessor(FaceDataManager faceDataManager, FaceMatchJobService faceMatchJobService) {
	   this.faceDataManager = faceDataManager;
	   this.faceMatchJobService = faceMatchJobService;
   }

   /*
    * VAS_NODE_SRVC table에서 해당 node의 정보를 읽어 온다
    */
   public Node getNodeInfo(String nodeAddress, String nodePort) {

	   return faceDataManager.getNodeInfo(nodeAddress, nodePort);
   }

   /*
    *  VAS_NODE_SRVC table에서 해당 node의 정보를 읽어 온다
    */
   public Node getNodeInfoById(int nodeId){
	   return faceDataManager.getNodeInfoById(nodeId);
   }

   /*
    * VAS_NODE_SRVC table에 새로운 node를 추가하고 초기화한다
    */
   public boolean makeNewNode(String nodeAddress, String nodePort) {

	   Node node = new Node();
	   node.setDefault(nodeAddress, nodePort);
	   return faceDataManager.makeNewNode(node);
   }
   
   /*
    * VAS_NODE_SRVC table에 새로운 node를 추가하고 초기화한다
    */
   public boolean makeNewMatchingNode(String nodeAddress, String nodePort, String Role) {

	   Node node = new Node();
	   node.setMatchingNodeDefault(nodeAddress, nodePort, Role );
	   return faceDataManager.makeNewNode(node);
   }

   /*
    * VAS_NODE_SRVC table에 기 존재하는 node를 정보를 초기화 한다
    */
   public boolean resetNode(String nodeAddress, String nodePort, String nodeClass){

	   Node node = new Node();
	   node.setDefault(nodeAddress, nodePort);
	   node.setNodeClass(nodeClass);
	   return faceDataManager.resetNode(node);
   }
   
   /*
    * VAS_NODE_SRVC table에 기 존재하는 node를 정보를 초기화 한다
    */
   public boolean resetMatchingNode(String nodeAddress, String nodePort, String nodeClass, String Role){

	   Node node = new Node();
	   node.setMatchingNodeDefault(nodeAddress, nodePort, Role);
	   node.setNodeClass(nodeClass);
	   return faceDataManager.resetNode(node);
   }
   
   public boolean resetMatchingNode(String nodeAddress, String nodePort, String nodeClass, String Role, String nodeStatus){

	   Node node = new Node();
	   node.setMatchingNodeDefault(nodeAddress, nodePort, Role);
	   node.setNodeClass(nodeClass);
	   node.setNodeStatus(nodeStatus);
	   return faceDataManager.resetNode(node);
   }


   /*
    * VAS_FR_CCTV table에 node id와 mapping되어 존재하는 cctv id를 모두 삭제한다
    */
	public boolean clearCctvList(int nodeId) {
	   return faceDataManager.clearCctv(nodeId);

   }
	
	/*
	 * VAS_FR_CCTV table에 node id와 mapping되어 존재하는 cctv id를 모두 삭제한다
	 */
	public boolean clearCctv(int nodeId, String cctvId) {
		return faceDataManager.clearCctv(nodeId, cctvId);

	}	

   /*
    * VAS_FR_NODE_CCTV table에서 node id에 해당되는 cctv list를 모두 가져온다
    */
   public List<Cctv> getCctvList(int nodeId){
	   return faceDataManager.getCctvList(nodeId);

   }

	/*
	 * VAS_FR_NODE table에서 기 존재하는 Node 정보를 update한다 update 대상 column = ROLE,
	 * NODE_STATUS, UPDATE_AT
	 */
   public boolean updateNode(Node node){
	   return faceDataManager.updateNode(node);
   }

   /*
    * VAS_FR_CCTV
    */
   public boolean setCctvList(List<Cctv> cctvList) {
	   return faceDataManager.setCctvList(cctvList);
   }

   /*
    * VAS_FR_NODE table에서 모든 node data를 가져온다
    */
   public List<Node> getNodeList() {
	   return faceDataManager.getNodeList();
   }

   /*
    * VAS_FR_NODE_CCTV table에서 cctvId, systemId에 해당되는 cctv를 가져온다
    */
   public Cctv findCctvByCctvId(String cctvId, String systemId) {
	   return faceDataManager.findCctvByCctvId(cctvId, systemId);
   }

   /*
    * VAS_FR_NODE table에서 role=standby, class=ondemand 인 node list를 가져온다
    */
   public List<Node> getStandbyOndemandNodeList() {
	   return faceDataManager.getStandbyOndemandNodeList();
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_DB table에서 status = started 이고 job Id에 해당되는 Node_ID
	 * 정보를 가져온다
    */
   public List<Integer> getOngoingOndemandDBNodeList(String jobId) {
	   return faceDataManager.getOngoingOndemandDBNodeList(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VMS table에서 status = started 이고 job Id에 해당되는 Node_ID
	 * 정보를 가져온다
    */
   public List<Integer> getOngoingOndemandVMSNodeList(String jobId) {
	   return faceDataManager.getOngoingOndemandVMSNodeList(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VIDEO table에서 status = started 이고 job Id에 해당되는
	 * Node_ID 정보를 가져온다
    */
   public List<Integer> getOngoingOndemandVideoNodeList(String jobId) {
	   return faceDataManager.getOngoingOndemandVideoNodeList(jobId);
   }

   /*
	 * VAS_JOB_CNCRN_FACE의 face id 값에 해당되는 feature 정보를 VAS_CNCRN_FACE table에서
	 * 가져온다
    */
   public HashMap<String, byte[]> getFeatures(String jobId) {

	   HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("job_id", jobId);

		/*
		 * String: face id Object: byte[] feature
		 */
		List<HashMap<String, Object>> faceFeatures = faceMatchJobService.findConcernedFaceFeatureListByJobId(param);

		HashMap<String, byte[]> concernFaces = new HashMap<String, byte[]>();
		for(HashMap<String, Object> faceFeature : faceFeatures) {
			concernFaces.put(String.valueOf(faceFeature.get("job_cncrn_face_id")), (byte[])faceFeature.get("feature"));
		}

		return concernFaces;
   }

   /*
    * VAS_FR_NODE_ONDEMAND_DB table에 store
    */
   public void storeOndemandDBSubJob(OndemandDBSubJobVO ondemandDBSubJobVO) {
	   faceDataManager.storeOndemandDBSubJob(ondemandDBSubJobVO);

   }

   /*
    * VAS_FR_NODE_ONDEMAND_VMS table에 store
    */
   public void storeOndemandVMSSubJob(OndemandVMSSubJobVO ondemandVMSSubJobVO) {
	   faceDataManager.storeOndemandVMSSubJob(ondemandVMSSubJobVO);

   }

   /*
    * VAS_FR_NODE_ONDEMAND_VIDEO table에 store
    */
   public void storeOndemandVideoSubJob(OndemandVideoSubJobVO ondemandVideoSubJobVO) {
	   faceDataManager.storeOndemandVideoSubJob(ondemandVideoSubJobVO);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_DB table에서 node Id에 해당되는 job 중, status = started or
	 * allocated에 해당되는 job을 가져온다
    */
   public OndemandDBSubJobVO getOngoingDBSubJob(int nodeId) {
	   return faceDataManager.getOngoingDBSubJob(nodeId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VMS table에서 node Id에 해당되는 job 중, status = started or
	 * allocated에 해당되는 job을 가져온다
    */
   public OndemandVMSSubJobVO getOngoingVMSSubJob(int nodeId) {
	   return faceDataManager.getOngoingVMSSubJob(nodeId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VIDEO table에서 node Id에 해당되는 job 중, status = started
	 * or allocated에 해당되는 job을 가져온다
    */
   public OndemandVideoSubJobVO getOngoingVideoSubJob(int nodeId) {
	   return faceDataManager.getOngoingVideoSubJob(nodeId);
   }

   /*
	 * VAS_FR_NODE_ODDEMAND_DB table에서 job Id를 갖는 모든 node의 status = completed,
	 * completed_with_error, aborted에 해당되는지 확인한다
    */
   public boolean isOndemandDBJobofAllNodeCompleted(String jobId) {
	   return faceDataManager.isOndemandDBJobofAllNodeCompleted(jobId);
   }

   /*
	 * VAS_FR_NODE_ODDEMAND_VMS table에서 job Id를 갖는 모든 node의 status = completed,
	 * completed_with_error, aborted에 해당되는지 확인한다
    */
   public boolean isOndemandVMSJobofAllNodeCompleted(String jobId) {
	   return faceDataManager.isOndemandVMSJobofAllNodeCompleted(jobId);
   }

   /*
	 * VAS_FR_NODE_ODDEMAND_VIDEO table에서 job Id를 갖는 모든 node의 status =
	 * completed, completed_with_error, aborted에 해당되는지 확인한다
    */
   public boolean isOndemandVideoJobofAllNodeCompleted(String jobId) {
	   return faceDataManager.isOndemandVideoJobofAllNodeCompleted(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_DB table에서 job Id를 갖는 모든 node에 대해서 status =
	 * completed_with_error, aborted를 하나라도 갖게되면 fail return
    */
   public boolean isOndemandDBJobSuccessful(String jobId) {
	   return faceDataManager.isOndemandDBJobSuccessful(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VMS table에서 job Id를 갖는 모든 node에 대해서 status =
	 * completed_with_error, aborted를 하나라도 갖게되면 fail return
    */
   public boolean isOndemandVMSJobSuccessful(String jobId) {
	   return faceDataManager.isOndemandVMSJobSuccessful(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_Video table에서 job Id를 갖는 모든 node에 대해서 status =
	 * completed_with_error, aborted를 하나라도 갖게되면 fail return
    */
   public boolean isOndemandVideoJobSuccessful(String jobId) {
	   return faceDataManager.isOndemandVideoJobSuccessful(jobId);
   }

   /*
	 * VAS_FR_NODE_ONDEMNAD_DB table에 job id, node id에 해당되는 status, (start time
	 * or end time)를 update 한다
    */
   public void updateOndemandDBSubJobUpdate(int nodeId, String jobId, String status) {
	   faceDataManager.updateOndemandDBStatus(nodeId, jobId, status);
   }

   /*
	 * VAS_FR_NODE_ONDEMNAD_VMS table에 job id, node id에 해당되는 status, (start time
	 * or end time)를 update 한다
    */
   public void updateOndemandVMSSubJobUpdate(int nodeId, String jobId, String status) {
	   faceDataManager.updateOndemandVMSStatus(nodeId, jobId, status);
   }

   /*
	 * VAS_FR_NODE_ONDEMNAD_Video table에 job id, node id에 해당되는 status, (start
	 * time or end time)를 update 한다
    */
   public void updateOndemandVideoSubJobUpdate(int nodeId, String jobId, String status) {
	   faceDataManager.updateOndemandVideoStatus(nodeId, jobId, status);
   }

   /*
	 * VAS_FR_NODE_ONDEMNAD_DB table에 job id, node id에 해당되는 status, start_time,
	 * total_start_thread를 update 한다
    */
   public void updateOndemandDBSubJobUpdateWithThread(OndemandDBSubJobVO dbSubJobVO) {
	   faceDataManager.updateOndemandDBStatusWithThread(dbSubJobVO);
   }


   /*
	 * VAS_FR_NODE_ONDEMNAD_VMS table에 job id, node id에 해당되는 status, start_time,
	 * total_start_thread를 update 한다
    */
   public void updateOndemandVMSSubJobUpdateWithThread(OndemandVMSSubJobVO vmsSubJobVO) {
	   faceDataManager.updateOndemandVMSStatusWithThread(vmsSubJobVO);
   }

   /*
	 * VAS_FR_NODE_ONDEMNAD_VIDEO table에 job id, node id에 해당되는 status,
	 * start_time, total_start_thread를 update 한다
    */
   public void updateOndemandVideoSubJobUpdateWithThread(OndemandVideoSubJobVO videoSubJobVO) {
	   faceDataManager.updateOndemandVideoStatusWithThread(videoSubJobVO);
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_DB table에서 job id, node id에 해당되는 total_start_thread,
	 * total_completed_thread 값이 동일한지 확인
    */
   public List<Integer> checkDBSubJobThread(int nodeId, String jobId) {
	   HashMap<String, Integer> totalThreadMap = faceDataManager.selectOndemandDBThread(nodeId,jobId);
		if (totalThreadMap == null)
			return null;

	   List<Integer> totalThreads = new ArrayList<Integer>();
	   totalThreads.add(totalThreadMap.get("total_start_thread"));
	   totalThreads.add(totalThreadMap.get("total_completed_thread"));

	   return totalThreads;
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_VMS table에서 job id, node id에 해당되는
	 * total_start_thread, total_completed_thread 값이 동일한지 확인
    */
   public List<Integer> checkVMSSubJobThread(int nodeId, String jobId) {
	   HashMap<String, Integer> totalThreadMap = faceDataManager.selectOndemandVMSThread(nodeId, jobId);
		if (totalThreadMap == null)
			return null;

	   List<Integer> totalThreads = new ArrayList<Integer>();
	   totalThreads.add(totalThreadMap.get("total_start_thread"));
	   totalThreads.add(totalThreadMap.get("total_completed_thread"));

	   return totalThreads;
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_Video table에서 job id, node id에 해당되는
	 * total_start_thread, total_completed_thread 값이 동일한지 확인
    */
   public List<Integer> checkVideoSubJobThread(int nodeId, String jobId) {
	   HashMap<String, Integer> totalThreadMap = faceDataManager.selectOndemandVideoThread(nodeId,jobId);
		if (totalThreadMap == null)
			return null;

	   List<Integer> totalThreads = new ArrayList<Integer>();
	   totalThreads.add(totalThreadMap.get("total_start_thread"));
	   totalThreads.add(totalThreadMap.get("total_completed_thread"));

	   return totalThreads;
   }

   /*
	 * VAS_FR_NODE_ONDEMAND_DB table에서 job id, node id에 해당되는
	 * total_completed_thread 값을 update 한다
    */
   public int updateOndemandDBCompletedThread(int nodeId, String jobId, int completedTotalThread){
	   return faceDataManager.updateOndemandDBCompletedThread(nodeId, jobId, completedTotalThread);
   }

   /*
    * VAS_FR_NODE_ONDEMAND_VMS table에서 job id, node id에 해당되는 total_completed_thread 값을 update 한다
    */
   public int updateOndemandVMSCompletedThread(int nodeId, String jobId, int completedTotalThread){
	   return faceDataManager.updateOndemandVMSCompletedThread(nodeId, jobId, completedTotalThread);
   }

   /*
    * VAS_FR_NODE_ONDEMAND_DB table에서 job id, node id에 해당되는 total_completed_thread 값을 update 한다
    */
   public int updateOndemandVideoCompletedThread(int nodeId, String jobId, int completedTotalThread){
	   return faceDataManager.updateOndemandVideoCompletedThread(nodeId, jobId, completedTotalThread);
   }

   /*
    * VAS_FR_NODE_ONDMENAD_DB table에서 job id에 해당되는 모든 node 정보를 가져온다
    */
   public List<OndemandDBSubJobVO> getDBAllNodeSubJobThread(String jobId) {
	   return faceDataManager.selectOndemandDBNode(jobId);
   }

   /*
    * VAS_FR_NODE_ONDMENAD_VMS table에서 job id에 해당되는 모든 node 정보를 가져온다
    */
   public List<OndemandVMSSubJobVO> getVMSAllNodeSubJobThread(String jobId) {
	   return faceDataManager.selectOndemandVMSNode(jobId);
   }

   /*
    * VAS_FR_NODE_ONDMENAD_Video table에서 job id에 해당되는 모든 node 정보를 가져온다
    */
   public List<OndemandVideoSubJobVO> getVideoAllNodeSubJobThread(String jobId) {
	   return faceDataManager.selectOndemandVideoNode(jobId);
   }

   /*
    * VAS_FR_NODE_ODNEMNAD_DB table에서 node id, job id에 해당되는 정보를 삭제한다
    */
   public void deleteDBSubJob(int nodeId, String jobId) {
	   faceDataManager.deleteDBSubJob(nodeId, jobId);
   }

   /*
    * VAS_FR_NODE_ONDEMNAD_VMS table에서 node id, job id에 해당되는 정보를 삭제한다
    */
   public void deleteVMSSubJob(int nodeId, String jobId) {
	   faceDataManager.deleteVMSSubJob(nodeId, jobId);
   }

   /*
    * VAS_FR_NODE_ONDEMNAD_Video table에서 node id, job id에 해당되는 정보를 삭제한다
    */
   public void deleteVideoSubJob(int nodeId, String jobId) {
	   faceDataManager.deleteVideoSubJob(nodeId, jobId);
   }

   /*
    * VAS_JOB_MASTER table에 RSLT_STTS, PROGRESS, EDIT_TIME을 update 한다
    */
   public void updateJobMaster(String jobId, OndemandJobMasterVO jobMasterVO) {
	   faceDataManager.updateJobMaster(jobId, jobMasterVO.getProgress(), jobMasterVO.getResultStatus());
   }

   public List<String> selectOngoingDBJob(int nodeId) {
	   return faceDataManager.selectOngoingDBJob(nodeId);
   }

   public List<String> selectOngoingVMSJob(int nodeId) {
	   return faceDataManager.selectOngoingVMSJob(nodeId);
   }

   public List<String> selectOngoingVideoJob(int nodeId) {
	   return faceDataManager.selectOngoingVideoJob(nodeId);
   }

   public List<Integer> selectNumOfOndemandDBStanbyNode() {
	   return faceMatchJobService.selectNumOfOndemandDBStanbyNode();
   }

   public List<Integer> selectNumOfOndemandVMSStanbyNode() {
	   return faceMatchJobService.selectNumOfOndemandVMSStanbyNode();
   }

   public List<Integer> selectNumOfOndemandVideoStanbyNode() {
	   return faceMatchJobService.selectNumOfOndemandVideoStanbyNode();
   }

   public FileAnalysisRequest.AnalysisResource selectAnalysisResource(int rscId) {
	   return faceDataManager.selectAnalysisResource(rscId);
   }

	/*
	 * 관심인물 from to를 삭제한다
	 */
	public void clearConcernIndex(int nodeId) {

		faceDataManager.deleteMatchingNodeCncrnIndex(nodeId);
	}
	
	/*
	 * 관심인물 from to를 변경한다
	 */
	public HashMap<Integer,Integer> selectConcernMatchingVolumeInfo(String nodeAddress, String nodePort) {

		return faceDataManager.getConcernMatchingVolumeInfo(nodeAddress, nodePort);
	}
	
	/*
	 * 관심인물 from to를 변경한다
	 */
	public HashMap<Integer,Integer> selectConcernMatchingVolumeInfo(int nodeId) {

		return faceDataManager.getConcernMatchingVolumeInfo(nodeId);
	}
	
	/*
	 * 관심인물 from to를 변경한다
	 */
	public void updateConcernIndex(int nodeId, int fromIdx, int toIdx) {

		faceDataManager.updateMatchingNodeCncrnIndex(nodeId, fromIdx, toIdx);
	}
	
	/*
	 * 관심인물 from to를 입력한다
	 */
	public void insertMatchingNodeCncrnIndex(int nodeId, int fromIdx, int toIdx) {

		faceDataManager.insertMatchingNodeCncrnIndex(nodeId, fromIdx, toIdx);
	}
	
	/*
	 * VAS_IF_MQ_MAPPING table에서 group Id를 가져오고 , VAS_FR_NODE, VAS_IF_MQ_MAPPING table을 사용해서 standby node 리스르틀 가져온다.
	 */
	public List<Node> getMatchingNodeListOfGroup(int nodeId) {
		return faceDataManager.getMatchingNodeListOfGroup(nodeId);
	}

	/*
	 * VAS_IF_MQ_MAPPING table에서 group Id를 가져오고 , VAS_FR_NODE, VAS_IF_MQ_MAPPING table을 사용해서 standby node 리스르틀 가져온다.
	 */
	public List<Node> getDetectionNodeListOfGroup(String nodeClass, int nodeId) {
		return faceDataManager.getDetectionNodeListOfGroup(nodeClass, nodeId);
	}	
	
	/*
	 * VAS_IF_MQ_MAPPING table에서 자신에게 해당되는 group Id를 가져온다
	 */
	public int getGroupId(int nodeId) {
		return faceDataManager.getGroupId(nodeId);
		
	}
	

}
