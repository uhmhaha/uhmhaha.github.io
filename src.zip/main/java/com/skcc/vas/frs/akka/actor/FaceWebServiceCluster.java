package com.skcc.vas.frs.akka.actor;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.*;

import javax.annotation.*;
import javax.validation.constraints.*;

import org.apache.commons.lang3.*;
import org.hibernate.validator.constraints.*;

import akka.actor.*;
import akka.camel.*;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.ser.impl.*;
import com.skcc.vas.frs.akka.cluster.*;
import com.skcc.vas.frs.akka.model.*;
import com.skcc.vas.frs.akka.routing.*;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.live.biz.*;
import com.skcc.vas.frs.ondemand.db.biz.*;
import com.skcc.vas.frs.ondemand.video.biz.OndemandVideoProcessor;
import com.skcc.vas.frs.ondemand.vms.biz.OndemandVMSProcessor;

/**
 *
 * <h4>Start live on a CCTV</h4> To start live face recognition on a CCTV, the
 * request JSON object should contain {@code type}, {@code systemId}, and
 * {@code id} fields. The {@code type} should be always "{@code START_CCTV}".
 * The {@code id} should be the ID of CCTV to start. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "START_CCTV",
 *   "systemId" : "VMS03",
 *   "id" : "51"
 * }
 * </pre>
 *
 * <h4>Stop live on a CCTV</h4> To stop live face recognition on a CCTV, the
 * request JSON object should contain {@code type}, {@code systemId}, and
 * {@code id} fields.<br>
 * The {@code type} should be always "{@code STOP_CCTV}". The {@code id} should
 * be the ID of CCTV to stop. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "STOP_CCTV",
 *   "systemId" : "VMS03",
 *   "id" : "51"
 * }
 * </pre>
 *
 * <h4>Generate features and landmarks for the faces of a concerned person</h4>
 * To generate the metas (features and landmarks) for the faces of the specified
 * person, the request should contain {@code type} and {@code id} fields.<br>
 * The {@code type} filed should be always "{@code GENERATE_FACE_METAS_BY_PERSON}
 * ". The {@code id} field should be the ID of concerned person to process. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "GENERATE_FACE_METAS_BY_PERSON",
 *    "id" : "335"
 * }
 * </pre>
 *
 * <h4>Generate features and landmarks for the specified faces</h4> To generate
 * the metas (features and landmarks) for the specified faces, the request
 * should contain {@code type} and {@code object} fields.<br>
 * The {@code type} filed should be always "{@code GENERATE_FACE_METAS}". The
 * {@code object} field should be an array of the IDs of faces wrapped by the
 * outer array led by "{@code java.util.ArrayList}". <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "GENERATE_FACE_METAS",
 *    "object" : ["java.util.ArrayList", ["11","12","13"]]
 * }
 * </pre>
 *
 * <h4>Remove a concerned person</h4> To remove a concerned person, the request
 * should contain {@code type} and {@code id} fields.<br>
 * The {@code type} field should be always "{@code REMOVE_PERSON}". The
 * {@code id} field should be the ID of concerned person to remove.<br>
 * Actually the data would not removed but the data for the concerned person
 * would be set <strong>invalid</strong> and the data for the faces of the
 * concerned person would be set invalid. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "REMOVE_PERSON",
 *    "id" : "335"
 * }
 * </pre>
 *
 * <h4>Remove concerned faces</h4> To remove concerned faces, the request should
 * contain {@code type} and {@code object} fields.<br>
 * The {@code type} field should be always "{@code REMOVE_FACES}" The
 * {@code object} field should be an array of the IDs of faces wrapped by the
 * outer array led by "{@code java.util.ArrayList}". <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "REMOVE_FACES",
 *    "object" : ["java.util.ArrayList", ["21","22","23"]]
 * }
 * </pre>
 *
 * <h4>Search faces</h4> <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "SEARCH_FACES",
 *    "id" : "2231"
 * }
 * </pre>
 *
 * <h4>Register faces</h4> <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "REGISTER_CONCERNED_FACE",
 *    "faceImgPath" : "/cncrnface/aaa.jpg"
 * }
 * </pre>
 *
 * <pre style="font-family:Consolas">
 * {
 *    "type" : "REGISTER_CONCERNED_FACE_DONE"
 * }
 * </pre>
 *
 * <h4>Start Node</h4> To start live face recognition about the specified node,
 * the request JSON object should contain {@code type}, {@code systemId}, and
 * {@code nodeId} fields.<br>
 * The {@code type} should be always "{@code START_NODE}". The {@code nodeId}
 * should be the ID of Node to start. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "START_NODE",
 *   "systemId" : "VMS03",
 *   "id" : "2"
 * }
 * </pre>
 * 
 * <h4>Stop Node</h4> To stop live face recognition about the specified node,
 * the request JSON object should contain {@code type}, {@code systemId}, and
 * {@code nodeId} fields.<br>
 * The {@code type} should be always "{@code START_NODE}". The {@code nodeId}
 * should be the ID of Node to start. <br>
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "STOP_NODE",
 *   "systemId" : "VMS03",
 *   "id" : "2"
 * }
 * </pre>
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "START_NODE_ALL",
 *   "systemId" : "VMS03"
 * }
 * </pre>
 * 
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "STOP_NODE_ALL",
 *   "systemId" : "VMS03"
 * }
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "ROI_UPDATED",
 *   "systemId" : "VMS03"
 *   "id": "2"
 * }
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES",
 *   "systemId" : "VMS03"
 * }
 *
 * <pre style="font-family:Consolas">
 * {
 *   "type" : "FR_ENGINE_PARAMETER_UPDATED_IN_ONE_CCTV",
 *   "systemId" : "VMS03"
 *   "id": "2"
 * }
 *
 *
 */

public class FaceWebServiceCluster extends WebServiceBase {

	private final ActorRef detectionService;

	@Nonnull
	private final ConcernedPersonProcessor concernedPersonProcessor;

	@Nullable
	private final OndemandDBProcessor clusterDBProcessor;
	@Nullable
	private final OndemandVMSProcessor clusterVMSProcessor;
	@Nullable
	private final OndemandVideoProcessor clusterVideoProcessor;

	@Nullable
	private final FaceMatchJobService faceMatchJobService;

	private final FRSVersion frsVersion;

	/**
	 * @param uri
	 *            expected to be start with "http://"
	 * @param jacksonMapper
	 * @param timeout
	 */
	public FaceWebServiceCluster(@NotBlank String uri, @Nonnull ObjectMapper jacksonMapper,
			@Min(TIMEOUT_MIN) int timeout, @Nonnull ActorRef detectionService,
			@Nonnull ConcernedPersonProcessor concernedPersonProcessor,
			@Nullable OndemandDBProcessor clusterDBProcessor, @Nullable OndemandVMSProcessor clusterVMSProcessor,
			@Nullable OndemandVideoProcessor clusterVideoProcessor, @Nullable FaceMatchJobService faceMatchJobService,
			FRSVersion frsVersion) {

		// @TODO Check it is safe or not to hand over an actor reference to the
		// constructor.
		super(uri, jacksonMapper, timeout);

		Validate.isTrue(detectionService != null, "Actor for detection service should be provided.");
		Validate.isTrue(clusterDBProcessor != null, "OndemandDBProcessor should be provided.");
		Validate.isTrue(clusterVMSProcessor != null, "OndemandVMSProcessor should be provided.");
		Validate.isTrue(clusterVideoProcessor != null, "OndemandVideoProcessor should be provided.");

		this.detectionService = detectionService;
		this.concernedPersonProcessor = concernedPersonProcessor;
		this.clusterDBProcessor = clusterDBProcessor;
		this.clusterVMSProcessor = clusterVMSProcessor;
		this.clusterVideoProcessor = clusterVideoProcessor;
		this.faceMatchJobService = faceMatchJobService;
		this.frsVersion = frsVersion;

	}

	@Override
	public void onReceive(Object msg) throws Exception {

		if (msg instanceof CamelMessage) {

			final CamelMessage cm = (CamelMessage) msg;
			final String body;
			final FaceRequest req;
			FaceResponse response = new FaceResponse();
			String jsonResponse;

			try {
				body = cm.getBodyAs(String.class, getCamelContext());
				logger.info("++ HTTP request body message = [{}]", body);
				req = this.getJacksonMapper().readValue(body, FaceRequest.class);
			} catch (Exception ex) {
				this.logger.error("Fail to parse the request.", ex.getMessage());
				// make response message
				response.setResponseCode(FaceResponse.RESPONSE_CODE_REQUEST_FORMAT_ERROR);
				response.setResponseMessage("Fail to parse the request. : " + ex.getMessage());
				// jsonResponse =
				// this.getJacksonMapper().writeValueAsString(response);
				jsonResponse = this.getJacksonMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response);
				this.getSender().tell(jsonResponse, this.getSelf());
				return;
			}

			final FaceRequest.Type type = req.getType();

			CctvKey ck = null;
			KeyedMessage<?, ?> km = null;
			String personId = null;
			List<String> faceIds = null;
			String jobId = null;

			switch (type) {

				case START_CCTV :
					// need validation on req.id and req.systemId
					ck = new CctvKey(req.getSystemId(), req.getId());
					km = new KeyedMessage<CctvKey, Boolean>(ck, Boolean.TRUE);

					this.detectionService.tell(km, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					break;

				case STOP_CCTV :
					ck = new CctvKey(req.getSystemId(), req.getId());
					km = new KeyedMessage<CctvKey, Boolean>(ck, Boolean.FALSE);
					this.detectionService.tell(km, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					break;

				case REMOVE_PERSON :
					/*
					 * VAS_CNCRN_PERSION, VAS_CNCRN_FACE 해상 IS_VALID = N으로
					 * Update 실제 row 삭제는 없음
					 */
					try {
//						personId = req.getId();
//						this.concernedPersonProcessor.removePerson(personId);

						this.logger.debug("Remove Person ID : {} " , req.getPersonId());
						
						// send response message
						sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
								FaceResponse.RESPONSE_MESSAGE_SUCCESS);

						if (frsVersion == FRSVersion.FRS20) {
							// send VAS_CNCRN_FACE DB update message to all
							// worker nodes.
							ck = new CctvKey(CctvKey.CODE_CNCRN_FACE_DB_UPDATED);
							km = new KeyedMessage<CctvKey, Boolean>(ck, Boolean.FALSE);
							this.detectionService.tell(km, this.getSelf());
						} else {
							NodeMessage nm = new NodeMessage(NodeMessage.NodeMessageCode.NM_CNCRN_FACE_DB_UPDATED,
									req.getSystemId(), req.getId(), req.getPersonId());
							this.detectionService.tell(nm, this.getSelf());
						}

					} catch (Throwable ex) {
						// @TODO Upgrade the following temporary code
						// send response message
						sendResponse(response, FaceResponse.RESPONSE_CODE_REMOVE_PERSON_FAIL,
								FaceResponse.RESPONSE_MESSAGE_REMOVE_PERSON_FAIL + personId);

					}
					break;
				case REMOVE_FACES :
					/*
					 * VAS_CNCRN_FACE 해상 IS_VALID = N으로 Update 실제 row 삭제는 없음
					 */
					try {
//						faceIds = (ArrayList<String>) (req.getObject());
//						this.concernedPersonProcessor.removeFaces(faceIds.toArray(new String[faceIds.size()]));

						faceIds = (ArrayList<String>) (req.getFaceIds());
						this.logger.debug("Remove Face ID : {} " , faceIds.toString());
						
						// send response message
						sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
								FaceResponse.RESPONSE_MESSAGE_SUCCESS);

						if (frsVersion == FRSVersion.FRS20) {
							// send VAS_CNCRN_FACE DB update message to all
							// worker nodes.
							ck = new CctvKey(CctvKey.CODE_CNCRN_FACE_DB_UPDATED);
							km = new KeyedMessage<CctvKey, Boolean>(ck, Boolean.FALSE);
							this.detectionService.tell(km, this.getSelf());
						} else {
							NodeMessage nm = new NodeMessage(NodeMessage.NodeMessageCode.NM_CNCRN_FACE_DB_UPDATED,
									req.getSystemId(), req.getId(), faceIds);
							this.detectionService.tell(nm, this.getSelf());
						}

					} catch (Throwable ex) {
						// send response message
						sendResponse(response, FaceResponse.RESPONSE_CODE_REMOVE_FACE_FAIL,
								FaceResponse.RESPONSE_MESSAGE_REMOVE_FACE_FAIL + faceIds);
					}
					break;

				case SEARCH_FACES_DB :
					try {

						// test코드
						// clusterDBProcessor.search(clusterDBProcessor.splitJobs(jobId,
						// 3).get(1), 5, "10.250.46.129");
						// 실제코드

						jobId = req.getId();
						List<Integer> numOfStandbyNodeIds = faceMatchJobService.selectNumOfOndemandDBStanbyNode();
						if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
							logger.info("[Ondmend DB] there is no standby nodes. Job Id =[{}]", jobId);
							sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMAND_NO_STANDBY_NODE,
									FaceResponse.RESPONSE_MESSAGE_ONDEMAND_NO_STANDBY_NODE);

						} else {
							// sendResponse(response,
							// FaceResponse.RESPONSE_CODE_SUCCESS,
							// FaceResponse.RESPONSE_MESSAGE_SUCCESS);

							List<Integer> allocatedNodes = getAllocatedOndemandNodes(numOfStandbyNodeIds);

							List<OndemandDBSubJob> dbSubJobs = clusterDBProcessor.splitJobs(jobId,
									allocatedNodes.size());
							if (dbSubJobs == null) {
								faceMatchJobService.updateOndmenadFailStatus(jobId,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL + jobId);

								sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_DB_NO_DETECTED_FACES,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_NO_DETECTED_FACES + jobId);

								logger.error("++ [Ondemand DB] there is any detected faces to analysis.  ");

							} else if (allocatedNodes.size() != dbSubJobs.size()) {
								// update VAS_JOB_MASTER table
								faceMatchJobService.updateOndmenadFailStatus(jobId,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL + jobId);

								sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_DB_SPLITJOB_FAIL,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL + jobId);

								logger.error("++ [Ondemand DB] the number of standby node [{}] is not same "
										+ "the number of sub job [{}]", allocatedNodes.size(), dbSubJobs.size());
							} else {

								sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
										FaceResponse.RESPONSE_MESSAGE_SUCCESS);

								OndemandJob ondemandJob = new OndemandJob(OndemandJobConstant.JobType.DBJOB, jobId,
										OndemandJobConstant.JobCode.ONDEMNAD_JOB_START, dbSubJobs, null, null,
										allocatedNodes);

								this.detectionService.tell(ondemandJob, this.getSelf());
							}
						}

					} catch (Throwable ex) {
						this.logger.error("[Ondemand DB] fail to split DB Jobs. job Id = [{}]", jobId);

						// update VAS_JOB_MASTER table
						faceMatchJobService.updateOndmenadFailStatus(jobId,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL);

						sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_DB_SPLITJOB_FAIL,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_DB_SPLITJOB_FAIL + jobId);

					}
					break;
					
				case SEARCH_FACES_VMS :
					try {
						jobId = req.getId();
						List<Integer> numOfStandbyNodeIds = faceMatchJobService.selectNumOfOndemandVMSStanbyNode();
						if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
							logger.info("[Ondmend VMS] there is no standby nodes. Job Id =[{}]", jobId);
							sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMAND_NO_STANDBY_NODE,
									FaceResponse.RESPONSE_MESSAGE_ONDEMAND_NO_STANDBY_NODE);

						} else {

							// sendResponse(response,
							// FaceResponse.RESPONSE_CODE_SUCCESS,
							// FaceResponse.RESPONSE_MESSAGE_SUCCESS);
							List<Integer> allocatedNodes = getAllocatedOndemandNodes(numOfStandbyNodeIds);

							List<OndemandVMSSubJob> vmsSubJobs = clusterVMSProcessor.splitJobs(jobId,
									allocatedNodes.size());

							if (allocatedNodes.size() != vmsSubJobs.size()) {
								// update VAS_JOB_MASTER table
								faceMatchJobService.updateOndmenadFailStatus(jobId,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VMS_SPLITJOB_FAIL + jobId);

								sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_VMS_SPLITJOB_FAIL,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VMS_SPLITJOB_FAIL + jobId);

								logger.error("++ [Ondemand VMS] the number of standby node [{}] is not same "
										+ "the number of sub job [{}]", allocatedNodes.size(), vmsSubJobs.size());
							} else {
								sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
										FaceResponse.RESPONSE_MESSAGE_SUCCESS);

								OndemandJob ondemandJob = new OndemandJob(OndemandJobConstant.JobType.VMSJOB, jobId,
										OndemandJobConstant.JobCode.ONDEMNAD_JOB_START, null, vmsSubJobs, null,
										allocatedNodes);

								this.detectionService.tell(ondemandJob, this.getSelf());
							}
						}

					} catch (Throwable ex) {
						this.logger.error("[Ondemand VMS] fail to split VMS Jobs. job Id = [{}]", jobId);

						// update VAS_JOB_MASTER table
						faceMatchJobService.updateOndmenadFailStatus(jobId,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VMS_SPLITJOB_FAIL);

						sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_VMS_SPLITJOB_FAIL,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VMS_SPLITJOB_FAIL + jobId);

					}
					break;

				case SEARCH_FACE_VIDEO :
					try {
						jobId = req.getId();
						List<Integer> numOfStandbyNodeIds = faceMatchJobService.selectNumOfOndemandVideoStanbyNode();
						if (numOfStandbyNodeIds == null || numOfStandbyNodeIds.size() == 0) {
							logger.info("[Ondmend Video] there is no standby nodes. Job Id =[{}]", jobId);
							sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMAND_NO_STANDBY_NODE,
									FaceResponse.RESPONSE_MESSAGE_ONDEMAND_NO_STANDBY_NODE);

						} else {
							// sendResponse(response,
							// FaceResponse.RESPONSE_CODE_SUCCESS,
							// FaceResponse.RESPONSE_MESSAGE_SUCCESS);

							List<Integer> allocatedNodes = getAllocatedOndemandNodes(numOfStandbyNodeIds);

							List<OndemandVideoSubJob> videoSubJobs = clusterVideoProcessor.splitJobs(jobId,
									allocatedNodes.size());
							if (allocatedNodes.size() != videoSubJobs.size()) {
								// update VAS_JOB_MASTER table
								faceMatchJobService.updateOndmenadFailStatus(jobId,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VIDEO_SPLITJOB_FAIL + jobId);

								sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_VIDEO_SPLITJOB_FAIL,
										FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VIDEO_SPLITJOB_FAIL + jobId);

								logger.error("++ [Ondemand Video] the number of standby node [{}] is not same "
										+ "the number of sub job [{}]", allocatedNodes.size(), videoSubJobs.size());
							} else {

								sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
										FaceResponse.RESPONSE_MESSAGE_SUCCESS);

								OndemandJob ondemandJob = new OndemandJob(OndemandJobConstant.JobType.VIDEOJOB, jobId,
										OndemandJobConstant.JobCode.ONDEMNAD_JOB_START, null, null, videoSubJobs,
										allocatedNodes);

								this.detectionService.tell(ondemandJob, this.getSelf());
							}
						}

					} catch (Throwable ex) {
						this.logger.error("[Ondemand Video] fail to split Video Jobs. job Id = [{}]", jobId);

						// update VAS_JOB_MASTER table
						faceMatchJobService.updateOndmenadFailStatus(jobId,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VIDEO_SPLITJOB_FAIL);

						sendResponse(response, FaceResponse.RESPONSE_CODE_ONDEMNAD_VIDEO_SPLITJOB_FAIL,
								FaceResponse.RESPONSE_MESSAGE_ONDEMNAD_VIDEO_SPLITJOB_FAIL + jobId);

					}
					break;

				case STOP_FACES_DB :
					jobId = req.getId();

					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					OndemandJob ondemandJobDB = new OndemandJob(OndemandJobConstant.JobType.DBJOB, jobId,
							OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT);

					this.detectionService.tell(ondemandJobDB, this.getSelf());
					break;

				case STOP_FACES_VMS :
					jobId = req.getId();

					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					OndemandJob ondemandJobVMS = new OndemandJob(OndemandJobConstant.JobType.VMSJOB, jobId,
							OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT);

					this.detectionService.tell(ondemandJobVMS, this.getSelf());
					break;

				case STOP_FACES_VIDEO :
					jobId = req.getId();

					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					OndemandJob ondemandJobVideo = new OndemandJob(OndemandJobConstant.JobType.VIDEOJOB, jobId,
							OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT);

					this.detectionService.tell(ondemandJobVideo, this.getSelf());
					break;

				case REGISTER_CONCERNED_FACE :
					try {

						HashMap<Integer, Object> result = this.concernedPersonProcessor.registerConcernedFace(req
								.getFaceImgPath());
						int ret = 0;
						for (int key : result.keySet()) {
							ret = key;
						}

						switch (ret) {
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_SUCCESS : // send
																						// response
																						// message
								response.setFeature(result.get(ret));
								sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS,
										FaceResponse.RESPONSE_MESSAGE_SUCCESS);
								break;
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_NO_IMAGE : // 실패상태
																							// 리턴
								// send response message
								sendResponse(response, FaceResponse.RESPONSE_CODE_REGISTER_FACE_NO_IMAGE,
										FaceResponse.RESPONSE_MESSAGE_REGISTER_FACE_NO_IMAGE);
								break;
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_NO_FACE : // 실패상태
																						// 리턴
								// send response message
								sendResponse(response, FaceResponse.RESPONSE_CODE_REGISTER_FACE_DETECT_FAIL,
										FaceResponse.RESPONSE_MESSAGE_REGISTER_FACE_DETECT_FAIL);
								break;
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_MULTIPLE_FACES : // 실패상태
																								// 리턴
								// send response message
								sendResponse(response, FaceResponse.RESPONSE_CODE_REGISTER_FACE_MULTIPLE_FACES,
										FaceResponse.RESPONSE_MESSAGE_REGISTER_FACE_MULTIPLE_FACES);
								break;
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_FACE_OVER_CAPACITY : // 실패상태
																									// 리턴
								// send response message
								sendResponse(response, FaceResponse.RESPONSE_CODE_REGISTER_FACE_OVER_CAPACITY,
										FaceResponse.RESPONSE_MESSAGE_REGISTER_FACE_OVER_CAPACITY);
								break;
							case HbInnoConcernedPersonProcessor.RESPONSE_CODE_NO_FILE_EXTENSION :
								sendResponse(response, FaceResponse.RESPONSE_CODE_REGISTER_FACE_NO_FILE_EXTENSION,
										FaceResponse.RESPONSE_MESSAGE_REGISTER_FACE_NO_FILE_EXTENSION);
								break;
						}// switch()

					} catch (Exception ex) {
						// send response message
						logger.debug("Register concerned face meets exception : [{}]", getPrintStacTraceString(ex));
						sendResponse(response, FaceResponse.RESPONSE_CODE_FAIL, FaceResponse.RESPONSE_MESSAGE_FAIL);
					}
					break;
				case REGISTER_CONCERNED_FACE_DONE :
					// send VAS_CNCRN_FACE DB update message to all worker
					// nodes.
					if (frsVersion == FRSVersion.FRS20) {
						ck = new CctvKey(CctvKey.CODE_CNCRN_FACE_DB_UPDATED);
						km = new KeyedMessage<CctvKey, Boolean>(ck, Boolean.FALSE);
						this.detectionService.tell(km, this.getSelf());
					} else {
						this.logger.debug("Registered Face Count : {}", req.getFacesCount());
						NodeMessage nm = new NodeMessage(NodeMessage.NodeMessageCode.NM_CNCRN_FACE_DB_UPDATED,
								req.getSystemId(), req.getFaceIdFrom(), req.getFaceIdTo());
						this.detectionService.tell(nm, this.getSelf());
					}

					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					break;

				case START_NODE :
					NodeMessage nmStart = new NodeMessage(NodeMessage.NodeMessageCode.NM_NODE_START, req.getSystemId(),
							Integer.parseInt(req.getId()));
					this.detectionService.tell(nmStart, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					break;
				case STOP_NODE :
					NodeMessage nmStop = new NodeMessage(NodeMessage.NodeMessageCode.NM_NODE_STOP, req.getSystemId(),
							Integer.parseInt(req.getId()));
					this.detectionService.tell(nmStop, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					break;
				case START_NODE_ALL :
					NodeMessage nmStartAll = new NodeMessage(NodeMessage.NodeMessageCode.NM_NODE_START_ALL,
							req.getSystemId());
					this.detectionService.tell(nmStartAll, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					break;

				case STOP_NODE_ALL :
					NodeMessage nmStopAll = new NodeMessage(NodeMessage.NodeMessageCode.NM_NODE_STOP_ALL,
							req.getSystemId());
					this.detectionService.tell(nmStopAll, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					break;

				case ROI_UPDATED :
					NodeMessage nmROIUpdated = new NodeMessage(
							NodeMessage.NodeMessageCode.NM_NODE_ROI_UPDATED_IN_ONE_DEVICE, req.getSystemId(),
							req.getId());
					this.detectionService.tell(nmROIUpdated, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					break;

				case FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES :
					NodeMessage nmFREngineUpdated = new NodeMessage(
							NodeMessage.NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ALL_NODES,
							req.getSystemId());

					this.detectionService.tell(nmFREngineUpdated, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					break;

				case FR_ENGINE_PARAMETER_UPDATED_IN_ONE_CCTV :
					NodeMessage nmFREngineUpdatedOne = new NodeMessage(
							NodeMessage.NodeMessageCode.NM_NODE_FR_ENGINE_PARAMETER_UPDATED_IN_ONE_DEVICE,
							req.getSystemId(), req.getId());

					this.detectionService.tell(nmFREngineUpdatedOne, this.getSelf());

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);

					break;

				case ONDEMAND_DB_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.DBJOB, OndemandJobConstant.JobCode.ONDEMNAD_JOB_START,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;
				case ONDEMAND_VMS_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.VMSJOB, OndemandJobConstant.JobCode.ONDEMNAD_JOB_START,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;
				case ONDEMAND_VIDEO_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.VIDEOJOB, OndemandJobConstant.JobCode.ONDEMNAD_JOB_START,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;
				case ONDEMAND_DB_ABORT_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.DBJOB, OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;
				case ONDEMAND_VMS_ABORT_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.VMSJOB, OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;
				case ONDEMAND_VIDEO_ABORT_RESULT :
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
					{
						jobId = req.getId();
						int nodeId = req.getNodeId();
						int subJobResult = req.getSubJobResult();
						String subJobMessage = req.getSubJobMessage();
						OndemandJobResponse jobResponse = new OndemandJobResponse(jobId,
								OndemandJobConstant.JobType.VIDEOJOB, OndemandJobConstant.JobCode.ONDEMAND_JOB_ABORT,
								nodeId, subJobResult, subJobMessage);

						this.detectionService.tell(jobResponse, this.getSelf());
					}
					break;

				case HEALTH_CHECK :
					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_SUCCESS, FaceResponse.RESPONSE_MESSAGE_SUCCESS);
				default :

					// send response message
					sendResponse(response, FaceResponse.RESPONSE_CODE_NOT_DEFINED,
							FaceResponse.RESPONSE_MESSAGE_NOT_DEFINED_REQUEST + type);
					break;

			}// switch()

		} else {
			if (msg != null) {
				this.logger.warning("Received unexpected type of message. {}", msg.getClass().getSimpleName());
			} else {
				this.logger.warning("Received null message.");
			}

			this.unhandled(msg);
		}

	} // end of OnReceive()

	private void sendResponse(FaceResponse response, int code, String message) {

		try {
			response.setResponseCode(code);
			response.setResponseMessage(message);

			this.getJacksonMapper().setFilterProvider(
					new SimpleFilterProvider().addFilter("FaceResponeJSONFilter", new FaceResponeJSONFilter()));
			String jsonResponse = this.getJacksonMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response);
			// String jsonResponse =
			// this.getJacksonMapper().writeValueAsString(response);
			this.getSender().tell(jsonResponse, this.getSelf());
			logger.debug("++ http response : [{}]", response);
		} catch (Exception ex) {
			this.logger.warning("JacksonMapper Exception : {}", ex.toString());
		}

	}// end of sendResponse();

	private List<Integer> getAllocatedOndemandNodes(List<Integer> standbyNodes) {

		// int numOfStandbyNode = standbyNodes.size();
		// if(numOfStandbyNode <= 3) return standbyNodes;
		//
		// double numOfIdelNode = Math.round((double)numOfStandbyNode * 0.1);
		//
		// if((int)numOfIdelNode == 0) return standbyNodes;
		//
		// int eraseCount = 0;
		// for(int index = (numOfStandbyNode - 1); index <= 0; index-- ) {
		// standbyNodes.remove(index);
		// eraseCount++;
		// if(eraseCount == (int)numOfIdelNode) break;
		// }

		return standbyNodes;

	}
	
	public static String getPrintStacTraceString(Exception e) {
		String returnValue = "";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		returnValue = out.toString();
		return returnValue;
	}


}
