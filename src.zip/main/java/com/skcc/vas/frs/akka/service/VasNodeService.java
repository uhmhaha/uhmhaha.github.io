package com.skcc.vas.frs.akka.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.skcc.vas.frs.akka.cluster.ClusterMasterDynamicRouting;
import com.skcc.vas.frs.akka.cluster.ClusterWorkerDynamicRouting;
import com.skcc.vas.frs.akka.db.rdb.domain.VasNode;
import com.skcc.vas.frs.akka.db.repository.NodeMapper;

@Service("vasNodeService")
public class VasNodeService {

	public static final int PORT_ERROR = -1;
	public static final String ALLOCATED = "Y";
	public static final String NODE_TYPE_MASTER = "MAST-NODE";
	public static final String NODE_TYPE_WORKER = "WORK-NODE";

	@Resource(name = "face.NodeMapper")
	private NodeMapper nodeMapper;

	public List<VasNode> getNodeInfo() {

		List<VasNode> vasNodes = nodeMapper.selectVasNodes();
		if (vasNodes == null || vasNodes.size() == 0) {
			return Collections.emptyList();
		}

		// remove VasNode with useYN = 'N' or 'n'
		List<VasNode> filteredVasNodes = new ArrayList<VasNode>();
		for (VasNode vasNode : vasNodes) {
			if (vasNode.getUseYN() != null && vasNode.getUseYN().equalsIgnoreCase("n")) {
				continue;
			}
			filteredVasNodes.add(vasNode);
		}
		return filteredVasNodes;
	}

	public List<VasNode> getNodeInfo(String systemId) {

		List<VasNode> vasNodes = nodeMapper.selectVasNodesWithSystemId(systemId);
		if (vasNodes == null || vasNodes.size() == 0) {
			return Collections.emptyList();
		}

		return vasNodes;
	}

	public boolean existAddressnPort(String ipAddress, String port) {

		Integer nodeId = nodeMapper.selectNodeId(ipAddress, port);
		if (nodeId == null) {
			return false;
		} else {
			if (nodeId.intValue() <= 0) {
				return false;
			}
		}

		return true;
	}

	public boolean existAddressnPort(String ipAddress, String port, String role) {

		VasNode vasNode = nodeMapper.selectVasNode(ipAddress, port);
		if (vasNode == null) {
			return false;
		}

		String nodeType = vasNode.getNodeType();

		// master node
		if (role.equalsIgnoreCase(ClusterMasterDynamicRouting.ROLE)) {
			if (nodeType.equalsIgnoreCase(NODE_TYPE_MASTER))
				return true;
			else
				return false;
		} else if (role.equalsIgnoreCase(ClusterWorkerDynamicRouting.ROLE)) {
			if (nodeType.equalsIgnoreCase(NODE_TYPE_WORKER))
				return true;
			else
				return false;
		} else {
			return false;
		}

	}

	public int getAvailablePort(String ipAddress, String role) {

		String nodeType;

		// master node
		if (role.equalsIgnoreCase(ClusterMasterDynamicRouting.ROLE)) {
			nodeType = NODE_TYPE_MASTER;

		} else {// worker node
			nodeType = NODE_TYPE_WORKER;
		}

		// get available port
		List<VasNode> vasNodes = nodeMapper.selectVasNodesbyAddress(ipAddress, nodeType);
		if (vasNodes == null || vasNodes.isEmpty()) {
			return PORT_ERROR;
		}

		// update the port as already occupied
		String akkaPort = vasNodes.get(0).getPort();
		nodeMapper.updateVasNodePortUsed(ipAddress, akkaPort, ALLOCATED);

		return Integer.parseInt(akkaPort);
	}

	public void setVasNodePortOccupied(String ipAddress, String port) {

		nodeMapper.updateVasNodePortUsed(ipAddress, port, ALLOCATED);

	}

}
