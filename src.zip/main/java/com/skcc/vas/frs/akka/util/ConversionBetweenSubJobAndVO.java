package com.skcc.vas.frs.akka.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;

import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.akka.model.OndemandDBSubJob;
import com.skcc.vas.frs.akka.model.OndemandVMSSubJob;
import com.skcc.vas.frs.akka.model.OndemandVideoSubJob;
import com.skcc.vas.frs.common.biz.model.SearchRequest.Cctv;
import com.skcc.vas.frs.ondemand.video.db.rdb.domain.FileAnalysisRequest.AnalysisResource;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandDBSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVMSSubJobVO;
import com.skcc.vas.frs.akka.db.rdb.domain.OndemandVideoSubJobVO;

public class ConversionBetweenSubJobAndVO {

	private final static String SEPERATOR = ";";
	private final static String INNER_SEPERATOR = ":";

	public static OndemandDBSubJob convert(OndemandDBSubJobVO dbSubJobVO, Map<String, byte[]> concernFaces) {

		OndemandDBSubJob dbSubJob = new OndemandDBSubJob(dbSubJobVO.getPortionOfProgress(), dbSubJobVO.getJobId(),
				dbSubJobVO.getStartId(), dbSubJobVO.getDetectedFaceCount(), concernFaces, dbSubJobVO.getTimeType());

		return dbSubJob;
	}

	public static OndemandDBSubJobVO convert(OndemandDBSubJob dbSubJob, int nodeId, String jobStatus, String startTime,
			String endTime) {

		OndemandDBSubJobVO dbSubJobVO = new OndemandDBSubJobVO();
		dbSubJobVO.setDetectedFaceCount(dbSubJob.getDetectedFaceCount());
		dbSubJobVO.setJobId(dbSubJob.getJobId());
		dbSubJobVO.setPortionOfProgress(dbSubJob.getPortionOfProgress());
		dbSubJobVO.setStartId(dbSubJob.getStartId());
		dbSubJobVO.setEndTime(endTime);
		dbSubJobVO.setJobStatus(jobStatus);
		dbSubJobVO.setNodeId(nodeId);
		dbSubJobVO.setStartTime(startTime);
		dbSubJobVO.setTimeType(dbSubJob.getTimeType());
		dbSubJobVO.setTotalCompletedThread(0);
		dbSubJobVO.setTotalStartThread(0);

		return dbSubJobVO;
	}

	public static OndemandVMSSubJob convert(OndemandVMSSubJobVO vmsSubJobVO, HashMap<String, byte[]> concernFaces) {

		// List<String> baseDirs = makeBaseDirList(vmsSubJobVO.getBaseDir());

		List<Cctv> cctvs = makeCctvs(vmsSubJobVO.getCctvIds(), vmsSubJobVO.getVmsIds());

		OndemandVMSSubJob vmsSubJob = new OndemandVMSSubJob(vmsSubJobVO.getPortionOfProgress(), vmsSubJobVO.getJobId(),
				concernFaces, cctvs, vmsSubJobVO.getMatchingThreshold(), vmsSubJobVO.getAnalysisTimeFrom(),
				vmsSubJobVO.getAnalysisTimeTo(), vmsSubJobVO.getTimeType());

		return vmsSubJob;
	}

	/*
	 * baseDir format:
	 */
	private static List<String> makeBaseDirList(String baseDir) {
		String[] baseDirArray = baseDir.split(SEPERATOR);

		List<String> baseDirs = new ArrayList<String>();

		for (int index = 0; index < baseDirArray.length; index++) {
			baseDirs.add(baseDirArray[index]);
		}

		return baseDirs;
	}
	/*
	 * cctvIds format: 1123;2345;1344 vmsIds format: vms001;vms002;vms003
	 */
	private static List<Cctv> makeCctvs(String cctvIds, String vmsIds) {
		String[] cctvIdArray = cctvIds.split(SEPERATOR);
		String[] vmsIdArray = vmsIds.split(SEPERATOR);

		List<Cctv> cctvs = new ArrayList<Cctv>();

		int diffLength = cctvIdArray.length - vmsIdArray.length;

		int index = 0;
		for (; index < vmsIdArray.length; index++) {
			Cctv cctv = new Cctv();
			cctv.setId(cctvIdArray[index]);
			cctv.setSystemId(vmsIdArray[index]);
			cctvs.add(cctv);
		}

		for (int i = 0; i < diffLength; i++, index++) {
			Cctv cctv = new Cctv();
			cctv.setId(cctvIdArray[index]);
			cctv.setSystemId(vmsIdArray[vmsIdArray.length - 1]);
			cctvs.add(cctv);
		}

		return cctvs;
	}

	public static OndemandVMSSubJobVO convert(OndemandVMSSubJob vmsSubJob, int nodeId, String jobStatus,
			String startTime, String endTime) {

		OndemandVMSSubJobVO vmsSubJobVO = new OndemandVMSSubJobVO();
		vmsSubJobVO.setAnalysisTimeFrom(vmsSubJob.getAnalysisTimeFrom());
		vmsSubJobVO.setAnalysisTimeTo(vmsSubJob.getAnalysisTimeTo());

		List<Cctv> Cctvs = vmsSubJob.getCctvs();
		String cctvIds = "";
		String vmsIds = "";
		for (Cctv cctv : Cctvs) {
			cctvIds += cctv.getId();
			cctvIds += SEPERATOR;
			vmsIds += cctv.getSystemId();
			vmsIds += SEPERATOR;
		}

		vmsSubJobVO.setCctvIds(cctvIds);
		vmsSubJobVO.setVmsIds(vmsIds);

		vmsSubJobVO.setEndTime(endTime);
		vmsSubJobVO.setJobId(vmsSubJob.getJobId());
		vmsSubJobVO.setJobStatus(jobStatus);
		vmsSubJobVO.setMatchingThreshold(vmsSubJob.getThreshold());
		vmsSubJobVO.setNodeId(nodeId);
		vmsSubJobVO.setPortionOfProgress(vmsSubJob.getPortionOfProgress());
		vmsSubJobVO.setStartTime(startTime);
		vmsSubJobVO.setTotalCompletedThread(0);
		vmsSubJobVO.setTotalStartThread(0);

		return vmsSubJobVO;
	}

	public static OndemandVideoSubJob convert(OndemandVideoSubJobVO videoSubJobVO, Map<String, byte[]> concernFaces,
			DynamicNodeRoutingProcessor routingProcessor) {

		OndemandVideoSubJob videoSubJob = new OndemandVideoSubJob();

		videoSubJob.setJobId(videoSubJobVO.getJobId());
		videoSubJob.setBaseDir(videoSubJobVO.getBaseDir());
		videoSubJob.setConcernFaces(concernFaces);
		videoSubJob.setPortionOfProgress(videoSubJobVO.getPortionOfProgress());
		videoSubJob.setThreshold(videoSubJobVO.getMatchingThreshold());

		// convert String -> List<String> -> List<Pair<Integer, Integer>
		List<String> filePeriodList = convertStringToList(videoSubJobVO.getFilePeriods());
		List<Pair<Integer, Integer>> filePeriods = new ArrayList<Pair<Integer, Integer>>();
		for (String filePeroid : filePeriodList) {
			String[] array = filePeroid.split(INNER_SEPERATOR);
			Pair<Integer, Integer> pair = Pair.of(Integer.parseInt(array[0]), Integer.parseInt(array[1]));
			filePeriods.add(pair);
		}
		videoSubJob.setFilePeriods(filePeriods);

		// convert String -> List<String> -> List<AnalysisResource>
		List<String> rscIds = convertStringToList(videoSubJobVO.getRscIds());
		List<AnalysisResource> analysisResources = new ArrayList<AnalysisResource>();

		for (int i = 0; i < rscIds.size(); i++) {
			AnalysisResource ar = routingProcessor.selectAnalysisResource(Integer.parseInt(rscIds.get(i)));
			analysisResources.add(ar);
		}
		videoSubJob.setAnalysisResources(analysisResources);

		return videoSubJob;
	}

	public static OndemandVideoSubJobVO convert(OndemandVideoSubJob videoSubJob, int nodeId, String jobStatus,
			String startTime, String endTime) {

		OndemandVideoSubJobVO videoSubJobVO = new OndemandVideoSubJobVO();
		videoSubJobVO.setNodeId(nodeId);
		videoSubJobVO.setJobId(videoSubJob.getJobId());
		videoSubJobVO.setStartTime(startTime);
		videoSubJobVO.setEndTime(endTime);
		videoSubJobVO.setJobStatus(jobStatus);
		videoSubJobVO.setPortionOfProgress(videoSubJob.getPortionOfProgress());
		videoSubJobVO.setBaseDir(videoSubJob.getBaseDir());
		videoSubJobVO.setMatchingThreshold(videoSubJob.getThreshold());

		// convert List<Pair<Integer, Integer>> -> List<String> -> String
		List<Pair<Integer, Integer>> filePeriods = videoSubJob.getFilePeriods();
		List<String> filePeriodList = new ArrayList<String>();
		for (Pair<Integer, Integer> filePeriod : filePeriods) {
			int left = filePeriod.getLeft();
			int right = filePeriod.getRight();
			String str = String.valueOf(left) + INNER_SEPERATOR + String.valueOf(right);
			filePeriodList.add(str);
		}

		videoSubJobVO.setFilePeriods(convertListToString(filePeriodList));

		// convert List<AnalysisResource> -> List<String> -> String
		List<AnalysisResource> analysisResources = videoSubJob.getAnalysisResources();
		List<String> rscIds = new ArrayList<String>();

		for (AnalysisResource ar : analysisResources) {
			rscIds.add(ar.getId());
		}

		videoSubJobVO.setRscIds(convertListToString(rscIds));
		videoSubJobVO.setTotalCompletedThread(0);
		videoSubJobVO.setTotalStartThread(0);

		return videoSubJobVO;
	}

	private static String convertListToString(List<String> list) {
		String ret = "";

		for (String str : list) {
			ret += str;
			ret += SEPERATOR;
		}

		return ret;
	}

	private static List<String> convertStringToList(String str) {
		List<String> list = new ArrayList<String>();
		String[] strArray = str.split(SEPERATOR);

		for (int i = 0; i < strArray.length; i++) {
			list.add(strArray[i]);
		}

		return list;
	}

	public static OndemandDBSubJobVO updateDBSubJob(int nodeId, String jobId, String startTime, String jobStatus,
			int totalStartThread) {
		OndemandDBSubJobVO subJobVO = new OndemandDBSubJobVO();
		subJobVO.setNodeId(nodeId);
		subJobVO.setStartTime(startTime);
		subJobVO.setJobStatus(jobStatus);
		subJobVO.setTotalStartThread(totalStartThread);
		subJobVO.setJobId(jobId);
		subJobVO.setTotalCompletedThread(0);

		return subJobVO;
	}

	public static OndemandVMSSubJobVO updateVMSSubJob(int nodeId, String jobId, String startTime, String jobStatus,
			int totalStartThread) {
		OndemandVMSSubJobVO subJobVO = new OndemandVMSSubJobVO();
		subJobVO.setNodeId(nodeId);
		subJobVO.setStartTime(startTime);
		subJobVO.setJobStatus(jobStatus);
		subJobVO.setTotalStartThread(totalStartThread);
		subJobVO.setJobId(jobId);
		subJobVO.setTotalCompletedThread(0);

		return subJobVO;
	}

	public static OndemandVideoSubJobVO updateVideoSubJob(int nodeId, String jobId, String startTime, String jobStatus,
			int totalStartThread) {
		OndemandVideoSubJobVO subJobVO = new OndemandVideoSubJobVO();
		subJobVO.setNodeId(nodeId);
		subJobVO.setStartTime(startTime);
		subJobVO.setJobStatus(jobStatus);
		subJobVO.setTotalStartThread(totalStartThread);
		subJobVO.setJobId(jobId);
		subJobVO.setTotalCompletedThread(0);

		return subJobVO;
	}

}
