package com.skcc.vas.frs.akka.db.rdb.domain;

import java.util.Date;

import com.skcc.vas.frs.common.util.base.BaseUtils;

/**
 * The Value Object of VAS_NODE_SRVC This is used for dynamic node control and
 * routing
 * 
 * @author Na Hoon
 * @since 2016. 9. 8.
 *
 */
public class Node {

	// worker node id
	private int nodeId;

	// worker node name
	private String nodeName;

	// worker role
	private String role;

	// worker ip address
	private String ipAddress;

	// worker node port
	private String port;

	// worker node status
	private String nodeStatus;

	// the latest updated time of the worker node status
	private String updateTime;

	private String descr;

	private String nodeClass;
   
   private int fromIdx;
   
   private int toIdx;

	public void setDefault(String address, String port) {
		// set initial information
		this.role = Role.NODE_ROLE_STANDBY;
		this.ipAddress = address;
		this.port = port;
		this.nodeStatus = NodeStatus.NODE_STATUS_INITIAL;
		this.updateTime = BaseUtils.formatToYear2SecString(new Date());
		this.nodeClass = NodeClass.NODE_CLASS_INITAL;

	}
	
	public void setMatchingNodeDefault(String address, String port, String Role) {
		// set initial information
		this.role = Role;
		this.ipAddress = address;
		this.port = port;
		this.nodeStatus = NodeStatus.NODE_STATUS_INITIAL;
		this.updateTime = BaseUtils.formatToYear2SecString(new Date());
		this.nodeClass = NodeClass.NODE_CLASS_MATCHING;
		
	}
	
	

	public void setDefault(int nodeId, String address, String port) {
		this.setDefault(address, port);
		this.nodeId = nodeId;
	}

	public void setDefault(Node newNode) {
		nodeId = newNode.nodeId;
		nodeName = newNode.nodeName;
		role = newNode.role;
		ipAddress = newNode.ipAddress;
		port = newNode.port;
		nodeStatus = newNode.nodeStatus;
		updateTime = newNode.updateTime;
		descr = newNode.descr;
		nodeClass = newNode.nodeClass;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getNodeStatus() {
		return nodeStatus;
	}

	public void setNodeStatus(String nodeStatus) {
		this.nodeStatus = nodeStatus.toLowerCase();
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getNodeClass() {
		return nodeClass;
	}

	public void setNodeClass(String nodeClass) {
		this.nodeClass = nodeClass;
	}

	public static class NodeStatus {
		public static final String NODE_STATUS_INITIAL = "initial";
		public static final String NODE_STATUS_STARTED = "started";
		public static final String NODE_STATUS_STOPPED = "stopped";
		public static final String NODE_STATUS_REMOVED = "removed";
		public static final String NODE_STATUS_REMOVED_FAILOVER = "removed_failover";
	}

	public int getFromIdx() {
		return fromIdx;
	}

	public void setFromIdx(int fromIdx) {
		this.fromIdx = fromIdx;
	}

	public int getToIdx() {
		return toIdx;
	}

	public void setToIdx(int toIdx) {
		this.toIdx = toIdx;
	}

	public static class Role {
		public static final String NODE_ROLE_ACTIVE = "active";
		public static final String NODE_ROLE_STANDBY = "standby";
		public static final String NODE_ROLE_NA = "na";
	}

	public static class NodeClass {
		public static final String NODE_CLASS_INITAL = "initial";
		public static final String NODE_CLASS_ONDEMAND = "ondemand";
		public static final String NODE_CLASS_LIVE = "live";
		public static final String NODE_CLASS_MATCHING = "matching-cluster";
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Node class =");
		sb.append(" Node ID [" + nodeId + "]");

		if (nodeClass != null) {
			sb.append(" Node class [" + nodeClass + "]");
		}

		if (nodeName != null) {
			sb.append(" Node name [" + nodeName + "]");
		}
		if (role != null) {
			sb.append(" Role [" + role + "]");
		}
		if (ipAddress != null) {
			sb.append(" IP Address [" + ipAddress + "]");
		}
		if (port != null) {
			sb.append(" port [" + port + "]");
		}
		if (nodeStatus != null) {
			sb.append(" node status [" + nodeStatus + "]");
		}
		if (updateTime != null) {
			sb.append(" update time [" + updateTime + "]");
		}

		return sb.toString();

	}

}
