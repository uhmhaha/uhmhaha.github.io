package com.skcc.vas.frs.live.biz;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.Validate;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.adapter.vms.incon.FsUtilAdapter;
import com.skcc.adapter.vms.incon.InteropLiveAdapter;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.live.biz.HbInnoDetectionProcessorBase;

/**
 * @author
 * @since 2016-08-12
 *
 */
public abstract class TriumiHbInnoDetectionProcessorBase extends HbInnoDetectionProcessorBase {

	@Nullable
	private FsUtilAdapter triumiFsUtilAdapter;

	protected FsUtilAdapter getTriumiFsUtilAdapter() {
		return this.triumiFsUtilAdapter;
	}

	public void setTriumiFsUtilAdapter(FsUtilAdapter triumiFsUtilAdapter) {
		this.triumiFsUtilAdapter = triumiFsUtilAdapter;
	}

	@Nonnull
	private final InteropLiveAdapter triumiLiveAdapter;

	protected InteropLiveAdapter getTriumiLiveAdapter() {
		return this.triumiLiveAdapter;
	}

	public TriumiHbInnoDetectionProcessorBase(@NotBlank String systemId, @NotBlank String dataDir,
			@Nonnull InteropLiveAdapter triumiLiveAdapter, @Nonnull HbInnoAdapter hbInnoAdapter,
			@Nonnull FaceDataManager faceDataManager, @Min(0) @Max(FRAME_SKIPS_MAX) int skips,
			@NotEmpty String svrAddr, @Min(1) int svrPort, @NotEmpty String svrUserId, @Nonnull String svrPasswd,
			@NotBlank String screenShotDirName) {
		super(systemId, dataDir, hbInnoAdapter, faceDataManager, skips, screenShotDirName);

		Validate.isTrue(triumiLiveAdapter != null, "The VMS live adapter should be provided.");

		this.triumiLiveAdapter = triumiLiveAdapter;
		if (this.triumiLiveAdapter.connect(svrAddr, svrPort, svrUserId, svrPasswd)) {
			this.logger.info("Connected to VMS at {}:{} as {}", svrAddr, svrPort, svrUserId);
			// Disabling the event would NOT disable streaming.
			// this.triumiLiveAdapter.setEventEnabled(false);
		} else {
			String msg = String.format("Fail to connect VMS at %1$s:%2$d as %3$s", svrAddr, svrPort, svrUserId);
			this.logger.error(msg);
			throw new IllegalStateException(msg);
		}

	}

}
