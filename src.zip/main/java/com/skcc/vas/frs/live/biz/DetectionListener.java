package com.skcc.vas.frs.live.biz;

import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;

/**
 * @author
 * @since 2016. 7. 12.
 *
 * @param <T>
 *            The type of callback's return
 */
public interface DetectionListener<T> {

	/**
	 * Called when a face is detected
	 *
	 * @param face
	 * @return
	 */
	T detected(DetectedFace face, boolean async);

}
