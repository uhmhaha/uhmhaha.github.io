package com.skcc.vas.frs.live.db.nosql.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.skcc.vas.frs.common.db.nosql.dao.DetectedFaceMatchDao;
import com.skcc.vas.frs.common.db.repository.RSkfDevAuxPropMapper;

@Service("face.CommonService")
public class CommonService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Resource(name = "mongoTemplate")
	protected MongoTemplate mongoTemplate;

	@Autowired
	private DetectedFaceMatchDao detectedFaceMatchDao;

	@Autowired
	private RSkfDevAuxPropMapper rSkfDevAuxPropMapper;

	public Map<String, Long> analysisSummury(Map<String, Object> variableMap) {
		Map<String, Long> analysisResult = new HashMap<String, Long>();

		String baseDate = (String) variableMap.get("baseDate");

		long cctvIdNum = getCctvNum(baseDate);
		analysisResult.put("CCTV_NUM", cctvIdNum);
		long detectedNum = getDetectedNum(baseDate);
		analysisResult.put("DETECTED_NUM", detectedNum);
		long matchedNum = getMatchedNum(baseDate);
		analysisResult.put("MATCHED_NUM", matchedNum);

		return analysisResult;
	}

	private long getCctvNum(String baseDate) {
		long count = rSkfDevAuxPropMapper.countCCTVNumForVAS();
		return count;
	}

	private long getDetectedNum(String baseDate) {

		DBCollection detectedFaceCol = mongoTemplate.getCollection("VAS_DETECTED_FACE_NOSQL");
		BasicDBObject query = new BasicDBObject("frmTime", new BasicDBObject("$gte", baseDate));
		long countList = detectedFaceCol.count(query);
		return countList;
	}

	private long getMatchedNum(String baseDate) {

		DBCollection detectedFaceMatchCol = mongoTemplate.getCollection("VAS_DETECTED_FACE_N_MATCH_NOSQL");
		BasicDBObject query = new BasicDBObject("lastUpdateMatchAt", new BasicDBObject("$gte", baseDate));
		long countList = detectedFaceMatchCol.count(query);

		return countList;
	}

}
