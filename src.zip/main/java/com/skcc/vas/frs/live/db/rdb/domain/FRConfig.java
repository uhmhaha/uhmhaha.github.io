package com.skcc.vas.frs.live.db.rdb.domain;

/**
 * UI에서 설정한 config 정보는 VAS_FR_CONFIG table에 저장되고, VAS_FR_CONFIG table에 대한 VO에 해당
 * 
 * @author 09469
 *
 */

public class FRConfig {

	private int scoreMatching;
	private int scoreMatchingLow;
	private String useFiltering;
	private int filteringPeriod;
	private int scoreFiltering;
	private int maxNumDetectedFaces;
	private int detectedFaceWidth;
	private String useCctvResolutionInScreenshot;
	private int screenShotWidth;
	private String updateTime;

	private String detectedFaceWidthUsesOriginalResolution;
	private float scoreConfidence;
	private int maxNumMatchedFaces;
	private float scoreDetection;
	private int minEyesWidth;
	private int maxEyesWidth;

	private String deviceId;

	public int getScoreMatching() {
		return scoreMatching;
	}

	public void setScoreMatching(int scoreMatching) {
		this.scoreMatching = scoreMatching;
	}

	public String getUseFiltering() {
		return useFiltering;
	}

	public void setUseFiltering(String useFiltering) {
		this.useFiltering = useFiltering;
	}

	public int getFilteringPeriod() {
		return filteringPeriod;
	}

	public void setFilteringPeriod(int filteringPeriod) {
		this.filteringPeriod = filteringPeriod;
	}

	public int getScoreFiltering() {
		return scoreFiltering;
	}

	public void setScoreFiltering(int scoreFiltering) {
		this.scoreFiltering = scoreFiltering;
	}

	public int getMaxNumDetectedFaces() {
		return maxNumDetectedFaces;
	}

	public void setMaxNumDetectedFaces(int maxNumDetectedFaces) {
		this.maxNumDetectedFaces = maxNumDetectedFaces;
	}

	public int getDetectedFaceWidth() {
		return detectedFaceWidth;
	}

	public void setDetectedFaceWidth(int detectedFaceWidth) {
		this.detectedFaceWidth = detectedFaceWidth;

		// set 4's multiple
		int r = detectedFaceWidth % 4;
		int q = detectedFaceWidth / 4;
		if (r != 0) {
			q = q + 1;
			this.detectedFaceWidth = q * 4;
		}

	}

	public String getUseCctvResolutionInScreenshot() {
		return useCctvResolutionInScreenshot;
	}

	public void setUseCctvResolutionInScreenshot(String useCctvResolutionInScreenshot) {
		this.useCctvResolutionInScreenshot = useCctvResolutionInScreenshot;
	}

	public int getScreenShotWidth() {
		return screenShotWidth;
	}

	public void setScreenShotWidth(int screenShotWidth) {
		this.screenShotWidth = screenShotWidth;

		// set 4's multiple
		int r = screenShotWidth % 4;
		int q = screenShotWidth / 4;
		if (r != 0) {
			q = q + 1;
			this.screenShotWidth = q * 4;
		}

	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getDetectedFaceWidthUsesOriginalResolution() {
		return detectedFaceWidthUsesOriginalResolution;
	}

	public void setDetectedFaceWidthUsesOriginalResolution(String detectedFaceWidthUsesOriginalResolution) {
		this.detectedFaceWidthUsesOriginalResolution = detectedFaceWidthUsesOriginalResolution;
	}

	public float getScoreConfidence() {
		return scoreConfidence;
	}

	public void setScoreConfidence(float scoreConfidence) {
		this.scoreConfidence = scoreConfidence;
	}

	public int getMaxNumMatchedFaces() {
		return maxNumMatchedFaces;
	}

	public void setMaxNumMatchedFaces(int maxNumMatchedFaces) {
		this.maxNumMatchedFaces = maxNumMatchedFaces;
	}

	public float getScoreDetection() {
		return scoreDetection;
	}

	public void setScoreDetection(float scoreDetection) {
		this.scoreDetection = scoreDetection;
	}

	public int getMinEyesWidth() {
		return minEyesWidth;
	}

	public void setMinEyesWidth(int minEyesWidth) {
		this.minEyesWidth = minEyesWidth;
	}

	public int getMaxEyesWidth() {
		return maxEyesWidth;
	}

	public void setMaxEyesWidth(int maxEyesWidth) {
		this.maxEyesWidth = maxEyesWidth;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append("\n ====== FRConfig class ====== \n");

		if (deviceId != null) {
			sb.append(" This Config values are limited into device id [" + deviceId + "]\n");
		}

		// scoreMatching
		sb.append(" score for face matching [" + scoreMatching + "]\n");

		// scoreMatchingLow
		sb.append(" low score for face matching [" + scoreMatchingLow + "]\n");

		// useFiltering
		if (useFiltering != null) {
			sb.append(" use filtering [" + useFiltering + "]\n");

			if (useFiltering.equalsIgnoreCase("y")) {
				// filteringPeriod
				sb.append(" filtering period(seconds) [" + filteringPeriod + "]\n");
				// scoreFiltering
				sb.append(" score for filtering [" + scoreFiltering + "]\n");
			}
		}
		// maxNumDetectedFaces
		sb.append(" max number of detected faces in one frame [" + maxNumDetectedFaces + "]\n");

		// detectedFaceWidth
		sb.append(" detected face image width [" + detectedFaceWidth + "]\n");

		// useCctvResolutionInScreenshot
		if (useCctvResolutionInScreenshot != null) {
			sb.append(" use cctv resolution in screenshot [" + useCctvResolutionInScreenshot + "]\n");

			if (useCctvResolutionInScreenshot.equalsIgnoreCase("n")) {
				// screenShotWidth
				sb.append(" screenshot width [" + screenShotWidth + "]\n");
			}
		}

		// detectedFaceWidthUsesOriginalResolution
		sb.append(" use original resolution when saving detected face [" + detectedFaceWidthUsesOriginalResolution
				+ "]\n");

		// scoreConfidence
		sb.append(" confidence score [" + scoreConfidence + "]\n");

		// maxNumMatchedFaces
		sb.append(" max number of matched faces [" + maxNumMatchedFaces + "]\n");

		// scoreDetection
		sb.append(" detection score [" + scoreDetection + "]\n");

		// minEyesWidth
		sb.append(" min eyes width [" + minEyesWidth + "]\n");

		// maxEyesWidth
		sb.append(" max eyes width [" + maxEyesWidth + "]\n");

		// updateTime
		if (updateTime != null) {
			sb.append(" update time [" + updateTime + "]\n");
		}

		return sb.toString();

	}

	public int getScoreMatchingLow() {
		return scoreMatchingLow;
	}

	public void setScoreMatchingLow(int scoreMatchingLow) {
		this.scoreMatchingLow = scoreMatchingLow;
	}

}
