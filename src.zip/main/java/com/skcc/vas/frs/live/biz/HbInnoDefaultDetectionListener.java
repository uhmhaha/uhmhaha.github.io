package com.skcc.vas.frs.live.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.util.live.HttpProcessor;

/**
 * Identifies the detected face against all the concerned faces in concurrent
 * way.
 *
 * @author
 * @since 2016-07-15
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=hbInnoDefaultDetectionListener", description = "Identifies the detected face against all the concerned faces in concurrent way.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class HbInnoDefaultDetectionListener implements DetectionListener<Void> {

	public static final int CONCERNED_FACE_BUNDLE_SIZE_MAX = 100000;

	public static final int CONCERNED_FACE_BUNDLE_SIZE_MIN = 500;

	public static final int CONCERNED_FACE_BUNDLE_SIZE_DEFAULT = 1000;

	public static final int IDENTIFICATION_THRESHOLD_MAX = 98;

	public static final int IDENTIFICATION_THRESHOLD_MIN = 0;

	public static final int IDENTIFICATION_THRESHOLD_DEFAULT = 95;

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private volatile boolean isDestroying = false;

	private int concernedFacesNum;

	@ManagedAttribute
	public int getNumberOfConcernedFaces() {
		return this.concernedFacesNum;
	}

	private int concernedFaceBundleSize;

	@ManagedAttribute
	public int getConcernedFaceBundleSize() {
		return this.concernedFaceBundleSize;
	}

	private List<Map<String, byte[]>> concernedFeatureBundles;

	// 2016-08-18 added by skyang
	private Map<String, ConcernedFace> concernedFaces;

	private volatile int identificationThreshold;

	@ManagedAttribute
	public int getIdentificationThreshold() {
		return this.identificationThreshold;
	}

	@ManagedAttribute
	public void setIdentificationThreshold(int threshold) {
		if (threshold > IDENTIFICATION_THRESHOLD_MAX) {
			this.logger.warn(
					"The specified identification threshold({}) is too large. The threshold is adjusted to {}",
					threshold, IDENTIFICATION_THRESHOLD_MAX);
			this.identificationThreshold = IDENTIFICATION_THRESHOLD_MAX;
		} else if (threshold < IDENTIFICATION_THRESHOLD_MIN) {
			this.logger.warn(
					"The specified identification threshold({}) is too small. The threshold is adjusted to {}",
					threshold, IDENTIFICATION_THRESHOLD_MIN);
			this.identificationThreshold = IDENTIFICATION_THRESHOLD_MIN;
		} else {
			this.identificationThreshold = threshold;
		}
	}

	private final HttpProcessor httpProcessor;

	protected HttpProcessor getHttpProcessor() {
		return this.httpProcessor;
	}

	private String ccsAddress;

	protected String getCcsAddress() {
		return this.ccsAddress;
	}

	@Min(1)
	private int ccsHttpPort;

	protected int getCcsHttpPort() {
		return this.ccsHttpPort;
	}

	private String imgDirRoot;

	protected String getImgDirRoot() {
		return this.imgDirRoot;
	}

	@Nonnull
	private final HbInnoAdapter hbInnoAdapter;

	public HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	@Nonnull
	private final FaceDataManager faceDataManager;

	public FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	private final ExecutorService executor;

	private volatile boolean statsLogEnabled = true;

	@ManagedOperation(description = "Enable or disable statistics logging.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "enabled", description = "To enalbe statistics logging, set true"), })
	public void setStatsLogEnabled(final boolean enabled) {
		this.statsLogEnabled = enabled;
	}

	private VasConfigService configService;

	public HbInnoDefaultDetectionListener(@Nonnull HbInnoAdapter hbInnoAdapter,
			@Nonnull FaceDataManager faceDataManager, @Nonnull ThreadPoolTaskExecutor taskExecutor,
			HttpProcessor httpProcessor, @Nonnull VasConfigService configService) {

		Validate.isTrue(hbInnoAdapter != null, "The VA engine should be provided.");
		Validate.isTrue(faceDataManager != null, "The data accessor should be provided.");
		Validate.isTrue(taskExecutor != null, "The task executor to deal with tasks concurrently should be provided.");

		this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.httpProcessor = httpProcessor;

		/*
		 * DB에서 concerned face data 전체를 가져온다
		 */
//		필요여부 확인 필요
//		final List<ConcernedFace> faces = this.faceDataManager.findValidConcernedFaces();
//		this.concernedFacesNum = faces.size();
//
//		this.logger.info("Found {} concerned faces.", this.concernedFacesNum);
//
//		Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();
//
//		/*
//		 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId() =
//		 * face Id
//		 */
//		for (ConcernedFace cf : faces) {
//
//			featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
//		}
//
//		int count = this.hbInnoAdapter.addTargetFeaturesNpath(featureNpath);
//		this.logger.debug("total {} concerned features added in Hbinno Adatper", count);

		// build bundles
		// final int divider = this.concernedFaceBundleSize;
		// final int quotient = faces.size() / divider;
		// final int remainder = faces.size() - quotient * divider;
		//
		// this.concernedFeatureBundles = new ArrayList<Map<String,
		// byte[]>>(quotient + 1);
		// Map<String, byte[]> bundle = null;
		// List<String> emptyFeatures = new ArrayList<String>();
		// int marker;
		// String id = null;
		// byte[] feature = null;
		// ConcernedFace tmpface = null;
		// for(int i = 0; i < quotient; i++){
		// bundle = new HashMap<String, byte[]>(divider);
		// marker = i * divider;
		// for(int j = 0; j < divider; j++){
		// id = faces.get(marker + j).getId();
		// feature = faces.get(marker + j).getFeature();
		// if(feature == null || feature.length == 0){
		// emptyFeatures.add(id);
		// continue;
		// }else{
		// bundle.put(id, feature);
		// }
		// }
		// this.concernedFeatureBundles.add(bundle);
		// }
		//
		// if(remainder != 0){
		// bundle = new HashMap<String, byte[]>(remainder);
		// marker = quotient * divider;
		// for(int i = 0; i < remainder; i++){
		// id = faces.get(marker + i).getId();
		// feature = faces.get(marker + i).getFeature();
		// if(feature == null || feature.length == 0){
		// emptyFeatures.add(id);
		// continue;
		// }else{
		// bundle.put(id, feature);
		// }
		// }
		// this.concernedFeatureBundles.add(bundle);
		// }
		//
		// //2016-08-18 added by skyang
		// this.concernedFaces = new HashMap<String,
		// ConcernedFace>(faces.size());
		// for(ConcernedFace face: faces){
		// this.concernedFaces.put(face.getId(), face);
		// }
		//
		// if(emptyFeatures.size() != 0){
		// this.logger.warn("There's {} faces of which feature is empty or null amongst total {} faces.",
		// emptyFeatures.size(), faces.size());
		// }
		// this.logger.info("Loaded {} faces into {} bundles each of which size is {}.",
		// faces.size(), this.concernedFeatureBundles.size(), divider);

		this.executor = new ExecutorServiceAdapter(taskExecutor);

		this.configService = configService;
	}

	public void initConfig() {
		// bundle size
		this.concernedFaceBundleSize = Integer.parseInt(configService
				.getConfigValByName("vas.hbInnoAdapter.maxConcernedface"));

		if (concernedFaceBundleSize > CONCERNED_FACE_BUNDLE_SIZE_MAX) {
			this.logger.warn("The specified size is too large. The size is adjusted to {}",
					CONCERNED_FACE_BUNDLE_SIZE_MAX);
			this.concernedFaceBundleSize = CONCERNED_FACE_BUNDLE_SIZE_MAX;
		} else if (concernedFaceBundleSize < CONCERNED_FACE_BUNDLE_SIZE_MIN) {
			this.logger.warn("The specified size is too small. The size is adjusted to {}",
					CONCERNED_FACE_BUNDLE_SIZE_MIN);
			this.concernedFaceBundleSize = CONCERNED_FACE_BUNDLE_SIZE_MIN;
		} else {

		}

		identificationThreshold = Integer.parseInt(configService
				.getConfigValByName("vas.hbInnoIdentificationProcessor.defaultThreshold"));
		ccsAddress = configService.getConfigValByName("vas.ccs.address");
		ccsHttpPort = Integer.parseInt(configService.getConfigValByName("vas.ccs.httpPort"));
		imgDirRoot = configService.getConfigValByName("vas.dataDir");

	}

	public void addConcernedFaceBundleItem(String cncrnFaceId, byte[] feature) {
		// TODO: 어떤 Bundle에 값을 넣을지 정하는 로직 필요. 현재는 가장 마지막 Bundle에 넣음.
		// (hong-yongman, 2016-08-31)
		this.concernedFeatureBundles.get(concernedFeatureBundles.size() - 1).put(cncrnFaceId, feature);
	}

	/**
	 * 사진 삭제시 bundle에서 사진을 삭제한다
	 * 
	 * @param cncrnFaceId
	 */
	public void removeConcernedFaceBundleItem(String cncrnFaceId) {
		// TODO: 어떤 Bundle에 값을 넣을지 정하는 로직 필요. 현재는 가장 마지막 Bundle에 넣음.
		// (hong-yongman, 2016-08-31)
		for (int i = 0; i < concernedFeatureBundles.size(); i++) {
			Map<String, byte[]> isThere = concernedFeatureBundles.get(i);

			if (isThere.containsKey(cncrnFaceId)) {
				this.logger
						.info("Before Removing face. input cncrnFaceId {}, remove faces {}, before concernedFeatureBundles {}",
								cncrnFaceId, isThere.get(cncrnFaceId), concernedFeatureBundles.size());
				this.concernedFeatureBundles.remove(i);
				this.logger.info(
						"After Removing face. input cncrnFaceId {}, remove faces {}, after concernedFeatureBundles {}",
						cncrnFaceId, isThere.get(cncrnFaceId), concernedFeatureBundles.size());

				break;
			}
		}
	}

	/**
	 * 사진 삭제시 bundle에서 사진을 삭제한다
	 * 
	 * @param String
	 *            [] faceIds
	 */
	public void removeConcernedFaceBundleItem(String[] faceIds) {
		// TODO: 어떤 Bundle에 값을 넣을지 정하는 로직 필요. 현재는 가장 마지막 Bundle에 넣음.
		// (hong-yongman, 2016-08-31)
		for (int j = 0; j < faceIds.length; j++) {
			for (int i = 0; i < concernedFeatureBundles.size(); i++) {
				Map<String, byte[]> isThere = concernedFeatureBundles.get(i);

				if (isThere.containsKey(faceIds[j])) {
					this.logger
							.info("Before Removing face. input cncrnFaceId {}, remove faces {}, before concernedFeatureBundles {}",
									faceIds[j], isThere.get(faceIds[j]), concernedFeatureBundles.size());
					concernedFeatureBundles.get(i).remove(faceIds[j]);
					// this.concernedFeatureBundles.remove(i);
					this.logger
							.info("After Removing face. input cncrnFaceId {}, remove faces {}, after concernedFeatureBundles {}",
									faceIds[j], isThere.get(faceIds[j]), concernedFeatureBundles.size());

					break;
				}
			}
		}

	}

	final private AtomicLong processedFacesNum = new AtomicLong(0);

	@ManagedAttribute
	public long getNumberOfProcessedFaces() {
		return this.processedFacesNum.get();
	}

	final private AtomicLong submittedTasksNum = new AtomicLong(0);

	@ManagedAttribute
	public long getNumberOfSubmittedTasks() {
		return this.submittedTasksNum.get();
	}

	final private AtomicLong finishedTasksNum = new AtomicLong(0);

	@ManagedAttribute
	public long getNumberOfFinishedTasks() {
		return this.finishedTasksNum.get();
	}

	final private AtomicLong matchesNum = new AtomicLong(0);

	@ManagedAttribute
	public long getNumberOfMatches() {
		return this.matchesNum.get();
	}

	public AtomicLong processingTime = new AtomicLong(0);

	@ManagedAttribute(description = "Average processing time for a detected face in milli-seconds. This value is meaningless in async mode.")
	public long getAverageProcessingTimePerDetectedFace() {
		if (this.processedFacesNum.get() == 0)
			return 0;

		return this.processingTime.get() / this.processedFacesNum.get();
	}

	@Override
	public Void detected(@Nonnull DetectedFace face, boolean async) {

		return null;
	}

	// @Scheduled(fixedDelayString =
	// "${vas.identificationProcessor.statsLog.fixedDelay}",
	// initialDelayString =
	// "${vas.identificationProcessor.statsLog.initialDelay}")
	public void logStats() {
		if (!this.statsLogEnabled)
			return;

		this.logger
				.info("The HbInnoDefaultDetectionListener is running. - detected faces: {}, avg processing time/detected face: {}ms, concenred faces: {}",
						this.processedFacesNum.get(), this.getAverageProcessingTimePerDetectedFace(),
						this.concernedFacesNum);
	}

	public void destroy() {
		this.isDestroying = true;

		if (this.executor != null && !(this.executor instanceof ExecutorServiceAdapter)) {
			this.executor.shutdown();
		}
	}

	@Override
	protected void finalize() {
		this.destroy();
	}

}
