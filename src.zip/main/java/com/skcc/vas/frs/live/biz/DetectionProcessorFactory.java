package com.skcc.vas.frs.live.biz;

import javax.annotation.concurrent.ThreadSafe;

/**
 * @author
 * @since 2016-06-17
 *
 */
@ThreadSafe
public interface DetectionProcessorFactory {

	DetectionProcessor getDetectionProcessor(String systemId);

	public String[] getSystemIdsOfDetectionProcessors();

}
