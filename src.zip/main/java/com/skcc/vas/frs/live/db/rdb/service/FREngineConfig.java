package com.skcc.vas.frs.live.db.rdb.service;

import javax.annotation.Nonnull;

import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;

public class FREngineConfig {

	final static boolean CCTV_RESOLUTION_ENABLE_DEFAULT = true;
	final static boolean CACHE_ENABLE_DEFAULT = false;
	final static int CACHE_THRESHOLD_DEFAULT = 75;
	final static int CACHE_PERIOD_DEFAULT = 3;
	final static boolean DETECTED_FACE_USE_ORIGINAL_RESOLUTION_DEFAULT = false;
	final static int CCTV_SCREENSHOT_WIDTH_DEFAULT = 1024;

	private boolean cctvResolutionEnable = CCTV_RESOLUTION_ENABLE_DEFAULT;
	private int cctvScreenshotWidth = CCTV_SCREENSHOT_WIDTH_DEFAULT;
	private boolean cacheEnable = CACHE_ENABLE_DEFAULT;
	private int cacheThreshold = CACHE_THRESHOLD_DEFAULT;
	private int cachePeroid = CACHE_PERIOD_DEFAULT;
	private boolean detectedFaceOrgResolutionEnable = DETECTED_FACE_USE_ORIGINAL_RESOLUTION_DEFAULT;

	HbInnoParameter hbInnoParam;

	private VasConfigService configService;

	public FREngineConfig(HbInnoParameter hbInnoParam, @Nonnull VasConfigService configService) {

		this.hbInnoParam = hbInnoParam;
		this.configService = configService;

	}

	public void initConfig() {

		setParameters(configService.getConfigValByName("vas.screenshot.cctvResolutionEnable"),
				configService.getConfigValByName("vas.cachedEnabled"),
				configService.getConfigValByName("vas.cache.scoreThreshold"),
				configService.getConfigValByName("vas.hbInnoDetectionProcessor.verification.recentSeconds"),
				configService.getConfigValByName("vas.detectedFace.orgResolutionEnable"),
				configService.getConfigValByName("vas.hbInnoDetectionProcessor.screenshot.width"));

	}

	private void setParameters(String cctvResolutionEnable, String cacheEnable, int cacheThreshold, int cachePeroid,
			String detectedFaceOrgResolutionEnable, int cctvScreenShotWidth) {

		String lowercase;

		lowercase = cctvResolutionEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.cctvResolutionEnable = false;
		} else
			this.cctvResolutionEnable = true;

		lowercase = cacheEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.cacheEnable = false;
		} else
			this.cacheEnable = true;

		this.cacheThreshold = cacheThreshold;

		this.cachePeroid = cachePeroid;

		lowercase = detectedFaceOrgResolutionEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.detectedFaceOrgResolutionEnable = false;
		} else
			this.detectedFaceOrgResolutionEnable = true;

		this.cctvScreenshotWidth = cctvScreenShotWidth;
		if (cctvScreenshotWidth < 10)
			cctvScreenshotWidth = CCTV_SCREENSHOT_WIDTH_DEFAULT;

	}

	private void setParameters(String cctvResolutionEnable, String cacheEnable, String cacheThreshold,
			String cachePeriod, String detectedFaceOrgResolutionEnable, String cctvScreenShotWidth) {

		String lowercase;

		lowercase = cctvResolutionEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.cctvResolutionEnable = false;
		} else
			this.cctvResolutionEnable = true;

		lowercase = cacheEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.cacheEnable = false;
		} else
			this.cacheEnable = true;

		this.cacheThreshold = Integer.parseInt(cacheThreshold);

		this.cachePeroid = Integer.parseInt(cachePeriod);

		lowercase = detectedFaceOrgResolutionEnable.toLowerCase();
		if (lowercase.contains("n")) {
			this.detectedFaceOrgResolutionEnable = false;
		} else
			this.detectedFaceOrgResolutionEnable = true;

		cctvScreenshotWidth = Integer.parseInt(cctvScreenShotWidth);
		if (cctvScreenshotWidth < 10)
			cctvScreenshotWidth = CCTV_SCREENSHOT_WIDTH_DEFAULT;
	}

	public void setParameters(FRConfig frConfig) {
		/*
		 * FRConfig의 값을 내부 변수에 update
		 */
		setParameters(configService.getConfigValByName("vas.screenshot.cctvResolutionEnable"),
				configService.getConfigValByName("vas.cachedEnabled"),
				configService.getConfigValByName("vas.cache.scoreThreshold"),
				configService.getConfigValByName("vas.hbInnoDetectionProcessor.verification.recentSeconds"),
				configService.getConfigValByName("vas.detectedFace.orgResolutionEnable"),
				configService.getConfigValByName("vas.hbInnoDetectionProcessor.screenshot.width"));

		/*
		 * FRConfig의 값은 Hbinno Parameter에 update
		 */
		hbInnoParam.setLicenseKey(configService.getConfigValByName("vas.licenseKey"));
		hbInnoParam.setConfidenceThreshold(frConfig.getScoreConfidence());
		hbInnoParam.setDetectionThreshold(frConfig.getScoreDetection());
		hbInnoParam.setEyesMaxWidth(frConfig.getMaxEyesWidth());
		hbInnoParam.setEyesMinWidth(frConfig.getMinEyesWidth());
		hbInnoParam.setFaceImgWidth(frConfig.getDetectedFaceWidth());
		hbInnoParam.setMaxFacesPerImage(frConfig.getMaxNumDetectedFaces());
		hbInnoParam.setMaxMatchedFace(frConfig.getMaxNumMatchedFaces());
		hbInnoParam.setVerificationThreshold((float) frConfig.getScoreMatching() * (float) 0.01);
		hbInnoParam.setVerificationLowThreshold((float) frConfig.getScoreMatchingLow() * (float) 0.01);

	}

	public boolean isCctvResolutionEnable() {
		return cctvResolutionEnable;
	}

	public void setCctvResolutionEnable(boolean cctvResolutionEnable) {
		this.cctvResolutionEnable = cctvResolutionEnable;
	}

	public boolean isCacheEnable() {
		return cacheEnable;
	}

	public void setCacheEnable(boolean cacheEnable) {
		this.cacheEnable = cacheEnable;
	}

	public int getCacheThreshold() {
		return cacheThreshold;
	}

	public void setCacheThreshold(int cacheThreshold) {
		this.cacheThreshold = cacheThreshold;
	}

	public HbInnoParameter getHbInnoParam() {
		return hbInnoParam;
	}

	public void setHbInnoParam(HbInnoParameter hbInnoParam) {
		this.hbInnoParam = hbInnoParam;
	}

	public boolean isDetectedFaceOrgResolutionEnable() {
		return detectedFaceOrgResolutionEnable;
	}

	public void setDetectedFaceOrgResolutionEnable(boolean detectedFaceOrgResolutionEnable) {
		this.detectedFaceOrgResolutionEnable = detectedFaceOrgResolutionEnable;
	}

	public int getCctvScreenshotWidth() {
		return cctvScreenshotWidth;
	}

	public void setCctvScreenshotWidth(int cctvScreenshotWidth) {
		if (cctvScreenshotWidth < 10)
			cctvScreenshotWidth = CCTV_SCREENSHOT_WIDTH_DEFAULT;
		this.cctvScreenshotWidth = cctvScreenshotWidth;
	}

	public int getCachePeroid() {
		return cachePeroid;
	}

	public void setCachePeroid(int cachePeroid) {
		this.cachePeroid = cachePeroid;
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("\n == [FR Engine Configuration] ========================\n");
		sb.append("cache enable: " + cacheEnable + "\n");
		if (cacheEnable)
			sb.append("cache threshold: " + cacheThreshold + "\n");
		sb.append("Use cctv resolution when saving screenshot: " + cctvResolutionEnable + "\n");
		if (!cctvResolutionEnable) {
			sb.append("CCTV screenshot width fixed into " + cctvScreenshotWidth + "\n");
		}
		sb.append("Use original resolution when saving detected face: " + detectedFaceOrgResolutionEnable + "\n");

		sb.append(hbInnoParam.toString());

		sb.append("== [end of FR Engine Configuration] =========================\n");

		return sb.toString();

	}

}
