package com.skcc.vas.frs.live.biz;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.Resource;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import scala.collection.mutable.StringBuilder;

import com.skcc.vas.adapter.fr.hbinno.HbInnoConstants;
import com.skcc.vas.adapter.fr.hbinno.HbInnoFace;
import com.skcc.vas.adapter.fr.hbinno.HbInnoParameter;
import com.skcc.vas.adapter.fr.hbinno.HbinnoEngine;
import com.skcc.vas.frs.live.biz.ConcernedPersonProcessorBase;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.rdb.service.ConcernPersonAndFaceService;

/**
 * @author
 * @since 2016-07-04
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=hbInnoConcernedPersonProcessor", description = "Provide services for concerned persons and concenred faces using HB innovation's FR library")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class HbInnoConcernedPersonProcessor extends ConcernedPersonProcessorBase {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
	@Resource(name = "config")
	private Properties config;
	// protected static ApplicationContext spring =
	// SpringContainerLocator.getSingleton().getSpringContainer("spring.xml");

	private HbInnoParameter hbInnoParam;
	@Nonnull
	private final HbinnoEngine hbInnoAdapter;

	private boolean landmarkused = false;

	private VasConfigService configService;

	private HbInnoConstants hbInnoConstants = new HbInnoConstants();
	// @Value("${vas.dataDir}")
	private String vadDir;

	// @Value("${vas.concernedFace.saveDir}")
	private String concernedFaceDir;

	// @Value("${vas.hbInnoAdapter.maxConcernedface}")
	private int concernedFaceNum;

	protected HbinnoEngine getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	@Autowired
	private ConcernPersonAndFaceService concernPersonAndFaceService;

	@Nonnull
	private final HbInnoDefaultDetectionListener detectionListener;

	protected HbInnoDefaultDetectionListener getDetectionListener() {
		return detectionListener;
	}

	private String imgBase;

	final static public int RESPONSE_CODE_SUCCESS = 1;
	final static public int RESPONSE_CODE_NO_IMAGE = -1;
	final static public int RESPONSE_CODE_NO_FACE = -2;
	final static public int RESPONSE_CODE_MULTIPLE_FACES = -3;
	final static public int RESPONSE_CODE_FACE_OVER_CAPACITY = -4;
	final static public int RESPONSE_CODE_NO_FILE_EXTENSION = -5;

	/**
	 * The base directory where the images of concerned faces would be saved.
	 *
	 * @return
	 */
	@ManagedAttribute(currencyTimeLimit = 100000)
	@NotBlank
	public String getImageBaseDir() {
		return this.imgBase;
	}

	public HbInnoConcernedPersonProcessor(@Nonnull HbinnoEngine vaAdapter, @Nonnull FaceDataManager dataMgr,
			@Nonnull HbInnoDefaultDetectionListener detectionListener, @Nonnull VasConfigService configService) {
		super(dataMgr);

		Validate.isTrue(vaAdapter != null,
				"The HBInnoAdapter should be provided for HbInnoConcernedPersonProcessor instacne to work.");

		this.hbInnoAdapter = vaAdapter;
		this.detectionListener = detectionListener;
		this.configService = configService;

	}

	public void initConfig() {
		// /@Value("${vas.dataDir}")
		this.vadDir = configService.getConfigValByName("vas.dataDir");

		// @Value("${vas.concernedFace.saveDir}")
		this.concernedFaceDir = configService.getConfigValByName("vas.concernedFace.saveDir");

		// @Value("${vas.hbInnoAdapter.maxConcernedface}")
		this.concernedFaceNum = Integer
				.parseInt(configService.getConfigValByName("vas.hbInnoAdapter.maxConcernedface"));

		this.imgBase = configService.getConfigValByName("vas.dataDir");
	}

	@Override
	public HashMap<Integer, Object> registerConcernedFace(String faceImgPath) {

		String envPath = vadDir;
		String fullPath = null;
		String imgPath = null;
		int cnt = 0;

		HashMap<Integer, Object> response = new HashMap<Integer, Object>();

		if (!faceImgPath.isEmpty()) {

			String[] splitByExt = faceImgPath.split("\\.");

			if (splitByExt.length != 2) {

				response.put(RESPONSE_CODE_NO_FILE_EXTENSION, null);
				return response;

			} else {

				fullPath = new StringBuilder().append(envPath).append(faceImgPath).toString();
				// imgPath = new
				// StringBuilder().append(concernedFaceDir).append(faceImgPath).toString();

				File file = new File(fullPath);

				if (!file.exists()) {
					this.logger.error("there is no file : {}", fullPath);
					response.put(RESPONSE_CODE_NO_IMAGE, null);
					return response;
				}

				// List<HbInnoFace> faces = detectFaceFromFile(fullPath);
				List<HbInnoFace> faces = this.getHbInnoAdapter().loadFrameAndExtractFeature(fullPath);
				if (faces.size() == 0) {
					response.put(RESPONSE_CODE_NO_FACE, null);
					return response; // there is no detected face
				}

				if (faces.size() > 1) {
					response.put(RESPONSE_CODE_MULTIPLE_FACES, null);
					return response; // there is no detected face
				}

				response.put(RESPONSE_CODE_SUCCESS, faces.get(0).getFeature());
				// this.getHbInnoAdapter().setAdapterInActive();
				return response;
			}

		} else {
			this.logger.error("There is no image in request data.");
			// return -1;//There is no image in request data.
			response.put(RESPONSE_CODE_NO_IMAGE, null);

			return response;
		}

	}

	@Override
	public void removeFaces(@NotEmpty String[] faceIds) {

	}

	@Override
	public void removePerson(@NotBlank String personId) {

	}

	@Override
	public Pair<Integer, Integer> generateFaceMetasByPerson(String personId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateFaceMetas(String[] faceIds) {
		// TODO Auto-generated method stub
		return 0;
	}

}
