package com.skcc.vas.frs.live.biz;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.commons.lang3.Validate;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.common.db.service.FaceDataManager;

@ParametersAreNonnullByDefault
public abstract class ConcernedPersonProcessorBase implements ConcernedPersonProcessor {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	@Nonnull
	private final FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	public ConcernedPersonProcessorBase(@Nonnull FaceDataManager dataMgr) {
		Validate.isTrue(dataMgr != null,
				"FaceDataManager instance should be provided for ConcernedPersonProcessorBase work.");

		this.faceDataManager = dataMgr;
	}

}
