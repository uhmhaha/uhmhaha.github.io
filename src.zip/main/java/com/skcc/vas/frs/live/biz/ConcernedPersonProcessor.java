package com.skcc.vas.frs.live.biz;

import java.util.HashMap;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author
 * @since 2016-06-30
 *
 */
@ThreadSafe
@ParametersAreNonnullByDefault
public interface ConcernedPersonProcessor {

	/**
	 * The return value of this method consists of the photos of the person that
	 * has no feature in database and the number of faces that generate the
	 * feature. When this method is called after new concerned person is added,
	 * two numbers are expected to be same.
	 *
	 * @param personId
	 * @return
	 */
	Pair<Integer, Integer> generateFaceMetasByPerson(@NotBlank String personId);

	/**
	 * The return value of this method is the number of faces that generate the
	 * feature. When this method is called after new concerned faces are added,
	 * the return value is expected to be same with the size of input array.
	 *
	 * @param faceIds
	 * @return
	 */
	int generateFaceMetas(@NotEmpty String[] faceIds);

	// int registerConcernedFace(@NotEmpty ConcernedFace face,
	// NConcernPersonAndFace nConcernPersonAndFace);

	HashMap<Integer, Object> registerConcernedFace(@NotEmpty String faceImgPath);

	void removePerson(@NotBlank String personId);

	void removeFaces(@NotEmpty String[] faceIds);

}
