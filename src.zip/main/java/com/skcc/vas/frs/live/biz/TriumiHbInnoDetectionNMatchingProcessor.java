package com.skcc.vas.frs.live.biz;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.Resource;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.support.ExecutorServiceAdapter;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.skcc.adapter.vms.incon.InteropLiveAdapter;
import com.skcc.adapter.vms.incon.InteropTypes.StreamType;
import com.skcc.adapter.vms.incon.NativeFrame;
import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.adapter.fr.hbinno.HbInnoFace;
import com.skcc.vas.frs.akka.db.rdb.domain.Cctv;
import com.skcc.vas.frs.common.biz.model.AnalyticFace;
import com.skcc.vas.frs.common.biz.model.ConfigService;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFace;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatch;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedRoi;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.live.FaceUtils;
import com.skcc.vas.frs.common.util.live.HttpProcessor;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;
import com.skcc.vas.frs.live.db.rdb.service.FREngineConfig;
import com.skcnc.hbinno.HBFRfacePro;
import com.skcnc.hbinno.HBFRfaceProConstants;

/**
 * @author
 * @since 2016-08-16
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=triumiHbInnoDetectionNMatchingProcessor", description = "Detects and extract faces from the video streams using HB innovation FR library in pull way.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class TriumiHbInnoDetectionNMatchingProcessor extends TriumiHbInnoDetectionProcessorBase implements
		ListenableDetectionProcessor {

	final private String screenshotBaseDir2;

	private final Set<DetectionListener<?>> detectionListeners = new HashSet<DetectionListener<?>>();

	protected Set<DetectionListener<?>> getDetectionListeners() {
		return this.detectionListeners;
	}

	@Resource(name = "config")
	private Properties config;

	@Override
	public void addListener(@Nonnull DetectionListener<?> listener) {
		if (listener != null)
			this.getDetectionListeners().add(listener);
	}

	@ManagedAttribute
	public int getNumberOfDetectionListeners() {
		return this.detectionListeners.size();
	}

	private final ExecutorService executor;

	protected ExecutorService getExecutor() {
		return this.executor;
	}

	private final ConcurrentMap<String, DetectionTask> tasks = new ConcurrentHashMap<String, DetectionTask>();

	protected ConcurrentMap<String, DetectionTask> getDetectionTasks() {
		return this.tasks;
	}

	private List<DetectionTask> idleTasks = new ArrayList<DetectionTask>();

	public List<DetectionTask> getIdleTasks() {
		return this.idleTasks;
	}

	public int getNumberOfIdleDetetionTasks() {
		return this.idleTasks.size();
	}

	public boolean isIdleTasks() {
		if (this.idleTasks.size() > 0)
			return true;
		else
			return false;
	}

	@Override
	public Set<String> getLiveDeviceIds() {
		return this.tasks.keySet();
	}

	@ManagedAttribute
	public int getNumberOfDetectionTasks() {
		return this.tasks.size();
	}

	private final HttpProcessor httpProcessor;

	private FREngineConfig frEngineConfig;

	private VasConfigService configService;

	// @Value("${vas.dataDir}")
	private String vasDir;

	// @Value("${vas.liveDataDir}")
	private String liveDataDir;

	// @Value("${vas.thumbnail.saveDir}")
	private String thumbnailDirName;

	// @Value("${vas.concernedFace.saveDir.fileIOPath}")
	private String concernedFaceDirName;

	// @Value("${vas.screenshot.saveDir}")
	private String screenShotDir;

	// @Value("${vas.triumiLiveAdapter.streamNo}")
	private String triumiLiveStreamNo;

	// @Value("${vas.ccs.httpPush}")
	private String httpPushEnabled;

	// @Value("${vas.ccs.httpPush.imageBinary}")
	private String imageBinaryYn;

	// @Value("${vas.ccs.httpPush.imageFromFileYn}")
	private String imageFromFileYn;

	// @Value("${vas.liveDataDirUseYN}")
	private String liveDataDirUseYN;

	private boolean getLiveDataDirUseYN() {
		return liveDataDirUseYN.equalsIgnoreCase("y");
	}

	final static private String TERMINATE_FILE_NAME = "killworkernode";

	public boolean getHttpPushStatus() {
		return httpPushEnabled.equalsIgnoreCase("y");
	}

	public boolean getHttpPushImageBinaryStatus() {
		return imageBinaryYn.equalsIgnoreCase("y");
	}

	public boolean getHttpPushImageFromFileYn() {
		return imageFromFileYn.equalsIgnoreCase("y");
	}

	private FRConfig frConfig;

	public TriumiHbInnoDetectionNMatchingProcessor(@Nonnull InteropLiveAdapter triumiLiveAdapter,
			@Nonnull HbInnoAdapter hbInnoAdapter, @Nonnull FaceDataManager faceDataManager,
			@Nonnull ThreadPoolTaskExecutor taskExecutor, @Nonnull HttpProcessor httpProcessor,
			@Nonnull FREngineConfig frEngineConfig, @Nonnull VasConfigService configService) {

		// super(systemId, dataDir, triumiLiveAdapter, hbInnoAdapter,
		// faceDataManager, skips, vmsAddr, vmsPort, vmsUserId, vmsPasswd);

		super(configService.getConfigValByName("vas.detectionProcessors.1.vmsId"), configService
				.getConfigValByName("vas.dataDir"), triumiLiveAdapter, hbInnoAdapter, faceDataManager, Integer
				.parseInt(configService.getConfigValByName("vas.hbInnoDetectionProcessor.skips")), configService
				.getConfigValByName("vas.hbInnoDetectionProcessor.vmsAddr"), Integer.parseInt(configService
				.getConfigValByName("vas.hbInnoDetectionProcessor.vmsPort")), configService
				.getConfigValByName("vas.hbInnoDetectionProcessor.vmsUserId"), configService
				.getConfigValByName("vas.hbInnoDetectionProcessor.vmsPasswd"), configService
				.getConfigValByName("vas.screenshot.saveDir"));

		Validate.isTrue(taskExecutor != null, "The executor for detection taks should be provided.");
		this.executor = new ExecutorServiceAdapter(taskExecutor);

		this.screenshotBaseDir2 = this.getScreenshotBaseDir() + this.getSystemId() + "/";

		this.httpProcessor = httpProcessor;
		this.frEngineConfig = frEngineConfig;

		/*
		 * terminate file이 존재하면 삭제한다
		 */
		deleteTerminateFile();

		this.configService = configService;
		// logger.info("==>>>>>>>>>>vasConfigService.getEnvByName {} " +
		// configService.getConfigValByName("VAS_DATA_DIR"));
		initConfig(configService);
	}

	private void initConfig(VasConfigService configService) {
		// @Value("${vas.dataDir}")
		this.vasDir = configService.getConfigValByName("vas.dataDir");

		// @Value("${vas.liveDataDir}")//삭제
		this.liveDataDir = configService.getConfigValByName("vas.dataDir");

		// @Value("${vas.thumbnail.saveDir}")
		this.thumbnailDirName = configService.getConfigValByName("vas.thumbnail.saveDir");

		// @Value("${vas.concernedFace.saveDir.fileIOPath}")//삭제
		this.concernedFaceDirName = configService.getConfigValByName("vas.concernedFace.saveDir.fileIOPath");

		// @Value("${vas.screenshot.saveDir}")
		this.screenShotDir = configService.getConfigValByName("vas.screenshot.saveDir");

		// @Value("${vas.triumiLiveAdapter.streamNo}")
		this.triumiLiveStreamNo = configService.getConfigValByName("vas.triumiLiveAdapter.streamNo");

		// @Value("${vas.ccs.httpPush}")
		this.httpPushEnabled = configService.getConfigValByName("vas.ccs.httpPush");

		// @Value("${vas.ccs.httpPush.imageBinary}")
		this.imageBinaryYn = configService.getConfigValByName("vas.ccs.httpPush.imageBinary");

		// @Value("${vas.ccs.httpPush.imageFromFileYn}")
		this.imageFromFileYn = configService.getConfigValByName("vas.ccs.httpPush.imageFromFileYn");

		// @Value("${vas.liveDataDirUseYN}")
		this.liveDataDirUseYN = configService.getConfigValByName("vas.liveDataDirUseYN");

	}

	@Override
	@Deprecated
	public void process(String deviceId, boolean starts) {
		throw new UnsupportedOperationException(
				"The method in super inteface is deprecated before the invention of this class.");
	}

	@Override
	@ManagedOperation(description = "Start live detection for a CCTV.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "deciveId", description = "CCTV to start live detection") })
	public boolean startDetection(@NotBlank String deviceId) {
		Validate.isTrue(StringUtils.isNotBlank(deviceId), "The ID for CCTV should be specified.");

		if (this.getDetectionTasks().containsKey(deviceId)) {
			logger.info("[start process:{}] the specified CCTV is running", deviceId);
			return true;
		}

		if (this.getTriumiLiveAdapter().startLive(Integer.valueOf(deviceId), Integer.valueOf(triumiLiveStreamNo),
				StreamType.RGB24, true)) {

			// deviceId 에 대한 ROI 정보를 DB에서 조회 한다.
			List<DetectedRoi> cctvRoiList = this.getFaceDataManager().findCctvIdByRoiList(deviceId);

			/*
			 * VAS_FR_CONFIG_CCTV table에서 UI에서 설정한 값을 읽어 온다
			 */
			FRConfig frConfigCctv = this.getFaceDataManager().getConfigInfoByCctvId(deviceId);
			if (frConfigCctv != null) {
				logger.info("[start live:{}] Get FR Config info from VAS_FR_CONFIG_CCTV DB table : {}", deviceId,
						frConfigCctv);
				this.frEngineConfig.setParameters(frConfigCctv);

			} else {

				/*
				 * VAS_FR_CONFIG_CCTV에 값이 없으면 VAS_FR_CONFIG table에서 설정한 값을 읽어 온다
				 */
				FRConfig frConfig = this.getFaceDataManager().getConfigInfo();
				if (frConfig != null) {
					this.frEngineConfig.setParameters(frConfig);
					logger.info(
							"[start live:{}] NO VAS_FR_CONFIG_CCTV, but get FR Config info from VAS_FR_CONFIG DB table : {}, {}",
							deviceId, frConfig, this.frEngineConfig);

				} else {
					logger.info(
							"[start live:{}] There is no FR Config info in VAS_FR_CONFIG, VAS_FR_CONFIG_CCTV table."
									+ " Instead of it, config.properties will be used : {}", deviceId,
							this.frEngineConfig);
				}
			}

			// detection Task를 실행하기 전에 UI에서 설정한 filtering 관련된 FR config 정보를
			// setting한다.
			setFRConfigurationForCache();

			// 관심 인물이 update 되었을 경우에 대비해서 관심인물을 DB에서 가져와 업데이트 한다
			updateTargetFeaturesBeforeCreatingTask();

			if (isIdleTasks()) {
				DetectionTask task = getIdleTasks().get(0);

				task.breakIdleStateAndSetDevice(deviceId);

				// detectiontask map에 추가
				this.getDetectionTasks().putIfAbsent(deviceId, task);
				// idle detectiontask list에서 삭제
				getIdleTasks().remove(0);

			} else {
				DetectionTask task = new DetectionTask(deviceId, this.getDetectionListeners(), cctvRoiList);
				this.getExecutor().submit(task);
				this.getDetectionTasks().putIfAbsent(deviceId, task);
			}

			this.logger.info("Started live detection for a CCTV. - systemId: {}, deviceId: {}.", this.getSystemId(),
					deviceId);
			int capa = this.getRecentSeconds() * 2;
			this.recentFaces.putIfAbsent(deviceId,
					Pair.of(new ArrayList<AnalyticFace>(capa), new ArrayList<byte[]>(capa)));

			// insert start time into DB table
			this.getFaceDataManager().insertCctvServiceStart(getSystemId(), deviceId, SERVICE_TYPE_NAME);
			// update cctv status into DB table
			this.getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_STARTED);

			return true;
		} else {
			this.logger
					.warn("Start live command returns false. This may means the requested CCTV is already in live or not registerd CCTV or problem of CCTV. - systemId: {}, deviceId: {}",
							this.getSystemId(), deviceId);

			// update cctv status into DB table
			this.getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_START_FAILED);
			return false;
		}

	}

	/*
	 * UI에서 입력한 FR config 정보를 VAS_FR_CONFIG table에서 읽어 온 후 각 class의 member 변수에
	 * setting한다.
	 */
	private void setFRConfigurationForCache() {

		//set filtering period
		int filteringPeriod = Integer.parseInt(configService.getConfigValByName("vas.hbInnoDetectionProcessor.verification.recentSeconds"));
		this.setRecentSeconds(filteringPeriod);

		// set filtering score threshold
		int scoreFiltering =Integer.parseInt(configService.getConfigValByName("vas.cache.scoreThreshold"));
		this.setFilterOutThreshold(scoreFiltering);

		//set cctv screenshot  width
		int width = Integer.parseInt(configService.getConfigValByName("vas.hbInnoDetectionProcessor.screenshot.width"));
		this.setScreenshotWidth(width);

	}

	@Override
	@ManagedOperation(description = "Stop live detection for a CCTV.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "deciveId", description = "CCTV to stop live detection") })
	public void stopDetection(@NotBlank String deviceId) {
		Validate.isTrue(StringUtils.isNotBlank(deviceId), "The ID for CCTV should be specified.");

		DetectionTask task = this.getDetectionTasks().get(deviceId);
		if (task == null) {
			String msg = String.format(
					"The specified CCTV to stop hasn't been started. - systemId: %1$s, deviceId: %2$s.", getSystemId(),
					deviceId);
			this.logger.error(msg);
			// update cctv status into DB table
			this.getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_STOPPED);
			// throw new IllegalStateException(msg);
			return;
		}

		task.stop();
		this.getDetectionTasks().remove(deviceId);

		// insert stop time into DB table
		this.getFaceDataManager().updateCctvServiceEnd(deviceId);

		// add this task into idle task list for re-using
		getIdleTasks().add(task);

	}

	@Override
	public void destroy() {
		super.destroy();

		for (Map.Entry<String, DetectionTask> entry : this.getDetectionTasks().entrySet()) {
			try {
				this.logger.debug("Destory DetectionTask with CCTV {} ", entry.getKey());
				entry.getValue().destroyDetectionTask();
			} catch (Throwable t) {
				this.logger.error(
						"Fail to destroy DetectionTask with CCTV {} during desctruction of detection processor.",
						entry.getKey(), t);
			}
		}
	}

	@Override
	@ManagedOperation(description = "Add/remove target features in HBInno engine")
	public void updateTargetFeatures() {
		/*
		 * DB에서 concerned face data 전체를 가져온다
		 */
		final List<ConcernedFace> faces = getFaceDataManager().findValidConcernedFaces();

		this.logger.info("++ For updating target features, Found {} concerned faces in VAS_CNCRN_FACE table.",
				faces.size());

		// Map<String, byte[]> features = new HashMap<String, byte[]>();
		Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();

		/*
		 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId() =
		 * face Id
		 */
		for (ConcernedFace cf : faces) {

			featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
		}

		/*
		 * 진행 중인 DetectionTask()를 중지한다
		 */
		List<String> deviceIdList = new ArrayList<String>();
		for (String deviceId : tasks.keySet()) {
			// task 중지
			stopDetection(deviceId);
			// 중지된 task의 device id를 기록
			deviceIdList.add(deviceId);
			logger.debug("++ device Id : {} detectiontask stopped ", deviceId);
		}

		try {

			/*
			 * DetectionTask()를 정지할 시간동안 기다린다
			 */
			Thread.sleep(3000);

			/*
			 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId()
			 * = face Id
			 */
			// int count =
			// getHbInnoAdapter().insertLiveTargetFeatures(features);
			int count = getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
			if (faces.size() > count) {
				this.logger
						.warn("++ The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
								count);
			}
			this.logger.debug("++ Total {} concerned features added into Hbinno Adatper.", count);

			/*
			 * 진행 중인 DetectionTask()를 다시 순차적으로 기동한다
			 */
			for (String deviceId : deviceIdList) {
				Thread.sleep(3000);
				startDetection(deviceId);
				logger.debug("++ device Id : {} detectiontask re-started ", deviceId);
			}
		} catch (Exception ex) {
			logger.error("++ Thread sleep() meet error !");
		}

	}

	@Override
	@ManagedOperation(description = "Without destroying thread, Add/remove target features in HBInno engine")
	public void updateTargetFeaturesWithoutTaskStop() {

		/*
		 * Detection Task를 일단 pause 시킨다 2 means sleep period in seconds
		 */
		pauseDetectionTask(2);

		try {

			/*
			 * DB에서 concerned face data 전체를 가져온다
			 */
			final List<ConcernedFace> faces = getFaceDataManager().findValidConcernedFaces();

			this.logger
					.info("[cncrn face update] For updating target features, Found {} concerned faces in VAS_CNCRN_FACE table.",
							faces.size());

			// Map<String, byte[]> features = new HashMap<String, byte[]>();
			Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();

			/*
			 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId()
			 * = face Id
			 */
			for (ConcernedFace cf : faces) {
				featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
			}

			int count = getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
			if (faces.size() > count) {
				this.logger
						.warn("[cncrn face update] The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
								count);
			}
			this.logger.debug("[cncrn face update] Total {} concerned features added into Hbinno Adatper.", count);

			/*
			 * Detection Task를 resume 시킨다
			 */
			resumeDetectionTask();

		} catch (Exception ex) {
			logger.error("[cncrn face update] excetption happens : {}", ex.toString());
		}

	}

	public void updateTargetFeaturesBeforeCreatingTask() {

		try {

			/*
			 * DB에서 concerned face data 전체를 가져온다
			 */
			final List<ConcernedFace> faces = getFaceDataManager().findValidConcernedFaces();

			this.logger
					.info("[cncrn face update before creating task] For updating target features, Found {} concerned faces in VAS_CNCRN_FACE table.",
							faces.size());

			// Map<String, byte[]> features = new HashMap<String, byte[]>();
			Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();

			/*
			 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId()
			 * = face Id
			 */
			for (ConcernedFace cf : faces) {
				featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
			}

			int count = getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
			if (faces.size() > count) {
				this.logger
						.warn("[cncrn face update before creating task] The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
								count);
			}
			this.logger.debug(
					"[cncrn face update before creating task] Total {} concerned features added into Hbinno Adatper.",
					count);

		} catch (Exception ex) {
			logger.error("[cncrn face update before creating task] excetption happens : {}", ex.toString());
		}

	}

	@Override
	@ManagedOperation(description = "Update ROI")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "deciveId", description = "CCTV Id") })
	public void updateROI(String deviceId) {

		/*
		 * Detection task를 pause 시킨다
		 */
		int ret = pauseDetectionTask(deviceId, 2);
		if (ret == -1) {
			logger.warn("[update ROI:{}] Detection Task doesn't exist. ROI update failed", deviceId);
			return;
		}

		/*
		 * device Id에 대한 ROI 정보를 DB에서 가져온다
		 */
		boolean isCctvRoi;
		List<DetectedRoi> cctvRoiList = this.getFaceDataManager().findCctvIdByRoiList(deviceId);
		// VAS_CCTV_SRVC_ROI_PT table 에 roi가 저장되어 있는지를 체크
		if ((cctvRoiList != null) && (cctvRoiList.size() == 4)) {
			isCctvRoi = true;
			for (DetectedRoi roi : cctvRoiList) {
				logger.debug("[update ROI:{}] ROI from DB: No ={}, X={}, Y={}", deviceId, roi.getPointNo(),
						roi.getPointX(), roi.getPointY());
			}

		} else {
			isCctvRoi = false;
		}

		/*
		 * Detection task의 set ROI 함수를 호출한다
		 */
		DetectionTask dt = tasks.get(deviceId);
		if (dt == null) {
			logger.warn("[update ROI:{}] Detection task doesn't exist. So ROI update failed", deviceId);
			return;

		}

		logger.info("[update ROI:{}] Update ROI", deviceId);
		dt.setVideoFrameROI(isCctvRoi, cctvRoiList);

		/*
		 * Detection task를 resume 시킨다
		 */
		resumeDetectionTask(deviceId);

	}

	@Override
	@ManagedOperation(description = "Update engine params in one cctv")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "deciveId", description = "CCTV Id") })
	public void updateFREngineParameters(String deviceId) {

		/*
		 * Detection task를 pause 시킨다
		 */
		int ret = pauseDetectionTask(deviceId, 2);
		if (ret == -1) {
			logger.warn("[update engine params:{}] Detection Task doesn't exist. update engine params failed", deviceId);
			return;
		}

		/*
		 * Detection task의 setFREngieParameters() 함수를 호출한다
		 */
		DetectionTask dt = tasks.get(deviceId);
		if (dt == null) {
			logger.warn("[update engine params:{}] Detection task doesn't exist. So Engine params update failed",
					deviceId);
			return;
		}

		/*
		 * VAS_FR_CONFIG_CCTV table에서 UI에서 설정한 값을 읽어 온다
		 */
		FRConfig frConfigCctv = this.getFaceDataManager().getConfigInfoByCctvId(deviceId);
		if (frConfigCctv != null) {
			logger.info("[update engine params:{}] Get FR Config info from VAS_FR_CONFIG_CCTV DB table : {}", deviceId,
					frConfigCctv);
			dt.setFREngieParameters(frConfigCctv);

		} else {

			/*
			 * VAS_FR_CONFIG_CCTV에 값이 없으면 VAS_FR_CCTV table에서 설정한 값을 읽어 온다
			 */
			FRConfig frConfig = this.getFaceDataManager().getConfigInfo();
			if (frConfig != null) {
				logger.info(
						"[update engine params:{}] NO VAS_FR_CONFIG_CCTV, but get FR Config info from VAS_FR_CONFIG DB table : {}",
						deviceId, frConfig);
				dt.setFREngieParameters(frConfig);
			} else {
				logger.info(
						"[update engine params:{}] There is no FR Config info in VAS_FR_CONFIG, VAS_FR_CONFIG_CCTV table."
								+ " Instead of it, config.properties will be used : {}", deviceId, this.frEngineConfig);
				dt.setFREngieParameters();

			}
		}

		/*
		 * Detection task를 resume 시킨다
		 */
		logger.info("[update engine params:{}] Update engine params ", deviceId);
		resumeDetectionTask(deviceId);
	}

	@Override
	@ManagedOperation(description = "Update engine params in all cctvs")
	public void updateFREngineParameters() {
		for (String deviceId : tasks.keySet()) {
			updateFREngineParameters(deviceId);
		}

	}

	private void pauseDetectionTask(int pausePeriodSeconds) {
		for (String deviceId : tasks.keySet()) {
			pauseDetectionTask(deviceId, pausePeriodSeconds);
		}
	}

	private int pauseDetectionTask(String deviceId, int pausePeriodSeconds) {

		/*
		 * Detection task thread에 멈추라는 신호를 전송한다
		 */
		DetectionTask dt = tasks.get(deviceId);
		if (dt == null) {
			logger.warn("[update process: {}] Detection task doesn't exist", deviceId);
			return -1;
		}

		logger.info("[update process:{}] Pause DetectionTask, sleep period : [{}]sec", deviceId, pausePeriodSeconds);

		dt.pause();
		/*
		 * Detection task가 멈출때 까지 기다린다
		 */
		try {
			Thread.sleep(pausePeriodSeconds * 1000);
		} catch (Exception ex) {
			throw new RuntimeException("[update process] Thread.sleep error");
		}

		return 1;
	}

	private void resumeDetectionTask() {

		for (String deviceId : tasks.keySet()) {
			resumeDetectionTask(deviceId);
		}

	}

	private void resumeDetectionTask(String deviceId) {

		/*
		 * detectiontask thread에 다시 시작하라는 신호를 전송한다
		 */
		DetectionTask dt = tasks.get(deviceId);
		if (dt == null) {
			logger.warn("[update process:{}] Detection task doesn't exist", deviceId);
			return;
		}

		logger.info("[update process:{}] Resume DetectionTask", deviceId);

		dt.resume();

	}

	@Scheduled(fixedDelay = 60000, initialDelay = 60000)
	public void terminate() {
		String currDir = System.getProperty("user.dir");

		/*
		 * terminate file이 있는지 확인
		 */
		StringBuilder sb = new StringBuilder(200).append(currDir).append("/").append(TERMINATE_FILE_NAME);
		String fullPath = sb.toString();

		File termiateFile = new File(fullPath);
		if (!termiateFile.exists())
			return;

		/*
		 * terminate file이 있는 경우 terminate file을 삭제한다
		 */
		logger.info("++ [terminate] termiate file [{}} exists, Now this node will be shutdowned", fullPath);
		termiateFile.delete();

		/*
		 * DetectionTask를 destroy한다
		 */
		destroy();

		/*
		 * Node 종료한다
		 */
		System.exit(0);

	}

	public void deleteTerminateFile() {
		String currDir = System.getProperty("user.dir");

		/*
		 * terminate file이 있는지 확인하고 있으면 강제로 삭제한다
		 */
		StringBuilder sb = new StringBuilder(200).append(currDir).append("/").append(TERMINATE_FILE_NAME);
		String fullPath = sb.toString();

		File termiateFile = new File(fullPath);
		if (termiateFile.exists()) {
			termiateFile.delete();
		}

	}

	@ManagedOperation(description = "Get statistics data for a CCTV.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "deciveId", description = "Get statistics data for a CCTV") })
	public String getDetectionTaskData(@NotBlank String deviceId) {

		Validate.isTrue(StringUtils.isNotBlank(deviceId), "The ID for CCTV should be specified.");

		DetectionTask task = this.getDetectionTasks().get(deviceId);
		if (task == null) {
			String msg = String.format(
					"The specified CCTV is not in the working list. systemId: %1$s, deviceId: %2$s.", getSystemId(),
					deviceId);
			this.logger.error(msg);
			throw new IllegalStateException(msg);
		}

		long numDetectedFace = task.getNumDetectedFace();
		long numEfficientFrame = task.getNumEfficientFrame();
		long numMatchedFace = task.getNumMatchedFace();
		long totalElapasedTimeinMsec = task.getTotalElapasedTimeinMsec();

		// processing time
		long averageProcessingTimePerFace = totalElapasedTimeinMsec / numDetectedFace;
		float facesPerSec = (float) 1000.0 / (float) averageProcessingTimePerFace;
		String msg = String.format(
				"[device id: %s] \r\n Average processing Time Per a Face = [%d]msec \r\n Faces Per Second = [%.2f]",
				deviceId, averageProcessingTimePerFace, facesPerSec);

		// number of matched face
		msg += String.format("\r\n the number of matched face = [%d]", numMatchedFace);

		// number of detected frame
		msg += String.format("\r\n the number of processed frame = [%d]", numEfficientFrame);

		// print start and current tiem
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String startDate = df.format(task.getThreadStartTime());
		msg += String.format("\r\n Start time = %s", startDate);

		long currentTime = System.currentTimeMillis();
		String currentDate = df.format(currentTime);
		msg += String.format("\r\n Current time = %s", currentDate);

		long duration = (currentTime - task.getThreadStartTime());
		float hours = (float) duration / (float) (1000.0 * 3600.0);
		msg += String.format("\r\n Elapsed time = [%.2f] hours ", hours);

		return msg;
	}

	@ManagedAttribute
	public String getLiveDeviceIdList() {

		String msg = String.format("Total live Device Ids = [%d]", this.getDetectionTasks().size());
		for (Map.Entry<String, DetectionTask> entry : this.getDetectionTasks().entrySet()) {
			String deviceId = entry.getKey();
			msg += String.format("\r\n Device Id = [%s]", deviceId);
		}

		return msg;
	}

	@ManagedAttribute
	public String getSavePerformanceDataToFile() {

		// make dir
		if (StringUtils.isBlank(vasDir)) {
			throw new IllegalStateException("The environment variables VAS_DATA_DIR doesn't be defined.");
		}

		String dir = new StringBuilder().append(vasDir).append("/performance/").append(getSystemId()).append("/")
				.toString();

		String separator = "\r\n================================================\r\n\r\n";

		// make file
		String filename = "performance_";
		filename += BaseUtils.formatToYear2SecString(new java.util.Date());
		filename += ".txt";

		String filenamenPath = dir;
		filenamenPath += filename;

		try {

			// make directory
			FileUtils.forceMkdir(new java.io.File(dir));

			FileWriter fw = new FileWriter(filenamenPath);

			// write live device id list
			String msg = getLiveDeviceIdList();
			fw.write(msg);
			fw.write(separator);

			// write performance data
			for (Map.Entry<String, DetectionTask> entry : this.getDetectionTasks().entrySet()) {
				String deviceId = entry.getKey();
				msg = getDetectionTaskData(deviceId);
				fw.write(msg);
				fw.write(separator);
			}

			// close file
			fw.close();

		} catch (IOException ex) {
			String msg = ex.toString();
			throw new IllegalStateException(msg);
		}

		return filenamenPath + " saved";

	}

	@Override
	public boolean startDetectionAndRetry(String deviceId) {
		// TODO Auto-generated method stub
		return false;
	}

	public Properties getConfig() {
		return config;
	}

	public void setConfig(Properties config) {
		this.config = config;
	}

	public FREngineConfig getFrEngineConfig() {
		return frEngineConfig;
	}

	public void setFrEngineConfig(FREngineConfig frEngineConfig) {
		this.frEngineConfig = frEngineConfig;
	}

	public VasConfigService getConfigService() {
		return configService;
	}

	public void setConfigService(VasConfigService configService) {
		this.configService = configService;
	}

	public String getVasDir() {
		return vasDir;
	}

	public void setVasDir(String vasDir) {
		this.vasDir = vasDir;
	}

	public String getLiveDataDir() {
		return liveDataDir;
	}

	public void setLiveDataDir(String liveDataDir) {
		this.liveDataDir = liveDataDir;
	}

	public String getThumbnailDirName() {
		return thumbnailDirName;
	}

	public void setThumbnailDirName(String thumbnailDirName) {
		this.thumbnailDirName = thumbnailDirName;
	}

	public String getConcernedFaceDirName() {
		return concernedFaceDirName;
	}

	public void setConcernedFaceDirName(String concernedFaceDirName) {
		this.concernedFaceDirName = concernedFaceDirName;
	}

	public String getScreenShotDir() {
		return screenShotDir;
	}

	public void setScreenShotDir(String screenShotDir) {
		this.screenShotDir = screenShotDir;
	}

	public String getTriumiLiveStreamNo() {
		return triumiLiveStreamNo;
	}

	public void setTriumiLiveStreamNo(String triumiLiveStreamNo) {
		this.triumiLiveStreamNo = triumiLiveStreamNo;
	}

	public String getHttpPushEnabled() {
		return httpPushEnabled;
	}

	public void setHttpPushEnabled(String httpPushEnabled) {
		this.httpPushEnabled = httpPushEnabled;
	}

	public String getImageBinaryYn() {
		return imageBinaryYn;
	}

	public void setImageBinaryYn(String imageBinaryYn) {
		this.imageBinaryYn = imageBinaryYn;
	}

	public String getImageFromFileYn() {
		return imageFromFileYn;
	}

	public void setImageFromFileYn(String imageFromFileYn) {
		this.imageFromFileYn = imageFromFileYn;
	}

	public FRConfig getFrConfig() {
		return frConfig;
	}

	public void setFrConfig(FRConfig frConfig) {
		this.frConfig = frConfig;
	}

	public String getScreenshotBaseDir2() {
		return screenshotBaseDir2;
	}

	public ConcurrentMap<String, DetectionTask> getTasks() {
		return tasks;
	}

	public HttpProcessor getHttpProcessor() {
		return httpProcessor;
	}

	public static String getTerminateFileName() {
		return TERMINATE_FILE_NAME;
	}

	public void setIdleTasks(List<DetectionTask> idleTasks) {
		this.idleTasks = idleTasks;
	}

	public void setLiveDataDirUseYN(String liveDataDirUseYN) {
		this.liveDataDirUseYN = liveDataDirUseYN;
	}

	class DetectionTask implements Runnable {

		private AtomicBoolean stopped = new AtomicBoolean(false);

		private AtomicBoolean breakIdleState = new AtomicBoolean(false);

		private AtomicBoolean pauseFlag = new AtomicBoolean(false);

		private AtomicBoolean resumeFlag = new AtomicBoolean(false);

		private AtomicBoolean updateHbinnoParamFlag = new AtomicBoolean(false);

		private AtomicBoolean destroyFlag = new AtomicBoolean(false);

		private final Set<DetectionListener<?>> listeners;

		private String deviceId;

		private int skipCounter = 0;

		private List<DetectedRoi> cctvRoiList;

		private final boolean isCctvRoi; // roi 가 db에 저장이 되어 있는지를 체크

		/*
		 * 시스템 환경 변수로 부터 구한 VAS_DATA_DIR 값 =
		 * Watz_Eye_VAS/data/face/vmsid/deviceid/currentdate/filename.jpg
		 */
		private String thumbBase;
		private String liveThumbBase;
		private String concernFaceBase;

		// 실시간 engine parameter 변경을 적용하기 위한 parameters
		private float verificationoThreshold;
		private float verificationLowThreshold;
		private float confidenceThreshold;
		private boolean cacheEnable;
		private boolean cctvResolutionEnable;
		private int maxMatchedFaces;
		private int fromLowMatchedface;
		private int cctvScreenshotWidth;
		private boolean detecedFaceOriginalResolutionEnable;
		private int detectedFaceImageWidth;
		private int cacheScoreThreshold;
		private int cachePeriod;

		private int MAX_FACE_IMAGE_WIDTH = 140;

		// check duration time
		private long start, end;

		// statistics for jmx
		private long numDetectedFace = 0;
		private long numMatchedFace = 0;
		private long numEfficientFrame = 0;
		private long totalElapasedTimeinMsec = 0;
		private long threadStartTime = 0;

		// check invalid frame count
		private int invalidFrameCount = 0;
		private long previousFrameTime = 0;

		public DetectionTask(@NotBlank final String devId, @Nonnull final Set<DetectionListener<?>> listeners,
				List<DetectedRoi> cctvRoiList) {
			this.deviceId = devId;
			this.listeners = listeners;
			this.cctvRoiList = cctvRoiList;

			// VAS_CCTV_SRVC_ROI_PT table 에 roi가 저장되어 있는지를 체크
			if ((this.cctvRoiList != null) && (this.cctvRoiList.size() == 4)) {
				this.isCctvRoi = true;
			} else {
				this.isCctvRoi = false;
			}

			// Thumbnail base directory
			this.thumbBase = getThumbBaseDir(getSystemId(), deviceId);
			this.liveThumbBase = getLiveThumbBaseDir(getSystemId(), deviceId);
			this.concernFaceBase = getConcernImgBaseDir();

		}

		@Override
		public final void run() {

			/*
			 * 업무 순서-(1): HBInno engine 초기화
			 */

			// 1. HB Inno engine 생성
			if (HBFRfacePro.HBFRCreate(0) != 0) {
				logger.error("[face:{}] HBFRCreate failure", deviceId);
				throw new RuntimeException("[face:" + deviceId + "] Fail to HBFRCreate()");
			}

			// 2. Detection Task 동작에 필요한 값들을 설정
			setFREngieParameters();

			// for statistics
			threadStartTime = System.currentTimeMillis();

			/*
			 * 업무 순서-(2'): VSM library 변경으로 ROI 값을 미리 설정해야 함
			 */

			setVideoFrameROI(isCctvRoi, cctvRoiList);

			previousFrameTime = System.currentTimeMillis();

			for (;;) {
				if (destroyFlag.get()) {

					// update cctv status into DB table
					getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_STOPPED);
					logger.debug(
							"[terminate:Dectection Thread id={}] Now I(Detection task) am [killed], device Id =[{}]",
							Thread.currentThread().getId(), deviceId);
					getTriumiLiveAdapter().stopLive(Integer.valueOf(deviceId));
					HBFRfacePro.HBFRDestroy();
					return;

				}
				if (stopped.get()) {
					// cctv stop 실패에 대비해서 [미리] stop_failed 상태로 fr_node_cctv DB
					// table에 적어 놓는다
					getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_STOP_FAILED);

					getTriumiLiveAdapter().stopLive(Integer.valueOf(deviceId));
					// HBFRfacePro.HBFRDestroy();

					// update cctv status into DB table
					getFaceDataManager().updateCctvStatus(getSystemId(), deviceId, Cctv.CCTV_STATUS_STOPPED);

					while (true) {
						logger.debug("[idle:Dectection Thread id={}] Now I(Detection task) am [idle] state.", Thread
								.currentThread().getId());
						try {
							Thread.sleep(500);
						} catch (Exception e) {
							logger.error("[idle:Dectection Thread id={}]Thread sleep error : {}", Thread
									.currentThread().getId(), e.toString());
						}

						if (breakIdleState.get()) {
							break;
						}
					} // while(true)

					// re-initialize detection task
					stopped.set(false);
					breakIdleState.set(false);
					logger.debug(
							"[idle:Dectection Thread id={}] Now I(Detection task) am [idle] --> [working] state with new device id = [{}]",
							Thread.currentThread().getId(), deviceId);

					setEngineParamterAndROI();

				}

				if (this.pauseFlag.get()) {
					while (true) {
						logger.debug("[update process:{}] Now I(Detection task) stopped for a while", deviceId);
						try {
							Thread.sleep(500);
						} catch (Exception ee) {
							logger.error("[update process:{}]Thread sleep error : {}", deviceId, ee.toString());
						}

						if (this.resumeFlag.get()) {
							break;
						}
					}
					// reinitialize flag
					this.resumeFlag.set(false);
					this.pauseFlag.set(false);
					logger.debug("[update process:{}] Now I(Detection task) will resumed and run again", deviceId);
				}

				if (updateHbinnoParamFlag.get()) {

					int ret = HBFRfacePro.HBFRSetLicense(frEngineConfig.getHbInnoParam().getLicenseKey());
					if (ret < 0) {
						logger.error(
								"[update process: {}] HBFRfacePro.HBFRSetLicense() error, return value = [{}] : license key = [{}] ",
								deviceId, ret, frEngineConfig.getHbInnoParam().getLicenseKey());
						throw new RuntimeException("Hbinno license setting error : license key = "
								+ frEngineConfig.getHbInnoParam().getLicenseKey());
					}
					HBFRfacePro.HBFRSetDetectionThreshold(frEngineConfig.getHbInnoParam().getDetectionThreshold());
					HBFRfacePro.HBFRSetParameter(HBFRfaceProConstants.HB_SETPARAM_EYESROLL, frEngineConfig
							.getHbInnoParam().getEyesRoll());
					HBFRfacePro.HBFRSetParameter(HBFRfaceProConstants.HB_SETPARAM_EYESMINWIDTH, frEngineConfig
							.getHbInnoParam().getEyesMinWidth());
					HBFRfacePro.HBFRSetParameter(HBFRfaceProConstants.HB_SETPARAM_EYESMAXWIDTH, frEngineConfig
							.getHbInnoParam().getEyesMaxWidth());
					HBFRfacePro.HBFRSetParameter(HBFRfaceProConstants.HB_SETPARAM_MAXFACE, frEngineConfig
							.getHbInnoParam().getMaxFacesPerImage());

					logger.debug("[update process:{}] Hbinno parameters are setted in run() method", deviceId);

					updateHbinnoParamFlag.set(false);
				}

				if (getSkips() > 0) {
					if (this.skipCounter++ < getSkips()) {
						logger.trace("[face:{}] Skip current frame. - systemId: {}, {}/{}", deviceId, getSystemId(),
								skipCounter, getSkips());
						continue;
					} else {
						this.skipCounter = 0;
					}
				}

				boolean frmCaught = false;
				NativeFrame frm = null;

				try {

					if (logger.isDebugEnabled()) {
						start = System.currentTimeMillis();
					}

					/*
					 * 업무 순서-(2): VMS에서 영상 한 frame을 pull 한다.
					 */
					frm = getTriumiLiveAdapter().getLiveFrame(Integer.valueOf(this.deviceId));

					if (!this.validateNativeFrame(frm)) {
						invalidFrameCount++;
						// 오랜 시간(약 3~4시간 이상), VMS 또는 CCTV가 죽어있을 경우, VMS가 정상적으로
						// 복귀되더라도 영상을 재수신 못하는 경우, StartLive 로직 재 요청
						// 로직 변경 필요
						if (invalidFrameCount % 30000 == 0) {
							logger.warn(
									"[face:{}] [warning]Now call stopLive() and startLive() again !!!. invaild frame = [{}}",
									deviceId, invalidFrameCount);
							if (getTriumiLiveAdapter().stopLive(Integer.valueOf(deviceId))) {
								getTriumiLiveAdapter().startLive(Integer.valueOf(deviceId),
										Integer.valueOf(triumiLiveStreamNo), StreamType.RGB24, true);

								setVideoFrameROI(isCctvRoi, cctvRoiList);
							}
						}

						continue;
					} else {
						frmCaught = true;
						logger.debug(
								"[face:{}] Pull a frame from the VMS. - systemId: {} address: {}, size: {}, width: {}, height: {}, time: {}",
								deviceId, getSystemId(), frm.getAddress(), frm.getSize(), frm.getWidth(),
								frm.getHeight(), frm.getTime());

						long timeSpan = System.currentTimeMillis() - previousFrameTime;
						logger.debug("[NIC:{}], num of invalid frame count = {}, frame caputred time span = {}msec",
								deviceId, invalidFrameCount, timeSpan);
						invalidFrameCount = 0;
						previousFrameTime = System.currentTimeMillis();

					}

					/*
					 * 업무 순서-(4): 얼굴을 검출하고 thumbnail을 jpg 파일로 저장한다. ROI 정보가 없는
					 * 경우 전체 영역을 대상으로 한다.
					 */
					List<HbInnoFace> faces = new ArrayList<HbInnoFace>();
					if (HBFRfacePro.HBFRLoadBGR24FromPointer(frm.getAddress(), frm.getWidth(), frm.getHeight(),
							frm.getWidth() * 3, -1) != 0) {
						logger.error("[face:{}] HBFRLoadBGR24FromPointer() failure", deviceId);
						continue;
					}

					int nFace = HBFRfacePro.HBFRDetectFaces(0, 0, frm.getWidth() - 1, frm.getHeight() - 1);
					logger.debug("[face:{}] [VMS Id: {}] the number of detected face : {}, framePtr: {}", deviceId,
							getSystemId(), nFace, frm.getAddress());
					if (nFace < 0) {
						if (nFace == HBFRfaceProConstants.HBFR_ERR_INVALID_LICENSE_KEY) {
							logger.error("[face:{}] HBFRDetectedFaces() error! because of invalid license = [{}]",
									frEngineConfig.getHbInnoParam().getLicenseKey());
							throw new RuntimeException("HBInno license is invalid !!! license = "
									+ frEngineConfig.getHbInnoParam().getLicenseKey());
						}
						continue;
					}

					numDetectedFace += nFace;
					numEfficientFrame++;

					HbInnoFace hbInnoFace = null;

					String dayStr = BaseUtils.formatToYear2DayString(new java.util.Date()); // yyyMMdd
																							// format
					for (int i = 0; i < nFace; i++) {
						hbInnoFace = new HbInnoFace();

						// 안면의 정면 응시도 체크
						float faceConfidence = HBFRfacePro.HBFRGetFaceConcentration(i);
						if (faceConfidence < confidenceThreshold) {
							logger.debug(
									"[face:{}] Face Concentration is LOW. Face Concentration : {}, Face Num : {} ",
									deviceId, faceConfidence, i);
							continue;
						}

						// extract face feature
						byte[] feature = HBFRfacePro.HBFRExtractFeature(i);
						hbInnoFace.setFeature(feature);
						float faceWidth = HBFRfacePro.HBFRGetFaceWidth(i);
						int faceWidthInt = Math.round(faceWidth);
						if (faceWidthInt < 100) {
							logger.warn(
									"[face:{}] detected face width [{}] is smaller than [100]. So this face is not the detetion process",
									deviceId, faceWidthInt);
							continue;
						}
						hbInnoFace.setImgWidth(Math.round(faceWidth));

						float faceHeight = HBFRfacePro.HBFRGetFaceHeight(i);
						hbInnoFace.setImgHeight(Math.round(faceHeight));

						// HBFaceFloatPoint.ByReference center = new
						// HBFaceFloatPoint.ByReference();
						float[] centerposition = HBFRfacePro.HBFRGetFaceCenterPosition(i); // 얼굴의
																							// 중앙
																							// 위치.
						hbInnoFace.setImgX(Math.round(centerposition[0] - faceWidth / 2));
						hbInnoFace.setImgY(Math.round(centerposition[1] - faceHeight / 2));

						String fileNamePrefix = BaseUtils.formatToYear2MillisecString(new Date());
						// Save Face Image
						String thumbDir = new StringBuilder().append(thumbBase).append("/").append(dayStr).toString();
						String cncrnDir = new StringBuilder().append(thumbBase).append("/").append(dayStr).toString();
						String thumbPath = new StringBuilder(thumbDir).append("/").append(fileNamePrefix).append("-")
								.append(i).append(".jpg").toString();
						String thumbRelativePath = getRelativeFaceThumbnailPath(thumbPath);

						FileUtils.forceMkdir(new java.io.File(thumbDir));

						// 썸네일 저장시 원래 사이즈 그대로 저장
						if (detecedFaceOriginalResolutionEnable) {
							if (faceWidthInt > MAX_FACE_IMAGE_WIDTH)
								faceWidthInt = MAX_FACE_IMAGE_WIDTH;
							if (HBFRfacePro.HBFRSaveFaceThumbnail(i, thumbPath, HBFRfaceProConstants.HB_THUMBNAIL_JPEG,
									faceWidthInt) > 0) {
								logger.error("[face:{}] Fail to save face thumbnail. path: {} ", deviceId, thumbPath);
							} else {
								logger.trace("[face:{}] Saved face thumbnail. path: {}", deviceId, thumbPath);
								hbInnoFace.setFaceBinary(HBFRfacePro.HBFRExtractFaceThumbnail(i,
										HBFRfaceProConstants.HB_THUMBNAIL_JPEG, faceWidthInt));
							}
						} else { // 고정된 사이즈로 저장
							if (HBFRfacePro.HBFRSaveFaceThumbnail(i, thumbPath, HBFRfaceProConstants.HB_THUMBNAIL_JPEG,
									detectedFaceImageWidth) > 0) {
								logger.error("[face:{}] Fail to save face thumbnail. path: {} ", deviceId, thumbPath);
							} else {
								logger.trace("[face:{}] Saved face thumbnail. path: {}", deviceId, thumbPath);
								hbInnoFace.setFaceBinary(HBFRfacePro.HBFRExtractFaceThumbnail(i,
										HBFRfaceProConstants.HB_THUMBNAIL_JPEG, detectedFaceImageWidth));
							}
						}

						if (getLiveDataDirUseYN()) {
							// Save Face Image (for Live Analysis)
							String thumbDir2 = new StringBuilder().append(liveThumbBase).append("/").append(dayStr)
									.toString();
							String thumbPath2 = new StringBuilder(thumbDir2).append("/").append(fileNamePrefix)
									.append("-").append(i).append(".jpg").toString();

							FileUtils.forceMkdir(new java.io.File(thumbDir2));

							if (detecedFaceOriginalResolutionEnable) {
								if (HBFRfacePro.HBFRSaveFaceThumbnail(i, thumbPath2,
										HBFRfaceProConstants.HB_THUMBNAIL_JPEG, faceWidthInt) > 0) {
									logger.error("[face:{}] Fail to save face thumbnail. path: {} ", deviceId,
											thumbPath2);
								} else {
									logger.trace("[face:{}] Saved face thumbnail. path: {}", deviceId, thumbPath2);
								}
							} else { // 고정된 사이즈로 저장
								if (HBFRfacePro.HBFRSaveFaceThumbnail(i, thumbPath2,
										HBFRfaceProConstants.HB_THUMBNAIL_JPEG, detectedFaceImageWidth) > 0) {
									logger.error("[face:{}] Fail to save face thumbnail. path: {} ", deviceId,
											thumbPath2);
								} else {
									logger.trace("[face:{}] Saved face thumbnail. path: {}", deviceId, thumbPath2);
								}
							}
						}

						// thumbnail relative path with file name
						hbInnoFace.setFaceFile(thumbRelativePath);

						// thumbnail absolute path with file name
						hbInnoFace.setAbsolutePath(thumbPath);

						faces.add(hbInnoFace);
					}

					if (faces == null || faces.isEmpty()) {
						logger.trace("[face:{}] No face is detected from a frame. time: {}", deviceId, frm.getTime());
						continue;
					}

					/*
					 * 업무 순서-(5): 얼굴이 검출된 경우 VMS에 가져온 영상 frame을 저장한다.
					 */
					String shotDir = null;
					String shotPath = null;
					if (getTriumiFsUtilAdapter() != null) {
						Pair<String, String> pathAndDir = getScreenshotPathAndDir(this.deviceId);
						shotPath = pathAndDir.getLeft();
						shotDir = pathAndDir.getRight();
						FileUtils.forceMkdir(new java.io.File(shotDir));

						if (cctvResolutionEnable) {
							/*
							 * getLiveFrame()에서 받은 영상 frame 해상도를 그대로 저장
							 */
							getTriumiFsUtilAdapter().saveImageToFile(shotPath, frm.getWidth(), frm.getHeight(),
									frm.getAddress(), frm.getSize());
						} else {
							/*
							 * config.properites에서 설정한 크기대로 frame을 저장
							 */
							getTriumiFsUtilAdapter().saveImageToFile(shotPath, frm.getAddress(), frm.getWidth(),
									frm.getHeight(), frm.getSize(), cctvScreenshotWidth,
									getScreenshotFormat().getHeight(), getScreenshotFormat().keepsRatio());
						}

					} // if(getTriumiFsUtilAdapter() != null)

					/*
					 * 업무 순서-(6): 검출된 얼굴 정보들을 DB에 저장한다
					 */
					DetectedFace detectedFace = null;
					AnalyticFace recentFace = null;
					String faceId = null;
					final Map<String, byte[]> recentFeatures = getRecentFaceFeaturesByDevice(deviceId);

					for (HbInnoFace face : faces) {
						if (cacheEnable) {
							if (containsFeature(face.getFeature(), recentFeatures, cacheScoreThreshold)) {
								logger.debug("[cache:{}] face = {} already exists in cache ", deviceId,
										face.getFaceFile());
								continue;
							}
						}

						detectedFace = new DetectedFace()
								.setSystemId(getSystemId())
								.setCctvId(this.deviceId)
								.setSrvcType(SERVICE_TYPE_NAME)
								.setImgFile(face.getFaceFile())
								.setImgWidth(face.getImgWidth())
								.setImgHeight(face.getImgHeight())
								.setImgX(face.getImgX())
								.setImgY(face.getImgY())
								.setFeature(face.getFeature())
								.setFrmFile(
										shotPath.substring(getScreenshotBaseDir().length() - screenShotDir.length() - 1))
								.setFrmWidth(frm.getWidth()).setFrmHeight(frm.getHeight()).setFrmTime(frm.getTime());
						detectedFace.setAbsoluteImagePath(face.getAbsolutePath());
						// RDB를 통한 저장 - 테스트를 위한 주석처리
						// getFaceDataManager().addDetectedFace(detectedFace);

						// NoSQL을 통한 저장
						NDetectedFace nDetectedFace = getFaceDataManager().addNDetectedFace(detectedFace);
						logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + nDetectedFace.getDetectedFaceId());
						detectedFace.setId(nDetectedFace.getDetectedFaceId());

						// if(frmCaught){
						// getTriumiLiveAdapter().releaseLiveFrame(Integer.valueOf(this.deviceId));
						// }
						faceId = String.valueOf(detectedFace.getId());
						/*
						 * update date: 2016/10/04 author : NA HOON
						 * HbInnoDefaultDetectionListener.java를 호출하지 않고 단일
						 * thread에서 실행하도록 변경
						 * 
						 * for(DetectionListener<?> listener : listeners){
						 * listener.detected(detectedFace, false); }
						 */

						/*
						 * 업무 순서-(7): 검출된 feature 정보가 concerned face에 있는 지를
						 * verify 하고 verification 결과를 DB에 저장한다.
						 */
						// findMatch(detectedFace, 3, verificationoThreshold,
						// hbInnoAdapterMultiInst);
						findMatch(detectedFace, maxMatchedFaces, verificationoThreshold, verificationLowThreshold,
								face.getFaceBinary());

						/*
						 * 업무 순서 - (8): 내부 cache에 검출된 정보를 저장한다.
						 */
						if (cacheEnable) {
							recentFace = new AnalyticFace(faceId, face.getFeature(), Long.valueOf(frm.getTime()));
							addRecentFace(this.deviceId, recentFace);
							logger.debug("[cache:{}] face id = {}, face file = {} stored in cache ", deviceId, faceId,
									face.getFaceFile());
						}

						long cnt = foundFacesNum.incrementAndGet();
						logger.trace("[face:{}] Saved a face - id: {}, count: {}", deviceId, faceId, cnt);
					}

					if (logger.isDebugEnabled()) {
						end = System.currentTimeMillis();
						logger.debug("[face:{}] ==> Elapsed Time (total): {} msec per {} faces <==", deviceId, end
								- start, faces.size());
						logger.debug("[face:{}] ==> Elapsed Time (Each): {} msec per one face <==", deviceId,
								(end - start) / faces.size());

						totalElapasedTimeinMsec += (end - start);
					}

					logger.trace("[face:{}] Saved {} faces for a frame. systemId: {} deviceId: {}, time: {}", deviceId,
							faces.size(), getSystemId(), this.deviceId, frm.getTime());
					logger.trace(
							"[face:{}] Processing statistics : processed frames: {}, detected faces: {}, exceptions: {}, processed frames/sec: {}",
							deviceId, processedFramesNum, foundFacesNum, exceptionsNum,
							getNumberOfProcessedFramesPerSecond());

				} catch (Exception t) {
					logger.error(
							"[face:{}] Fail to analysis a frame or save the result. - systemId: {}, time: {} : {}",
							deviceId, getSystemId(), frm.getTime(), t.toString());

				} finally {
					// getTriumiLiveAdapter().releaseLiveFrame(Integer.valueOf(this.deviceId));

				}
			}// for(;;) loop
		} // end of run()

		private final boolean validateNativeFrame(final NativeFrame frm) {
			if (frm == null) {
				// logger.warn("[face:{}] Fail to get a frame from the VMS for CCTV ",
				// deviceId);
				return false;
			} else if (frm.getAddress() < 1L || frm.getSize() < 1 || frm.getWidth() < 1 || frm.getHeight() < 1) {
				// logger.error("Invalid frame from the VMS. - systemId: {}, deviceId: {}, address: {}, size: {}, width: {}, height: {}, time: {}",
				// getSystemId(), this.deviceId, frm.getAddress(),
				// frm.getSize(), frm.getWidth(), frm.getHeight(),
				// frm.getTime());
				return false;
			}

			return true;
		}

		private Pair<String, String> getScreenshotPathAndDir(@NotBlank String devId) {
			final String date = BaseUtils.formatToYear2MillisecString(new java.util.Date()); // 'yyyyMMddHHmmssSSS'
																								// format

			final StringBuilder sb = new StringBuilder(100).append(screenshotBaseDir2).append(devId).append("/")
					.append(date.substring(0, 8)).append("/");
			final String dir = sb.toString();
			sb.append(date.substring(8)).append(".").append(getScreenshotFormat().getImageFormat().getExtension())
					.toString();

			return Pair.of(sb.toString(), dir);
		}

		public final void stop() {
			this.stopped.set(true);
			releasePasueState();
		}

		private List<Pair<String, Integer>> findMatch(@Nonnull DetectedFace face, @Min(1) int limitCount,
				float threshold, float lowThreshold, byte[] faceBinary) throws Exception {

			logger.debug("[face:{}] findMatch() limitCount = {}, threshold = {}, low threshold = {}", deviceId,
					limitCount, threshold, lowThreshold);

			/*
			 * string = face Id integer = score
			 */
			List<Pair<String, Integer>> matches = new ArrayList<Pair<String, Integer>>(); // 리턴값....
			// FRS UI에 push를 보내기 위한 데이터 저장
			List<Pair<String, Integer>> matchesforPush = new ArrayList<Pair<String, Integer>>();
			// matching threshold를 넘는 데이터 중 top 2를 저장
			List<NDetectedFaceMatch> faceMatchs = new ArrayList<NDetectedFaceMatch>();
			// 그 이외의 데이터를 저장
			List<NDetectedFaceMatch> lowFaceMatchs = new ArrayList<NDetectedFaceMatch>();

			int thresholdInt = Math.round(threshold * (float) 100.0);

			// 작업순서
			// 0. insertLiveTargetFeatures(Map<String, byte[]> targetFeatures)
			// 먼저 실행해야 함.
			// 1. insertLiveTargetFeatures 통해서 타켓정보가 C 메모리에 저장되고, liveTmap에 인덱스와
			// getId 가 저장된다.
			// 2.targetFeatures 의 개수만큼 loop 돌면서 INDEX 와 STRING 에 해당하는 getId 정보를
			// liveTmap 에 복제한다.
			// 3.미리 입력된 targetFeatures 정보(多)와 1건 verify 비교
			// 4.targetFeatures의 키정보와 스코어 점수를 tmap 에 담는다.
			// 5.최종적으로 count 된 건수 만큼의 List 정보를 리턴한다.

			// 점수 판단 기준을 threshold에서 lowThreshold로 변경
			int count = HBFRfacePro.HBFRVerifyBatch(face.getFeature(), face.getFeature().length, limitCount,
					lowThreshold); // ex. limitCount 3 이면 3건만 리턴.
			Map<String, String> cncrnImgPath = new HashMap<String, String>();
			// 만약 limitCount 를 3건으로 설정했으면,
			// ex. indices[0]->12 , indices[1]->13, indices[1]->17
			if (count > 0) {
				int indices[] = HBFRfacePro.HBFRGetIndices();
				float scores[] = HBFRfacePro.HBFRGetScores();
				logger.debug("[face:{}] Verification Score Result: ", deviceId);

				for (int j = 0; j < count; j++) {
					int score = (int) Math.round(scores[j] * 100.0);
					// matches.add(Pair.of(getHbInnoAdapter().getLiveFaceIdMap().get(indices[j]),
					// score));
					matches.add(Pair.of(getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(), score));
					cncrnImgPath.put(getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(),
							getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getRight());
					if (score >= thresholdInt)
						matchesforPush.add(Pair.of(
								getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(), score));
					logger.debug("[face:{}] HBInno List index: {}, score: {} ", deviceId, indices[j], scores[j]);
					logger.debug("[face:{}] Face Id from liveFaceIdnPathMap : {}", deviceId, getHbInnoAdapter()
							.getLiveFaceIdnPathMap().get(indices[j]).getLeft());
				}

				numMatchedFace += count;

			}

			if (count != 0) {

				logger.debug("----------------------------------------------------");
				logger.debug("[face:{}] Find matched faces = {} from Concerned Features", deviceId, count);
				logger.debug("----------------------------------------------------");

				// RDB를 통한 저장
				// getFaceDataManager().addConcernedFaceMatches(String.valueOf(face.getId()),
				// matches);

				// MONGODB를 통한 저장
				logger.debug("[DetectionTask] Applying to Nosql: {}", face.getId());
				List<NDetectedFaceMatch> nDetectedFaceMatchs = getFaceDataManager().addNConcernedFaceMatches(face,
						matches, thresholdInt);

				for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
					if ((nDetectedFaceMatch.getScore() >= thresholdInt) && (faceMatchs.size() < fromLowMatchedface)) {
						faceMatchs.add(nDetectedFaceMatch);
					} else {
						lowFaceMatchs.add(nDetectedFaceMatch);
					}
				}
				// skyang 03-22 count는 기본적으로 lowthreshold를 기준으로 발생하기에
				// highthreshold보다 하지 않는 경우에는 LowMatchWithProfile와 detected
				// face정보만을 가지고FaceMatchWithProfile에 데이터를 입력해야한다.
				// 즉, 3가지 경우인 1. detected face만 있는 경우, 2.detectedface와 hight
				// matched face가 있는 경우 3.detectedface와 low matched face가 있는 경우

				if (faceMatchs.size() < 1) {
					// 3번case
					logger.debug("[face:{}] No matched faces from Concerned Features", deviceId);

					getFaceDataManager().addNConcernedFaceMatchWithProfile(face, null);

				} else {
					// 2번case
					// VAS_DETECTED_FACE_N_MATCH_WITH_PROFILE_NOSQL에 입력
					getFaceDataManager().addNConcernedFaceMatchWithProfile(face, faceMatchs);
					// VAS_DETECTED_FACE_N_LOW_MATCH_WITH_PROFILE_NOSQL에 입력
					getFaceDataManager().addNConcernedFaceLowMatchWithProfile(face, lowFaceMatchs);
				}

			} else {
				// 1번case
				logger.debug("[face:{}] No matched faces from Concerned Features", deviceId);

				getFaceDataManager().addNConcernedFaceMatchWithProfile(face, null);
			}

			/*
			 * CCS server에 detection or detection and matched data를 http
			 * request로 전송한다.
			 */
			if (getHttpPushStatus()) {
				makePushDataSet(face, matchesforPush, cncrnImgPath, faceBinary);
			}

			return matches;
		}

		private void makePushDataSet(DetectedFace dFace, List<Pair<String, Integer>> matches,
				Map<String, String> cncrnImgPath, byte[] faceBinary) throws IOException {

			File file = new File(dFace.getAbsoluteImagePath());
			if (!file.exists()) {
				logger.error("[face:{}] Thumbnail[{}] doesn't exist. So http push never go to ccs", deviceId,
						file.getAbsolutePath());
				return;
			} else {
				logger.debug("[face:{}] Thumbnail[{}] exists. so http push will go to ccs", deviceId,
						file.getAbsolutePath());
			}

			Map<String, String> pData = new HashMap<String, String>();
			JSONObject jsonObj = new JSONObject();
			Pair<String, Integer> aMatch = null;

			jsonObj.put("bizProcessId", "frinfopushBizOperation");
			jsonObj.put("encryptCallYN", "N");

			FaceUtils.sortFaceMatches(matches, true);

			if (CollectionUtils.isNotEmpty(matches)) {
				for (int i = 0; i < 1; i++) {
					aMatch = matches.get(i);

					// GENERAL INFO
					jsonObj.put("SYSTEM_ID", String.valueOf(dFace.getSystemId()));
					jsonObj.put("CCTV_ID", String.valueOf(dFace.getCctvId()));
					jsonObj.put("SRVC_TYPE", String.valueOf(dFace.getSrvcType()));

					// DETECTED FACE INFO
					jsonObj.put("DETECTED_FACE_ID", String.valueOf(dFace.getId()));
					if (getHttpPushImageBinaryStatus()) {
						jsonObj.put("DETECTED_IMG_BINARY", String.valueOf(Base64ConverToString(faceBinary)));
						jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");
					} else {
						jsonObj.put("DETECTED_IMG_BINARY", "");
						jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
					}
					jsonObj.put("DECTECTED_FILE_PATH", String.valueOf(dFace.getImgFile()));

					// FRMFILE INFO
					jsonObj.put("FRM_FILE_PATH", String.valueOf(dFace.getFrmFile()));
					jsonObj.put("FRM_TIME", String.valueOf(dFace.getFrmTime()));

					// CONCERN PERSON INFO
					jsonObj.put("CNCRN_FACE_ID", String.valueOf(aMatch.getLeft()));
					if (getHttpPushImageBinaryStatus()) {
						// 1. use file i/o
						if (getHttpPushImageFromFileYn()) {
							String[] imgPathArr = cncrnImgPath.get(aMatch.getLeft()).split("/");
							String imgPath = new StringBuilder().append(getConcernImgBaseDir())
									.append(imgPathArr[1].toString()).append("\\").append(imgPathArr[2].toString())
									.toString();
							jsonObj.put("CNCRN_IMG_BINARY", String.valueOf(Base64ConverToString(getImageByte(imgPath))));
						} else {
							// 2.use push image binary
							byte[] imgBinary = getFaceDataManager().findConcernedFaceImageBinaryByCncrnfaceId(
									aMatch.getLeft());
							jsonObj.put("CNCRN_IMG_BINARY", Base64ConverToString(imgBinary));
						}

						jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");

					} else {
						jsonObj.put("CNCRN_IMG_BINARY", "");
						jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
					}
					jsonObj.put("CNCRN_IMG_PATH", cncrnImgPath.get(aMatch.getLeft()));
					jsonObj.put("SCORE", String.valueOf(aMatch.getRight()));

					try {
						if (jsonObj.get("INCLUDE_IMG_BINARY_YN") != null)
							httpProcessor.pushData(jsonObj.toString());
					} catch (InterruptedException | ExecutionException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} else {

				// GENERAL INFO
				jsonObj.put("SYSTEM_ID", String.valueOf(dFace.getSystemId()));
				jsonObj.put("CCTV_ID", String.valueOf(dFace.getCctvId()));
				jsonObj.put("SRVC_TYPE", String.valueOf(dFace.getSrvcType()));

				// DETECTED FACE INFO
				jsonObj.put("DETECTED_FACE_ID", String.valueOf(dFace.getId()));
				if (getHttpPushImageBinaryStatus()) {
					jsonObj.put("DETECTED_IMG_BINARY", String.valueOf(Base64ConverToString(faceBinary)));
					jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");
				} else {
					jsonObj.put("DETECTED_IMG_BINARY", "");
					jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
				}
				jsonObj.put("DECTECTED_FILE_PATH", String.valueOf(dFace.getImgFile()));

				// FRMFILE INFO
				jsonObj.put("FRM_FILE_PATH", String.valueOf(dFace.getFrmFile()));
				jsonObj.put("FRM_TIME", String.valueOf(dFace.getFrmTime()));

				// CONCERN PERSON INFO
				jsonObj.put("CNCRN_FACE_ID", "");
				jsonObj.put("CNCRN_IMG_BINARY", "");
				jsonObj.put("CNCRN_IMG_PATH", "");

				jsonObj.put("SCORE", "");

				try {
					httpProcessor.pushData(jsonObj.toString());
				} catch (InterruptedException | ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		public void setVideoFrameROI(boolean roiSetFlag, List<DetectedRoi> roiList) {
			/*
			 * 현재 CCTV에 설정된 해상도 정보를 가져온다
			 */
			NativeFrame frm = null;
			for (;;) {
				// logger.debug("++ before TriumiLiveAdapter().getLiveFrame() in setVideoFrameROI");
				frm = getTriumiLiveAdapter().getLiveFrame(Integer.valueOf(this.deviceId));
				// logger.debug("++ after TriumiLiveAdapter().getLiveFrame() in setVideoFrameROI");
				if (!validateNativeFrame(frm)) {
					// logger.warn("Fail to get a video frame from VMS in order to find out cctv resolution, device Id = {}",
					// deviceId);
					try {
						Thread.sleep(2 * 1000);
					} catch (Exception ex) {
						logger.warn("thread sleep error");
					}
					continue;
				} else {
					break;
				}
			}
			logger.info("[face:{}] cctv original resolution: width = {}, height = {}", deviceId, frm.getOriginWidth(),
					frm.getOriginHeight());

			/*
			 * ROI 설정전 0.5초 정도 sleep 필요. incon의 요구사항
			 */
			try {
				Thread.sleep(500);
			} catch (Exception ex) {
				throw new RuntimeException("fail to sleep()");
			}

			/*
			 * UI에 저장한 ROI 정보를 바탕으로 실제 해상도로 부터 ROI 값을 계산한다.
			 */
			int roiTopleftX = 0;
			int roiTopleftY = 0;
			int roiBottomrightX = 0;
			int roiBottomrightY = 0;
			int roiWidth = 0;
			int roiHeight = 0;

			if (roiSetFlag) { // roi topleft, bottomright 좌표를 구함.
				// revice roi rate
				List<DetectedRoi> reviceCctvRoiList = FaceUtils.reviceRoiRate(roiList);
				HashMap<String, Object> hmap = FaceUtils.roiRateToPoint(frm.getOriginWidth(), frm.getOriginHeight(),
						reviceCctvRoiList);
				if (hmap != null)
					logger.debug("[face:{}] ROI flag is ture. CctvRoi info hmap : {} ==>  ", deviceId, hmap.toString());
				else {
					logger.warn("[face:{}] ROI flag is true. but hmap ROI is null", deviceId);
				}
				roiTopleftX = (Integer) hmap.get("topleftX");
				roiTopleftY = (Integer) hmap.get("topleftY");
				roiBottomrightX = (Integer) hmap.get("bottomrightX");
				roiBottomrightY = (Integer) hmap.get("bottomrightY");
				roiWidth = roiBottomrightX - roiTopleftX + 1;
				roiHeight = roiBottomrightY - roiTopleftY + 1;

				// roiWidth를 4의 배수로 설정
				int q = roiWidth / 4;
				int r = roiWidth % 4;
				if (r != 0) {
					logger.info("[face:{}] Width({}) is not multiple of 4. So Width will be modified", deviceId,
							roiWidth);
					roiWidth = q * 4;
				}

				/*
				 * 임시코드: 현재 HbInno engine이 FullHD 만을 지원하므로 ROI가 full HD 보다 큰 경우
				 * 강제로 Full HD로 제안한다.
				 */
				// if(roiWidth > 1920) roiWidth = 1920;
				// if(roiHeight > 1080) roiHeight = 1080;

				/*
				 * ROI 설정을 수행한다
				 */
				// 0 : live , 1: search
				logger.info("[face:{}] ROI will be defined, device Id = {}:  x = {}, y = {}, width = {}, height = {}",
						deviceId, deviceId, roiTopleftX, roiTopleftY, roiWidth, roiHeight);
				getTriumiLiveAdapter().setROI(0, Integer.valueOf(this.deviceId), roiTopleftX, roiTopleftY, roiWidth,
						roiHeight);

			} else {
				/*
				 * ROI 설정 함수를 호출하지 않는다
				 */
				logger.info(
						"[face:{}] ROI not defined in DB. So original CCTV resolution(width={}, height={}) will be used for detection",
						deviceId, frm.getOriginWidth(), frm.getOriginHeight());

				/*
				 * 임시코드: 현재 HbInno engine이 FullHD 만을 지원하므로 ROI가 full HD 보다 큰 경우
				 * 강제로 Full HD로 제안한다.
				 */
				if (frm.getOriginWidth() > 1920 || frm.getOriginHeight() > 1080) {
					int topX = 960;
					int topY = 540;
					roiWidth = 1920;
					roiHeight = 1080;
					logger.info(
							"[face:{}] ROI not defined. But CCTV resolution is larger than Full HD. So ROI will be shrank into x={}, y = {}, width={}, height={}",
							deviceId, topX, topY, roiWidth, roiHeight);
					getTriumiLiveAdapter().setROI(0, Integer.valueOf(this.deviceId), topX, topY, roiWidth, roiHeight);
				} else {
					// orginal 해상도로 ROI를 바꾼다
					getTriumiLiveAdapter().setROI(0, Integer.valueOf(this.deviceId), 0, 0, frm.getOriginWidth(),
							frm.getOriginHeight());
				}
			}

			try {
				Thread.sleep(1000);
			} catch (Exception ex) {
				throw new RuntimeException("fail to sleep()");
			}

		}

		private boolean containsFeature(final byte[] detectedFeature, final Map<String, byte[]> cachedFeatures,
				final int thresholdScore) {

			if (cachedFeatures == null) {
				logger.warn("[cache:{}] recentFace is null", deviceId);
				return false;
			}

			byte[] cachedFeature = null;
			float score;
			int scoreInt;
			for (String faceId : cachedFeatures.keySet()) {
				cachedFeature = cachedFeatures.get(faceId);
				score = HBFRfacePro.HBFRVerify(detectedFeature, detectedFeature.length, cachedFeature,
						cachedFeature.length);
				scoreInt = (int) (score * 100.);
				logger.info("[cache:{}] for cache, verfy score = {}, threshold score = {}", deviceId, scoreInt,
						thresholdScore);
				if (scoreInt >= thresholdScore) {
					return true;
				}
			}

			return false;
		}

		private String getThumbBaseDir(String systemId, String deviceId) {

			if (StringUtils.isBlank(vasDir)) {
				throw new IllegalStateException("The environment variables VAS_DATA_DIR doen't be defined.");
			}

			String thumbbase = new StringBuilder().append(vasDir).append(thumbnailDirName).append("/").append(systemId)
					.append("/").append(deviceId).toString();
			return thumbbase;
		}

		private String getConcernImgBaseDir() {

			if (StringUtils.isBlank(vasDir)) {
				throw new IllegalStateException(
						"The environment variables VAS_DATA_DIR and VAS_HOME are not set properly.");
			}

			String concernFacebase = new StringBuilder().append(vasDir).toString();
			return concernFacebase;
		}

		private String getLiveThumbBaseDir(String systemId, String deviceId) {

			if (StringUtils.isBlank(liveDataDir)) {
				throw new IllegalStateException("The environment variables VAS_LIVE_DATA_DIR doen't be defined.");
			}

			String thumbbase = new StringBuilder().append(liveDataDir).append(thumbnailDirName).append("/")
					.append(systemId).append("/").append(deviceId).toString();
			return thumbbase;
		}

		private String getRelativeCncrnThumbnailPath(String path) {

			return path.substring(path.indexOf("/temp"));
		}

		private String getRelativeFaceThumbnailPath(String path) {

			return path.substring(path.indexOf(thumbnailDirName));
		}

		public long getNumDetectedFace() {
			return numDetectedFace;
		}

		public long getNumMatchedFace() {
			return numMatchedFace;
		}

		public long getNumEfficientFrame() {
			return numEfficientFrame;
		}

		public long getTotalElapasedTimeinMsec() {
			return totalElapasedTimeinMsec;
		}

		public long getThreadStartTime() {
			return threadStartTime;
		}

		private String Base64ConverToString(byte[] img) {
			String imgStr = Base64.encodeBase64String(img);

			return imgStr;

		}

		private byte[] getImageByte(String imageFilePath) {
			// open image
			Path path = Paths.get(imageFilePath);
			byte[] image = null;

			try {
				image = Files.readAllBytes(path);

				// image = imgPath.readAllBytes();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				return image;
			}

			// BufferedImage bufferedImage = null;
			// try {
			// bufferedImage = ImageIO.read(imgPath);
			// } catch (IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// // get DataBufferBytes from Raster
			// WritableRaster raster = bufferedImage .getRaster();
			// DataBufferByte data = (DataBufferByte) raster.getDataBuffer();
			//
			// return ( data.getData() );

		}

		public void resume() {
			resumeFlag.set(true);
		}

		public void pause() {
			pauseFlag.set(true);
		}

		public void breakIdleStateAndSetDevice(String deviceId) {
			this.deviceId = deviceId;
			breakIdleState.set(true);

		}

		public void setFREngieParameters() {

			// Hbinno params는 run() 내에서 수행해야 함
			updateHbinnoParamFlag.set(true);

			verificationoThreshold = frEngineConfig.getHbInnoParam().getVerificationThreshold();
			confidenceThreshold = frEngineConfig.getHbInnoParam().getConfidenceThreshold();
			verificationLowThreshold = frEngineConfig.getHbInnoParam().getVerificationLowThreshold();

			cctvResolutionEnable = frEngineConfig.isCctvResolutionEnable();
			maxMatchedFaces = frEngineConfig.getHbInnoParam().getMaxMatchedFace();
			fromLowMatchedface = frEngineConfig.getHbInnoParam().getFromLowMatchedface();
			cctvScreenshotWidth = frEngineConfig.getCctvScreenshotWidth();
			setScreenshotWidth(cctvScreenshotWidth);
			detecedFaceOriginalResolutionEnable = frEngineConfig.isDetectedFaceOrgResolutionEnable();
			int faceImageWidth = frEngineConfig.getHbInnoParam().getFaceImgWidth();
			// set 4's multiple
			int r = faceImageWidth % 4;
			int q = faceImageWidth / 4;
			if (r != 0) {
				faceImageWidth = q * 4;
			}
			detectedFaceImageWidth = faceImageWidth;
			if (detectedFaceImageWidth > MAX_FACE_IMAGE_WIDTH)
				detectedFaceImageWidth = MAX_FACE_IMAGE_WIDTH;

			/*
			 * cache 관련 설정
			 */
			// cache 사용 유/무
			cacheEnable = frEngineConfig.isCacheEnable();

			// cache score threshold
			cacheScoreThreshold = frEngineConfig.getCacheThreshold();

			// cache period
			cachePeriod = frEngineConfig.getCachePeroid();
			setRecentSeconds(cachePeriod);

			logger.debug("[update engine params:{}] Updated in Detection task local variables", deviceId);
			logger.debug("[update engine params:{}] Updated information ------", deviceId);
			logger.debug("[update engine params:{}] {}", deviceId, frEngineConfig);
			logger.debug("[update engine params:{}] verificationoThreshold = {}", deviceId, verificationoThreshold);
			logger.debug("[update engine params:{}] confidenceThreshold = {}", deviceId, confidenceThreshold);
			logger.debug("[update engine params:{}] cctvResolutionEnable = {}", deviceId, cctvResolutionEnable);
			logger.debug("[update engine params:{}] maxMatchedFaces = {}", deviceId, maxMatchedFaces);
			logger.debug("[update engine params:{}] cctvScreenshotWidth = {}", deviceId, cctvScreenshotWidth);
			logger.debug("[update engine params:{}] detecedFaceOriginalResolutionEnable = {}", deviceId,
					detecedFaceOriginalResolutionEnable);
			logger.debug("[update engine params:{}] detectedFaceImageWidth = {}", deviceId, detectedFaceImageWidth);
			logger.debug("[update engine params:{}] cacheEnable = {}", deviceId, cacheEnable);
			logger.debug("[update engine params:{}] cacheScoreThreshold = {}", deviceId, cacheScoreThreshold);
			logger.debug("[update engine params:{}] cachePeriod = {}", deviceId, cachePeriod);
			logger.debug("[update engine params:{}] verificationLowThreshold = {}", deviceId, verificationLowThreshold);
		}

		public void setFREngieParameters(FRConfig frConfig) {

			frEngineConfig.setParameters(frConfig);
			setFREngieParameters();

		}

		public void releasePasueState() {
			pauseFlag.set(false);
			resumeFlag.set(false);
		}

		private void setEngineParamterAndROI() {
			/*
			 * FR engine parameter 설정한다
			 */
			setFREngieParameters();

			/*
			 * device Id에 대한 ROI 정보를 DB에서 가져온다
			 */
			boolean isCctvRoi;
			List<DetectedRoi> cctvRoiList = getFaceDataManager().findCctvIdByRoiList(deviceId);
			// VAS_CCTV_SRVC_ROI_PT table 에 roi가 저장되어 있는지를 체크
			if ((cctvRoiList != null) && (cctvRoiList.size() == 4)) {
				isCctvRoi = true;
				for (DetectedRoi roi : cctvRoiList) {
					logger.debug("[update ROI:{}] ROI from DB: No ={}, X={}, Y={}", deviceId, roi.getPointNo(),
							roi.getPointX(), roi.getPointY());
				}

			} else {
				isCctvRoi = false;
			}
			setVideoFrameROI(isCctvRoi, cctvRoiList);

			/*
			 * 통계 변수 초기화
			 */
			this.numDetectedFace = 0;
			this.numMatchedFace = 0;
			this.numEfficientFrame = 0;
			this.totalElapasedTimeinMsec = 0;
			this.threadStartTime = System.currentTimeMillis();

			// check invalid frame count
			this.invalidFrameCount = 0;
			this.previousFrameTime = 0;
		}

		public void destroyDetectionTask() {
			destroyFlag.set(true);
		}

	}// end of DetectionTask class

}// end of xxxPullProcessor class