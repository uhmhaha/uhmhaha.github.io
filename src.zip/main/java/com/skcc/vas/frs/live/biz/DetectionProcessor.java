package com.skcc.vas.frs.live.biz;

import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import org.hibernate.validator.constraints.NotBlank;

import com.skcc.vas.frs.common.biz.model.AnalyticFace;

/**
 * @author
 * @since 2015-11-23
 */
@ThreadSafe
public interface DetectionProcessor {

	/**
	 * Gets the ID of the system (such as VMS or NVR) that contains the CCTV to
	 * which this detection processor is related.
	 *
	 * @return ID of the system
	 */
	String getSystemId();

	/**
	 * @param deviceId
	 * @param starts
	 * @see #startDetection(String)
	 * @see #stopDetection(String)
	 */
	@Deprecated
	void process(@NotBlank String deviceId, boolean starts);

	/**
	 * Makes the specified CCTV or device to start to detect faces
	 *
	 * @param deviceId
	 * @see #stopDetection
	 */
	boolean startDetection(@NotBlank String deviceId);

	/**
	 * Makes the specified CCTV or device to stop to detect faces
	 *
	 * @param deviceId
	 * @see #startDetection
	 */
	void stopDetection(@Nonnull String deviceId);

	// @TODO Change the return type to List<AnalyticFace> (2016-07-14, Sangmoon
	// Oh)
	/**
	 * Gets recently detected faces.
	 *
	 * @return
	 */
	@Nullable
	Set<AnalyticFace> getRecentlyDetectedFacesByDevice(String deviceId);

	void updateTargetFeatures();

	void updateTargetFeaturesWithoutTaskStop();

	boolean startDetectionAndRetry(@NotBlank String deviceId);

	void updateROI(String deviceId);

	void updateFREngineParameters();

	void updateFREngineParameters(String deviceId);

}
