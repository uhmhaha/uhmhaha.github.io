package com.skcc.vas.frs.live.biz;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.scheduling.annotation.Scheduled;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.util.base.BaseUtils;
import com.skcc.vas.frs.common.util.base.ThumbnailFormat;
import com.skcc.vas.frs.common.biz.model.AnalyticFace;
import com.skcc.vas.frs.live.biz.DetectionProcessor;
import com.skcc.vas.frs.common.db.service.FaceDataManager;

/**
 * @author
 * @since 2016-05-04
 */
public abstract class HbInnoDetectionProcessorBase implements DetectionProcessor {

	public static final String SERVICE_TYPE_NAME = "LIVE_FACE_RECOG";

	/**
	 * The max for the number of frames to skip after a frame is processed in
	 * stream handler
	 *
	 */
	public static final int FRAME_SKIPS_MAX = 120;

	public static final int RECENT_SECONDS_DEFAULT = 3;

	public static final int FILTER_OUT_THRESHOLD_MIN = 80;

	public static final int FILTER_OUT_THRESHOLD_MAX = 98;

	public static final int FILTER_OUT_THRESHOLD_DEFAULT = 90;

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private String systemId;

	@ManagedAttribute(description = "Gets the ID of the system that contains the CCTV to which this detection processor is related.")
	@Override
	public String getSystemId() {
		return this.systemId;
	}

	@Nonnull
	private HbInnoAdapter hbInnoAdapter;

	protected HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	@Nonnull
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	/**
	 * The number of frames to skip after a frame is processed in stream handler
	 *
	 * @see #FRAME_SKIPS_MAX
	 * @see #getSkips()
	 * @see #setSkips(int)
	 * @see <code>vas.hbInnoDetectionProcessor.skips</code>
	 */
	@Min(0)
	@Max(FRAME_SKIPS_MAX)
	private volatile int skips;

	/**
	 * @return
	 *
	 * @see #setSkips(int)
	 */
	@ManagedAttribute(description = "The number of frames to skip after a frame is processed.")
	public int getSkips() {
		return this.skips;
	}

	/**
	 * @param num
	 *
	 * @see #getSkips()
	 */
	@ManagedAttribute
	public void setSkips(@Min(0) @Max(FRAME_SKIPS_MAX) int num) {
		if (num < 0) {
			this.logger.warn("The specified number({}) is less than 0. The frame skips would be set to 0", num);
			this.skips = 0;
		} else if (num > FRAME_SKIPS_MAX) {
			this.logger.warn(
					"The specified number({}) is greater than max value({}). The frame skips would be set to max", num,
					FRAME_SKIPS_MAX);
			this.skips = FRAME_SKIPS_MAX;
		} else {
			this.skips = num;
			this.logger.info("Set frame skips to {}", num);
		}
	}

	private ThreadLocal<Integer> skipCounter;

	public ThreadLocal<Integer> getSkipCounter() {
		return this.skipCounter;
	}

	private volatile ThumbnailFormat screenshotFormat;

	protected ThumbnailFormat getScreenshotFormat() {
		return this.screenshotFormat;
	}

	// @NOTE Add max and min for screenshot width and height.
	@ManagedAttribute(description = "The width of screenshot(frame image) file.")
	public int getScreenshotWidth() {
		return this.screenshotFormat.getWidth();
	}

	@ManagedAttribute
	public void setScreenshotWidth(@Min(1) int width) {
		Validate.isTrue(width > 0, "Screenshot width should be positive.");
		this.screenshotFormat = new ThumbnailFormat(width, this.screenshotFormat.getHeight());
	}

	private String screenshotBase;

	/**
	 * The base directory where the frame images(screenshots) from where the
	 * faces are detected would be saved. Normally the value would ends with
	 * '/'(slash).
	 * 
	 * @return
	 */
	@ManagedAttribute(currencyTimeLimit = 100000)
	@NotBlank
	public String getScreenshotBaseDir() {
		return this.screenshotBase;
	}

	private volatile boolean isDestroying = false;

	protected boolean isDestroying() {
		return this.isDestroying;
	}

	private Date startedAt;

	/**
	 * @return the time when this instance start to service.
	 */
	@ManagedAttribute(currencyTimeLimit = 100000)
	@Nonnull
	public Date getStartTime() {
		return this.startedAt;
	}

	@ManagedAttribute
	@Nonnull
	public Date getCurrentTime() {
		return new java.util.Date();
	}

	protected volatile AtomicLong processedFramesNum = new AtomicLong(0);

	@ManagedAttribute
	public long getNumberOfProcessedFrames() {
		return this.processedFramesNum.get();
	}

	@ManagedAttribute
	public double getNumberOfProcessedFramesPerSecond() {

		long msec = System.currentTimeMillis() - this.startedAt.getTime();
		if (msec != 0) {
			BigDecimal cnt = BigDecimal.valueOf(this.getNumberOfProcessedFrames()).divide(BigDecimal.valueOf(msec), 5,
					BigDecimal.ROUND_HALF_UP);
			return cnt.doubleValue() * 1000;
		} else {
			return 0.0;
		}
	}

	protected volatile AtomicLong foundFacesNum = new AtomicLong(0);

	/**
	 * @return the number of faces detected so far from this instance.
	 */
	@ManagedAttribute
	public long getNumberOfFoundFaces() {
		return this.foundFacesNum.get();
	}

	protected volatile AtomicLong exceptionsNum = new AtomicLong(0);

	@ManagedAttribute(description = "The number of exceptions which are passed by(chached but not rethrown).")
	public long getNumberOfExceptions() {
		return this.exceptionsNum.get();
	}

	@Min(0)
	private int recentSeconds = RECENT_SECONDS_DEFAULT;

	@ManagedAttribute
	public int getRecentSeconds() {
		return this.recentSeconds;
	}

	public void setRecentSeconds(@Min(0) int num) {
		Validate.isTrue(num > 0, "The value should be positive.");
		this.recentSeconds = num;
	}

	private volatile boolean statsLogEnabled = false;

	@ManagedOperation(description = "Enable or disable statistics logging.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "enabled", description = "To enalbe statistics logging, set true"), })
	public void setStatsLogEnabled(final boolean enabled) {
		this.statsLogEnabled = enabled;
	}

	public void logStats() {
		if (!this.statsLogEnabled)
			return;

		this.logger
				.info("The TriumiHbInnoDetectionProcessor is running. - processed frames: {}, processed frames/sec: {}, found faces: {}, occurred exceptions: {}, started at: {}",
						this.processedFramesNum.get(), this.getNumberOfProcessedFramesPerSecond(),
						this.foundFacesNum.get(), this.exceptionsNum.get(), this.getStartTime());
	}

	private final Set<String> liveDeviceIds = new TreeSet<String>();

	// @ManagedAttribute @Nonnull
	public Set<String> getLiveDeviceIds() {
		return this.liveDeviceIds;
	}

	/**
	 * Recently detected face by device
	 */
	protected final ConcurrentMap<String, Pair<? extends List<AnalyticFace>, ? extends List<byte[]>>> recentFaces = new ConcurrentHashMap<String, Pair<? extends List<AnalyticFace>, ? extends List<byte[]>>>();

	@Nullable
	@Override
	public Set<AnalyticFace> getRecentlyDetectedFacesByDevice(String devId) {
		Pair<? extends List<AnalyticFace>, ? extends List<byte[]>> faces = recentFaces.get(devId);
		if (faces == null)
			return null;
		else
			return new HashSet<AnalyticFace>(faces.getLeft());
	}

	@Nonnull
	protected Map<String, byte[]> getRecentFaceFeaturesByDevice(@NotBlank String deviceId) {
		Validate.isTrue(StringUtils.isNotBlank(deviceId), "The device ID should be specified.");

		Set<AnalyticFace> faces = this.getRecentlyDetectedFacesByDevice(deviceId);
		if (faces == null)
			return new HashMap<String, byte[]>(0);
		else {
			final Map<String, byte[]> features = new HashMap<String, byte[]>(faces.size());
			for (AnalyticFace face : faces)
				features.put(face.getId(), face.getFeature());
			return features;
		}
	}

	/**
	 * Gets the number of recently detected faces in cache of each device.
	 *
	 * @return
	 */
	@ManagedAttribute(description = "Gets the number of recently detected faces in cache of each device.")
	public Map<String, Integer> getNumberOfRecentlyDetectedFacesByDevice() {
		Map<String, Integer> numbers = new HashMap<String, Integer>();

		for (Map.Entry<String, Pair<? extends List<AnalyticFace>, ? extends List<byte[]>>> entry : this.recentFaces
				.entrySet()) {
			numbers.put(entry.getKey(), entry.getValue().getLeft().size());
		}

		return numbers;
	}

	protected void addRecentFace(@NotBlank final String devId, @Nonnull final AnalyticFace face) {
		new CacheUpdateTask(devId, face).start();
	}

	@Scheduled(fixedDelayString = "8000", initialDelayString = "8000")
	public void removeOldFacesFromCache() {

		// this.logger.debug("[cache]Starting removal of detected faces in cache at {}.",
		// new java.util.Date());
		Date currentDate = new java.util.Date();

		String time = BaseUtils.formatToYear2MillisecString(DateUtils.addSeconds(currentDate,
				-1 * this.getRecentSeconds()));

		long time2 = Long.valueOf(time);
		Set<String> devIds = this.recentFaces.keySet();
		List<AnalyticFace> cache = null;
		Iterator<AnalyticFace> cacheItrt = null;
		AnalyticFace face = null;
		int facesNum = 0;
		int removedNum = 0;
		for (String devId : devIds) {
			cache = this.recentFaces.get(devId).getLeft();
			facesNum = cache.size();
			removedNum = 0;

			// @TODO Change to use reentrant lock instead of intrinsic monitor
			// (Sangmoon Oh, 2016-08-09)
			synchronized (cache) {
				cacheItrt = cache.iterator();
				while (cacheItrt.hasNext()) {
					face = cacheItrt.next();
					if (face.getTimestamp() < time2) {
						this.logger
								.trace("[cache]Removing a face from the cache. face Id: {}, current time:[{}] cache-out time:[{}], face id's time:[{}]",
										face.getId(), BaseUtils.formatToYear2MillisecString(currentDate), time2,
										face.getTimestamp());
						cacheItrt.remove();
						removedNum++;
					}
				}
			}
			if (removedNum != 0) {
				this.logger.debug("[cache] Cache updated. device Id:{}, # of removed: {}, # of remains: {}", devId,
						removedNum, facesNum - removedNum);
			}
		}// for() loop

		// this.logger.debug("[cache] Completed removal of recently detected faces cache");
		// this.logStats();
	}

	@Max(FILTER_OUT_THRESHOLD_MAX)
	@Min(FILTER_OUT_THRESHOLD_MIN)
	private int filterOutThreshold = FILTER_OUT_THRESHOLD_DEFAULT;

	@ManagedAttribute(description = "Gets the threshold score to filter out recently detected faces.")
	public int getFilterOutThreshold() {
		return this.filterOutThreshold;
	}

	@ManagedOperation(description = "Set the threshold score to filter out recently detected faces.")
	@ManagedOperationParameters({ @ManagedOperationParameter(name = "threshold", description = "threshold should be between 80 ~ 98"), })
	public void setFilterOutThreshold(@Max(FILTER_OUT_THRESHOLD_MAX) @Min(FILTER_OUT_THRESHOLD_MIN) int threshold) {
		if (threshold > FILTER_OUT_THRESHOLD_MAX)
			this.filterOutThreshold = FILTER_OUT_THRESHOLD_MAX;
		else if (threshold < FILTER_OUT_THRESHOLD_MIN)
			this.filterOutThreshold = FILTER_OUT_THRESHOLD_MIN;
		else
			this.filterOutThreshold = threshold;
	}

	/**
	 * @param dataDir
	 * @param hbInnoAdapter
	 * @param faceDataManager
	 * @param skips
	 */
	public HbInnoDetectionProcessorBase(@NotBlank String systemId, @NotBlank String dataDir,
			@Nonnull HbInnoAdapter hbInnoAdapter, @Nonnull FaceDataManager faceDataManager,
			@Min(0) @Max(FRAME_SKIPS_MAX) int skips, @NotBlank String screenShotDirName) {

		Validate.isTrue(StringUtils.isNotBlank(systemId), "The system ID should be specified.");
		Validate.isTrue(StringUtils.isNotBlank(dataDir),
				"The db variables 'vas.dataDir' are not set properly.");
		Validate.isTrue(hbInnoAdapter != null, "The VA engine should be provided.");
		Validate.isTrue(faceDataManager != null, "The data accessor should be provided.");
		Validate.inclusiveBetween(0, FRAME_SKIPS_MAX, skips);

		// super(systemId, dataDir, triumiLiveAdapter, hbInnoAdapter,
		// faceDataManager, skips, vmsAddr, vmsPort, vmsUserId, vmsPasswd);
		// screenshot관련 하여 문제 발생시 Exception 발생

		String path = new StringBuilder().append(dataDir).toString();
		File file = new File(path);

		if (!file.exists()) {
			logger.info("Incorrect vas.dataDir path =[{}]. please check the vas.dataDir Path", path);
			throw new RuntimeException("Incorrect vas.dataDir path = [" + path
					+ "]. please check the vas.dataDir Path in VAS_CONF_NODE TABLE");
		}

		this.systemId = systemId;
		this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.screenshotBase = dataDir + screenShotDirName + "/";

		this.setSkips(skips);
		if (this.getSkips() > 0) {
			this.skipCounter = new ThreadLocal<Integer>() {
				@Override
				protected Integer initialValue() {
					return getSkips();
				}
			};
		} else {
			this.skipCounter = null;
			this.logger.info("The skip number for stream handler is set to 0.");
		}

		this.screenshotFormat = new ThumbnailFormat(ThumbnailFormat.THUMBNAIL_WIDTH_DEFAULT,
				ThumbnailFormat.THUMBNAIL_HEIGHT_DEFAULT);
		this.startedAt = new Date();
	}

	private final String[] dateFormatChars = new String[] { "-", " ", ":" };
	private final String[] emptyChars = new String[] { "", "", "" };

	/**
	 * This method is Spring framework's destruction callback
	 *
	 * @throws IllegalStateException
	 */
	public void destroy() {

		// @TODO How to remove the thread local set to skipCounter when
		// destroying
		this.isDestroying = true;

		// @TODO Clear or remove collection type member fields. (2016-08-12,
		// Sangmoon Oh)
	}

	class CacheUpdateTask extends Thread {

		private final String devId;
		private final AnalyticFace face;

		CacheUpdateTask(@NotBlank final String devId, @Nonnull final AnalyticFace face) {
			this.devId = devId;
			this.face = face;
		}

		@Override
		public void run() {
			logger.debug("[cache] Adding a new detected face into cache. deviceId = {}", devId);
			final int capa = getRecentSeconds() * 2;
			recentFaces.putIfAbsent(devId, Pair.of(new ArrayList<AnalyticFace>(capa), new ArrayList<byte[]>(capa)));
			final List<AnalyticFace> cache = recentFaces.get(devId).getLeft();

			synchronized (cache) {
				cache.add(face);
			}
		}
	}

}
