package com.skcc.vas.frs.live.biz;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

/**
 * @author
 * @since 2016-07-12
 *
 */
@ThreadSafe
public interface ListenableDetectionProcessor extends DetectionProcessor {

	void addListener(@Nonnull DetectionListener<?> listener);

}
