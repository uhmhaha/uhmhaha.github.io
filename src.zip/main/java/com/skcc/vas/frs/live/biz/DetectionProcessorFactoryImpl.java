package com.skcc.vas.frs.live.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;

import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.skcc.vas.frs.common.biz.service.VasConfigService;

/**
 * @author
 * @since 2016-06-17
 *
 */
@ManagedResource(objectName = "vas:type=bean,name=detectionProcessorFactory", description = "Make it enable to manage multiple detection processors in a system.")
@ThreadSafe
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public class DetectionProcessorFactoryImpl implements DetectionProcessorFactory {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private final Map<String, DetectionProcessor> processors = new HashMap<String, DetectionProcessor>();

	private VasConfigService configService;

	public DetectionProcessorFactoryImpl() {
	}

	/**
	 * @param processors
	 *            will be shallow-copied, not referenced
	 */
	public DetectionProcessorFactoryImpl(@Nullable List<DetectionProcessor> processors) {
		if (processors != null) {
			for (DetectionProcessor processor : processors) {
				this.processors.put(processor.getSystemId(), processor);
			}
		}

		this.logger.info("Initially {} detection processor(s) is/are registered.", this.processors.size());
	}

	@Override
	public DetectionProcessor getDetectionProcessor(@NotBlank String systemId) {
		return this.processors.get(systemId);
	}

	public void addDetectionProcessor(@NotBlank String systemId, @Nonnull DetectionProcessor processor) {
		this.processors.put(systemId, processor);
	}

	public void removeDetectionProcessor(@NotBlank String systemId) {
		this.processors.remove(systemId);
	}

	public boolean containsDetectionProcessor(@NotBlank String systemId) {
		return this.processors.containsKey(systemId);
	}

	@ManagedAttribute(description = "Gets the number of detector processors in this factory")
	public int getNumberOfDetectionProcessors() {
		return this.processors.size();
	}

	/**
	 * @return
	 */
	@Override
	@ManagedAttribute(description = "Gets all the system IDs of detector processors in this factory")
	public String[] getSystemIdsOfDetectionProcessors() {
		Set<String> keys = this.processors.keySet();

		return keys.toArray(new String[keys.size()]);
	}

}
