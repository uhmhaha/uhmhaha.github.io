package com.skcc.vas.frs.interfaces.activemq.publisher;

import java.util.List;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.akka.db.repository.NodeMapper;
import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqBroker;
import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqTopic;
import com.skcc.vas.frs.interfaces.activemq.repository.ActiveMqConfigMapper;


public class ActiveMqPubConfig {
	
	public static final String COMM_TYPE_TOPIC = "COMM" ;
	
	public static final String NODE_TYPE_TOPIC = "NODE";
	
	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private int nodeId;
	
	private String detectedFaceTopic;

	private String brokerUrl;
	
	private String brokerUrlForCommonTopic;
	
	private NodeMapper nodeMapper;
	
	public NodeMapper getNodeMapper() { return nodeMapper; }
	
	private ActiveMqConfigMapper activeMqConfigMapper;

	public ActiveMqConfigMapper getActiveMqConfigMapper() { return activeMqConfigMapper; }

	public ActiveMqPubConfig(@Nonnull NodeMapper nodeMapper,@Nonnull ActiveMqConfigMapper activeMqConfigMapper, @Nonnull int nodeId){

		Validate.isTrue(nodeMapper != null, "nodeMapper instance should be provided.");
		Validate.isTrue(activeMqConfigMapper != null, "activeMqConfigMapper instance should be provided.");
		
		this.nodeMapper = nodeMapper;
		this.activeMqConfigMapper = activeMqConfigMapper;
		this.nodeId = nodeId;
		
		List<ActiveMqBroker> brokerList = activeMqConfigMapper.selectBrokers(nodeId, NODE_TYPE_TOPIC);
		if(brokerList.isEmpty()) {
			throw new IllegalStateException("Can't get broker list for node id = [" + nodeId +"]");
		}
		setBrokerUrlWithFailOver(brokerList, NODE_TYPE_TOPIC);
		
		List<ActiveMqBroker> brokerForCommonTopicList = brokerList;
		if(brokerForCommonTopicList.isEmpty()) {
			throw new IllegalStateException("Can't get common broker list for node id = [" + nodeId +"]");
		}
		setBrokerUrlWithFailOver(brokerForCommonTopicList, COMM_TYPE_TOPIC);
		
		List<ActiveMqTopic> nodeTopics = activeMqConfigMapper.selectTopics(nodeId,NODE_TYPE_TOPIC);
		if(nodeTopics.isEmpty()) {
			throw new IllegalStateException("Can't get node topic list for node id = [" + nodeId +"]");
		}
		setTopics(nodeTopics, NODE_TYPE_TOPIC);
		
	}
	
	public String getDetectedFaceTopic() {
		return detectedFaceTopic;
	}

	public void setDetectedFaceTopic(String detectedFaceTopic) {
		this.detectedFaceTopic = detectedFaceTopic;
	}

	public String getBrokerUrl() {
		return brokerUrl;
	}

	public void setBrokerUrl(String brokerUrl) {
		this.brokerUrl = brokerUrl;
	}
	
	public String getBrokerUrlForCommonTopic() {
		return brokerUrlForCommonTopic;
	}

	public void setBrokerUrlForCommonTopic(String brokerUrlForCommonTopic) {
		this.brokerUrlForCommonTopic = brokerUrlForCommonTopic;
	}

	private void setBrokerUrlWithFailOver(List<ActiveMqBroker> brokerList, String topicType ){
		
		Validate.isTrue( brokerList != null, "++ There is no brokers!! You must insert brokers for this nodeId in table: VAS_IF_MQ!!");
		
		StringBuffer brokerUrlBuffer = new StringBuffer().append("failover:(");
		
		for(ActiveMqBroker broker: brokerList){
			brokerUrlBuffer.append("nio://");
			brokerUrlBuffer.append(broker.getIpAddr());
			brokerUrlBuffer.append(":");
			brokerUrlBuffer.append(broker.getPort());
			brokerUrlBuffer.append(",");
		}
		
		brokerUrlBuffer.deleteCharAt(brokerUrlBuffer.length()-1);
		brokerUrlBuffer.append(")?randomize=true");
		
		if(COMM_TYPE_TOPIC.equals(topicType)){
			this.brokerUrl = brokerUrlBuffer.toString();
		} else if(NODE_TYPE_TOPIC.equals(topicType)){
			this.brokerUrlForCommonTopic = brokerUrlBuffer.toString();
		}
		
	}
	
	private void setTopics(List<ActiveMqTopic> topics, String topicType){
		//媛곴컖 �떒 �븯�굹留� �엳�뼱�빞 �븿
		Validate.isTrue( topics != null, "++ There is no topics!! You must insert topics for this nodeId in table: VAS_IF_MQ_TOPIC!!");

		if(NODE_TYPE_TOPIC.equals(topicType)){
			for(ActiveMqTopic activeMqTopic: topics){
				this.detectedFaceTopic = activeMqTopic.getTopicName();
				break;
			}
		}
	}
}
