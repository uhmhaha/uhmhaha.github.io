package com.skcc.vas.frs.interfaces.activemq.model;

public class ActiveMqBroker {
	
	private int brokerId;
	
	private String brokerType;
	
	private String systemId;
	
	private String mQgroupId;
	
	private String ipAddr;
	
	private String port;

	public int getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}

	public String getBrokerType() {
		return brokerType;
	}

	public void setBrokerType(String brokerType) {
		this.brokerType = brokerType;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getmQgroupId() {
		return mQgroupId;
	}

	public void setmQgroupId(String mQgroupId) {
		this.mQgroupId = mQgroupId;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "ActiveMqBroker [brokerId=" + brokerId + ", brokerType="
				+ brokerType + ", systemId=" + systemId + ", groupId="
				+ mQgroupId + ", ipAddr=" + ipAddr + ", port=" + port + "]";
	}
}
