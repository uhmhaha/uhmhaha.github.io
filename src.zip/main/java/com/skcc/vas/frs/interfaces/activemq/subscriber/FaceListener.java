package com.skcc.vas.frs.interfaces.activemq.subscriber;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Nonnull;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;
import com.skcc.vas.frs.matching.biz.MatchingTaskManager;

public class FaceListener implements MessageListener {
	private static final Logger logger = LoggerFactory.getLogger(FaceListener.class);

	@Nonnull private final MatchingTaskManager matchingTaskManager;
	
	private long totalMessageCount = 0;
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	protected MatchingTaskManager getMatchingTaskManager() {
		return matchingTaskManager;
	}

	public FaceListener(MatchingTaskManager matchingTaskManager){
		//System.setProperty("org.apache.activemq.SERIALIZABLE_PACKAGES", "java.lang,javax.security,java.util,org.apache.activemq,com");	
		this.matchingTaskManager = matchingTaskManager;
	}

	@Override
	public void onMessage(Message msg) {
		DetectedFaceMessage dfm = null;

		try {
			dfm = (DetectedFaceMessage)((ObjectMessage)msg).getObject();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			logger.error("DetectedFaceMessage Exception: [{}]", e.toString());
			return;
		}

		if(dfm == null) {
			logger.error("DetectedFaceMessage is null.");
			return;
		}
		
		totalMessageCount++;
		logger.info("++ << total message count >> : [{}] current time [{}]", totalMessageCount, dateFormat.format(new Date()));
		logger.info("==> CCTV ID of Received DetectedFaceMessage : [{}]", dfm.getCctvId());

		getMatchingTaskManager().sendMatchingNodeJob(dfm);
	}	
}
