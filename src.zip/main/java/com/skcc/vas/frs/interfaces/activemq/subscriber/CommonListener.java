package com.skcc.vas.frs.interfaces.activemq.subscriber;

import javax.annotation.Nonnull;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.interfaces.activemq.model.ConcernedFaceUpdateMessage;
import com.skcc.vas.frs.matching.biz.CncrnFaceManager;

public class CommonListener implements MessageListener {
	private static final Logger logger = LoggerFactory.getLogger(CommonListener.class);
	
	private int nodeId;
	
	@Nonnull private final CncrnFaceManager cncrnFaceManager;

	protected CncrnFaceManager getCncrnFaceManager() {
		return cncrnFaceManager;
	}

	public CommonListener(CncrnFaceManager cncrnFaceManager, @Nonnull int nodeId){		
		this.cncrnFaceManager = cncrnFaceManager;
		this.nodeId = nodeId;
	}

	@Override
	public void onMessage(Message msg) {
		ConcernedFaceUpdateMessage cfum = null;
		try {
			cfum = (ConcernedFaceUpdateMessage)((ObjectMessage)msg).getObject();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			logger.error("ConcernedFaceUpdateMessage Exception: [{}]", e.toString());
			return;
		}
		
		if(cfum == null) {
			logger.error("ConcernedFaceUpdateMessage is null");
			return;
		}
		
		logger.info("==> Received ConcernedFaceUpdateMessage : [{}]", cfum);
	
		
		String[] nodeidlist = cfum.getMatchNodeIdList();
		for(String nodeID : nodeidlist) {
			if (Integer.parseInt(nodeID) == nodeId) {
				getCncrnFaceManager().updateCncrnFace(cfum, nodeId);
				return;
			}
		}
		logger.info("==> This is a node with no CncrnFace information updates.");
	}

}
