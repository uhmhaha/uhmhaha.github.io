package com.skcc.vas.frs.interfaces.activemq.model;

public class ActiveMqTopic {

	private int brokerId;
	
	private int nodeId;
	
	private String topicName;

	public int getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	@Override
	public String toString() {
		return "ActiveMqTopic [brokerId=" + brokerId + ", nodeId=" + nodeId
				+ ", topicName=" + topicName + "]";
	}
}
