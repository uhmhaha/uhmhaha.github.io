package com.skcc.vas.frs.interfaces.activemq.model;

import java.io.Serializable;
import java.util.Arrays;

public class ConcernedFaceUpdateMessage implements Serializable{
	
	private static final long serialVersionUID = -3433626634773496579L;
	
	public static final String UPDATE_FEATURE_COMMAND = "UPDATE_TARGER_FEATURE";
	
	public static final String INSERT_FEATURES = "INSERT_FEATURES";
	public static final String UPDATE_FEATURES = "UPDATE_FEATURES";
	public static final String DELETE_FEATURES = "DELETE_FEATURES";
	
	private String command;
	
	private String reason;
	
	private String[] matchNodeIdList;

	public String getCommand() {
		return command;
	}

	public ConcernedFaceUpdateMessage setCommand(String command) {
		this.command = command;
		return this;
	}

	public String getReason() {
		return reason;
	}

	public ConcernedFaceUpdateMessage setReason(String reason) {
		this.reason = reason;
		return this;
	}

	public String[] getMatchNodeIdList() {
		return matchNodeIdList;
	}

	public ConcernedFaceUpdateMessage setMatchNodeIdList(String[] matchNodeIdList) {
		this.matchNodeIdList = matchNodeIdList;
		return this;
	}

	@Override
	public String toString() {
		return "ConcernedFaceUpdateMessage [command=" + command + ", reason="
				+ reason + ", matchNodeIdList="
				+ Arrays.toString(matchNodeIdList) + "]";
	}
}
