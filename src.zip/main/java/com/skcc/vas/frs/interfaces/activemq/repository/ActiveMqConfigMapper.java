package com.skcc.vas.frs.interfaces.activemq.repository;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqBroker;
import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqTopic;

@Repository("activeMqConfigMapper")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@ParametersAreNonnullByDefault
public interface ActiveMqConfigMapper {
	
	List<ActiveMqBroker> selectBrokers(@Param("nodeId")int nodeId, @Param("topicType")String topicType);
	
	List<ActiveMqBroker> selectCommonTopicBrokers(@Param("topicType")String topicType);	
	
	List<ActiveMqTopic> selectTopics(@Param("nodeId")int nodeId, @Param("topicType")String topicType);

}
