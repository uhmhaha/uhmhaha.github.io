package com.skcc.vas.frs.interfaces.activemq.subscriber;

import java.util.List;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.LoggerFactory;

import com.skcc.vas.frs.akka.db.repository.NodeMapper;
import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqBroker;
import com.skcc.vas.frs.interfaces.activemq.model.ActiveMqTopic;
import com.skcc.vas.frs.interfaces.activemq.repository.ActiveMqConfigMapper;

public class ActiveMqSubConfig {
	
	public static final String COMM_TYPE_TOPIC = "COMM" ;
	
	public static final String NODE_TYPE_TOPIC = "NODE";
	
	private int nodeId;
	
	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private String detectedFaceTopic;
	
	private String brokerUrl_1;
	private String brokerUrl_2;		

	private String brokerUrlForCommonTopic_1;
	private String brokerUrlForCommonTopic_2;
	
	private NodeMapper nodeMapper;
	
	public NodeMapper getNodeMapper() { return nodeMapper; }
	
	private ActiveMqConfigMapper activeMqConfigMapper;

	public ActiveMqConfigMapper getActiveMqConfigMapper() { return activeMqConfigMapper; }

	public ActiveMqSubConfig(@Nonnull ActiveMqConfigMapper activeMqConfigMapper, @Nonnull int nodeId){

		Validate.isTrue(activeMqConfigMapper != null, "activeMqConfigMapper instance should be provided.");
		
		this.activeMqConfigMapper = activeMqConfigMapper;
		
		this.nodeId = nodeId;

		List<ActiveMqBroker> brokerList = activeMqConfigMapper.selectBrokers(nodeId, NODE_TYPE_TOPIC);
		setBrokerUrl(brokerList, NODE_TYPE_TOPIC);
		
		List<ActiveMqBroker> brokerForCommonTopicList = brokerList;
		setBrokerUrl(brokerForCommonTopicList, COMM_TYPE_TOPIC);
		
		List<ActiveMqTopic> nodeTopics = activeMqConfigMapper.selectTopics(nodeId,NODE_TYPE_TOPIC);
		setTopics(nodeTopics, NODE_TYPE_TOPIC);
	}
	
	// DetectedFaceTopic
	public String getDetectedFaceTopic() {
		return detectedFaceTopic;
	}
	public void setDetectedFaceTopic(String detectedFaceTopic) {
		this.detectedFaceTopic = detectedFaceTopic;
	}

	// BrokerURL
	public String getBrokerUrl_1() {
		return brokerUrl_1;
	}

	public void setBrokerUrl_1(String brokerUrl_1) {
		this.brokerUrl_1 = brokerUrl_1;
	}

	public String getBrokerUrl_2() {
		return brokerUrl_2;
	}

	public void setBrokerUrl_2(String brokerUrl_2) {
		this.brokerUrl_2 = brokerUrl_2;
	}
	
	public String getBrokerUrlForCommonTopic_1() {
		return brokerUrlForCommonTopic_1;
	}
	
	public String getBrokerUrlForCommonTopic_2() {
		return brokerUrlForCommonTopic_2;
	}

	public void setBrokerUrlForCommonTopic_1(String brokerUrlForCommonTopic_1) {
		this.brokerUrlForCommonTopic_1 = brokerUrlForCommonTopic_1;
	}
	
	public void setBrokerUrlForCommonTopic_2(String brokerUrlForCommonTopic_2) {
		this.brokerUrlForCommonTopic_2 = brokerUrlForCommonTopic_2;
	}
	
	private void setBrokerUrl(List<ActiveMqBroker> brokerList, String topicType){
		//媛곴컖 �떒 �븯�굹留� �엳�뼱�빞 �븿
		Validate.isTrue( brokerList.size() > 1, "++ Brokers must be at least two. You must insert brokers for this nodeId in table: VAS_IF_MQ!!");
		
		if(COMM_TYPE_TOPIC.equals(topicType)){
			for(ActiveMqBroker activeMqBroker: brokerList){
				if (StringUtils.isEmpty(this.brokerUrl_1)) {
					this.brokerUrl_1 = setBrokerUrlWithFailOver(activeMqBroker, COMM_TYPE_TOPIC);					
					continue;
				}
				this.brokerUrl_2 = setBrokerUrlWithFailOver(activeMqBroker, COMM_TYPE_TOPIC);
				break;
			}
		} else if(NODE_TYPE_TOPIC.equals(topicType)){
			for(ActiveMqBroker activeMqBroker: brokerList){
				if (StringUtils.isEmpty(this.brokerUrlForCommonTopic_1)) {
					this.brokerUrlForCommonTopic_1 = setBrokerUrlWithFailOver(activeMqBroker, COMM_TYPE_TOPIC);
					continue;
				}
				this.brokerUrlForCommonTopic_2 = setBrokerUrlWithFailOver(activeMqBroker, COMM_TYPE_TOPIC);
				break;
			}
		}
	}
	
	private String setBrokerUrlWithFailOver(ActiveMqBroker broker, String topicType) {
		StringBuffer brokerUrlBuffer = new StringBuffer().append("failover:(");
		
		brokerUrlBuffer.append("nio://");
		brokerUrlBuffer.append(broker.getIpAddr());
		brokerUrlBuffer.append(":");
		brokerUrlBuffer.append(broker.getPort());
		brokerUrlBuffer.append(")");		
		//brokerUrlBuffer.deleteCharAt(brokerUrlBuffer.length()-1);

		return brokerUrlBuffer.toString();
	}
	
	private void setTopics(List<ActiveMqTopic> topics, String topicType){
		//媛곴컖 �떒 �븯�굹留� �엳�뼱�빞 �븿
		Validate.isTrue( topics != null, "++ There is no topics!! You must insert topics for this nodeId in table: VAS_IF_MQ_TOPIC!!");
		
		if(NODE_TYPE_TOPIC.equals(topicType)){
			for(ActiveMqTopic activeMqTopic: topics){
				this.detectedFaceTopic = activeMqTopic.getTopicName();
				break;
			}
		}
	}
}
