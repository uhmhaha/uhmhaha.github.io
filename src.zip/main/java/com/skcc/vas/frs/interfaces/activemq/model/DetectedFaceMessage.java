package com.skcc.vas.frs.interfaces.activemq.model;

import java.io.Serializable;
import java.util.Arrays;

public class DetectedFaceMessage implements Serializable{
	
	private static final long serialVersionUID = -3433626634773496577L;
	
	private String id;
	
	private String systemId;
	
	private String cctvId;

	private String srvcType;

	private String imgFile;

	private int imgWidth;

	private int imgHeight;

	private int imgX;

	private int imgY;

    private byte[] feature;
    
    private String frmFile;

    private int frmWidth;

    private int frmHeight;
    
    private String absoluteImagePath;
    
    private byte[] faceBinary;
    
    private int maxMatchedFace;
    
    private float verificationThreshold;
    
    private float verificationLowThreshold;
    
	private String frmTime;
	
	private String jobId;
	
	private int totalDBMsgCount = -1;
	
	private int currentDBMsgCount;

	public String getId() {
		return id;
	}

	public DetectedFaceMessage setId(String id) {
		this.id = id;
		return this;
	}

	public String getSystemId() {
		return systemId;
	}

	public DetectedFaceMessage setSystemId(String systemId) {
		this.systemId = systemId;
		return this;
	}

	public String getCctvId() {
		return cctvId;
	}

	public DetectedFaceMessage setCctvId(String cctvId) {
		this.cctvId = cctvId;
		return this;
	}

	public String getSrvcType() {
		return srvcType;
	}

	public DetectedFaceMessage setSrvcType(String srvcType) {
		this.srvcType = srvcType;
		return this;
	}

	public String getImgFile() {
		return imgFile;
	}

	public DetectedFaceMessage setImgFile(String imgFile) {
		this.imgFile = imgFile;
		return this;
	}

	public int getImgWidth() {
		return imgWidth;
	}

	public DetectedFaceMessage setImgWidth(int imgWidth) {
		this.imgWidth = imgWidth;
		return this;
	}

	public int getImgHeight() {
		return imgHeight;
	}

	public DetectedFaceMessage setImgHeight(int imgHeight) {
		this.imgHeight = imgHeight;
		return this;
	}

	public int getImgX() {
		return imgX;
	}

	public DetectedFaceMessage setImgX(int imgX) {
		this.imgX = imgX;
		return this;
	}

	public int getImgY() {
		return imgY;
	}

	public DetectedFaceMessage setImgY(int imgY) {
		this.imgY = imgY;
		return this;
	}

	public byte[] getFeature() {
		return feature;
	}

	public DetectedFaceMessage setFeature(byte[] feature) {
		this.feature = feature;
		return this;
	}

	public String getFrmFile() {
		return frmFile;
	}

	public DetectedFaceMessage setFrmFile(String frmFile) {
		this.frmFile = frmFile;
		return this;
	}

	public int getFrmWidth() {
		return frmWidth;
	}

	public DetectedFaceMessage setFrmWidth(int frmWidth) {
		this.frmWidth = frmWidth;
		return this;
	}

	public int getFrmHeight() {
		return frmHeight;
	}

	public DetectedFaceMessage setFrmHeight(int frmHeight) {
		this.frmHeight = frmHeight;
		return this;
	}

	public String getAbsoluteImagePath() {
		return absoluteImagePath;
	}

	public DetectedFaceMessage setAbsoluteImagePath(String absoluteImagePath) {
		this.absoluteImagePath = absoluteImagePath;
		return this;
	}

	public byte[] getFaceBinary() {
		return faceBinary;
	}

	public DetectedFaceMessage setFaceBinary(byte[] faceBinary) {
		this.faceBinary = faceBinary;
		return this;
	}

	public int getMaxMatchedFace() {
		return maxMatchedFace;
	}

	public DetectedFaceMessage setMaxMatchedFace(int maxMatchedFace) {
		this.maxMatchedFace = maxMatchedFace;
		return this;
	}

	public float getVerificationThreshold() {
		return verificationThreshold;
	}

	public DetectedFaceMessage setVerificationThreshold(float verificationThreshold) {
		this.verificationThreshold = verificationThreshold;
		return this;
	}

	public float getVerificationLowThreshold() {
		return verificationLowThreshold;
	}

	public DetectedFaceMessage setVerificationLowThreshold(float verificationLowThreshold) {
		this.verificationLowThreshold = verificationLowThreshold;
		return this;
	}
	
	public String getFrmTime() {
		return frmTime;
	}

	public DetectedFaceMessage setFrmTime(String frmTime) {
		this.frmTime = frmTime;
		return this;
	}
	
	public String getJobId() {
		return jobId;
	}

	public DetectedFaceMessage setJobId(String jobId) {
		this.jobId = jobId;
		return this;
	}

	public int getTotalDBMsgCount() {
		return totalDBMsgCount;
	}

	public DetectedFaceMessage setTotalDBMsgCount(int totalDBMsgCount) {
		this.totalDBMsgCount = totalDBMsgCount;
		return this;
	}

	public int getCurrentDBMsgCount() {
		return currentDBMsgCount;
	}

	public DetectedFaceMessage setCurrentDBMsgCount(int currentDBMsgCount) {
		this.currentDBMsgCount = currentDBMsgCount;
		return this;
	}

	@Override
	public String toString() {
		return "DetectedFaceMessage [id=" + id + ", systemId=" + systemId
				+ ", cctvId=" + cctvId + ", srvcType=" + srvcType
				+ ", imgFile=" + imgFile + ", imgWidth=" + imgWidth
				+ ", imgHeight=" + imgHeight + ", imgX=" + imgX + ", imgY="
				+ imgY + ", feature=" + Arrays.toString(feature) + ", frmFile="
				+ frmFile + ", frmWidth=" + frmWidth + ", frmHeight="
				+ frmHeight + ", absoluteImagePath=" + absoluteImagePath
				+ ", faceBinary=" + Arrays.toString(faceBinary)
				+ ", maxMatchedFace=" + maxMatchedFace
				+ ", verificationThreshold=" + verificationThreshold
				+ ", verificationLowThreshold=" + verificationLowThreshold
				+ ", frmTime=" + frmTime
				+ "]";
	}    
}
