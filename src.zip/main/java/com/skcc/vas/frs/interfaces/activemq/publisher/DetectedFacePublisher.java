package com.skcc.vas.frs.interfaces.activemq.publisher;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;

public class DetectedFacePublisher {
	
	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private JmsTemplate jmsTemplate = null;
	
	public void setJmsTemplate(JmsTemplate jmsTemplate) { this.jmsTemplate = jmsTemplate; }

	private Destination destination;

	public Destination getDestination() { return destination; }

	public void setDestination(Destination destination) { this.destination = destination; }
	
	public void init(){
		
		this.logger.info("+++++++++++++++++++++ This topic is {}, broker url is {}", destination, jmsTemplate.getConnectionFactory());
	}
	
	public void publish(final DetectedFaceMessage detectedFaceMessage){
		jmsTemplate.send(this.destination, new MessageCreator() {
			
			public Message createMessage(Session session) throws JMSException {
				ObjectMessage msg = session.createObjectMessage();
				msg.setObject(detectedFaceMessage);
				logger.debug("<== Send DetectMessage object : [{}]", msg.toString());
				
				return msg;
			}
			
		}
		);
	}	
}