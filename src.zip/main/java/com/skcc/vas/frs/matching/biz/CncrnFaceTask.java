package com.skcc.vas.frs.matching.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;

public class CncrnFaceTask implements Runnable {

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private String nodeId;
	
	private MatchingTaskManager matchingTaskManager;

	@Nonnull
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	@Nonnull
	private HbInnoAdapter hbInnoAdapter;

	protected HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	public CncrnFaceTask(FaceDataManager faceDataManager, HbInnoAdapter hbInnoAdapter, MatchingTaskManager matchingTaskManager, String nodeId) {
		this.faceDataManager = faceDataManager;
		this.hbInnoAdapter = hbInnoAdapter;
		this.matchingTaskManager = matchingTaskManager;
		this.nodeId = nodeId;
	}

	@Override
	public void run() {

		logger.debug("Running the CncrnFaceTask Thread.");
		updateTargetFeatures();

	}

	public void updateTargetFeatures() {

		try {

			Map<String, String> volumeInfo = this.getFaceDataManager().findConcernedFaceVolume(this.nodeId);

			if (ObjectUtils.isEmpty(volumeInfo)) {
				logger.info("Not Exist Volume Info of : {}", this.nodeId);
				
				this.matchingTaskManager.setActiveFlag(new AtomicBoolean(false));
				return;
			}

			final List<ConcernedFace> faces = this.getFaceDataManager().findValidScopeConcernedFaces(String.valueOf(volumeInfo.get("from_idx")),
					String.valueOf(volumeInfo.get("to_idx")));
			
			if (faces.size() == 0) {
				logger.info("Not Exist Concerned Face Info of  : {} (Concerned Face Size is 0)", this.nodeId);
				
				this.matchingTaskManager.setActiveFlag(new AtomicBoolean(false));
				return;
			}

			this.logger.info("[cncrn face update] For updating target features, Found {} concerned faces in VAS_CNCRN_FACE table.",
					faces.size());
			

			Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();

			/*
			 * HBInno Adapter에 concerned feature를 모두 추가한다 ConcernedFace.getId()
			 * = face Id
			 */
			for (ConcernedFace cf : faces) {
				featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
			}

			int count = getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
			if (faces.size() > count) {
				this.logger
						.warn("[cncrn face update] The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
								count);
			}
			this.logger.debug("[cncrn face update] Total {} concerned features added into Hbinno Adatper.", count);
			
			this.matchingTaskManager.setActiveFlag(new AtomicBoolean(true));
			this.matchingTaskManager.updateMatchingProcessFaceInfo(faces);

		} catch (Exception ex) {
			logger.error("[cncrn face update before creating task] excetption happens : {}", ex.toString());
		}

	}

}
