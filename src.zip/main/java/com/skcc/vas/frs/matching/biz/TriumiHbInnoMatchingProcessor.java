package com.skcc.vas.frs.matching.biz;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;
import javax.validation.constraints.Min;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.akka.service.DynamicNodeRoutingProcessor;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.nosql.domain.NDetectedFaceMatch;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.rdb.domain.DetectedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.db.service.FaceMatchJobService;
import com.skcc.vas.frs.common.util.base.TaskUseStatus;
import com.skcc.vas.frs.common.util.base.ThumbnailFormat;
import com.skcc.vas.frs.common.util.live.FaceUtils;
import com.skcc.vas.frs.common.util.live.HttpProcessor;
import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;
import com.skcc.vas.frs.live.db.rdb.service.FREngineConfig;
import com.skcnc.hbinno.HBFRfacePro;

public class TriumiHbInnoMatchingProcessor implements Runnable {

	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	public final int RECENT_SECONDS_DEFAULT = 3;
	
	private FREngineConfig frEngineConfig;

	private AtomicBoolean newCommandFlag = new AtomicBoolean(false);

	public AtomicBoolean getNewCommandFlag() {
		return newCommandFlag;
	}

	public void setNewCommandFlag(AtomicBoolean newCommandFlag) {
		this.newCommandFlag = newCommandFlag;
	}

	private String deviceId;

	private String threadId;

	private String vasDir;

	private DetectedFaceMessage detectedFaceMessage;
	
    DynamicNodeRoutingProcessor routingProcessor;

	private ConcurrentMap<String, TaskUseStatus> taskStatusMap = new ConcurrentHashMap<String, TaskUseStatus>();

	private List<ConcernedFace> faces = new ArrayList<ConcernedFace>();
	
	public void setFaces(List<ConcernedFace> faces) {
		this.faces = faces;
	}

	@Nonnull
	private HbInnoAdapter hbInnoAdapter;

	protected HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	@Nonnull
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	private final HttpProcessor httpProcessor;

	private VasConfigService configService;

	@Nonnull
	private MongoTemplateManager mongoTemplateManager;

	public MongoTemplateManager getMongoTemplateManager() {
		return mongoTemplateManager;
	}

	
	private int messageCount = 0;
	private long elapsedTime = 0;
	private long mongoDbTestTime = 0;
	private long hbinnoVerifyTime = 0;	

	/*
	 * 시스템 환경 변수로 부터 구한 VAS_DATA_DIR 값 =
	 * Watz_Eye_VAS/data/face/vmsid/deviceid/currentdate/filename.jpg
	 */
	private String thumbBase;
	private String liveThumbBase;
	private String concernFaceBase;
	private int maxMatchedFaces;
	private int fromLowMatchedface;

	private long numMatchedFace = 0;
	private long previousFrameTime = 0;

	public TriumiHbInnoMatchingProcessor(HttpProcessor httpProcessor, VasConfigService configService, HbInnoAdapter hbInnoAdapter,
			FaceDataManager faceDataManager, FREngineConfig frEngineConfig, ConcurrentMap<String, TaskUseStatus> taskStatusMap, String threadId,MongoTemplateManager mongoTemplateManager, List<ConcernedFace> faces) {
		this.httpProcessor = httpProcessor;
		this.configService = configService;
		this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.frEngineConfig = frEngineConfig;
		this.taskStatusMap = taskStatusMap;
		this.threadId = threadId;
		this.faces = faces;		

		this.mongoTemplateManager = mongoTemplateManager;

		this.vasDir = configService.getConfigValByName("vas.dataDir");
		this.httpPushEnabled = configService.getConfigValByName("vas.ccs.httpPush");
		this.imageBinaryYn = configService.getConfigValByName("vas.ccs.httpPush.imageBinary");
		this.imageFromFileYn = configService.getConfigValByName("vas.ccs.httpPush.imageFromFileYn");
		
		this.fromLowMatchedface = frEngineConfig.getHbInnoParam().getFromLowMatchedface();
		this.maxMatchedFaces = frEngineConfig.getHbInnoParam().getMaxMatchedFace();
		
	}

	private volatile ThumbnailFormat screenshotFormat;

	protected ThumbnailFormat getScreenshotFormat() {
		return this.screenshotFormat;
	}

	@Min(0)
	private int recentSeconds = RECENT_SECONDS_DEFAULT;

	@ManagedAttribute
	public int getRecentSeconds() {
		return this.recentSeconds;
	}

	public void setRecentSeconds(@Min(0) int num) {
		Validate.isTrue(num > 1, "The value should be positive.");
		this.recentSeconds = num;
	}

	private String httpPushEnabled;
	private String imageBinaryYn;
	private String imageFromFileYn;

	public boolean getHttpPushStatus() {
		return httpPushEnabled.equalsIgnoreCase("y");
	}

	public boolean getHttpPushImageBinaryStatus() {
		return imageBinaryYn.equalsIgnoreCase("y");
	}

	public boolean getHttpPushImageFromFileYn() {
		return imageFromFileYn.equalsIgnoreCase("y");
	}
	
	@Override
	public final void run() {

		/*
		 * 업무 순서-(1): HBInno engine 초기화
		 */
		
		
		// 1. HB Inno engine 생성
		if (HBFRfacePro.HBFRCreate(0) != 0) {
			logger.error("[matching process] HBFRCreate failure");
			throw new RuntimeException("[face:" + deviceId + "] Fail to HBFRCreate()");
		}

		// 2. license 설정
		int ret = HBFRfacePro.HBFRSetLicense(configService.getConfigValByName("vas.licenseKey"));
		if (ret < 0) {
			logger.error("[update process: {}] HBFRfacePro.HBFRSetLicense() error, return value = [{}] ", deviceId, ret);
		}

		DetectedFace detectedFace = new DetectedFace();

		for (;;) {

			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				logger.error("InterruptedException : {} ", this.threadId);
			}
			
			if (newCommandFlag.get()) {

				logger.debug("Running thread id is {} ", this.threadId);

				previousFrameTime = System.currentTimeMillis();

				detectedFace = convertMsgToDetectedFace(detectedFaceMessage);

				try {
					findMatch(detectedFace, this.detectedFaceMessage.getMaxMatchedFace(),
							this.detectedFaceMessage.getVerificationThreshold(), this.detectedFaceMessage.getVerificationLowThreshold(),
							detectedFaceMessage.getFaceBinary());

				} catch (Exception e) {
					logger.error("Findmatch Exception - {}", e.getMessage());
				}

				messageCount++;
				elapsedTime += (System.currentTimeMillis() - previousFrameTime);
				
				//logger.debug("findMatch elapsed time : {}", System.currentTimeMillis() - previousFrameTime);
				
				logger.debug("Thread[{}] Avg. findMatch elapsed time : {}, Message Count : {} ", this.threadId, elapsedTime / messageCount, messageCount);
				
				// After a matching job. Change the status of thread to busy.
				taskStatusMap.put(this.threadId, TaskUseStatus.IDLE);
				newCommandFlag.set(false);
			} else {

			}
		}
	}

	public void startMatchingNodeJob(DetectedFaceMessage detectedFaceMessage) {

		// change the status of thread to busy.
		taskStatusMap.put(this.threadId, TaskUseStatus.BUSY);
		newCommandFlag.set(true);
		this.detectedFaceMessage = detectedFaceMessage;
	    //this.perProgress = (float)currentDBMsgCount / (float)totalDBMsgCount;
	}
	
	private DetectedFace convertMsgToDetectedFace(DetectedFaceMessage detectedFaceMessage) {
		DetectedFace detectedFace = new DetectedFace();
		detectedFace.setId(detectedFaceMessage.getId());
		detectedFace.setSystemId(detectedFaceMessage.getSystemId());
		detectedFace.setCctvId(detectedFaceMessage.getCctvId());
		detectedFace.setSrvcType(detectedFaceMessage.getSrvcType());
		detectedFace.setImgFile(detectedFaceMessage.getImgFile());
		detectedFace.setImgWidth(detectedFaceMessage.getImgWidth());
		detectedFace.setImgHeight(detectedFaceMessage.getImgHeight());
		detectedFace.setImgX(detectedFaceMessage.getImgX());
		detectedFace.setImgY(detectedFaceMessage.getImgY());
		detectedFace.setFeature(detectedFaceMessage.getFeature());
		detectedFace.setFrmFile(detectedFaceMessage.getFrmFile());
		detectedFace.setFrmWidth(detectedFaceMessage.getFrmWidth());
		detectedFace.setFrmHeight(detectedFaceMessage.getFrmHeight());
		detectedFace.setAbsoluteImagePath(detectedFaceMessage.getAbsoluteImagePath());
		detectedFace.setFrmTime(detectedFaceMessage.getFrmTime());

		return detectedFace;
	}

	private List<Pair<String, Integer>> findMatch(@Nonnull DetectedFace face, @Min(1) int limitCount, float threshold, float lowThreshold,
			byte[] faceBinary) throws Exception {
		
		logger.debug("findMatch() limitCount = {}, threshold = {}, low threshold = {}", limitCount, threshold, lowThreshold);
		this.deviceId = face.getCctvId();
		
		/*
		 * string = face Id integer = score
		 */
		List<Pair<String, Integer>> matches = new ArrayList<Pair<String, Integer>>(); // 리턴값....
		// FRS UI에 push를 보내기 위한 데이터 저장
		List<Pair<String, Integer>> matchesforPush = new ArrayList<Pair<String, Integer>>();
		// matching threshold를 넘는 데이터 중 top 2를 저장
		List<NDetectedFaceMatch> faceMatchs = new ArrayList<NDetectedFaceMatch>();
		// 그 이외의 데이터를 저장
		List<NDetectedFaceMatch> lowFaceMatchs = new ArrayList<NDetectedFaceMatch>();

		int thresholdInt = Math.round(threshold * (float) 100.0);

		// 작업순서
		// 0. insertLiveTargetFeatures(Map<String, byte[]> targetFeatures) 먼저
		// 실행해야 함.
		// 1. insertLiveTargetFeatures 통해서 타켓정보가 C 메모리에 저장되고, liveTmap에 인덱스와
		// getId 가 저장된다.
		// 2.targetFeatures 의 개수만큼 loop 돌면서 INDEX 와 STRING 에 해당하는 getId 정보를
		// liveTmap 에 복제한다.
		// 3.미리 입력된 targetFeatures 정보(多)와 1건 verify 비교
		// 4.targetFeatures의 키정보와 스코어 점수를 tmap 에 담는다.
		// 5.최종적으로 count 된 건수 만큼의 List 정보를 리턴한다.

		// 점수 판단 기준을 threshold에서 lowThreshold로 변경

		hbinnoVerifyTime = System.currentTimeMillis();		

		int count = HBFRfacePro.HBFRVerifyBatch(face.getFeature(), face.getFeature().length, limitCount, lowThreshold); // ex.
																														// limitCount
																														// 3
																														// 이면
																														// 3건만
		logger.debug("++ HB INNO Verify Time : {} ", System.currentTimeMillis() - hbinnoVerifyTime);


																														// 리턴.
		// float score = HBFRfacePro.HBFRVerify(face.getFeature(),
		// face.getFeature().length, face.getFeature(),
		// face.getFeature().length);

		Map<String, String> cncrnImgPath = new HashMap<String, String>();
		// 만약 limitCount 를 3건으로 설정했으면,
		// ex. indices[0]->12 , indices[1]->13, indices[1]->17
		if (count > 0) {
			int indices[] = HBFRfacePro.HBFRGetIndices();
			float scores[] = HBFRfacePro.HBFRGetScores();
			logger.debug("[face:{}] Verification Score Result: ", deviceId);

			for (int j = 0; j < count; j++) {
				int score = (int) Math.round(scores[j] * 100.0);
				// matches.add(Pair.of(getHbInnoAdapter().getLiveFaceIdMap().get(indices[j]),
				// score));
				matches.add(Pair.of(getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(), score));
				cncrnImgPath.put(getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(), getHbInnoAdapter()
						.getLiveFaceIdnPathMap().get(indices[j]).getRight());
				if (score >= thresholdInt)
					matchesforPush.add(Pair.of(getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft(), score));
				logger.debug("[face:{}] HBInno List index: {}, score: {} ", deviceId, indices[j], scores[j]);
				logger.debug("[face:{}] Face Id from liveFaceIdnPathMap : {}", deviceId,
						getHbInnoAdapter().getLiveFaceIdnPathMap().get(indices[j]).getLeft());
			}

			numMatchedFace += count;

		}

		mongoDbTestTime = System.currentTimeMillis();

		if (count != 0) {

			logger.debug("----------------------------------------------------");
			logger.debug("[face:{}] Find matched faces = {} from Concerned Features", deviceId, count);
			logger.debug("----------------------------------------------------");

			// MONGODB를 통한 저장
			logger.debug("[DetectionTask] Applying to Nosql: {}", face.getId());
			List<NDetectedFaceMatch> nDetectedFaceMatchs = getFaceDataManager().addNConcernedFaceMatches(face, matches, thresholdInt, this.getMongoTemplateManager());

			for (NDetectedFaceMatch nDetectedFaceMatch : nDetectedFaceMatchs) {
				if ((nDetectedFaceMatch.getScore() >= thresholdInt) && (faceMatchs.size() < fromLowMatchedface)) {
					faceMatchs.add(nDetectedFaceMatch);
				} else {
					lowFaceMatchs.add(nDetectedFaceMatch);
				}
			}
			// skyang 03-22 count는 기본적으로 lowthreshold를 기준으로 발생하기에
			// highthreshold보다 하지 않는 경우에는 LowMatchWithProfile와 detected face정보만을
			// 가지고FaceMatchWithProfile에 데이터를 입력해야한다.
			// 즉, 3가지 경우인 1. detected face만 있는 경우, 2.detectedface와 hight matched
			// face가 있는 경우 3.detectedface와 low matched face가 있는 경우

			if (faceMatchs.size() < 1) {
				// 3번case
				logger.debug("[face:{}] No matched faces from Concerned Features", deviceId);

				getFaceDataManager().addNConcernedFaceMatchWithProfile(face, null, this.getMongoTemplateManager(), this.faces);

			} else {
				// 2번case
				// VAS_DETECTED_FACE_N_MATCH_WITH_PROFILE_NOSQL에 입력
				getFaceDataManager().addNConcernedFaceMatchWithProfile(face, faceMatchs, this.getMongoTemplateManager(), this.faces);
				// VAS_DETECTED_FACE_N_LOW_MATCH_WITH_PROFILE_NOSQL에 입력
				getFaceDataManager().addNConcernedFaceLowMatchWithProfile(face, lowFaceMatchs, this.getMongoTemplateManager(), this.faces);
			}

		} else {
			// 1번case
			logger.debug("[face:{}] No matched faces from Concerned Features", deviceId);

			getFaceDataManager().addNConcernedFaceMatchWithProfile(face, null, mongoTemplateManager, this.faces);
		}

		logger.debug("++ Mongodb Insert Time : {} , faceMatchs Size : {}, lowFaceMatchs Size : {} ", System.currentTimeMillis() - mongoDbTestTime, faceMatchs.size(), lowFaceMatchs.size());

		/*
		 * CCS server에 detection or detection and matched data를 http request로
		 * 전송한다.
		 */
		if (getHttpPushStatus()) {
			makePushDataSet(face, matchesforPush, cncrnImgPath, faceBinary);
		}

		return matches;
	}
	
	private void makePushDataSet(DetectedFace dFace, List<Pair<String, Integer>> matches, Map<String, String> cncrnImgPath,
			byte[] faceBinary) throws IOException {

		File file = new File(dFace.getAbsoluteImagePath());
		if (!file.exists()) {
			logger.error("[face:{}] Thumbnail[{}] doesn't exist. So http push never go to ccs", deviceId, file.getAbsolutePath());
			return;
		} else {
			logger.debug("[face:{}] Thumbnail[{}] exists. so http push will go to ccs", deviceId, file.getAbsolutePath());
		}

		JSONObject jsonObj = new JSONObject();
		Pair<String, Integer> aMatch = null;

		jsonObj.put("bizProcessId", "frinfopushBizOperation");
		jsonObj.put("encryptCallYN", "N");

		FaceUtils.sortFaceMatches(matches, true);

		if (CollectionUtils.isNotEmpty(matches)) {
			for (int i = 0; i < 1; i++) {
				aMatch = matches.get(i);

				// GENERAL INFO
				jsonObj.put("SYSTEM_ID", String.valueOf(dFace.getSystemId()));
				jsonObj.put("CCTV_ID", String.valueOf(dFace.getCctvId()));
				jsonObj.put("SRVC_TYPE", String.valueOf(dFace.getSrvcType()));

				// DETECTED FACE INFO
				jsonObj.put("DETECTED_FACE_ID", String.valueOf(dFace.getId()));
				if (getHttpPushImageBinaryStatus()) {
					jsonObj.put("DETECTED_IMG_BINARY", String.valueOf(Base64ConverToString(faceBinary)));
					jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");
				} else {
					jsonObj.put("DETECTED_IMG_BINARY", "");
					jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
				}
				jsonObj.put("DECTECTED_FILE_PATH", String.valueOf(dFace.getImgFile()));

				// FRMFILE INFO
				jsonObj.put("FRM_FILE_PATH", String.valueOf(dFace.getFrmFile()));
				jsonObj.put("FRM_TIME", String.valueOf(dFace.getFrmTime()));

				// CONCERN PERSON INFO
				jsonObj.put("CNCRN_FACE_ID", String.valueOf(aMatch.getLeft()));
				if (getHttpPushImageBinaryStatus()) {
					// 1. use file i/o
					if (getHttpPushImageFromFileYn()) {
						String[] imgPathArr = cncrnImgPath.get(aMatch.getLeft()).split("/");
						String imgPath = new StringBuilder().append(getConcernImgBaseDir()).append(imgPathArr[1].toString()).append("\\")
								.append(imgPathArr[2].toString()).toString();
						jsonObj.put("CNCRN_IMG_BINARY", String.valueOf(Base64ConverToString(getImageByte(imgPath))));
					} else {
						// 2.use push image binary
						byte[] imgBinary = getFaceDataManager().findConcernedFaceImageBinaryByCncrnfaceId(aMatch.getLeft());
						jsonObj.put("CNCRN_IMG_BINARY", Base64ConverToString(imgBinary));
					}

					jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");

				} else {
					jsonObj.put("CNCRN_IMG_BINARY", "");
					jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
				}
				jsonObj.put("CNCRN_IMG_PATH", cncrnImgPath.get(aMatch.getLeft()));
				jsonObj.put("SCORE", String.valueOf(aMatch.getRight()));

				try {
					if (jsonObj.get("INCLUDE_IMG_BINARY_YN") != null)
						httpProcessor.pushData(jsonObj.toString());
				} catch (InterruptedException | ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {

			// GENERAL INFO
			jsonObj.put("SYSTEM_ID", String.valueOf(dFace.getSystemId()));
			jsonObj.put("CCTV_ID", String.valueOf(dFace.getCctvId()));
			jsonObj.put("SRVC_TYPE", String.valueOf(dFace.getSrvcType()));

			// DETECTED FACE INFO
			jsonObj.put("DETECTED_FACE_ID", String.valueOf(dFace.getId()));
			if (getHttpPushImageBinaryStatus()) {
				jsonObj.put("DETECTED_IMG_BINARY", String.valueOf(Base64ConverToString(faceBinary)));
				jsonObj.put("INCLUDE_IMG_BINARY_YN", "Y");
			} else {
				jsonObj.put("DETECTED_IMG_BINARY", "");
				jsonObj.put("INCLUDE_IMG_BINARY_YN", "N");
			}
			jsonObj.put("DECTECTED_FILE_PATH", String.valueOf(dFace.getImgFile()));

			// FRMFILE INFO
			jsonObj.put("FRM_FILE_PATH", String.valueOf(dFace.getFrmFile()));
			jsonObj.put("FRM_TIME", String.valueOf(dFace.getFrmTime()));

			// CONCERN PERSON INFO
			jsonObj.put("CNCRN_FACE_ID", "");
			jsonObj.put("CNCRN_IMG_BINARY", "");
			jsonObj.put("CNCRN_IMG_PATH", "");

			jsonObj.put("SCORE", "");

			try {
				httpProcessor.pushData(jsonObj.toString());
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private String Base64ConverToString(byte[] img) {
		String imgStr = Base64.encodeBase64String(img);

		return imgStr;

	}

	private byte[] getImageByte(String imageFilePath) {
		// open image
		Path path = Paths.get(imageFilePath);
		byte[] image = null;

		try {
			image = Files.readAllBytes(path);

			// image = imgPath.readAllBytes();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			return image;
		}
	}

	private String getConcernImgBaseDir() {

		if (StringUtils.isBlank(vasDir)) {
			throw new IllegalStateException("The environment variables VAS_DATA_DIR and VAS_HOME are not set properly.");
		}

		String concernFacebase = new StringBuilder().append(vasDir).toString();
		return concernFacebase;
	}

	@ManagedAttribute
	public void setScreenshotWidth(@Min(1) int width) {
		Validate.isTrue(width > 0, "Screenshot width should be positive.");
		this.screenshotFormat = new ThumbnailFormat(width, this.screenshotFormat.getHeight());
	}
}
