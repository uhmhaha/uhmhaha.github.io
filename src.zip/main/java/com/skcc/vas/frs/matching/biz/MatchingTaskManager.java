package com.skcc.vas.frs.matching.biz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.ObjectUtils;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.util.base.TaskUseStatus;
import com.skcc.vas.frs.common.util.live.HttpProcessor;
import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;
import com.skcc.vas.frs.live.db.rdb.service.FREngineConfig;

public class MatchingTaskManager {

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	public final int MATCHING_THREAD_DEFAULT = 20;

	private int matchingThreadsNum = MATCHING_THREAD_DEFAULT;

	private ConcurrentMap<String, TaskUseStatus> taskStatusMap = new ConcurrentHashMap<String, TaskUseStatus>();
	private ConcurrentMap<String, TriumiHbInnoMatchingProcessor> taskMap = new ConcurrentHashMap<String, TriumiHbInnoMatchingProcessor>();

	private List<ConcernedFace> faces = new ArrayList<ConcernedFace>();

	private String selfNodeId;

	private long previousFrameTime = 0;

	private final HttpProcessor httpProcessor;

	private FREngineConfig frEngineConfig;

	public FREngineConfig getFrEngineConfig() {
		return this.frEngineConfig;
	}

	private VasConfigService configService;

	private FRConfig frConfig;

	private AtomicBoolean activeFlag = new AtomicBoolean(true);

	public AtomicBoolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(AtomicBoolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	private ExecutorService execService;

	@Nonnull
	private HbInnoAdapter hbInnoAdapter;

	protected HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	@Nonnull
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	@Nonnull
	private MongoTemplateManager mongoTemplateManager;


	public MongoTemplateManager getMongoTemplateManager() {
		return mongoTemplateManager;
	}

	private int messageCount = 0;

	public MatchingTaskManager(HbInnoAdapter hbInnoAdapter, FaceDataManager faceDataManager, HttpProcessor httpProcessor,
			FREngineConfig frEngineConfig, VasConfigService configService, String nodeId, MongoTemplateManager mongoTemplateManager) {

		this.httpProcessor = httpProcessor;
		this.configService = configService;
		this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.frEngineConfig = frEngineConfig;
		this.selfNodeId = nodeId;
		this.mongoTemplateManager = mongoTemplateManager;

		// Update a Target Feature
		updateTargetFeaturesBeforeCreatingTask();

		this.execService = Executors.newCachedThreadPool();

		if (configService.getConfigValByName("vas.matchingNode.threadsNum") == null
				|| configService.getConfigValByName("vas.matchingNode.threadsNum").length() == 0) {
			this.logger.warn("Not exist in configService");
		} else {
			this.matchingThreadsNum = Integer.parseInt(configService.getConfigValByName("vas.matchingNode.threadsNum"));
		}
		this.logger.debug("Matching Thread Num : {}", this.matchingThreadsNum);

		for (int i = 0; i < matchingThreadsNum; i++) {
			this.taskStatusMap.put(String.valueOf(i), TaskUseStatus.IDLE);
			TriumiHbInnoMatchingProcessor matchingTask = new TriumiHbInnoMatchingProcessor(this.httpProcessor, this.configService,
					this.hbInnoAdapter, this.faceDataManager, this.frEngineConfig, this.taskStatusMap, String.valueOf(i), 
					this.mongoTemplateManager, this.faces);
			this.taskMap.put(String.valueOf(i), matchingTask);

			this.execService.submit(matchingTask);
		}

		// �젙�빐吏� 媛쒖닔�쓽 thread瑜� �깮�꽦 �썑, 異붽��쟻�씤 thread瑜� �깮�꽦�븯吏� �븡�뒗�떎.
		this.execService.shutdown();
	}

	public void sendMatchingNodeJob(DetectedFaceMessage detectedFaceMessage) {
		this.logger.info("Received a matching node job info. {}", detectedFaceMessage.getCctvId());

		messageCount++;
		this.logger.debug("sendMatchingNodeJob - messageCount : " + messageCount);

		Boolean flag = false;
		if(!activeFlag.get()){
			this.logger.info("Active flag is False, so deactive matching job");
			return;
		}	

		if (checkDetectdFaceMessage(detectedFaceMessage)) {
			for (;;) {
				// idle �긽�깭�쓽 thread瑜� 李얠쓣 �븣源뚯�
				// 李얠쑝硫� startMatchingNodeJob �븿�닔 �샇異�
				for (String key : this.taskStatusMap.keySet()) {
					if (this.taskStatusMap.get(key) == TaskUseStatus.IDLE) {
						this.logger.debug("Idle Thread ID : {} ", key);
						TriumiHbInnoMatchingProcessor task = this.taskMap.get(key);
						task.startMatchingNodeJob(detectedFaceMessage);
						flag = true;
						break;
					}
				}

				if (flag == true){
					break;
				}

				try {
					logger.debug("Await a Idle MatchingTask Thread");
					Thread.sleep(20);
				} catch (InterruptedException e) {
					logger.error("Sleep error.");
				}
			}
		} else {
			logger.debug("Invalid a DetectedFaceMessage");
		}
	}

	private boolean checkDetectdFaceMessage(DetectedFaceMessage detectedFaceMessage) {
		if (detectedFaceMessage.getFeature() == null) {
			logger.warn("Feature is null");
			return false;
		}

		return true;
	}

	public void updateMatchingProcessFaceInfo(List<ConcernedFace> faces) {

		// 媛� matching thread�쓽 愿��떖�씤臾� �젙蹂� update
		for (String key : this.taskStatusMap.keySet()) {
			TriumiHbInnoMatchingProcessor task = this.taskMap.get(key);
			task.setFaces(faces);
		}

		return;
	}

	public void updateTargetFeaturesBeforeCreatingTask() {

		try {
			previousFrameTime = System.currentTimeMillis();

			/*
			 * DB�뿉�꽌 �젙�빐吏� 援ш컙�쓽 concerned face data 瑜� 媛��졇�삩�떎
			 */
			Map<String, String> volumeInfo = this.getFaceDataManager().findConcernedFaceVolume(this.selfNodeId);

			if (ObjectUtils.isEmpty(volumeInfo)) {
				logger.info("Not Exist Volume Info of : {}", this.selfNodeId);
				activeFlag.set(false);
				return;
			}

			faces = this.getFaceDataManager().findValidScopeConcernedFaces(
					String.valueOf(volumeInfo.get("from_idx")), String.valueOf(volumeInfo.get("to_idx")));


			if (faces.size() == 0) {
				logger.info("Not Exist Concerned Face Info of  : {} (Concerned Face Size is 0)", this.selfNodeId);
				activeFlag.set(false);
				return;
			}

			this.logger.info("[cncrn face update before creating task] For updating target features, Found {} concerned faces in VAS_CNCRN_FACE table.",
					faces.size());

			// Map<String, byte[]> features = new HashMap<String, byte[]>();
			Map<String, Pair<byte[], String>> featureNpath = new HashMap<String, Pair<byte[], String>>();

			/*
			 * HBInno Adapter�뿉 concerned feature瑜� 紐⑤몢 異붽��븳�떎 ConcernedFace.getId()
			 * = face Id
			 */
			for (ConcernedFace cf : faces) {
				featureNpath.put(cf.getId(), Pair.of(cf.getFeature(), cf.getImgPath()));
			}

			int count = getHbInnoAdapter().insertLiveTargetFeaturesNpath(featureNpath);
			if (faces.size() > count) {
				this.logger
				.warn("[cncrn face update before creating task] The concerned faces are {} from VAS_CNCRN_FACE table, but Only {} features can be added in Hbinno Adapter",
						count);
			}
			this.logger.debug("[cncrn face update before creating task] Total {} concerned features added into Hbinno Adatper.", count);
			this.logger.debug("[cncrn face update before creating task] Elapsed Time : {}", System.currentTimeMillis() - previousFrameTime);

		} catch (Exception ex) {
			logger.error("[cncrn face update before creating task] excetption happens : {}", ex.toString());
		}

	}

	public void setNodeId(int nodeId) {
		this.selfNodeId = String.valueOf(nodeId);
	}

	public void destory() {

		if (!(this.execService.isShutdown())) {
			this.execService.shutdown();
		}

		// for(Map.Entry<String, DetectionTask> entry :
		// this.getDetectionTasks().entrySet()){
		// try{
		// this.logger.debug("Destory DetectionTask with CCTV {} ",
		// entry.getKey());
		// entry.getValue().destroyDetectionTask();
		// }catch(Throwable t){
		// this.logger.error("Fail to destroy DetectionTask with CCTV {} during desctruction of detection processor.",
		// entry.getKey(), t);
		// }
		// }
	}
}
