package com.skcc.vas.frs.matching.biz;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.skcc.vas.frs.common.util.base.SpringApplicationContext;
import com.skcc.vas.frs.common.util.base.TaskUseStatus;
import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;

public class MongoJobProcessor implements Runnable {
	
	private MongoTemplate mongoTemplate;
	
	private Object dbInputData; 
	
	private String collectionName;
	
	private long mongoDbTestTime = 0;
	
	private String threadId;
	
	private final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private ConcurrentMap<String, TaskUseStatus> taskStatusMap = new ConcurrentHashMap<String, TaskUseStatus>();
	
	public MongoJobProcessor(ConcurrentMap<String, TaskUseStatus> taskStatusMap, String threadId) {
		mongoTemplate = (MongoTemplate) SpringApplicationContext.getBean("mongoTemplate");
		
		this.taskStatusMap = taskStatusMap;
		this.threadId = threadId;
	}
	
	private AtomicBoolean newCommandFlag = new AtomicBoolean(false);

	public AtomicBoolean getNewCommandFlag() {
		return newCommandFlag;
	}

	public void setNewCommandFlag(AtomicBoolean newCommandFlag) {
		this.newCommandFlag = newCommandFlag;
	}

	@Override
	public void run(){
		
		for(;;){
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e1) {
				logger.error("InterruptedException : {} ", this.threadId);
			}
			
			if (newCommandFlag.get()) {
				
				//mongoDbTestTime = System.currentTimeMillis();
				
				mongoTemplate.insert(this.dbInputData, this.collectionName);
				taskStatusMap.put(this.threadId, TaskUseStatus.IDLE);
				newCommandFlag.set(false);
			}
			
			
		}
		 
	
	}
	
	public void startMongoDBJob(Object dbInputData, String collectionName) {

		this.logger.debug("Call startMongoDBJob ...");
		// change the status of thread to busy.
		taskStatusMap.put(this.threadId, TaskUseStatus.BUSY);
		newCommandFlag.set(true);
		this.dbInputData = dbInputData;
		this.collectionName = collectionName;
	}
	
}
