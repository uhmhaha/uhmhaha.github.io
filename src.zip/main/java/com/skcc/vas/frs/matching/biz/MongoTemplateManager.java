package com.skcc.vas.frs.matching.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.ObjectUtils;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.rdb.domain.ConcernedFace;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.common.util.base.TaskUseStatus;
import com.skcc.vas.frs.common.util.live.HttpProcessor;
import com.skcc.vas.frs.interfaces.activemq.model.DetectedFaceMessage;
import com.skcc.vas.frs.live.db.rdb.domain.FRConfig;
import com.skcc.vas.frs.live.db.rdb.service.FREngineConfig;

public class MongoTemplateManager {

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	public final int MONGOTEMPLATE_THREAD_DEFAULT = 60;

	private int mongoTemplateThreadNum = MONGOTEMPLATE_THREAD_DEFAULT;

	private ConcurrentMap<String, TaskUseStatus> taskStatusMap = new ConcurrentHashMap<String, TaskUseStatus>();
	private ConcurrentMap<String, MongoJobProcessor> taskMap = new ConcurrentHashMap<String, MongoJobProcessor>();

	private ExecutorService execService;

	public MongoTemplateManager() {

		this.execService = Executors.newCachedThreadPool();

		// mongo template 개수 정의 필요
		for (int i = 0; i < (mongoTemplateThreadNum); i++) {
			this.taskStatusMap.put(String.valueOf(i), TaskUseStatus.IDLE);
			MongoJobProcessor mTemplateThread = new MongoJobProcessor(this.taskStatusMap, String.valueOf(i));
			this.taskMap.put(String.valueOf(i), mTemplateThread);
			
			this.execService.submit(mTemplateThread);
		}
		
		// 정해진 개수의 thread를 생성 후, 추가적인 thread를 생성하지 않는다.
		this.execService.shutdown();
	}

	public void sendMongoDBJob(Object dbInputData, String collectionName) {
		
		Boolean flag = false;
		
		for (;;) {
			// idle 상태의 thread를 찾을 때까지
			// 찾으면 startMongoDBJob 함수 호출
			for (String key : this.taskStatusMap.keySet()) {
				if (this.taskStatusMap.get(key) == TaskUseStatus.IDLE) {
					this.logger.debug("Mongo Template Idle Thread ID : {} ", key);
					MongoJobProcessor task = this.taskMap.get(key);
					task.startMongoDBJob(dbInputData, collectionName);
					flag = true;
					break;
				}
			}

			if (flag == true){
				break;
			}

			try {
				Thread.sleep(20);
				logger.debug("Await a Idle Mongo Template Thread");
			} catch (InterruptedException e) {
				logger.error("Sleep error.");
			}
		}
		
	}

	public void destory() {

		if (!(this.execService.isShutdown())) {
			this.execService.shutdown();
		}
	}
}
