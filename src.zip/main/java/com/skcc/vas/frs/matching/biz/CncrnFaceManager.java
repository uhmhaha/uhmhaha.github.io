package com.skcc.vas.frs.matching.biz;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Nonnull;

import org.slf4j.LoggerFactory;

import com.skcc.vas.adapter.fr.hbinno.HbInnoAdapter;
import com.skcc.vas.frs.common.biz.service.VasConfigService;
import com.skcc.vas.frs.common.db.service.FaceDataManager;
import com.skcc.vas.frs.interfaces.activemq.model.ConcernedFaceUpdateMessage;
import com.skcc.vas.frs.live.db.rdb.service.FREngineConfig;

public class CncrnFaceManager {

	protected final org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass());

	private FREngineConfig frEngineConfig;
	
	public FREngineConfig getFrEngineConfig() {
		return this.frEngineConfig;
	}

	@Nonnull
	private HbInnoAdapter hbInnoAdapter;

	protected HbInnoAdapter getHbInnoAdapter() {
		return this.hbInnoAdapter;
	}

	private VasConfigService configService;
	
	private MatchingTaskManager matchingTaskManager;


	@Nonnull
	private FaceDataManager faceDataManager;

	protected FaceDataManager getFaceDataManager() {
		return this.faceDataManager;
	}

	public CncrnFaceManager(HbInnoAdapter hbInnoAdapter, FaceDataManager faceDataManager, FREngineConfig frEngineConfig,
			VasConfigService vasConfigService, MatchingTaskManager matchingTaskManager) {

		this.hbInnoAdapter = hbInnoAdapter;
		this.faceDataManager = faceDataManager;
		this.frEngineConfig = frEngineConfig;
		this.configService = vasConfigService;		
		this.matchingTaskManager = matchingTaskManager;
	}

	public void updateCncrnFace(ConcernedFaceUpdateMessage concernedFaceUpdateMessage, int nodeId) {

		if(concernedFaceUpdateMessage != null) {
			this.logger.info("Update Concrned Face Info. {}", concernedFaceUpdateMessage.toString());
		}

		CncrnFaceTask cncrnFaceTask = new CncrnFaceTask(this.faceDataManager, this.hbInnoAdapter, this.matchingTaskManager, String.valueOf(nodeId));
		Thread t = new Thread(cncrnFaceTask);
		t.setDaemon(true);
		t.start();
		

	}

	public void destory() {
	
	}
}
